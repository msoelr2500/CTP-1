#ifndef __KDENCODE_H__
#define __KDENCODE_H__

/*************************************
Version : 1.0.0.3
*************************************/

#define KDCOMPLEX_ENCODE 6

#ifdef __cplusplus
extern "C" {
#endif

/*************************************
int nEncode_Level          ??????? = KDCOMPLEX_ENCODE
unsigned char *pSrcData    ???????????
int nSrcDataLen            ??????????????
unsigned char *pDestData   ?????????
int nDestDataBufLen        ????????????��
void *pKey                 ???
int nKeyLen                ????????

?????                     ????????????
?:
??????? = KDCOMPLEX_ENCODE ?
????????????��           nDestDataBufLen = 2*nSrcDataLen(???????????)????nDestDataBufLen>= 32
?????????0x00??��ASCII?????
*************************************/
int KDEncode(int nEncode_Level,
                          unsigned char *pSrcData, int nSrcDataLen,
                          unsigned char *pDestData, int nDestDataBufLen,
                          void *pKey, int nKeyLen);


/*************************************
*************************************/
int KDReEncode( unsigned char *pSrcData, int nSrcDataLen,
                          unsigned char *pDestData, int nDestDataBufLen,
                          int nOldEncode_Level, void *pOldKey, int nOldKeyLen,
                          int nNewEncode_Level, void *pNewKey, int nNewKeyLen );

int KD2HsReEncode( unsigned char *pSrcData, int nSrcDataLen,
                                  unsigned char *pDestData, int nDestDataBufLen,
                                  int nOldEncode_Level, void *pOldKey, int nOldKeyLen);

int KD2HsReEncodeExt( unsigned char *pSrcData, int nSrcDataLen,
                                  unsigned char *pDestData, int nDestDataBufLen,
                                  int nOldEncode_Level, void *pOldKey, int nOldKeyLen, void *pHsKey = NULL);

#ifdef __cplusplus
}
#endif

#endif
