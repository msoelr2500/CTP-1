//
// Created by lwk on 16-5-17.
//

#include "ReadConfig.h"

namespace ogs {

    LocalOption ReadConfig::localOption;

    ogs::ReadConfig::ReadConfig() {

    }

    bool ReadConfig::Reading(int argc, char *argv[]) {
        if (argc > 1) {
            if (argc == 2 && argv[1][0] != '/' && argv[1][0] != '-') {
                m_FilePath = argv[1];
                std::cout << m_FilePath << "\n";
            }
            else if (argc == 3 && argv[1][1] == 'o') {
                CreateDefaultConfig(argv[2]);
                exit(0);
            }
            else {
                std::cout << "error argument!" << std::endl;
                exit(0);
            }
        }
        else {
            m_FilePath = "ogs.ini";
        }

        char chTmp[512];
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "LocalAddr", chTmp, 512, "127.0.0.1", m_FilePath.c_str());
        localOption.LocalAddr.append(chTmp);

        localOption.LocalPort = read_ini_config_int(SECTION, "LocalPort", 4800, m_FilePath.c_str());
        localOption.TradeStart = read_ini_config_int(SECTION, "TradeStart", 83000, m_FilePath.c_str());
        localOption.TradeEnd = read_ini_config_int(SECTION, "TradeEnd", 153000, m_FilePath.c_str());
        localOption.RequestEnd = read_ini_config_int(SECTION, "RequestEnd", 153000, m_FilePath.c_str());
        localOption.TaskThreadCnt = read_ini_config_int(SECTION, "TaskThreadCnt", 1, m_FilePath.c_str());
        localOption.ReqThreadCnt = read_ini_config_int(SECTION, "ReqThreadCnt", 1, m_FilePath.c_str());
        localOption.RequestGap = read_ini_config_int(SECTION, "RequestGap", 3000, m_FilePath.c_str());
        localOption.HeartBeatGap = read_ini_config_int(SECTION, "HeartBeatGap", 60000, m_FilePath.c_str());
        localOption.HoldSessionGap = read_ini_config_int(SECTION, "HoldSessionGap", 1800, m_FilePath.c_str());
        localOption.unAckedOrderQryCnt = read_ini_config_int(SECTION, "UnAckedOrderQryCnt", 10, m_FilePath.c_str());

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "ClientIp", chTmp, 512, "192.168.1.100", m_FilePath.c_str());
        localOption.ClientIp.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "ClientMac", chTmp, 512, "14CF920391DD", m_FilePath.c_str());
        localOption.ClientMac.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "ClientDiskSn", chTmp, 512, "WD22HPJT0", m_FilePath.c_str());
        localOption.ClientDiskSn.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "SiteInfoFormat", chTmp, 512, "", m_FilePath.c_str());
        localOption.SiteInfoFormat.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "BrokerAddr", chTmp, 512, "", m_FilePath.c_str());
        localOption.BrokerAddr.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "BrokerPort", chTmp, 512, "", m_FilePath.c_str());
        localOption.BrokerPort.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "LicensePath", chTmp, 512, "", m_FilePath.c_str());
        localOption.LicensePath.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "BranchNo", chTmp, 512, "", m_FilePath.c_str());
        localOption.BranchNo.append(chTmp);

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "EntrustMode", chTmp, 512, "", m_FilePath.c_str());
        localOption.EntrustMode.append(chTmp);
        //std::string EntrustMode;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Currency", chTmp, 512, "", m_FilePath.c_str());
        localOption.Currency.append(chTmp);
        //std::string Currency;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "PwdType", chTmp, 512, "", m_FilePath.c_str());
        localOption.PwdType.append(chTmp);
        //std::string PwdType;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "BrokerType", chTmp, 512, "", m_FilePath.c_str());
        localOption.BrokerType.append(chTmp);
        //std::string BrokerType;
        memset(chTmp, 0, 512);
		read_ini_config_string(SECTION, "LibPath", chTmp, 512, "", m_FilePath.c_str());
        localOption.LibPath.append(chTmp);
        //std::string LibPath;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "LogDir", chTmp, 512, "ogslog", m_FilePath.c_str());
        localOption.LogDir.append(chTmp);
        //std::string LogDir;
        localOption.LogLevel = read_ini_config_int(SECTION, "LogLevel", 2, m_FilePath.c_str());
        //uint32_t LogLevel;
        localOption.LogVerbose = read_ini_config_int(SECTION, "LogVerbose", 100, m_FilePath.c_str());
        //uint32_t LogVerbose;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve1", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve1.append(chTmp);
        //std::string Reserve1;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve2", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve2.append(chTmp);
        //std::string Reserve2;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve3", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve3.append(chTmp);
        //std::string Reserve3;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve4", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve4.append(chTmp);
        //std::string Reserve4;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve5", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve5.append(chTmp);
        //std::string Reserve5;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve6", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve6.append(chTmp);
        //std::string Reserve6;
        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve7", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve7.append(chTmp);
        //std::string Reserve7;

        localOption.Reserve8 = read_ini_config_int(SECTION, "Reserve8", 0, m_FilePath.c_str());

        memset(chTmp, 0, 512);
        read_ini_config_string(SECTION, "Reserve9", chTmp, 512, "", m_FilePath.c_str());
        localOption.Reserve9.append(chTmp);

        //uint32_t Reserve8;


        return false;
    }

    void ReadConfig::CreateDefaultConfig(char *filename) {
        write_ini_config_string(SECTION,"LocalAddr","127.0.0.1",filename);
        write_ini_config_string(SECTION,"LocalPort","4800",filename);
        write_ini_config_string(SECTION,"TradeStart","85959",filename);
        write_ini_config_string(SECTION,"TradeEnd","152959",filename);
        write_ini_config_string(SECTION,"RequestEnd","152959",filename);
        write_ini_config_string(SECTION,"TaskThreadCnt","1",filename);
        write_ini_config_string(SECTION,"ReqThreadCnt","1",filename);
        write_ini_config_string(SECTION,"RequestGap","2000",filename);
        write_ini_config_string(SECTION,"HeartBeatGap","60000",filename);
        write_ini_config_string(SECTION,"HoldSessionGap","1800",filename);
        write_ini_config_string(SECTION,"UnAckedOrderQryCnt","10",filename);
        write_ini_config_string(SECTION,"ClientIp","192.168.1.100",filename);
        write_ini_config_string(SECTION,"ClientMac","14CF920391DD",filename);
        write_ini_config_string(SECTION,"ClientDiskSn","WD22HPJT0",filename);
        write_ini_config_string(SECTION,"SiteInfoFormat","",filename);
        write_ini_config_string(SECTION,"BrokerAddr","",filename);
        write_ini_config_string(SECTION,"BrokerPort","",filename);
        write_ini_config_string(SECTION,"LicensePath","",filename);
        write_ini_config_string(SECTION,"BranchNo","",filename);
        write_ini_config_string(SECTION,"EntrustMode","",filename);
        write_ini_config_string(SECTION,"Currency","",filename);
        write_ini_config_string(SECTION,"PwdType","",filename);
        write_ini_config_string(SECTION,"BrokerType","AI",filename);
		write_ini_config_string(SECTION,"LibPath","./lib.so",filename);
        write_ini_config_string(SECTION,"LogDir","ogslog",filename);
        write_ini_config_string(SECTION,"LogLevel","2",filename);
        write_ini_config_string(SECTION,"LogVerbose","100",filename);
        write_ini_config_string(SECTION,"Reserve1","",filename);
        write_ini_config_string(SECTION,"Reserve2","",filename);
        write_ini_config_string(SECTION,"Reserve3","",filename);
        write_ini_config_string(SECTION,"Reserve4","",filename);
        write_ini_config_string(SECTION,"Reserve5","",filename);
        write_ini_config_string(SECTION,"Reserve6","",filename);
        write_ini_config_string(SECTION,"Reserve7","",filename);
        write_ini_config_string(SECTION,"Reserve8","",filename);
        write_ini_config_string(SECTION,"Reserve9","",filename);
    }

}

