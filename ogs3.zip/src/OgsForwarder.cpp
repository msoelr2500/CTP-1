///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "OgsForwarder.h"
#include "OgsLogger.h"
#include "OgsMessage.h"

int OgsForwarder::SendMessage(uint32_t stage_id, qtp::QtpMessagePtr msg)
{
    int result = qtp::QtpQueueMgr::Instance().SendMessage(stage_id, msg);
    if (result < 0) {
        ogsError << "[OgsForwarder] [SendMessage] error: failed to send message: " << stage_id << " is disconnected.";
    } else {
        ogsTrace << "[OgsForwarder] [SendMessage] send message to " << stage_id;
#if defined(OGS_LOG_FORWARDER_MESSAGE)
        OgsMessage ogsMessage(msg);
        ogsLogger() << ogsMessage;
#endif
    }

    return result;
}

int OgsForwarder::ReplyClient(qtp::session_id_t session_id, qtp::QtpMessagePtr message)
{
    int result = qtp::QtpSessionMgr::Instance().SendMessage(session_id, message);

    if (result >= 0) {
#if defined(OGS_LOG_REPLY_CLIENT_MESSAGE)
        OgsMessage ogsMessage(message);
        ogsLogger() << ogsMessage;
#endif
        std::cout << "reply client(" << session_id << "): " << OgsLogger::msgType(ogsMessage.type()) << std::endl;
    } else {
        ogsError << "[OgsForwarder] [ReplyClient] failed to reply client( " << session_id << "), which may not be connected.";
    }

    return result;
}
