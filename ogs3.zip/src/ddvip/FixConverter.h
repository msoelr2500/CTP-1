///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef FIXCONVERTER_H
#define FIXCONVERTER_H

#include <string>

#include "../ogs_dict.h"
#include "../DataStruct.h"
#include "../universal_code.h"

/*! \brief 撤销标识。*/
enum FID_CXBZ_ENUM {
    WITHDRAW_RECORD,    //!< 撤单记录
    ENTRUST_RECORD      //!< 委托记录
};

class FixConverter
{
public:
    static std::string FID_ZQDM_STR(std::string& code);
    static std::string FID_KHH_STR(const char* acidcard);
    static std::string FID_ZJZH_STR(const char* bacid);
    static std::string FID_WTJG_STR(ogs::OGS_PRICE price);
    static std::string FID_WTSL_STR(ogs::OGS_VOLUME volume);
    static std::string FID_JYMM_STR(const char* password);
    static std::string FID_WTH_STR(const char* sysOrderId);
    static std::string FID_FLAG_STR();
    static std::string FID_ROWCOUNT_STR();

    static void CONV_FID_WTH(const std::string& FID_WTH_STR, char* sysOrderId);
    #define CONV_FID_WTPCH CONV_FID_WTH
    static void CONV_STRING(const std::string& source, char* target);
    #define CONV_FID_KHH CONV_STRING
    #define CONV_FID_ZJZH CONV_STRING

    //! \brief 价格。
    static void CONV_FID_PRICE(const std::string& FID_PRICE_STR, ogs::OGS_PRICE& price);

    #define CONV_FID_WTJG CONV_FID_PRICE
    #define CONV_FID_CJJG CONV_FID_PRICE

    //! \brief 证券数目。
    static void CONV_FID_VOL(const std::string& FID_VOL_STR, ogs::OGS_VOLUME& volume);

    #define CONV_FID_WTSL CONV_FID_VOL
    #define CONV_FID_CJSL CONV_FID_VOL
    #define CONV_FID_CDSL CONV_FID_VOL
    #define CONV_FID_ZQSL CONV_FID_VOL
    #define CONV_FID_KMCSL CONV_FID_VOL
    #define CONV_FID_ZCJSL CONV_FID_VOL

    //! \brief 金额。
    static void CONV_FID_AMOUNT(const std::string& FID_AMOUNT_STR, ogs::OGS_BALANCE& balance);

    #define CONV_FID_CJJE CONV_FID_AMOUNT
    #define CONV_FID_ZHYE CONV_FID_AMOUNT
    #define CONV_FID_DJJE CONV_FID_AMOUNT
    #define CONV_FID_T2DJJE CONV_FID_AMOUNT
    #define CONV_FID_ZZC CONV_FID_AMOUNT
    #define CONV_FID_ZQSZ CONV_FID_AMOUNT
    #define CONV_FID_KYZJ CONV_FID_AMOUNT
    #define CONV_FID_ZCJJE CONV_FID_AMOUNT

    static void CONV_FID_HBXH(const std::string& FID_HBXH_STR, char* dealId);
    static void CONV_FID_SBJG(const std::string& FID_SBJG_STR, ogs::OGS_ORDERSTATUS& orderStatus);
    static void CONV_FID_WTLB(const std::string& FID_WTLB_STR, ogs::OGS_DIRECTIVE& directive);
    static void CONV_FID_WTRQ(const std::string& FID_WTRQ_STR, ogs::OGS_TRADEDATE& tradeDate);
    static void CONV_FID_WTSJ(const std::string& FID_WTSJ_STR, ogs::OGS_ORDERTIME& orderTime);
    static void CONV_FID_ZQDM(const std::string& FID_ZQDM_STR, ogs::OGS_INNERCODE& innerCode);

    static std::string FID_DDLX_STR(ogs::OGS_EXECUTION type);
    static ogs::ogs_dict::ExecutionType ogsExecutionType(const std::string& FID_DDLX_STR);

    static std::string FID_SBJG_STR(ogs::OGS_ORDERSTATUS type);
    static ogs::ogs_dict::OrderStatusType ogsOrderStatusType(const std::string& FID_SBJG_STR);

    static std::string FID_JYS_STR(qtp::MarketCode type);
    static void CONV_FID_JYS(const std::string& FID_JYS_STR, qtp::MarketCode& code);

    static std::string FID_WTLB_STR(ogs::OGS_DIRECTIVE type);
    static ogs::ogs_dict::DirectiveType ogsDirectiveType(const std::string& FID_WTLB_STR);

    static std::string FID_CXBZ_STR(FID_CXBZ_ENUM type);
};

#endif
