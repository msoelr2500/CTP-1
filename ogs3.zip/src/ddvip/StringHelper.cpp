///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "StringHelper.h"

using std::string;

void StringHelper::split(const std::string &src, const std::string &separator, std::vector<std::string> &result){
    string::size_type index = 0;
    string::size_type nextTokenStart = 0;

    while ((nextTokenStart = src.find_first_not_of(separator, index)) != string::npos){
        index = src.find_first_of(separator, nextTokenStart);
        if (index == string::npos){
            result.push_back(src.substr(nextTokenStart));
            break;
        }
        else{
            result.push_back(src.substr(nextTokenStart, index - nextTokenStart));
        }
    }
}

bool StringHelper::endsWith(const std::string &src, const std::string &suffix){
    if (src.length() < suffix.length())
        return false;
    string srcEnds = src.substr(src.length() - suffix.length(), suffix.length());
    return srcEnds == suffix;
}

bool StringHelper::startsWith(const std::string &src, const std::string &suffix){
    if (src.length() < suffix.length())
        return false;
    string srcEnds = src.substr(0, suffix.length());
    return srcEnds == suffix;
}
