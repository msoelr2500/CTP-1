///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "DdInterface.h"

using namespace std;

namespace ogs {

DdInterface::DdInterface()
{
    LOG(info) << "[ddvip] 创建了一个DDVIP接口对象";
}

DdInterface::~DdInterface()
{

}

bool DdInterface::getConnectStatus()
{
    return ddImpl.isConnected();
}

Intf_RetType DdInterface::initCommon()
{
    static int counter = 1;

    if(ddImpl.initialize()){
        LOG(info) << "[ddvip] 初始化[" << counter << "]:成功";
        counter++;
        return kIntfSuccess;
    }
    LOG(info) << "[ddvip] 初始化失败";
    return kIntfFail;
}

Intf_RetType DdInterface::initSubscribe()
{
    LOG(info) << "[ddvip] 初始化订阅功能";
    return kIntfFail;
}

Intf_RetType DdInterface::connectBroker()
{
    if(ddImpl.connect()){
        LOG(info) << "[ddvip] 已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType DdInterface::reConnectBroker()
{
    if(ddImpl.isConnected()){
        ddImpl.disconnect();
    }
    return connectBroker();
}

Intf_RetType DdInterface::heartBeatToBroker()
{
    LOG(info) << "[ddvip] heartBeatToBroker";
    return ddImpl.heartBeatToBroker();
}

void DdInterface::setCallBack(int (*fn)(QueryOrderAns))
{
    ddImpl.setCallBack(fn);
}

Intf_RetType DdInterface::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsLogin(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsSendOrder(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsCancelOrder(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsQueryOrder(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsQueryPosition(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsQueryBargain(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsQueryFundInfo(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsPaybackSecurity(in, out, errMsg, args);
}

Intf_RetType DdInterface::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return ddImpl.ogsPaybackFunds(in, out, errMsg, args);
}

bool DdInterface::isFundAccountEnabled(const char* bacid)
{
    return ddImpl.isBacidEnabled(bacid);
}

}
