#ifndef FIXSUBMANAGER_H
#define FIXSUBMANAGER_H

#include <vector>
#include <string>
#include <functional>
#include <mutex>
#include <singleton.h>
#include "../DataStruct.h"

struct SecuBargainInfo {
    std::string FID_QRBZ_STR;           //!< 确认标志（0 确认成功--默认不发布成功消息，后台可控制是否发布该消息，1 确认失败）
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_CXBZ_STR;
    std::string FID_CJBH_STR;
    std::string FID_CJSJ_STR;
    std::string FID_WTSL_STR;           //!< 委托数量
    std::string FID_CDSL_STR;           //!< 撤单数量
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTLB_STR;           //!< 委托类别    
    std::string FID_QSZJ_STR;
    std::string FID_ZCJSL_STR;
    std::string FID_ZCJJE_STR;
    std::string FID_CJSL_STR;
    std::string FID_CJJG_STR;
    std::string FID_WTJG_STR;
    std::string FID_CJJE_STR;           //!<
    std::string FID_WTPCH_STR;          //!< 委托批次号
};
struct SecuEntrustAckInfo {
    std::string FID_QRBZ_STR;           //!< 确认标志（0 确认成功--默认不发布成功消息，后台可控制是否发布该消息，1 确认失败）
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_WTSL_STR;           //!< 委托数量
    std::string FID_CDSL_STR;           //!< 撤单数量
    std::string FID_CXBZ_STR;           //!< 撤销标志
    std::string FID_DJZJ_STR;           //!< 冻结资金（负数表示解冻）
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_SBJG_STR;           //!< 申报结果
    std::string FID_JGSM_STR;           //!< 结果说明
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_HZSJ_STR;           //!< 确认时间
};
struct SecuEntrustWithdrawAckInfo {
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_WTSL_STR;           //!< 委托数量
    std::string FID_CDSL_STR;           //!< 撤单数量（实际撤单数量）
    std::string FID_CJSL_STR;           //!< 成交数量（委托原来已成交数量）
    std::string FID_CXBZ_STR;           //!< 撤销标志
    std::string FID_DJZJ_STR;           //!< 冻结资金（负数表示解冻）
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_HZSJ_STR;           //!< 确认时间
};

template <typename SubInfoType>
struct SubCallbackItem {
    long subHandle = -1;
    void* subCallback = nullptr;
    void* subReserve = nullptr;
};

struct SubCallback {
    std::string FID_KHH_STR;
    std::string FID_JYMM_STR;
    SubCallbackItem<SecuBargainInfo> subSecuBargainInfo;
    SubCallbackItem<SecuEntrustAckInfo> subSecuEntrustAckInfo;
    SubCallbackItem<SecuEntrustWithdrawAckInfo> subSecuEntrustWithdrawAckInfo;
};

class FixApiWrapper;

class FixSubManager : public qtp::Singleton<FixSubManager>
{
public:
    virtual ~FixSubManager();

    bool containsClient(const std::string& FID_KHH_STR) const;

    // 检查指定节点是否在订阅管理器中。
    bool containsClient(SubCallback* item) const;

    SubCallback* getSubCallback(const std::string& FID_KHH_STR);

    std::vector<SubCallback*> subItems() const;

    void addSubItem(SubCallback* item);

#if 0
    SubCallback* addCallbackItem(const std::string& FID_KHH_STR, const SubCallbackItem<SecuBargainInfo>& item);
    SubCallback* addCallbackItem(const std::string& FID_KHH_STR, const SubCallbackItem<SecuEntrustAckInfo>& item);
    SubCallback* addCallbackItem(const std::string& FID_KHH_STR, const SubCallbackItem<SecuEntrustWithdrawAckInfo>& item);
#endif

    static bool unSubscibeByHandle(long nHandle);

    void invalidate();

protected:
    SubCallback* addSubItemLockless(SubCallback* item);
    bool containsClientLockless(const std::string &FID_KHH_STR) const;
    int indexOfClientLockless(const std::string& FID_KHH_STR) const;

private:
    mutable std::mutex mMutex;
    std::vector<SubCallback*> mSubItems;
};

#endif
