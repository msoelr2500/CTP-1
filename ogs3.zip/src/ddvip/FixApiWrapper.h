////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-28
////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef FIXAPIWRAPPER_H
#define FIXAPIWRAPPER_H

#include <string>
#include <list>
#include <functional>
#include <cassert>
#include <ddvip/fiddef.h>
#include <ddvip/FixApi_mdb.h>
#include <mutex>

#include "FixSubManager.h"
#include "FixReader.h"
#include "../Interface.h"   // For Intf_RetType

struct FixConfig {
    std::string mCounterType;           //!< 顶点柜台类型。
    std::string mCertFilePath;          //!< 信任证书文件路径。
    std::string mProtocol;              //!< 协议，SSLv3/TLSv1
    std::string mCertPwd;               //!< 客户端证书密码。
    std::string mCAFilePath;            //!< 信任证书文件（一般情况下为空，因为信任证书已经在客户端证书中）。
    std::string mServerAddr;            //!< 服务器地址。格式："[ip]@[port]/tcp"，例如："127.0.0.1@9901/tcp"。
    std::string mEntrustMode;           //!< 委托方式。
    std::string mSiteInfoFormat;        //!< 站点信息格式。
    std::string mSiteInfo;              //!< 站点信息，如ISON2。
    std::string mDefaultOperator;       //!< 默认操作员。
    std::string mRequestStation;        //!< 发生营业部。
    std::string mOpStation;             //!< 操作营业部。
    std::string mDefaultNodeIp;         //!< 默认节点IP，当生成节点信息时若IP为空则使用此项。\sa createNode()
    std::string mDefaultNodeMac;        //!< 默认节点MAC，当生成节点信息时若MAC为空则使用此项。\sa createNode()
    std::string mDefaultNodeDiskSn;     //!< 默认节点DiskSn，当生成节点信息时若DiskSn为空则使用此项。\sa createNode()
    int mTimeout = 30;                  //!< 请求的超时时间。
};
struct QrySystemTimeInput {
    std::string FID_FLAG_STR;           //!< 高精度返回标志
};
struct QrySystemTimeOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_DATE_STR;           //!< 当前日期
    std::string FID_TIME_STR;           //!< 当前时间
    std::string FID_WEEK_STR;           //!< 星期（FID_FLAG=1时返回）
    std::string FID_MILLISECOND_STR;    //!< 毫秒（FID_FLAG=1时返回）
};
struct HeartBeatOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
};
struct QryTradeNodeInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
};
struct QryTradeNodeOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_NODEID_STR;         //!< 交易节点编码
    std::string FID_NODENAME_STR;       //!< 交易节点名称
    std::string FID_ZT_STR;             //!< 交易节点状态（多值位与描述）
    std::string FID_DATE_STR;           //!< 当前交易日期
    std::string FID_RQ_STR;             //!< 系统当前日期
    std::string FID_TIME_STR;           //!< 系统当前时间
};
struct CheckTradePasswdInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号（客户号、股东号二者必须至少送入一个）
    std::string FID_GDH_STR;            //!< 股东号（客户号、股东号二者必须至少送入一个）
    std::string FID_JYS_STR;            //!< 交易所编码
};
struct CheckTradePasswdOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
};
struct ChangeTradePasswdInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_MM_STR;             //!< 密码
    std::string FID_NEWMM_STR;          //!< 新密码
};
struct ChangeTradePasswdOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
};
struct ChangeCapPasswdInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_MM_STR;             //!< 密码
    std::string FID_NEWMM_STR;          //!< 新密码
};
struct ChangeCapPasswdOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
};
struct TransferInFundInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_FSJE_STR;           //!< 发生金额
    std::string FID_ZY_STR;             //!< 摘要
};
struct TransferInFundOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_ZHYE_STR;           //!< 账户余额
    std::string FID_KYZJ_STR;           //!< 可用资金
    std::string FID_T2KYZJ_STR;         //!< T+2可用资金
};
struct TransferOutFundInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_FSJE_STR;           //!< 发生金额
    std::string FID_ZY_STR;             //!< 摘要
};
struct TransferOutFundOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_ZHYE_STR;           //!< 账户余额
    std::string FID_KYZJ_STR;           //!< 可用资金
    std::string FID_T2KYZJ_STR;         //!< T+2可用资金
};
struct TransferInSecuInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_FSSL_STR;           //!< 发生数量
    std::string FID_ZY_STR;             //!< 摘要
};
struct TransferInSecuOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_JCCL_STR;           //!< 今持仓量（当前余额）
    std::string FID_KMCSL_STR;          //!< 可卖出数量（可用数量）
};
struct TransferOutSecuInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_FSSL_STR;           //!< 发生数量
    std::string FID_ZY_STR;             //!< 摘要
};
struct TransferOutSecuOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_JCCL_STR;           //!< 今持仓量（当前余额）
    std::string FID_KMCSL_STR;          //!< 可卖出数量（可用数量）
};
struct SecuEntrustInput {
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_WTJG_STR;           //!< 委托价格
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_WTSL_STR;           //!< 委托数量
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_DDLX_STR;           //!< 订单类型
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_DFXW_STR;           //!< 对方席位号
};
struct SecuEntrustOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTPCH_STR;          //!< 委托批次号
};
struct BatchSecuEntrustInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_COUNT_STR;          //!< 委托笔数
    std::string FID_FJXX_STR;           //!< 委托详细信息
    std::string FID_LOGICAL_STR;        //!< 逻辑判断
    std::string FID_WTPCH_STR;          //!< 委托批次号
};
struct BatchSecuEntrustOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_EN_WTH_STR;         //!< 委托合同号
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_COUNT_STR;          //!< 委托成功笔数
    std::string FID_MEMCOUNT_STR;       //!< 委托总笔数
    std::string FID_ROWCOUNT_STR;       //!< 委托失败笔数
};
struct QryTradableVolInput {
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_DDLX_STR;           //!< 订单类型
    std::string FID_WTFS_STR;           //!< 委托方式
    std::string FID_WTJG_STR;           //!< 委托价格（限价订单必须送入）
};
struct QryTradableVolOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTSL_STR;           //!< 可委托数量
};
struct QryBuyableEtfSecuBacketCntInput {
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_WTFS_STR;           //!< 委托方式
};
struct QryBuyableEtfSecuBacketCntOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTSL_STR;           //!< 股票篮数量
};
struct QryLockableOptionsCntInput {
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_FLAG_STR;           //!< 加解锁类别 1 加锁 2 解锁
    std::string FID_WTFS_STR;           //!< 委托方式
};
struct QryLockableOptionsCntOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTSL_STR;           //!< 个股期权非交易可加锁/解锁数量
};
struct SecuEntrustWithdrawInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_WTH_STR;            //!< 原委托号
};
struct SecuEntrustWithdrawOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTH_STR;            //!< 撤单委托号
};
struct BatchSecuEntrustWithdrawInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_EN_WTH_STR;         //!< 撤单委托号范围，与FID_WTPCH二者至少送入一项
    std::string FID_WTPCH_STR;          //!< 委托批次号，与FID_EN_WTH二者至少送入一项
};
struct BatchSecuEntrustWithdrawOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTPCH_STR;          //!< 委托批次号(返回仅限于入参中有送入FID_WTPCH时)
    std::string FID_COUNT_STR;          //!< 委托成功笔数
    std::string FID_EN_WTH_STR;         //!< 撤单委托号及结果
};
struct OptionsLockOpsInput {
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_FLAG_STR;           //!< 加解锁类别 1 加锁 2 解锁
    std::string FID_WTSL_STR;           //!< 加锁委托数量/当日解锁委托数量（此数量不包括昨备兑持仓平仓数量）
    std::string FID_ZQSL_STR;           //!< 昨备兑持仓平仓数量（仅在FID_FLAG=2的条件下有效）
};
struct OptionsLockOpsOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
};
struct QryClientInfoInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
};
struct QryClientInfoOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_DH_STR;             //!< 电话
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_KHXM_STR;           //!< 客户姓名
    std::string FID_ZJBH_STR;           //!< 证件编号
    std::string FID_ZJLB_STR;           //!< 证件类别
    std::string FID_JGDM_STR;           //!< 机构代码
    std::string FID_JGBZ_STR;           //!< 机构账户标志
    std::string FID_MOBILE_STR;         //!< 移动电话
    std::string FID_WTFS_STR;           //!< 委托方式
    std::string FID_KHSX_STR;           //!< 客户属性
    std::string FID_KHZT_STR;           //!< 客户状态
    std::string FID_MMTB_STR;           //!< 密码同步标志
};
struct QryClientFundInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_EXFLG_STR;          //!< 扩展查询标志（1 增加返回证券市值和总资产）
};
struct QryClientFundOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_KYZJ_STR;           //!< 可用资金
    std::string FID_T2KYZJ_STR;         //!< T+2可用资金
    std::string FID_YJLX_STR;           //!< 预计利息
    std::string FID_ZHYE_STR;           //!< 账户余额
    std::string FID_ZHZT_STR;           //!< 账户状态
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_DJJE_STR;           //!< 冻结金额
    std::string FID_T2DJJE_STR;         //!< T+2冻结金额
    std::string FID_JGDM_STR;           //!< 机构代码
    std::string FID_ZZC_STR;            //!< 总资产（FID_EXFLG送1时返回）
    std::string FID_ZQSZ_STR;           //!< 证券市值（FID_EXFLG 送1时返回）
    std::string FID_FZJE_STR;           //!< 负债金额（正回购未到期的负债）（FID_EXFLG 送1时返回）
};
struct QryClientStkAcctInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
};
struct QryClientStkAcctOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_GDZDSX_STR;         //!< 股东指定属性
    std::string FID_JYQX_STR;           //!< 交易权限
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_GDZT_STR;           //!< 股东状态
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_ZZHBZ_STR;          //!< 主账户标志
    std::string FID_GDKZSX_STR;         //!< 股东控制属性
    std::string FID_JGDM_STR;           //!< 机构代码
};
struct QryClientPositionInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_EXFLG_STR;          //!< 查询扩展信息标志（送1增加输出参数强制标志为N的域）
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
    std::string FID_FLAG_STR;           //!< 过滤净持仓量等于0的标志（送1才会过滤）
};
struct QryClientPositionOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_DRMCCJJE_STR;       //!< 当日卖出成交金额
    std::string FID_DRMCCJSL_STR;       //!< 当日卖出成交数量
    std::string FID_DRMCWTSL_STR;       //!< 当日卖出委托数量
    std::string FID_DRMRCJJE_STR;       //!< 当日买入成交金额
    std::string FID_DRMRCJSL_STR;       //!< 当日买入成交数量
    std::string FID_DRMRWTSL_STR;       //!< 当日买入委托数量
    std::string FID_FLTSL_STR;          //!< 非流通数量
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KCRQ_STR;           //!< 开仓日期
    std::string FID_KMCSL_STR;          //!< 可卖出数量
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_ZQMC_STR;           //!< 证券名称
    std::string FID_ZQSL_STR;           //!< 证券数量
    std::string FID_JCCL_STR;           //!< 今持仓量
    std::string FID_WJSSL_STR;          //!< 未交收数量
    std::string FID_BDRQ_STR;           //!< 变动日期
    std::string FID_KSGSL_STR;          //!< 可申购数量
    std::string FID_KSHSL_STR;          //!< 可赎回数量
    std::string FID_DJSL_STR;           //!< 冻结数量
    std::string FID_MCDXSL_STR;         //!< 卖出抵消数量
    std::string FID_MRDXSL_STR;         //!< 买入抵消数量
    std::string FID_SGCJSL_STR;         //!< 申购成交数量
    std::string FID_SHCJSL_STR;         //!< 赎回成交数量
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
    std::string FID_JYDW_STR;           //!< 交易单位
    std::string FID_MCSL_STR;           //!< 累计卖出数量
    std::string FID_MRSL_STR;           //!< 累计买入数量
    std::string FID_PGSL_STR;           //!< 配股数量
    std::string FID_SGSL_STR;           //!< 申购数量
    std::string FID_TBFDYK_STR;         //!< 摊薄浮动盈亏
    std::string FID_TBBBJ_STR;          //!< 摊薄保本价
    std::string FID_TBCBJ_STR;          //!< 摊薄成本价
    std::string FID_CCJJ_STR;           //!< 持仓均价
    std::string FID_FDYK_STR;           //!< 浮动盈亏
    std::string FID_HLJE_STR;           //!< 红利金额
    std::string FID_LJYK_STR;           //!< 累计盈亏
    std::string FID_MCJE_STR;           //!< 卖出金额
    std::string FID_MRJE_STR;           //!< 买入金额
    std::string FID_MRJJ_STR;           //!< 买入均价
    std::string FID_PGJE_STR;           //!< 配股金额
    std::string FID_ZXSZ_STR;           //!< 最新市值
    std::string FID_BBJ_STR;            //!< 保本价
    std::string FID_ZXJ_STR;            //!< 最新价
    std::string FID_GPSZ_STR;           //!< 非流通市值
    std::string FID_LXBJ_STR;           //!< 利息报价
    std::string FID_ZSP_STR;            //!< 昨收盘
};
struct QryClientEntrustTodayInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_FLAG_STR;           //!< 查询标志（0所有委托，1可撤单委托）
    std::string FID_CXBZ_STR;           //!< 撤销标志（W撤单记录,O委托记录）
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
};
struct QryClientEntrustTodayOutput {
    std::string FID_BPGDH_STR;          //!< 报盘股东号
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_CJJE_STR;           //!< 成交金额
    std::string FID_CJJG_STR;           //!< 成交价格
    std::string FID_CJSJ_STR;           //!< 成交时间
    std::string FID_CJSL_STR;           //!< 成交数量
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_QSZJ_STR;           //!< 清算资金
    std::string FID_WTFS_STR;           //!< 委托方式
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTJG_STR;           //!< 委托价格
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_WTSL_STR;           //!< 委托数量
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_ZQMC_STR;           //!< 证券名称
    std::string FID_WTSJ_STR;           //!< 委托时间
    std::string FID_SBSJ_STR;           //!< 申报时间
    std::string FID_SBJG_STR;           //!< 申报结果(数据字典FID_SBJG编码)
    std::string FID_CXBZ_STR;           //!< 撤销标志
    std::string FID_DJZJ_STR;           //!< 冻结资金
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_JGSM_STR;           //!< 结果说明(数据字典FID_SBJG编码说明)
    std::string FID_CDSL_STR;           //!< 撤单数量
    std::string FID_SBWTH_STR;          //!< 申报委托号
    std::string FID_DDLX_STR;           //!< 订单类型
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_ZJDJLSH_STR;        //!< 资金冻结流水号
    std::string FID_ZQDJLSH_STR;        //!< 证券冻结流水号
    std::string FID_SBRQ_STR;           //!< 委托申报日期
    std::string FID_SBJLH_STR;          //!< 申报记录号
    std::string FID_WTRQ_STR;           //!< 委托日期
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
    std::string FID_ADDR_IP_STR;        //!< IP地址
    std::string FID_ADDR_MAC_STR;       //!< MAC地址
};
struct QryClientTickDealInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_FLAG_STR;           //!< 查询标志（0所有回转记录含撤单回转，1仅返回成交记录）
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
    std::string FID_HBXH_STR;           //!< 回报序号(结合FID_KH, FID_JYMM用于增量查询,返回大于该回报序号的记录)
};
struct QryClientTickDealOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_CJBH_STR;           //!< 成交编号
    std::string FID_CJJE_STR;           //!< 成交金额
    std::string FID_CJJG_STR;           //!< 成交价格
    std::string FID_CJSL_STR;           //!< 成交数量
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_QSJE_STR;           //!< 清算金额
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_ZQMC_STR;           //!< 证券名称
    std::string FID_CXBZ_STR;           //!< 撤销标志
    std::string FID_S1_STR;             //!< 佣金
    std::string FID_HBXH_STR;           //!< 回报序号
    std::string FID_LXBJ_STR;           //!< 利息报价
    std::string FID_SBWTH_STR;          //!< 申报委托号
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_LX_STR;             //!< 利息
    std::string FID_CJSJ_STR;           //!< 成交时间
};
struct QryClientRealTimeDealInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_FLAG_STR;           //!< 查询标志（0所有回转记录含撤单回转，1仅返回成交记录）
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
};
struct QryClientRealTimeDealOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_WTH_STR;            //!< 委托号
    std::string FID_SBWTH_STR;          //!< 申报委托号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_WTLB_STR;           //!< 委托类别
    std::string FID_CXBZ_STR;           //!< 撤销标志
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQMC_STR;           //!< 证券名称
    std::string FID_WTSL_STR;           //!< 委托数量
    std::string FID_WTJG_STR;           //!< 委托价格
    std::string FID_CDSL_STR;           //!< 撤单数量
    std::string FID_CJSL_STR;           //!< 成交数量
    std::string FID_CJJE_STR;           //!< 成交金额
    std::string FID_CJJG_STR;           //!< 成交价格
    std::string FID_CJSJ_STR;           //!< 成交时间
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_QSZJ_STR;           //!< 清算资金
    std::string FID_WTPCH_STR;          //!< 委托批次号
    std::string FID_DDLX_STR;           //!< 订单类型
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
};
struct QryClientFrozenFundInfoInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_DJLB_STR;           //!< 冻结类别
    std::string FID_ZJZH_STR;           //!< 资金帐号
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
};
struct QryClientFrozenFundInfoOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_DJLB_STR;           //!< 冻结类别
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_KHXM_STR;           //!< 客户姓名
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_ZY_STR;             //!< 摘要
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_FSJE_STR;           //!< 发生金额
    std::string FID_FSSJ_STR;           //!< 发生时间
    std::string FID_JGDM_STR;           //!< 机构代码
    std::string FID_FSRQ_STR;           //!< 发生日期
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
};
struct QryClientFrozenSecuInfoInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_DJLB_STR;           //!< 冻结类别
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
};
struct QryClientFrozenSecuInfoOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_DJLB_STR;           //!< 冻结类别
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_KHXM_STR;           //!< 客户姓名
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_ZQLB_STR;           //!< 证券类别
    std::string FID_ZQMC_STR;           //!< 证券名称
    std::string FID_ZY_STR;             //!< 摘要
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_FSSJ_STR;           //!< 发生时间
    std::string FID_JGDM_STR;           //!< 机构代码
    std::string FID_FSRQ_STR;           //!< 发生日期
    std::string FID_FSSL_STR;           //!< 发生数量
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
};
struct QryClientFundJourInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_DJLB_STR;           //!< 冻结类别（数据字典FID_ZJDJLB）
    std::string FID_ZJZH_STR;           //!< 资金帐号
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
};
struct QryClientFundJourOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_BZ_STR;             //!< 币种
    std::string FID_DJLB_STR;           //!< 冻结类别（数据字典FID_ZJDJLB）
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_KHXM_STR;           //!< 客户姓名
    std::string FID_ZJZH_STR;           //!< 资金账号
    std::string FID_ZY_STR;             //!< 摘要
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_FSJE_STR;           //!< 发生金额
    std::string FID_FSSJ_STR;           //!< 发生时间
    std::string FID_JGDM_STR;           //!< 机构代码
    std::string FID_FSRQ_STR;           //!< 发生日期
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值
};
struct QryClientSecuJourInput {
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_DJLB_STR;           //!< 冻结类别（数据字典FID_ZQDJLB）
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_BROWINDEX_STR;      //!< 增量查询索引值(定位串，首次查询可以送空)
    std::string FID_ROWCOUNT_STR;       //!< 查询记录数
};
struct QryClientSecuJourOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_KHXM_STR;           //!< 客户姓名
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_DJLB_STR;           //!< 冻结类别（数据字典FID_ZQDJLB）
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_ZQDM_STR;           //!< 证券代码
    std::string FID_LSH_STR;            //!< 流水号
    std::string FID_FSSL_STR;           //!< 发生数量
    std::string FID_FSSJ_STR;           //!< 发生时间
    std::string FID_JGDM_STR;           //!< 机构代码
    std::string FID_FSRQ_STR;           //!< 发生日期
    std::string FID_ZY_STR;             //!< 摘要
};
struct QryClientRationEquityInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所
};
struct QryClientRationEquityOutput {
    std::string FID_CODE_STR;           //!< 返回码
    std::string FID_MESSAGE_STR;        //!< 返回说明
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_GDH_STR;            //!< 股东号
    std::string FID_JYS_STR;            //!< 交易所编码
    std::string FID_ZQSL_STR;           //!< 权益数量
};
struct SubscribeInput {
    std::string FID_KHH_STR;            //!< 客户号
    std::string FID_JYMM_STR;           //!< 交易密码
};
struct SubscribeOutput {
    std::string FID_CODE_STR;           //!< 返回码（大于0订阅成功，小于0订阅失败）
    std::string FID_MESSAGE_STR;        //!< 返回说明
};

class FixApiWrapper
{
public:
    explicit FixApiWrapper();
    explicit FixApiWrapper(const FixConfig& config);
    virtual ~FixApiWrapper();

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    // 初始化，配置选项和网络连接
    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    bool initialize();
    bool connect(int timeout = 20);
    bool isConnected() const;

    void setConfig(const FixConfig& config);
    const FixConfig& config() const;

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    // 错误处理
    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    static Intf_RetType checkSessionError(HANDLE_SESSION session, std::string& errMsg);

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    // 字段转化
    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    static void createNode(std::string& node, const char* ip, const char* mac, const char* disksn, const char* site);
    std::string createNode(const char* ip, const char* mac, const char* disksn) const;
    static void createAddr(std::string& addr, const char* ip, const char* port);

    static bool isNetworkError(long errCode);

    /*! \brief 必须为12位十六进制MAC地址。*/
    static bool verifyMac(const char* mac);
    /*! \brief 必须为点分十进制IPv4地址。*/
    static bool verifyIp(const char* ip);
    /*! \brief 磁盘序列号字符串中，每一位都需要是字母或者数字。*/
    static bool verifyDiskSn(const char* disksn);

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    // FIX API -- 业务功能服务接口
    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    Intf_RetType fixQrySystemTime(const QrySystemTimeInput& input, std::list<QrySystemTimeOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixHeartBeat(std::list<HeartBeatOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryTradeNode(const QryTradeNodeInput& input, std::list<QryTradeNodeOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixCheckTradePasswd(const CheckTradePasswdInput& input, std::list<CheckTradePasswdOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixChangeTradePasswd(const ChangeTradePasswdInput& input, std::list<ChangeTradePasswdOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixChangeCapPasswd(const ChangeCapPasswdInput& input, std::list<ChangeCapPasswdOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixTransferInFund(const TransferInFundInput& input, std::list<TransferInFundOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixTransferOutFund(const TransferOutFundInput& input, std::list<TransferOutFundOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixTransferInSecu(const TransferInSecuInput& input, std::list<TransferInSecuOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixTransferOutSecu(const TransferOutSecuInput& input, std::list<TransferOutSecuOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixSecuEntrust(const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixBatchSecuEntrust(const BatchSecuEntrustInput& input, std::list<BatchSecuEntrustOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryTradableVol(const QryTradableVolInput& input, std::list<QryTradableVolOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryBuyableEtfSecuBacketCnt(const QryBuyableEtfSecuBacketCntInput& input, std::list<QryBuyableEtfSecuBacketCntOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryLockableOptionsCnt(const QryLockableOptionsCntInput& input, std::list<QryLockableOptionsCntOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixSecuEntrustWithdraw(const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixBatchSecuEntrustWithdraw(const BatchSecuEntrustWithdrawInput& input, std::list<BatchSecuEntrustWithdrawOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixOptionsLockOps(const OptionsLockOpsInput& input, std::list<OptionsLockOpsOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientInfo(const QryClientInfoInput& input, std::list<QryClientInfoOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientFund(const QryClientFundInput& input, std::list<QryClientFundOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientStkAcct(const QryClientStkAcctInput& input, std::list<QryClientStkAcctOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientPosition(const QryClientPositionInput& input, std::list<QryClientPositionOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientEntrustToday(const QryClientEntrustTodayInput& input, std::list<QryClientEntrustTodayOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientTickDeal(const QryClientTickDealInput& input, std::list<QryClientTickDealOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientRealTimeDeal(const QryClientRealTimeDealInput& input, std::list<QryClientRealTimeDealOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientFrozenFundInfo(const QryClientFrozenFundInfoInput& input, std::list<QryClientFrozenFundInfoOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientFrozenSecuInfo(const QryClientFrozenSecuInfoInput& input, std::list<QryClientFrozenSecuInfoOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientFundJour(const QryClientFundJourInput& input, std::list<QryClientFundJourOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientSecuJour(const QryClientSecuJourInput& input, std::list<QryClientSecuJourOutput>& output, std::string& errMsg, const std::string &node = "");
    Intf_RetType fixQryClientRationEquity(const QryClientRationEquityInput& input, std::list<QryClientRationEquityOutput>& output, std::string& errMsg, const std::string &node = "");

    //////////////////////////////////////////////////////////////////////////////////////////////////////////
    // FIX API -- 消息订阅、推送功能服务接口
    // Sub = Subscribe
    //////////////////////////////////////////////////////////////////////////////////////////////////////////

    void resubscribe();

    long fixSubSecuBargainInfo(const SubscribeInput& input, SubscribeOutput& output, void* callback, void* reserve = nullptr);
    long fixSubSecuEntrustAckInfo(const SubscribeInput& input, SubscribeOutput& output, void* callback, void* reserve = nullptr);
    long fixSubSecuEntrustWithdrawAckInfo(const SubscribeInput& input, SubscribeOutput& output, void* callback, void* reserve = nullptr);

    static bool fixUnsubscribe(long subHandle);
    static inline bool isSubHandleValid(long subHandle) { return subHandle >= 0; }

protected:
    typedef bool (*FixSubCallback)(HANDLE_CONN, HANDLE_SESSION, long, void*);

private:
    HANDLE_CONN mConnection = (HANDLE_CONN)NULL;
    bool mIsConnected = false;
    FixConfig mConfig;

    static std::mutex mInitMutex;
};

#endif
