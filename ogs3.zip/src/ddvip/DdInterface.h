///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef DDINTERFACE_H
#define DDINTERFACE_H

#include <string>
#include "../ogs_dict.h"
#include "../OgsApi.h"
#include "../ReadConfig.h"
#include "../OgsInterface.h"
#include "universal_code.h"
#include "DdImpl.h"

namespace ogs {

class DdInterface : public OgsInterface
{
public:
    DdInterface();

    virtual ~DdInterface();

    virtual bool getConnectStatus() override;

    virtual Intf_RetType initCommon() override;

    virtual Intf_RetType initSubscribe() override;

    virtual Intf_RetType connectBroker() override;

    virtual Intf_RetType reConnectBroker() override;

    virtual Intf_RetType heartBeatToBroker() override;

    virtual void setCallBack(int (*fn)(QueryOrderAns)) override;

    ///--------------------------------------------------------------------------------------------------------
    /// 业务操作接口
    ///--------------------------------------------------------------------------------------------------------

    virtual Intf_RetType ogsLogin(const LoginQry& in, std::list<LoginAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsSendOrder(const SendOrderQry& in, std::list<SendOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsCancelOrder(const CancelOrderQry& in, std::list<CancelOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsQueryOrder(const QueryOrderQry& in, std::list<QueryOrderAns>& out, std::string &errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsQueryPosition(const QueryPositionQry& in, std::list<QueryPositionAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsQueryBargain(const QueryBargainQry& in, std::list<QueryBargainAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsQueryFundInfo(const QueryFundInfoQry& in, std::list<QueryFundInfoAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsPaybackSecurity(const PaybackSecurityQry &in, std::list<PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsPaybackFunds(const PaybackFundsQry &in, std::list<PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args) override;

    virtual bool isFundAccountEnabled(const char* bacid);

private:
    DdImpl ddImpl;
};

}

#endif // DDINTERFACE_H
