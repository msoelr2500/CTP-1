///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "FixLogger.h"

OgsLogger& operator << (OgsLogger& logger, const QrySystemTimeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QrySystemTimeInput]====================";
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySystemTimeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QrySystemTimeOutput]====================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_DATE                     |" << data.FID_DATE_STR;
    ogsDebug << "|FID_TIME                     |" << data.FID_TIME_STR;
    ogsDebug << "|FID_WEEK                     |" << data.FID_WEEK_STR;
    ogsDebug << "|FID_MILLISECOND              |" << data.FID_MILLISECOND_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const HeartBeatOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[HeartBeatOutput]======================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryTradeNodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryTradeNodeInput]=====================";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryTradeNodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryTradeNodeOutput]====================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_NODEID                   |" << data.FID_NODEID_STR;
    ogsDebug << "|FID_NODENAME                 |" << data.FID_NODENAME_STR;
    ogsDebug << "|FID_ZT                       |" << data.FID_ZT_STR;
    ogsDebug << "|FID_DATE                     |" << data.FID_DATE_STR;
    ogsDebug << "|FID_RQ                       |" << data.FID_RQ_STR;
    ogsDebug << "|FID_TIME                     |" << data.FID_TIME_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CheckTradePasswdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[CheckTradePasswdInput]===================";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CheckTradePasswdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[CheckTradePasswdOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ChangeTradePasswdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[ChangeTradePasswdInput]==================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_MM                       |" << data.FID_MM_STR;
    ogsDebug << "|FID_NEWMM                    |" << data.FID_NEWMM_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ChangeTradePasswdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[ChangeTradePasswdOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ChangeCapPasswdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[ChangeCapPasswdInput]===================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_MM                       |" << data.FID_MM_STR;
    ogsDebug << "|FID_NEWMM                    |" << data.FID_NEWMM_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ChangeCapPasswdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[ChangeCapPasswdOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferInFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[TransferInFundInput]====================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_FSJE                     |" << data.FID_FSJE_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferInFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[TransferInFundOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_ZHYE                     |" << data.FID_ZHYE_STR;
    ogsDebug << "|FID_KYZJ                     |" << data.FID_KYZJ_STR;
    ogsDebug << "|FID_T2KYZJ                   |" << data.FID_T2KYZJ_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferOutFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[TransferOutFundInput]===================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_FSJE                     |" << data.FID_FSJE_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferOutFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[TransferOutFundOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_ZHYE                     |" << data.FID_ZHYE_STR;
    ogsDebug << "|FID_KYZJ                     |" << data.FID_KYZJ_STR;
    ogsDebug << "|FID_T2KYZJ                   |" << data.FID_T2KYZJ_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferInSecuInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[TransferInSecuInput]====================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_FSSL                     |" << data.FID_FSSL_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferInSecuOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[TransferInSecuOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_JCCL                     |" << data.FID_JCCL_STR;
    ogsDebug << "|FID_KMCSL                    |" << data.FID_KMCSL_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferOutSecuInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[TransferOutSecuInput]===================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_FSSL                     |" << data.FID_FSSL_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const TransferOutSecuOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[TransferOutSecuOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_JCCL                     |" << data.FID_JCCL_STR;
    ogsDebug << "|FID_KMCSL                    |" << data.FID_KMCSL_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[SecuEntrustInput]=====================";
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_WTJG                     |" << data.FID_WTJG_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_DDLX                     |" << data.FID_DDLX_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_DFXW                     |" << data.FID_DFXW_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEntrustOutput]=====================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[BatchSecuEntrustInput]===================";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_COUNT                    |" << data.FID_COUNT_STR;
    ogsDebug << "|FID_FJXX                     |" << data.FID_FJXX_STR;
    ogsDebug << "|FID_LOGICAL                  |" << data.FID_LOGICAL_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[BatchSecuEntrustOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_EN_WTH                   |" << data.FID_EN_WTH_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_COUNT                    |" << data.FID_COUNT_STR;
    ogsDebug << "|FID_MEMCOUNT                 |" << data.FID_MEMCOUNT_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryTradableVolInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryTradableVolInput]====================";
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_DDLX                     |" << data.FID_DDLX_STR;
    ogsDebug << "|FID_WTFS                     |" << data.FID_WTFS_STR;
    ogsDebug << "|FID_WTJG                     |" << data.FID_WTJG_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryTradableVolOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryTradableVolOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryBuyableEtfSecuBacketCntInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[QryBuyableEtfSecuBacketCntInput]==============";
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_WTFS                     |" << data.FID_WTFS_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryBuyableEtfSecuBacketCntOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[QryBuyableEtfSecuBacketCntOutput]=============";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryLockableOptionsCntInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryLockableOptionsCntInput]================";
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    ogsDebug << "|FID_WTFS                     |" << data.FID_WTFS_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryLockableOptionsCntOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryLockableOptionsCntOutput]================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustWithdrawInput]=================";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuEntrustWithdrawOutput]=================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[BatchSecuEntrustWithdrawInput]===============";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_EN_WTH                   |" << data.FID_EN_WTH_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[BatchSecuEntrustWithdrawOutput]==============";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_COUNT                    |" << data.FID_COUNT_STR;
    ogsDebug << "|FID_EN_WTH                   |" << data.FID_EN_WTH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsLockOpsInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[OptionsLockOpsInput]====================";
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_ZQSL                     |" << data.FID_ZQSL_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsLockOpsOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[OptionsLockOpsOutput]===================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryClientInfoInput]====================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientInfoOutput]====================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_DH                       |" << data.FID_DH_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_KHXM                     |" << data.FID_KHXM_STR;
    ogsDebug << "|FID_ZJBH                     |" << data.FID_ZJBH_STR;
    ogsDebug << "|FID_ZJLB                     |" << data.FID_ZJLB_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    ogsDebug << "|FID_JGBZ                     |" << data.FID_JGBZ_STR;
    ogsDebug << "|FID_MOBILE                   |" << data.FID_MOBILE_STR;
    ogsDebug << "|FID_WTFS                     |" << data.FID_WTFS_STR;
    ogsDebug << "|FID_KHSX                     |" << data.FID_KHSX_STR;
    ogsDebug << "|FID_KHZT                     |" << data.FID_KHZT_STR;
    ogsDebug << "|FID_MMTB                     |" << data.FID_MMTB_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryClientFundInput]====================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_EXFLG                    |" << data.FID_EXFLG_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientFundOutput]====================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_KYZJ                     |" << data.FID_KYZJ_STR;
    ogsDebug << "|FID_T2KYZJ                   |" << data.FID_T2KYZJ_STR;
    ogsDebug << "|FID_YJLX                     |" << data.FID_YJLX_STR;
    ogsDebug << "|FID_ZHYE                     |" << data.FID_ZHYE_STR;
    ogsDebug << "|FID_ZHZT                     |" << data.FID_ZHZT_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_DJJE                     |" << data.FID_DJJE_STR;
    ogsDebug << "|FID_T2DJJE                   |" << data.FID_T2DJJE_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    ogsDebug << "|FID_ZZC                      |" << data.FID_ZZC_STR;
    ogsDebug << "|FID_ZQSZ                     |" << data.FID_ZQSZ_STR;
    ogsDebug << "|FID_FZJE                     |" << data.FID_FZJE_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientStkAcctInput]===================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientStkAcctOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_GDZDSX                   |" << data.FID_GDZDSX_STR;
    ogsDebug << "|FID_JYQX                     |" << data.FID_JYQX_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_GDZT                     |" << data.FID_GDZT_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_ZZHBZ                    |" << data.FID_ZZHBZ_STR;
    ogsDebug << "|FID_GDKZSX                   |" << data.FID_GDKZSX_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientPositionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientPositionInput]==================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_EXFLG                    |" << data.FID_EXFLG_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientPositionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientPositionOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_DRMCCJJE                 |" << data.FID_DRMCCJJE_STR;
    ogsDebug << "|FID_DRMCCJSL                 |" << data.FID_DRMCCJSL_STR;
    ogsDebug << "|FID_DRMCWTSL                 |" << data.FID_DRMCWTSL_STR;
    ogsDebug << "|FID_DRMRCJJE                 |" << data.FID_DRMRCJJE_STR;
    ogsDebug << "|FID_DRMRCJSL                 |" << data.FID_DRMRCJSL_STR;
    ogsDebug << "|FID_DRMRWTSL                 |" << data.FID_DRMRWTSL_STR;
    ogsDebug << "|FID_FLTSL                    |" << data.FID_FLTSL_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KCRQ                     |" << data.FID_KCRQ_STR;
    ogsDebug << "|FID_KMCSL                    |" << data.FID_KMCSL_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_ZQMC                     |" << data.FID_ZQMC_STR;
    ogsDebug << "|FID_ZQSL                     |" << data.FID_ZQSL_STR;
    ogsDebug << "|FID_JCCL                     |" << data.FID_JCCL_STR;
    ogsDebug << "|FID_WJSSL                    |" << data.FID_WJSSL_STR;
    ogsDebug << "|FID_BDRQ                     |" << data.FID_BDRQ_STR;
    ogsDebug << "|FID_KSGSL                    |" << data.FID_KSGSL_STR;
    ogsDebug << "|FID_KSHSL                    |" << data.FID_KSHSL_STR;
    ogsDebug << "|FID_DJSL                     |" << data.FID_DJSL_STR;
    ogsDebug << "|FID_MCDXSL                   |" << data.FID_MCDXSL_STR;
    ogsDebug << "|FID_MRDXSL                   |" << data.FID_MRDXSL_STR;
    ogsDebug << "|FID_SGCJSL                   |" << data.FID_SGCJSL_STR;
    ogsDebug << "|FID_SHCJSL                   |" << data.FID_SHCJSL_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_JYDW                     |" << data.FID_JYDW_STR;
    ogsDebug << "|FID_MCSL                     |" << data.FID_MCSL_STR;
    ogsDebug << "|FID_MRSL                     |" << data.FID_MRSL_STR;
    ogsDebug << "|FID_PGSL                     |" << data.FID_PGSL_STR;
    ogsDebug << "|FID_SGSL                     |" << data.FID_SGSL_STR;
    ogsDebug << "|FID_TBFDYK                   |" << data.FID_TBFDYK_STR;
    ogsDebug << "|FID_TBBBJ                    |" << data.FID_TBBBJ_STR;
    ogsDebug << "|FID_TBCBJ                    |" << data.FID_TBCBJ_STR;
    ogsDebug << "|FID_CCJJ                     |" << data.FID_CCJJ_STR;
    ogsDebug << "|FID_FDYK                     |" << data.FID_FDYK_STR;
    ogsDebug << "|FID_HLJE                     |" << data.FID_HLJE_STR;
    ogsDebug << "|FID_LJYK                     |" << data.FID_LJYK_STR;
    ogsDebug << "|FID_MCJE                     |" << data.FID_MCJE_STR;
    ogsDebug << "|FID_MRJE                     |" << data.FID_MRJE_STR;
    ogsDebug << "|FID_MRJJ                     |" << data.FID_MRJJ_STR;
    ogsDebug << "|FID_PGJE                     |" << data.FID_PGJE_STR;
    ogsDebug << "|FID_ZXSZ                     |" << data.FID_ZXSZ_STR;
    ogsDebug << "|FID_BBJ                      |" << data.FID_BBJ_STR;
    ogsDebug << "|FID_ZXJ                      |" << data.FID_ZXJ_STR;
    ogsDebug << "|FID_GPSZ                     |" << data.FID_GPSZ_STR;
    ogsDebug << "|FID_LXBJ                     |" << data.FID_LXBJ_STR;
    ogsDebug << "|FID_ZSP                      |" << data.FID_ZSP_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientEntrustTodayInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientEntrustTodayInput]================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientEntrustTodayOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientEntrustTodayOutput]================";
    ogsDebug << "|FID_BPGDH                    |" << data.FID_BPGDH_STR;
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_CJJE                     |" << data.FID_CJJE_STR;
    ogsDebug << "|FID_CJJG                     |" << data.FID_CJJG_STR;
    ogsDebug << "|FID_CJSJ                     |" << data.FID_CJSJ_STR;
    ogsDebug << "|FID_CJSL                     |" << data.FID_CJSL_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_QSZJ                     |" << data.FID_QSZJ_STR;
    ogsDebug << "|FID_WTFS                     |" << data.FID_WTFS_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTJG                     |" << data.FID_WTJG_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_ZQMC                     |" << data.FID_ZQMC_STR;
    ogsDebug << "|FID_WTSJ                     |" << data.FID_WTSJ_STR;
    ogsDebug << "|FID_SBSJ                     |" << data.FID_SBSJ_STR;
    ogsDebug << "|FID_SBJG                     |" << data.FID_SBJG_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_DJZJ                     |" << data.FID_DJZJ_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_JGSM                     |" << data.FID_JGSM_STR;
    ogsDebug << "|FID_CDSL                     |" << data.FID_CDSL_STR;
    ogsDebug << "|FID_SBWTH                    |" << data.FID_SBWTH_STR;
    ogsDebug << "|FID_DDLX                     |" << data.FID_DDLX_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_ZJDJLSH                  |" << data.FID_ZJDJLSH_STR;
    ogsDebug << "|FID_ZQDJLSH                  |" << data.FID_ZQDJLSH_STR;
    ogsDebug << "|FID_SBRQ                     |" << data.FID_SBRQ_STR;
    ogsDebug << "|FID_SBJLH                    |" << data.FID_SBJLH_STR;
    ogsDebug << "|FID_WTRQ                     |" << data.FID_WTRQ_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ADDR_IP                  |" << data.FID_ADDR_IP_STR;
    ogsDebug << "|FID_ADDR_MAC                 |" << data.FID_ADDR_MAC_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientTickDealInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientTickDealInput]==================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    ogsDebug << "|FID_HBXH                     |" << data.FID_HBXH_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientTickDealOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientTickDealOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_CJBH                     |" << data.FID_CJBH_STR;
    ogsDebug << "|FID_CJJE                     |" << data.FID_CJJE_STR;
    ogsDebug << "|FID_CJJG                     |" << data.FID_CJJG_STR;
    ogsDebug << "|FID_CJSL                     |" << data.FID_CJSL_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_QSJE                     |" << data.FID_QSJE_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_ZQMC                     |" << data.FID_ZQMC_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_S1                       |" << data.FID_S1_STR;
    ogsDebug << "|FID_HBXH                     |" << data.FID_HBXH_STR;
    ogsDebug << "|FID_LXBJ                     |" << data.FID_LXBJ_STR;
    ogsDebug << "|FID_SBWTH                    |" << data.FID_SBWTH_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_LX                       |" << data.FID_LX_STR;
    ogsDebug << "|FID_CJSJ                     |" << data.FID_CJSJ_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRealTimeDealInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientRealTimeDealInput]================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_FLAG                     |" << data.FID_FLAG_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRealTimeDealOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientRealTimeDealOutput]================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_SBWTH                    |" << data.FID_SBWTH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQMC                     |" << data.FID_ZQMC_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_WTJG                     |" << data.FID_WTJG_STR;
    ogsDebug << "|FID_CDSL                     |" << data.FID_CDSL_STR;
    ogsDebug << "|FID_CJSL                     |" << data.FID_CJSL_STR;
    ogsDebug << "|FID_CJJE                     |" << data.FID_CJJE_STR;
    ogsDebug << "|FID_CJJG                     |" << data.FID_CJJG_STR;
    ogsDebug << "|FID_CJSJ                     |" << data.FID_CJSJ_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_QSZJ                     |" << data.FID_QSZJ_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_DDLX                     |" << data.FID_DDLX_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenFundInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientFrozenFundInfoInput]===============";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenFundInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[QryClientFrozenFundInfoOutput]===============";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_KHXM                     |" << data.FID_KHXM_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_FSJE                     |" << data.FID_FSJE_STR;
    ogsDebug << "|FID_FSSJ                     |" << data.FID_FSSJ_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    ogsDebug << "|FID_FSRQ                     |" << data.FID_FSRQ_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenSecuInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientFrozenSecuInfoInput]===============";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenSecuInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[QryClientFrozenSecuInfoOutput]===============";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_KHXM                     |" << data.FID_KHXM_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_ZQMC                     |" << data.FID_ZQMC_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_FSSJ                     |" << data.FID_FSSJ_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    ogsDebug << "|FID_FSRQ                     |" << data.FID_FSRQ_STR;
    ogsDebug << "|FID_FSSL                     |" << data.FID_FSSL_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFundJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientFundJourInput]==================";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFundJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientFundJourOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_KHXM                     |" << data.FID_KHXM_STR;
    ogsDebug << "|FID_ZJZH                     |" << data.FID_ZJZH_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_FSJE                     |" << data.FID_FSJE_STR;
    ogsDebug << "|FID_FSSJ                     |" << data.FID_FSSJ_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    ogsDebug << "|FID_FSRQ                     |" << data.FID_FSRQ_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientSecuJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientSecuJourInput]==================";
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_BROWINDEX                |" << data.FID_BROWINDEX_STR;
    ogsDebug << "|FID_ROWCOUNT                 |" << data.FID_ROWCOUNT_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientSecuJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientSecuJourOutput]==================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_KHXM                     |" << data.FID_KHXM_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_DJLB                     |" << data.FID_DJLB_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_LSH                      |" << data.FID_LSH_STR;
    ogsDebug << "|FID_FSSL                     |" << data.FID_FSSL_STR;
    ogsDebug << "|FID_FSSJ                     |" << data.FID_FSSJ_STR;
    ogsDebug << "|FID_JGDM                     |" << data.FID_JGDM_STR;
    ogsDebug << "|FID_FSRQ                     |" << data.FID_FSRQ_STR;
    ogsDebug << "|FID_ZY                       |" << data.FID_ZY_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRationEquityInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientRationEquityInput]================";
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_JYMM                     |" << data.FID_JYMM_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRationEquityOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientRationEquityOutput]================";
    ogsDebug << "|FID_CODE                     |" << data.FID_CODE_STR;
    ogsDebug << "|FID_MESSAGE                  |" << data.FID_MESSAGE_STR;
    ogsDebug << "|FID_KHH                      |" << data.FID_KHH_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_ZQSL                     |" << data.FID_ZQSL_STR;
    return logger;
}

OgsLogger &operator <<(OgsLogger &logger, const SecuBargainInfo &data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[SecuBargainInfo]======================";
    ogsDebug << "|FID_QRBZ                     |" << data.FID_QRBZ_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_CJBH                     |" << data.FID_CJBH_STR;
    ogsDebug << "|FID_CJSJ                     |" << data.FID_CJSJ_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_CDSL                     |" << data.FID_CDSL_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_QSZJ                     |" << data.FID_QSZJ_STR;
    ogsDebug << "|FID_ZCJSL                    |" << data.FID_ZCJSL_STR;
    ogsDebug << "|FID_ZCJJE                    |" << data.FID_ZCJJE_STR;
    ogsDebug << "|FID_CJSL                     |" << data.FID_CJSL_STR;
    ogsDebug << "|FID_CJJG                     |" << data.FID_CJJG_STR;
    ogsDebug << "|FID_WTJG                     |" << data.FID_WTJG_STR;
    ogsDebug << "|FID_CJJE                     |" << data.FID_CJJE_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    return logger;
}

OgsLogger &operator <<(OgsLogger &logger, const SecuEntrustAckInfo &data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEntrustAckInfo]====================";
    ogsDebug << "|FID_QRBZ                     |" << data.FID_QRBZ_STR;
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_CDSL                     |" << data.FID_CDSL_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_DJZJ                     |" << data.FID_DJZJ_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_SBJG                     |" << data.FID_SBJG_STR;
    ogsDebug << "|FID_JGSM                     |" << data.FID_JGSM_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_HZSJ                     |" << data.FID_HZSJ_STR;
    return logger;
}

OgsLogger &operator <<(OgsLogger &logger, const SecuEntrustWithdrawAckInfo &data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SecuEntrustWithdrawAckInfo]================";
    ogsDebug << "|FID_GDH                      |" << data.FID_GDH_STR;
    ogsDebug << "|FID_JYS                      |" << data.FID_JYS_STR;
    ogsDebug << "|FID_BZ                       |" << data.FID_BZ_STR;
    ogsDebug << "|FID_ZQDM                     |" << data.FID_ZQDM_STR;
    ogsDebug << "|FID_ZQLB                     |" << data.FID_ZQLB_STR;
    ogsDebug << "|FID_WTSL                     |" << data.FID_WTSL_STR;
    ogsDebug << "|FID_CDSL                     |" << data.FID_CDSL_STR;
    ogsDebug << "|FID_CJSL                     |" << data.FID_CJSL_STR;
    ogsDebug << "|FID_CXBZ                     |" << data.FID_CXBZ_STR;
    ogsDebug << "|FID_DJZJ                     |" << data.FID_DJZJ_STR;
    ogsDebug << "|FID_WTH                      |" << data.FID_WTH_STR;
    ogsDebug << "|FID_WTLB                     |" << data.FID_WTLB_STR;
    ogsDebug << "|FID_WTPCH                    |" << data.FID_WTPCH_STR;
    ogsDebug << "|FID_HZSJ                     |" << data.FID_HZSJ_STR;
    return logger;
}
