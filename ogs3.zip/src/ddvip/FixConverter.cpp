///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "FixConverter.h"
#include <ddvip/FixApi_mdb.h>
#include <string.h>

using std::string;

using ogs::ogs_dict::ExecutionType;
using ogs::ogs_dict::OrderStatusType;
using qtp::MarketCode;
using ogs::ogs_dict::DirectiveType;

std::string FixConverter::FID_ZQDM_STR(std::string &code)
{
    return (code == "000000") ? string("") : code;
}

std::string FixConverter::FID_KHH_STR(const char *acidcard)
{
    if (acidcard) return acidcard;
    return string();
}

std::string FixConverter::FID_ZJZH_STR(const char *bacid)
{
    if (bacid) return bacid;
    return string();
}

std::string FixConverter::FID_WTJG_STR(ogs::OGS_PRICE price)
{
    return std::to_string(price / 10000.0);
}

std::string FixConverter::FID_WTSL_STR(ogs::OGS_VOLUME volume)
{
    return std::to_string(volume);
}

std::string FixConverter::FID_JYMM_STR(const char *password)
{
    string encoded = password;
    Fix_Encode((char*)encoded.c_str());    // 加密密码。
    return encoded;
}

std::string FixConverter::FID_WTH_STR(const char *sysOrderId)
{
    if (sysOrderId) return string(sysOrderId);
    return string();
}

std::string FixConverter::FID_ROWCOUNT_STR()
{
    return std::to_string(2000);
}

void FixConverter::CONV_FID_WTH(const std::string &FID_WTH_STR, char *sysOrderId)
{
    strcpy(sysOrderId, FID_WTH_STR.c_str());
}

void FixConverter::CONV_STRING(const std::string &source, char *target)
{
    strcpy(target, source.c_str());
}

void FixConverter::CONV_FID_PRICE(const std::string &FID_PRICE_STR, ogs::OGS_PRICE &price)
{
    price = FID_PRICE_STR.empty() ? 0.0 : std::stof(FID_PRICE_STR) * 10000.0;
}

void FixConverter::CONV_FID_VOL(const std::string &FID_VOL_STR, ogs::OGS_VOLUME &volume)
{
    if (FID_VOL_STR.empty()) return;
    volume = std::stoi(FID_VOL_STR);
}

void FixConverter::CONV_FID_AMOUNT(const std::string &FID_AMOUNT_STR, ogs::OGS_BALANCE &balance)
{
    balance = std::atof(FID_AMOUNT_STR.c_str()) * 10000;
}

void FixConverter::CONV_FID_HBXH(const std::string &FID_HBXH_STR, char *dealId)
{
    memcpy(dealId, FID_HBXH_STR.c_str(), FID_HBXH_STR.size());
}

void FixConverter::CONV_FID_SBJG(const std::string &FID_SBJG_STR, ogs::OGS_ORDERSTATUS &orderStatus)
{
    orderStatus = ogsOrderStatusType(FID_SBJG_STR);
}

void FixConverter::CONV_FID_WTLB(const std::string &FID_WTLB_STR, ogs::OGS_DIRECTIVE &directive)
{
    directive = ogsDirectiveType(FID_WTLB_STR);
}

void FixConverter::CONV_FID_WTRQ(const std::string &FID_WTRQ_STR, ogs::OGS_TRADEDATE &tradeDate)
{
    //! \todo 由于不知道日期格式，无法转换！
}

void FixConverter::CONV_FID_WTSJ(const std::string &FID_WTSJ_STR, ogs::OGS_ORDERTIME &orderTime)
{
    //! \todo 由于不知道时间格式，无法转换！
}

void FixConverter::CONV_FID_ZQDM(const std::string &FID_ZQDM_STR, ogs::OGS_INNERCODE &innerCode)
{
    innerCode = qtp::UniversalCode::SymbolToUC(FID_ZQDM_STR);
}

std::string FixConverter::FID_DDLX_STR(ogs::OGS_EXECUTION type)
{
    switch (type) {
    case ExecutionType::kExeLimit:
        return string("0");
    default:
        return string("");
    }
}

ogs::ogs_dict::ExecutionType FixConverter::ogsExecutionType(const std::string &FID_DDLX_STR)
{
    if (FID_DDLX_STR == string("0")) {
        return ExecutionType::kExeLimit;
    } else {
        return ExecutionType::kExeLimit;
    }
}

std::string FixConverter::FID_SBJG_STR(ogs::OGS_ORDERSTATUS type)
{
    if (type == OrderStatusType::kOtNotApproved) return string("3");

    switch (type) {
    case OrderStatusType::kOtNotReported:
        return string("0");
    case OrderStatusType::kOtWaitReporting:
        return string("1");
    case OrderStatusType::kOtReported:
        return string("2");
    case OrderStatusType::kOtCanceling:
    case OrderStatusType::kOtMatchedCanceling:
        return string("9");
    case OrderStatusType::kOtMatchedCanceled:
        return string("7");
    case OrderStatusType::kOtCanceled:
        return string("8");
    case OrderStatusType::kOtPartMatched:
        return string("5");
    case OrderStatusType::kOtMatchedAll:
        return string("6");
    case OrderStatusType::kOtRiskBlocked:
    case OrderStatusType::kOtBad:
    default:
        return string("3"); // 默认为非法委托。
    }
}

ogs::ogs_dict::OrderStatusType FixConverter::ogsOrderStatusType(const std::string &FID_SBJG_STR)
{
    // ogs中没有 4-[申请资金授权中]，10-[等待人工申报] 状态。
    if (FID_SBJG_STR == string("0")) {
        return OrderStatusType::kOtNotReported;
    } else if (FID_SBJG_STR == string("1")) {
        return OrderStatusType::kOtWaitReporting;
    } else if (FID_SBJG_STR == string("2")) {
        return OrderStatusType::kOtReported;
    } else if (FID_SBJG_STR == string("3")) {
        return OrderStatusType::kOtBad;
    } else if (FID_SBJG_STR == string("5")) {
        return OrderStatusType::kOtPartMatched;
    } else if (FID_SBJG_STR == string("6")) {
        return OrderStatusType::kOtMatchedAll;
    } else if (FID_SBJG_STR == string("7")) {
        return OrderStatusType::kOtMatchedCanceled;
    } else if (FID_SBJG_STR == string("8")) {
        return OrderStatusType::kOtCanceled;
    } else if (FID_SBJG_STR == string("9")) {
        return OrderStatusType::kOtMatchedCanceled;
    } else {
        return OrderStatusType::kOtNotApproved;
    }
}

std::string FixConverter::FID_JYS_STR(qtp::MarketCode type)
{
    switch (type) {
    case MarketCode::kMC_SSE:
        return string("SH");
    case MarketCode::kMC_SZE:
        return string("SZ");
    default:
        return string("");
    }
}

void FixConverter::CONV_FID_JYS(const std::string &FID_JYS_STR, qtp::MarketCode &code)
{
    if (FID_JYS_STR == string("SH")) {
        code = MarketCode::kMC_SSE;
    } else if (FID_JYS_STR == string("SZ")) {
        code = MarketCode::kMC_SZE;
    } else {
        code = MarketCode::kMC_UNKNOW;
    }
}

std::string FixConverter::FID_WTLB_STR(ogs::OGS_DIRECTIVE type)
{
    switch (type) {
    case DirectiveType::kDtBuy:
    case DirectiveType::kDtGuaranteeBuy:
        return string("1");
    case DirectiveType::kDtSell:
    case DirectiveType::kDtGuaranteeSell:
        return string("2");
    case DirectiveType::kDtMarketMarginSell:
    case DirectiveType::kDtMarginSell:
        return string("5");
    case DirectiveType::kDtLoanBuy:
        return string("4");
    case DirectiveType::kDtCashRepay:
        return string("3");
    case DirectiveType::kDtMarketSecPayback:
    case DirectiveType::kDtSecPayback:
    case DirectiveType::kDtBuyPayback:
    case DirectiveType::kDtSellPayBack:
    default:
        return string("");
    }
}

ogs::ogs_dict::DirectiveType FixConverter::ogsDirectiveType(const std::string &FID_WTLB_STR)
{
    if (FID_WTLB_STR == "1") {
        return DirectiveType::kDtBuy;
    } else if (FID_WTLB_STR == "2") {
        return DirectiveType::kDtSell;
    } else if (FID_WTLB_STR == "3") {
        return DirectiveType::kDtCashRepay;
    } else if (FID_WTLB_STR == "4") {
        return DirectiveType::kDtLoanBuy;
    } else if (FID_WTLB_STR == "5") {
        return DirectiveType::kDtMarginSell;
    } else {
        return (DirectiveType)(-1);
    }
}

std::string FixConverter::FID_CXBZ_STR(FID_CXBZ_ENUM type)
{
    switch (type) {
    case FID_CXBZ_ENUM::WITHDRAW_RECORD:
        return "W";
    case FID_CXBZ_ENUM::ENTRUST_RECORD:
    default:
        return "O";
    }
}
