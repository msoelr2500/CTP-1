////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-28
////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "FixLogger.h" // 需要放到 "FixApiWrapper.h" 前面。
#include "FixApiWrapper.h"
#include "../StringHelper.h"
#include <arpa/inet.h>
#include <cstdio>

using std::cout;
using std::cerr;
using std::endl;
using std::string;
using std::list;

std::mutex FixApiWrapper::mInitMutex;

FixApiWrapper::FixApiWrapper()
{

}

FixApiWrapper::FixApiWrapper(const FixConfig &config)
{
    setConfig(config);
}

FixApiWrapper::~FixApiWrapper()
{
    Fix_Uninitialize();
}

void FixApiWrapper::setConfig(const FixConfig &config)
{
    mConfig = config;
}

const FixConfig &FixApiWrapper::config() const
{
    return mConfig;
}

Intf_RetType FixApiWrapper::checkSessionError(long session, std::string &errMsg)
{
    long errCode = Fix_GetCode(session);
    if (errCode < 0) {
        FixReader::getErrorInfo(session, errMsg);
        if (isNetworkError(errCode)) {
            return kIntfDisconnect;
        } else {
            return kIntfWorkFail;
        }
    }
    return kIntfSuccess;
}

bool FixApiWrapper::initialize()
{
    std::lock_guard<std::mutex> initLock(mInitMutex);

    static bool initialized = false;

    // 只在第一次调用时执行初始化操作。
    if (!initialized) {
        cout << "[ddvip] 初始化..." << endl;
        // 第三方接口库初始化。
        if (!Fix_Initialize()) {
            cerr << "[ddvip] 初始化时出现错误：Fix_Initialize()失败。" << endl;
            return false;
        }
        // 设置第三方软件名称和版本。
        if (!Fix_SetAppInfo("KingStar", "1.0")) {
            cerr << "[ddvip] 初始化时出现错误：Fix_SetApp()失败。" << endl;
            return false;
        }
        initialized = true;
        cout << "[ddvip] 初始化成功。" << endl;
    }
    return true;
}

bool FixApiWrapper::connect(int timeout)
{
    HANDLE_CONN connection = (HANDLE_SESSION)NULL;

    // 这里先不关闭先前连接，因为api可能正在尝试重连。
    Fix_SetDefaultInfo(mConfig.mDefaultOperator.c_str(), mConfig.mEntrustMode.c_str(),
                       mConfig.mRequestStation.c_str(), mConfig.mOpStation.c_str());

    connection = Fix_ConnectEx(mConfig.mServerAddr.c_str(), "ogs_lhhj", "",
                               mConfig.mCertFilePath.c_str(),
                               mConfig.mCertPwd.c_str(),
                               mConfig.mProtocol.c_str(),
                               mConfig.mCAFilePath.c_str(),
                               true, timeout);

    if (!connection) {
        string errMsg = "[ddvip] 建立连接时出现错误：Fix_ConnectEx()失败。";
        cerr << errMsg << endl;
        fixError << errMsg;
        return false;
    }

    ogsDebug << "[ddvip] [connect] start wait api to reconnect.";
    for (int i = 0; i < 5; i++) {
        if (!Fix_IsConnect(mConnection)) {
            sleep(1);
        } else {
            break;
        }
    }
    ogsDebug << "[ddvip] [connect] finish waiting.";

    // 由于api可能正在重连，如果重连成功则仍使用原来的连接，关闭新建立的连接。
    if (Fix_IsConnect(mConnection)) {
        Fix_Close(connection);
    } else {
        // 这里已经建立了新连接，但是api仍未能修复原有连接，说明原有连接已经无法重连成功。
        Fix_Close(mConnection);
        mConnection = connection;
        // 新连接要重新建立原有连接的订阅。
        resubscribe();
    }
    cout << "[ddvip] 建立连接成功。" << endl;
    return true;
}

bool FixApiWrapper::isConnected() const
{
    return Fix_IsConnect(mConnection);
}

void FixApiWrapper::createNode(std::string &node, const char *ip, const char *mac, const char *disksn, const char *site)
{
    StringHelper::string_format(node, "%s,%s;%s;%s", ip, mac, disksn, site);
}

std::string FixApiWrapper::createNode(const char *ip, const char *mac, const char *disksn) const
{
    string tNode;
    string tIp     = verifyIp(ip)         ? ip     : mConfig.mDefaultNodeIp;
    string tMac    = verifyMac(mac)       ? mac    : mConfig.mDefaultNodeMac;
    string tDiskSn = verifyDiskSn(disksn) ? disksn : mConfig.mDefaultNodeDiskSn;

    fixDebug << "[fix] node = " << tNode;
    FixApiWrapper::createNode(tNode, tIp.c_str(), tMac.c_str(), tDiskSn.c_str(), mConfig.mSiteInfo.c_str());
    return tNode;
}

void FixApiWrapper::createAddr(std::string &addr, const char *ip, const char *port)
{
    StringHelper::string_format(addr, "%s@%s/tcp", ip, port);
}

bool FixApiWrapper::isNetworkError(long errCode)
{
    return (errCode == -610301998 || errCode == -103 || errCode == -104 || errCode == -107);
}

bool FixApiWrapper::verifyMac(const char *mac)
{
    if (strlen(mac) != 12) return false;

    for (int i = 0; i < 12; i++) {
        if (!isdigit(mac[i])) {
            char c = toupper(mac[i]);
            if (c < 'A' || c > 'F')
                return false;
        }
    }
    return true;
}

bool FixApiWrapper::verifyIp(const char *ip)
{
    int sec1 = -1;
    int sec2 = -1;
    int sec3 = -1;
    int sec4 = -1;

    if (sscanf(ip, "%d.%d.%d.%d", &sec1, &sec2, &sec3, &sec4) != 4)
        return false;

    if ((sec1 < 0 || sec1 > 255) ||
        (sec2 < 0 || sec2 > 255) ||
        (sec3 < 0 || sec3 > 255) ||
        (sec4 < 0 || sec4 > 255))
    {
        return false;
    }

    return true;
}

bool FixApiWrapper::verifyDiskSn(const char *disksn)
{
    int len = strlen(disksn);
    for (int i = 0; i < len; ++i) {
        if (!isalnum(disksn[i]))
            return false;
    }
    return true;
}

/*!
 * \brief [601001] 取当前系统时间。
 */
Intf_RetType FixApiWrapper::fixQrySystemTime(const QrySystemTimeInput& input, list<QrySystemTimeOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 601001);

    // 输入业务数据。
    Fix_SetString(session, FID_FLAG, input.FID_FLAG_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQrySystemTime] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QrySystemTimeOutput item;
        item.FID_CODE_STR        = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR     = reader.get(FID_MESSAGE, i);
        item.FID_DATE_STR        = reader.get(FID_DATE, i);
        item.FID_TIME_STR        = reader.get(FID_TIME, i);
        item.FID_WEEK_STR        = reader.get(FID_WEEK, i);
        item.FID_MILLISECOND_STR = reader.get(FID_MILLISECOND, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [601012] 网络心跳检测
 */
Intf_RetType FixApiWrapper::fixHeartBeat(list<HeartBeatOutput>& output, string& errMsg, const string &node){

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 601012);

    // 没有业务数据。

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixHeartBeat] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        HeartBeatOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610104] 查询客户交易节点状态
 */
Intf_RetType FixApiWrapper::fixQryTradeNode(const QryTradeNodeInput& input, list<QryTradeNodeOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610104);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryTradeNode] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryTradeNodeOutput item;
        item.FID_CODE_STR     = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR  = reader.get(FID_MESSAGE, i);
        item.FID_NODEID_STR   = reader.get(FID_NODEID, i);
        item.FID_NODENAME_STR = reader.get(FID_NODENAME, i);
        item.FID_ZT_STR       = reader.get(FID_ZT, i);
        item.FID_DATE_STR     = reader.get(FID_DATE, i);
        item.FID_RQ_STR       = reader.get(FID_RQ, i);
        item.FID_TIME_STR     = reader.get(FID_TIME, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610301] 客户交易密码校验
 */
Intf_RetType FixApiWrapper::fixCheckTradePasswd(const CheckTradePasswdInput& input, list<CheckTradePasswdOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610301);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixCheckTradePasswd] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        CheckTradePasswdOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610303] 修改客户交易密码
 */
Intf_RetType FixApiWrapper::fixChangeTradePasswd(const ChangeTradePasswdInput& input, list<ChangeTradePasswdOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610303);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,   input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_MM,    input.FID_MM_STR.c_str());
    Fix_SetString(session, FID_NEWMM, input.FID_NEWMM_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixChangeTradePasswd] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        ChangeTradePasswdOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610304] 修改客户资金密码
 */
Intf_RetType FixApiWrapper::fixChangeCapPasswd(const ChangeCapPasswdInput& input, list<ChangeCapPasswdOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610304);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,   input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_MM,    input.FID_MM_STR.c_str());
    Fix_SetString(session, FID_NEWMM, input.FID_NEWMM_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixChangeCapPasswd] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        ChangeCapPasswdOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610403] 客户资金调入
 */
Intf_RetType FixApiWrapper::fixTransferInFund(const TransferInFundInput& input, list<TransferInFundOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610403);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_BZ,   input.FID_BZ_STR.c_str());
    Fix_SetString(session, FID_ZJZH, input.FID_ZJZH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_FSJE, input.FID_FSJE_STR.c_str());
    Fix_SetString(session, FID_ZY,   input.FID_ZY_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixTransferInFund] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        TransferInFundOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_LSH_STR     = reader.get(FID_LSH, i);
        item.FID_ZHYE_STR    = reader.get(FID_ZHYE, i);
        item.FID_KYZJ_STR    = reader.get(FID_KYZJ, i);
        item.FID_T2KYZJ_STR  = reader.get(FID_T2KYZJ, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610404] 客户资金调出
 */
Intf_RetType FixApiWrapper::fixTransferOutFund(const TransferOutFundInput& input, list<TransferOutFundOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610404);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_BZ,   input.FID_BZ_STR.c_str());
    Fix_SetString(session, FID_ZJZH, input.FID_ZJZH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_FSJE, input.FID_FSJE_STR.c_str());
    Fix_SetString(session, FID_ZY,   input.FID_ZY_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixTransferOutFund] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        TransferOutFundOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_LSH_STR     = reader.get(FID_LSH, i);
        item.FID_ZHYE_STR    = reader.get(FID_ZHYE, i);
        item.FID_KYZJ_STR    = reader.get(FID_KYZJ, i);
        item.FID_T2KYZJ_STR  = reader.get(FID_T2KYZJ, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610502] 客户证券调入
 */
Intf_RetType FixApiWrapper::fixTransferInSecu(const TransferInSecuInput& input, list<TransferInSecuOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610502);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_ZQDM, input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_FSSL, input.FID_FSSL_STR.c_str());
    Fix_SetString(session, FID_ZY,   input.FID_ZY_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixTransferInSecu] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        TransferInSecuOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_LSH_STR     = reader.get(FID_LSH, i);
        item.FID_JCCL_STR    = reader.get(FID_JCCL, i);
        item.FID_KMCSL_STR   = reader.get(FID_KMCSL, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [610503] 客户证券调出
 */
Intf_RetType FixApiWrapper::fixTransferOutSecu(const TransferOutSecuInput& input, list<TransferOutSecuOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 610503);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_ZQDM, input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_FSSL, input.FID_FSSL_STR.c_str());
    Fix_SetString(session, FID_ZY,   input.FID_ZY_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixTransferOutSecu] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        TransferOutSecuOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_LSH_STR     = reader.get(FID_LSH, i);
        item.FID_JCCL_STR    = reader.get(FID_JCCL, i);
        item.FID_KMCSL_STR   = reader.get(FID_KMCSL, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620001] 证券买卖委托
 */
Intf_RetType FixApiWrapper::fixSecuEntrust(const SecuEntrustInput& input, list<SecuEntrustOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620001);

    // 输入业务数据。
    Fix_SetString(session, FID_GDH,   input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYMM,  input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,   input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_KHH,   input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_WTJG,  input.FID_WTJG_STR.c_str());
    Fix_SetString(session, FID_WTLB,  input.FID_WTLB_STR.c_str());
    Fix_SetString(session, FID_WTSL,  input.FID_WTSL_STR.c_str());
    Fix_SetString(session, FID_ZQDM,  input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_DDLX,  input.FID_DDLX_STR.c_str());
    Fix_SetString(session, FID_WTPCH, input.FID_WTPCH_STR.c_str());
    Fix_SetString(session, FID_DFXW,  input.FID_DFXW_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixSecuEntrust] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        SecuEntrustOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_WTH_STR     = reader.get(FID_WTH, i);
        item.FID_WTPCH_STR   = reader.get(FID_WTPCH, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620002] 批量买卖委托
 */
Intf_RetType FixApiWrapper::fixBatchSecuEntrust(const BatchSecuEntrustInput& input, list<BatchSecuEntrustOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620002);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM,    input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,     input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_COUNT,   input.FID_COUNT_STR.c_str());
    Fix_SetString(session, FID_FJXX,    input.FID_FJXX_STR.c_str());
    Fix_SetString(session, FID_LOGICAL, input.FID_LOGICAL_STR.c_str());
    Fix_SetString(session, FID_WTPCH,   input.FID_WTPCH_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixBatchSecuEntrust] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        BatchSecuEntrustOutput item;
        item.FID_CODE_STR     = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR  = reader.get(FID_MESSAGE, i);
        item.FID_EN_WTH_STR   = reader.get(FID_EN_WTH, i);
        item.FID_WTPCH_STR    = reader.get(FID_WTPCH, i);
        item.FID_COUNT_STR    = reader.get(FID_COUNT, i);
        item.FID_MEMCOUNT_STR = reader.get(FID_MEMCOUNT, i);
        item.FID_ROWCOUNT_STR = reader.get(FID_ROWCOUNT, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620011] 可买卖数量计算
 */
Intf_RetType FixApiWrapper::fixQryTradableVol(const QryTradableVolInput& input, list<QryTradableVolOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620011);

    // 输入业务数据。
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_WTLB, input.FID_WTLB_STR.c_str());
    Fix_SetString(session, FID_ZQDM, input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_DDLX, input.FID_DDLX_STR.c_str());
    Fix_SetString(session, FID_WTFS, input.FID_WTFS_STR.c_str());
    Fix_SetString(session, FID_WTJG, input.FID_WTJG_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryTradableVol] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryTradableVolOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_WTSL_STR    = reader.get(FID_WTSL, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620012] 大约可买入ETF股票篮数计算
 */
Intf_RetType FixApiWrapper::fixQryBuyableEtfSecuBacketCnt(const QryBuyableEtfSecuBacketCntInput& input, list<QryBuyableEtfSecuBacketCntOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620012);

    // 输入业务数据。
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_ZQDM, input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_WTFS, input.FID_WTFS_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryBuyableEtfSecuBacketCnt] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryBuyableEtfSecuBacketCntOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_WTSL_STR    = reader.get(FID_WTSL, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620013] 个股期权非交易可加解锁数量计算
 */
Intf_RetType FixApiWrapper::fixQryLockableOptionsCnt(const QryLockableOptionsCntInput& input, list<QryLockableOptionsCntOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620013);

    // 输入业务数据。
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_ZQDM, input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_FLAG, input.FID_FLAG_STR.c_str());
    Fix_SetString(session, FID_WTFS, input.FID_WTFS_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryLockableOptionsCnt] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryLockableOptionsCntOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_WTSL_STR    = reader.get(FID_WTSL, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620021] 证券委托撤单
 */
Intf_RetType FixApiWrapper::fixSecuEntrustWithdraw(const SecuEntrustWithdrawInput& input, list<SecuEntrustWithdrawOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620021);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_WTH,  input.FID_WTH_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixSecuEntrustWithdraw] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        SecuEntrustWithdrawOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_WTH_STR     = reader.get(FID_WTH, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620022] 按委托批次号批量委托撤单
 */
Intf_RetType FixApiWrapper::fixBatchSecuEntrustWithdraw(const BatchSecuEntrustWithdrawInput& input, list<BatchSecuEntrustWithdrawOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620022);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM,   input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,    input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_EN_WTH, input.FID_EN_WTH_STR.c_str());
    Fix_SetString(session, FID_WTPCH,  input.FID_WTPCH_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixBatchSecuEntrustWithdraw] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        BatchSecuEntrustWithdrawOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_WTPCH_STR   = reader.get(FID_WTPCH, i);
        item.FID_COUNT_STR   = reader.get(FID_COUNT, i);
        item.FID_EN_WTH_STR  = reader.get(FID_EN_WTH, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [620031] 个股期权非交易加解锁
 */
Intf_RetType FixApiWrapper::fixOptionsLockOps(const OptionsLockOpsInput& input, list<OptionsLockOpsOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 620031);

    // 输入业务数据。
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_ZQDM, input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_FLAG, input.FID_FLAG_STR.c_str());
    Fix_SetString(session, FID_WTSL, input.FID_WTSL_STR.c_str());
    Fix_SetString(session, FID_ZQSL, input.FID_ZQSL_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixOptionsLockOps] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        OptionsLockOpsOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630001] 查询客户基本信息
 */
Intf_RetType FixApiWrapper::fixQryClientInfo(const QryClientInfoInput& input, list<QryClientInfoOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630001);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientInfo] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientInfoOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_DH_STR      = reader.get(FID_DH, i);
        item.FID_KHH_STR     = reader.get(FID_KHH, i);
        item.FID_KHXM_STR    = reader.get(FID_KHXM, i);
        item.FID_ZJBH_STR    = reader.get(FID_ZJBH, i);
        item.FID_ZJLB_STR    = reader.get(FID_ZJLB, i);
        item.FID_JGDM_STR    = reader.get(FID_JGDM, i);
        item.FID_JGBZ_STR    = reader.get(FID_JGBZ, i);
        item.FID_MOBILE_STR  = reader.get(FID_MOBILE, i);
        item.FID_WTFS_STR    = reader.get(FID_WTFS, i);
        item.FID_KHSX_STR    = reader.get(FID_KHSX, i);
        item.FID_KHZT_STR    = reader.get(FID_KHZT, i);
        item.FID_MMTB_STR    = reader.get(FID_MMTB, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630002] 查询客户资金信息
 */
Intf_RetType FixApiWrapper::fixQryClientFund(const QryClientFundInput& input, list<QryClientFundOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630002);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,   input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM,  input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_EXFLG, input.FID_EXFLG_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientFund] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientFundOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_BZ_STR      = reader.get(FID_BZ, i);
        item.FID_KYZJ_STR    = reader.get(FID_KYZJ, i);
        item.FID_T2KYZJ_STR  = reader.get(FID_T2KYZJ, i);
        item.FID_YJLX_STR    = reader.get(FID_YJLX, i);
        item.FID_ZHYE_STR    = reader.get(FID_ZHYE, i);
        item.FID_ZHZT_STR    = reader.get(FID_ZHZT, i);
        item.FID_ZJZH_STR    = reader.get(FID_ZJZH, i);
        item.FID_DJJE_STR    = reader.get(FID_DJJE, i);
        item.FID_T2DJJE_STR  = reader.get(FID_T2DJJE, i);
        item.FID_JGDM_STR    = reader.get(FID_JGDM, i);
        item.FID_ZZC_STR     = reader.get(FID_ZZC, i);
        item.FID_ZQSZ_STR    = reader.get(FID_ZQSZ, i);
        item.FID_FZJE_STR    = reader.get(FID_FZJE, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630003] 查询客户股东账户信息
 */
Intf_RetType FixApiWrapper::fixQryClientStkAcct(const QryClientStkAcctInput& input, list<QryClientStkAcctOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630003);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientStkAcct] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientStkAcctOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_GDH_STR     = reader.get(FID_GDH, i);
        item.FID_GDZDSX_STR  = reader.get(FID_GDZDSX, i);
        item.FID_JYQX_STR    = reader.get(FID_JYQX, i);
        item.FID_JYS_STR     = reader.get(FID_JYS, i);
        item.FID_GDZT_STR    = reader.get(FID_GDZT, i);
        item.FID_ZJZH_STR    = reader.get(FID_ZJZH, i);
        item.FID_ZZHBZ_STR   = reader.get(FID_ZZHBZ, i);
        item.FID_GDKZSX_STR  = reader.get(FID_GDKZSX, i);
        item.FID_JGDM_STR    = reader.get(FID_JGDM, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630004] 查询客户持仓
 */
Intf_RetType FixApiWrapper::fixQryClientPosition(const QryClientPositionInput& input, list<QryClientPositionOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630004);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_GDH,       input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYS,       input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_ZQDM,      input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_EXFLG,     input.FID_EXFLG_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());
    Fix_SetString(session, FID_FLAG,      input.FID_FLAG_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientPosition] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientPositionOutput item;
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_BZ_STR        = reader.get(FID_BZ, i);
        item.FID_DRMCCJJE_STR  = reader.get(FID_DRMCCJJE, i);
        item.FID_DRMCCJSL_STR  = reader.get(FID_DRMCCJSL, i);
        item.FID_DRMCWTSL_STR  = reader.get(FID_DRMCWTSL, i);
        item.FID_DRMRCJJE_STR  = reader.get(FID_DRMRCJJE, i);
        item.FID_DRMRCJSL_STR  = reader.get(FID_DRMRCJSL, i);
        item.FID_DRMRWTSL_STR  = reader.get(FID_DRMRWTSL, i);
        item.FID_FLTSL_STR     = reader.get(FID_FLTSL, i);
        item.FID_GDH_STR       = reader.get(FID_GDH, i);
        item.FID_JYS_STR       = reader.get(FID_JYS, i);
        item.FID_KCRQ_STR      = reader.get(FID_KCRQ, i);
        item.FID_KMCSL_STR     = reader.get(FID_KMCSL, i);
        item.FID_ZQDM_STR      = reader.get(FID_ZQDM, i);
        item.FID_ZQLB_STR      = reader.get(FID_ZQLB, i);
        item.FID_ZQMC_STR      = reader.get(FID_ZQMC, i);
        item.FID_ZQSL_STR      = reader.get(FID_ZQSL, i);
        item.FID_JCCL_STR      = reader.get(FID_JCCL, i);
        item.FID_WJSSL_STR     = reader.get(FID_WJSSL, i);
        item.FID_BDRQ_STR      = reader.get(FID_BDRQ, i);
        item.FID_KSGSL_STR     = reader.get(FID_KSGSL, i);
        item.FID_KSHSL_STR     = reader.get(FID_KSHSL, i);
        item.FID_DJSL_STR      = reader.get(FID_DJSL, i);
        item.FID_MCDXSL_STR    = reader.get(FID_MCDXSL, i);
        item.FID_MRDXSL_STR    = reader.get(FID_MRDXSL, i);
        item.FID_SGCJSL_STR    = reader.get(FID_SGCJSL, i);
        item.FID_SHCJSL_STR    = reader.get(FID_SHCJSL, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        item.FID_JYDW_STR      = reader.get(FID_JYDW, i);
        item.FID_MCSL_STR      = reader.get(FID_MCSL, i);
        item.FID_MRSL_STR      = reader.get(FID_MRSL, i);
        item.FID_PGSL_STR      = reader.get(FID_PGSL, i);
        item.FID_SGSL_STR      = reader.get(FID_SGSL, i);
        item.FID_TBFDYK_STR    = reader.get(FID_TBFDYK, i);
        item.FID_TBBBJ_STR     = reader.get(FID_TBBBJ, i);
        item.FID_TBCBJ_STR     = reader.get(FID_TBCBJ, i);
        item.FID_CCJJ_STR      = reader.get(FID_CCJJ, i);
        item.FID_FDYK_STR      = reader.get(FID_FDYK, i);
        item.FID_HLJE_STR      = reader.get(FID_HLJE, i);
        item.FID_LJYK_STR      = reader.get(FID_LJYK, i);
        item.FID_MCJE_STR      = reader.get(FID_MCJE, i);
        item.FID_MRJE_STR      = reader.get(FID_MRJE, i);
        item.FID_MRJJ_STR      = reader.get(FID_MRJJ, i);
        item.FID_PGJE_STR      = reader.get(FID_PGJE, i);
        item.FID_ZXSZ_STR      = reader.get(FID_ZXSZ, i);
        item.FID_BBJ_STR       = reader.get(FID_BBJ, i);
        item.FID_ZXJ_STR       = reader.get(FID_ZXJ, i);
        item.FID_GPSZ_STR      = reader.get(FID_GPSZ, i);
        item.FID_LXBJ_STR      = reader.get(FID_LXBJ, i);
        item.FID_ZSP_STR       = reader.get(FID_ZSP, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630005] 查询客户当日委托
 */
Intf_RetType FixApiWrapper::fixQryClientEntrustToday(const QryClientEntrustTodayInput& input, list<QryClientEntrustTodayOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630005);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_JYS,       input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_GDH,       input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_WTH,       input.FID_WTH_STR.c_str());
    Fix_SetString(session, FID_WTLB,      input.FID_WTLB_STR.c_str());
    Fix_SetString(session, FID_ZQDM,      input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_WTPCH,     input.FID_WTPCH_STR.c_str());
    Fix_SetString(session, FID_FLAG,      input.FID_FLAG_STR.c_str());
    Fix_SetString(session, FID_CXBZ,      input.FID_CXBZ_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientEntrustToday] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientEntrustTodayOutput item;
        item.FID_BPGDH_STR     = reader.get(FID_BPGDH, i);
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_BZ_STR        = reader.get(FID_BZ, i);
        item.FID_CJJE_STR      = reader.get(FID_CJJE, i);
        item.FID_CJJG_STR      = reader.get(FID_CJJG, i);
        item.FID_CJSJ_STR      = reader.get(FID_CJSJ, i);
        item.FID_CJSL_STR      = reader.get(FID_CJSL, i);
        item.FID_GDH_STR       = reader.get(FID_GDH, i);
        item.FID_JYS_STR       = reader.get(FID_JYS, i);
        item.FID_QSZJ_STR      = reader.get(FID_QSZJ, i);
        item.FID_WTFS_STR      = reader.get(FID_WTFS, i);
        item.FID_WTH_STR       = reader.get(FID_WTH, i);
        item.FID_WTJG_STR      = reader.get(FID_WTJG, i);
        item.FID_WTLB_STR      = reader.get(FID_WTLB, i);
        item.FID_WTSL_STR      = reader.get(FID_WTSL, i);
        item.FID_ZQDM_STR      = reader.get(FID_ZQDM, i);
        item.FID_ZQLB_STR      = reader.get(FID_ZQLB, i);
        item.FID_ZQMC_STR      = reader.get(FID_ZQMC, i);
        item.FID_WTSJ_STR      = reader.get(FID_WTSJ, i);
        item.FID_SBSJ_STR      = reader.get(FID_SBSJ, i);
        item.FID_SBJG_STR      = reader.get(FID_SBJG, i);
        item.FID_CXBZ_STR      = reader.get(FID_CXBZ, i);
        item.FID_DJZJ_STR      = reader.get(FID_DJZJ, i);
        item.FID_ZJZH_STR      = reader.get(FID_ZJZH, i);
        item.FID_JGSM_STR      = reader.get(FID_JGSM, i);
        item.FID_CDSL_STR      = reader.get(FID_CDSL, i);
        item.FID_SBWTH_STR     = reader.get(FID_SBWTH, i);
        item.FID_DDLX_STR      = reader.get(FID_DDLX, i);
        item.FID_WTPCH_STR     = reader.get(FID_WTPCH, i);
        item.FID_ZJDJLSH_STR   = reader.get(FID_ZJDJLSH, i);
        item.FID_ZQDJLSH_STR   = reader.get(FID_ZQDJLSH, i);
        item.FID_SBRQ_STR      = reader.get(FID_SBRQ, i);
        item.FID_SBJLH_STR     = reader.get(FID_SBJLH, i);
        item.FID_WTRQ_STR      = reader.get(FID_WTRQ, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        item.FID_ADDR_IP_STR   = reader.get(FID_ADDR_IP, i);
        item.FID_ADDR_MAC_STR  = reader.get(FID_ADDR_MAC, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630006] 查询客户分笔成交
 */
Intf_RetType FixApiWrapper::fixQryClientTickDeal(const QryClientTickDealInput& input, list<QryClientTickDealOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630006);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_GDH,       input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYS,       input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_WTH,       input.FID_WTH_STR.c_str());
    Fix_SetString(session, FID_WTLB,      input.FID_WTLB_STR.c_str());
    Fix_SetString(session, FID_ZQDM,      input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_WTPCH,     input.FID_WTPCH_STR.c_str());
    Fix_SetString(session, FID_FLAG,      input.FID_FLAG_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());
    Fix_SetString(session, FID_HBXH,      input.FID_HBXH_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientTickDeal] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientTickDealOutput item;
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_BZ_STR        = reader.get(FID_BZ, i);
        item.FID_CJBH_STR      = reader.get(FID_CJBH, i);
        item.FID_CJJE_STR      = reader.get(FID_CJJE, i);
        item.FID_CJJG_STR      = reader.get(FID_CJJG, i);
        item.FID_CJSL_STR      = reader.get(FID_CJSL, i);
        item.FID_GDH_STR       = reader.get(FID_GDH, i);
        item.FID_JYS_STR       = reader.get(FID_JYS, i);
        item.FID_QSJE_STR      = reader.get(FID_QSJE, i);
        item.FID_WTH_STR       = reader.get(FID_WTH, i);
        item.FID_WTLB_STR      = reader.get(FID_WTLB, i);
        item.FID_ZJZH_STR      = reader.get(FID_ZJZH, i);
        item.FID_ZQDM_STR      = reader.get(FID_ZQDM, i);
        item.FID_ZQLB_STR      = reader.get(FID_ZQLB, i);
        item.FID_ZQMC_STR      = reader.get(FID_ZQMC, i);
        item.FID_CXBZ_STR      = reader.get(FID_CXBZ, i);
        item.FID_S1_STR        = reader.get(FID_S1, i);
        item.FID_HBXH_STR      = reader.get(FID_HBXH, i);
        item.FID_LXBJ_STR      = reader.get(FID_LXBJ, i);
        item.FID_SBWTH_STR     = reader.get(FID_SBWTH, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        item.FID_WTPCH_STR     = reader.get(FID_WTPCH, i);
        item.FID_LX_STR        = reader.get(FID_LX, i);
        item.FID_CJSJ_STR      = reader.get(FID_CJSJ, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630007] 查询客户实时成交
 */
Intf_RetType FixApiWrapper::fixQryClientRealTimeDeal(const QryClientRealTimeDealInput& input, list<QryClientRealTimeDealOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630007);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_GDH,       input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYS,       input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_ZQDM,      input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_WTPCH,     input.FID_WTPCH_STR.c_str());
    Fix_SetString(session, FID_WTLB,      input.FID_WTLB_STR.c_str());
    Fix_SetString(session, FID_WTH,       input.FID_WTH_STR.c_str());
    Fix_SetString(session, FID_FLAG,      input.FID_FLAG_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientRealTimeDeal] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientRealTimeDealOutput item;
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_WTH_STR       = reader.get(FID_WTH, i);
        item.FID_SBWTH_STR     = reader.get(FID_SBWTH, i);
        item.FID_JYS_STR       = reader.get(FID_JYS, i);
        item.FID_GDH_STR       = reader.get(FID_GDH, i);
        item.FID_WTLB_STR      = reader.get(FID_WTLB, i);
        item.FID_CXBZ_STR      = reader.get(FID_CXBZ, i);
        item.FID_ZQDM_STR      = reader.get(FID_ZQDM, i);
        item.FID_ZQMC_STR      = reader.get(FID_ZQMC, i);
        item.FID_WTSL_STR      = reader.get(FID_WTSL, i);
        item.FID_WTJG_STR      = reader.get(FID_WTJG, i);
        item.FID_CDSL_STR      = reader.get(FID_CDSL, i);
        item.FID_CJSL_STR      = reader.get(FID_CJSL, i);
        item.FID_CJJE_STR      = reader.get(FID_CJJE, i);
        item.FID_CJJG_STR      = reader.get(FID_CJJG, i);
        item.FID_CJSJ_STR      = reader.get(FID_CJSJ, i);
        item.FID_BZ_STR        = reader.get(FID_BZ, i);
        item.FID_ZJZH_STR      = reader.get(FID_ZJZH, i);
        item.FID_QSZJ_STR      = reader.get(FID_QSZJ, i);
        item.FID_WTPCH_STR     = reader.get(FID_WTPCH, i);
        item.FID_DDLX_STR      = reader.get(FID_DDLX, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630010] 查询客户资金冻结明细
 */
Intf_RetType FixApiWrapper::fixQryClientFrozenFundInfo(const QryClientFrozenFundInfoInput& input, list<QryClientFrozenFundInfoOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630010);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_BZ,        input.FID_BZ_STR.c_str());
    Fix_SetString(session, FID_DJLB,      input.FID_DJLB_STR.c_str());
    Fix_SetString(session, FID_ZJZH,      input.FID_ZJZH_STR.c_str());
    Fix_SetString(session, FID_LSH,       input.FID_LSH_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientFrozenFundInfo] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientFrozenFundInfoOutput item;
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_BZ_STR        = reader.get(FID_BZ, i);
        item.FID_DJLB_STR      = reader.get(FID_DJLB, i);
        item.FID_KHH_STR       = reader.get(FID_KHH, i);
        item.FID_KHXM_STR      = reader.get(FID_KHXM, i);
        item.FID_ZJZH_STR      = reader.get(FID_ZJZH, i);
        item.FID_ZY_STR        = reader.get(FID_ZY, i);
        item.FID_LSH_STR       = reader.get(FID_LSH, i);
        item.FID_FSJE_STR      = reader.get(FID_FSJE, i);
        item.FID_FSSJ_STR      = reader.get(FID_FSSJ, i);
        item.FID_JGDM_STR      = reader.get(FID_JGDM, i);
        item.FID_FSRQ_STR      = reader.get(FID_FSRQ, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630011] 查询客户证券冻结明细
 */
Intf_RetType FixApiWrapper::fixQryClientFrozenSecuInfo(const QryClientFrozenSecuInfoInput& input, list<QryClientFrozenSecuInfoOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630011);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_DJLB,      input.FID_DJLB_STR.c_str());
    Fix_SetString(session, FID_GDH,       input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYS,       input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_ZQDM,      input.FID_ZQDM_STR.c_str());
    Fix_SetString(session, FID_LSH,       input.FID_LSH_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientFrozenSecuInfo] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientFrozenSecuInfoOutput item;
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_DJLB_STR      = reader.get(FID_DJLB, i);
        item.FID_GDH_STR       = reader.get(FID_GDH, i);
        item.FID_JYS_STR       = reader.get(FID_JYS, i);
        item.FID_KHH_STR       = reader.get(FID_KHH, i);
        item.FID_KHXM_STR      = reader.get(FID_KHXM, i);
        item.FID_ZQDM_STR      = reader.get(FID_ZQDM, i);
        item.FID_ZQLB_STR      = reader.get(FID_ZQLB, i);
        item.FID_ZQMC_STR      = reader.get(FID_ZQMC, i);
        item.FID_ZY_STR        = reader.get(FID_ZY, i);
        item.FID_LSH_STR       = reader.get(FID_LSH, i);
        item.FID_FSSJ_STR      = reader.get(FID_FSSJ, i);
        item.FID_JGDM_STR      = reader.get(FID_JGDM, i);
        item.FID_FSRQ_STR      = reader.get(FID_FSRQ, i);
        item.FID_FSSL_STR      = reader.get(FID_FSSL, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630012] 查询客户资金调拨明细
 */
Intf_RetType FixApiWrapper::fixQryClientFundJour(const QryClientFundJourInput& input, list<QryClientFundJourOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630012);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_BZ,        input.FID_BZ_STR.c_str());
    Fix_SetString(session, FID_DJLB,      input.FID_DJLB_STR.c_str());
    Fix_SetString(session, FID_ZJZH,      input.FID_ZJZH_STR.c_str());
    Fix_SetString(session, FID_LSH,       input.FID_LSH_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientFundJour] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientFundJourOutput item;
        item.FID_CODE_STR      = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR   = reader.get(FID_MESSAGE, i);
        item.FID_BZ_STR        = reader.get(FID_BZ, i);
        item.FID_DJLB_STR      = reader.get(FID_DJLB, i);
        item.FID_KHH_STR       = reader.get(FID_KHH, i);
        item.FID_KHXM_STR      = reader.get(FID_KHXM, i);
        item.FID_ZJZH_STR      = reader.get(FID_ZJZH, i);
        item.FID_ZY_STR        = reader.get(FID_ZY, i);
        item.FID_LSH_STR       = reader.get(FID_LSH, i);
        item.FID_FSJE_STR      = reader.get(FID_FSJE, i);
        item.FID_FSSJ_STR      = reader.get(FID_FSSJ, i);
        item.FID_JGDM_STR      = reader.get(FID_JGDM, i);
        item.FID_FSRQ_STR      = reader.get(FID_FSRQ, i);
        item.FID_BROWINDEX_STR = reader.get(FID_BROWINDEX, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630018] 查询客户证券调拨明细
 */
Intf_RetType FixApiWrapper::fixQryClientSecuJour(const QryClientSecuJourInput& input, list<QryClientSecuJourOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630018);

    // 输入业务数据。
    Fix_SetString(session, FID_JYMM,      input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_KHH,       input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYS,       input.FID_JYS_STR.c_str());
    Fix_SetString(session, FID_DJLB,      input.FID_DJLB_STR.c_str());
    Fix_SetString(session, FID_GDH,       input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_LSH,       input.FID_LSH_STR.c_str());
    Fix_SetString(session, FID_BROWINDEX, input.FID_BROWINDEX_STR.c_str());
    Fix_SetString(session, FID_ROWCOUNT,  input.FID_ROWCOUNT_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientSecuJour] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientSecuJourOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_KHH_STR     = reader.get(FID_KHH, i);
        item.FID_KHXM_STR    = reader.get(FID_KHXM, i);
        item.FID_JYS_STR     = reader.get(FID_JYS, i);
        item.FID_DJLB_STR    = reader.get(FID_DJLB, i);
        item.FID_GDH_STR     = reader.get(FID_GDH, i);
        item.FID_ZQDM_STR    = reader.get(FID_ZQDM, i);
        item.FID_LSH_STR     = reader.get(FID_LSH, i);
        item.FID_FSSL_STR    = reader.get(FID_FSSL, i);
        item.FID_FSSJ_STR    = reader.get(FID_FSSJ, i);
        item.FID_JGDM_STR    = reader.get(FID_JGDM, i);
        item.FID_FSRQ_STR    = reader.get(FID_FSRQ, i);
        item.FID_ZY_STR      = reader.get(FID_ZY, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}
/*!
 * \brief [630019] 查询客户配售权益
 */
Intf_RetType FixApiWrapper::fixQryClientRationEquity(const QryClientRationEquityInput& input, list<QryClientRationEquityOutput>& output, string& errMsg, const string &node){
    fixLogger() << input;

    Intf_RetType result = kIntfSuccess;
    // 检查连接情况。
    if (!isConnected()) return kIntfDisconnect;

    output.clear();
    errMsg.clear();

    // 创建新的业务会话。
    HANDLE_SESSION session = Fix_AllocateSession(mConnection);

    Fix_SetTimeOut(session, mConfig.mTimeout);
    Fix_SetNode(session, node.c_str());
    Fix_SetWTFS(session, mConfig.mEntrustMode.c_str());

    Fix_CreateReq(session, 630019);

    // 输入业务数据。
    Fix_SetString(session, FID_KHH,  input.FID_KHH_STR.c_str());
    Fix_SetString(session, FID_JYMM, input.FID_JYMM_STR.c_str());
    Fix_SetString(session, FID_GDH,  input.FID_GDH_STR.c_str());
    Fix_SetString(session, FID_JYS,  input.FID_JYS_STR.c_str());

    // 提交业务数据，并等待全部的业务结果返回。
    if (!Fix_Run(session)) {
        result = checkSessionError(session, errMsg);
        Fix_ReleaseSession(session);
        return result;
    }

    result = checkSessionError(session, errMsg);
    if (result != kIntfSuccess) {
        std::cerr << "[ddvip] [fixQryClientRationEquity] errMsg: " << errMsg << std::endl;
    } else {
        errMsg.assign("业务操作成功。");
    }

    // 依次读取回复数据。
    int count = Fix_GetCount(session);
    FixReader reader(session);
    for (int i = 0; i < count; i++) {
        QryClientRationEquityOutput item;
        item.FID_CODE_STR    = reader.get(FID_CODE, i);
        item.FID_MESSAGE_STR = reader.get(FID_MESSAGE, i);
        item.FID_KHH_STR     = reader.get(FID_KHH, i);
        item.FID_GDH_STR     = reader.get(FID_GDH, i);
        item.FID_JYS_STR     = reader.get(FID_JYS, i);
        item.FID_ZQSL_STR    = reader.get(FID_ZQSL, i);
        fixLogger() << item;
        output.push_back(item);
    }
    Fix_ReleaseSession(session);
    return result;
}

void FixApiWrapper::resubscribe()
{
    fixInfo << "[ddvip] FixApiWrapper::resubscribe() start.";
    FixSubManager::Instance().invalidate();
    std::vector<SubCallback*> subItems = FixSubManager::Instance().subItems();
    for (SubCallback* item : subItems) {
        SubscribeInput subIn;
        subIn.FID_KHH_STR  = item->FID_KHH_STR;
        subIn.FID_JYMM_STR = item->FID_JYMM_STR;

        SubscribeOutput subOut;
        fixSubSecuBargainInfo(subIn, subOut, item->subSecuBargainInfo.subCallback, this);
        fixSubSecuEntrustAckInfo(subIn, subOut, item->subSecuEntrustAckInfo.subCallback, this);
        fixSubSecuEntrustWithdrawAckInfo(subIn, subOut, item->subSecuEntrustWithdrawAckInfo.subCallback, this);
    }
    fixInfo << "[ddvip] FixApiWrapper::resubscribe() finish.";
}

/*!
 * \brief [100064] 委托成交消息订阅接口。
 */
long FixApiWrapper::fixSubSecuBargainInfo(const SubscribeInput &input, SubscribeOutput &output, void* callback, void *reserve)
{
    bool newItem = false;
    SubCallback* item = FixSubManager::Instance().getSubCallback(input.FID_KHH_STR);
    if (!item) {
        item = new SubCallback;
        item->FID_KHH_STR  = input.FID_KHH_STR;
        item->FID_JYMM_STR = input.FID_JYMM_STR;
        newItem = true;
    }

    item->subSecuBargainInfo.subHandle   = Fix_MDBSubscibeByCustomer(mConnection, 100064, callback, &item,
                                                                     input.FID_KHH_STR.c_str(), input.FID_JYMM_STR.c_str());
    item->subSecuBargainInfo.subCallback = callback;
    item->subSecuBargainInfo.subReserve  = reserve;

    if (item->subSecuBargainInfo.subHandle < 0) {
        if (newItem) {
            long handle = item->subSecuBargainInfo.subHandle;
            delete item;
            return handle;
        }
        fixError << "[fix] 委托成交消息订阅失败。";
    }

    if (newItem) {
        FixSubManager::Instance().addSubItem(item);
    }

    return item->subSecuBargainInfo.subHandle;
}
/*!
 * \brief [100065] 委托申报确认消息订阅接口。
 */
long FixApiWrapper::fixSubSecuEntrustAckInfo(const SubscribeInput &input, SubscribeOutput &output, void* callback, void *reserve)
{
    bool newItem = false;
    SubCallback* item = FixSubManager::Instance().getSubCallback(input.FID_KHH_STR);
    if (!item) {
        item = new SubCallback;
        item->FID_KHH_STR  = input.FID_KHH_STR;
        item->FID_JYMM_STR = input.FID_JYMM_STR;
        newItem = true;
    }

    item->subSecuEntrustAckInfo.subHandle   = Fix_MDBSubscibeByCustomer(mConnection, 100065, callback, &item,
                                                                        input.FID_KHH_STR.c_str(), input.FID_JYMM_STR.c_str());
    item->subSecuEntrustAckInfo.subCallback = callback;
    item->subSecuEntrustAckInfo.subReserve  = reserve;

    if (item->subSecuEntrustAckInfo.subHandle < 0) {
        if (newItem) {
            long handle = item->subSecuEntrustAckInfo.subHandle;
            delete item;
            return handle;
        }
        fixError << "[fix] 委托成交消息订阅失败。";
    }

    if (newItem) {
        FixSubManager::Instance().addSubItem(item);
    }

    return item->subSecuEntrustAckInfo.subHandle;
}
/*!
 * \brief [100066] 委托撤单确认消息订阅接口。
 */
long FixApiWrapper::fixSubSecuEntrustWithdrawAckInfo(const SubscribeInput &input, SubscribeOutput &output, void* callback, void* reserve)
{
    bool newItem = false;
    SubCallback* item = FixSubManager::Instance().getSubCallback(input.FID_KHH_STR);
    if (!item) {
        item = new SubCallback;
        item->FID_KHH_STR  = input.FID_KHH_STR;
        item->FID_JYMM_STR = input.FID_JYMM_STR;
        newItem = true;
    }

    item->subSecuEntrustWithdrawAckInfo.subHandle   = Fix_MDBSubscibeByCustomer(mConnection, 100066, callback, &item,
                                                                                input.FID_KHH_STR.c_str(), input.FID_JYMM_STR.c_str());
    item->subSecuEntrustWithdrawAckInfo.subCallback = callback;
    item->subSecuEntrustWithdrawAckInfo.subReserve  = reserve;

    if (item->subSecuEntrustAckInfo.subHandle < 0) {
        if (newItem) {
            long handle = item->subSecuEntrustWithdrawAckInfo.subHandle;
            delete item;
            return handle;
        }
        fixError << "[fix] 委托成交消息订阅失败。";
    }

    if (newItem) {
        FixSubManager::Instance().addSubItem(item);
    }

    return item->subSecuEntrustWithdrawAckInfo.subHandle;
}

bool FixApiWrapper::fixUnsubscribe(long subHandle)
{
    return Fix_UnSubscibeByHandle(subHandle);
}
