///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef FIXACCOUNT_H
#define FIXACCOUNT_H

#include "../AccountManager.h"

class FixTradeAccount : public TradeAccount
{
public:
    std::string exchange_type;
};

typedef FundAccount<FixTradeAccount> FixFundAccount;
typedef Client<FixFundAccount> FixClient;
typedef ClientManager<FixClient> FixClientManager;

#endif // FIXACCOUNT_H
