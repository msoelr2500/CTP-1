///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef STRINGHELPER_H
#define STRINGHELPER_H

#include <string>
#include <vector>

class StringHelper
{
public:
    template<typename ... Args>
    static int string_format(std::string& result, const std::string& format, Args ... args)
    {
        // 为'\0'留出额外的空间。
        size_t size = std::snprintf(nullptr, 0, format.c_str(), args ...) + 1;
        result.resize(size);
        return std::snprintf((char*)result.c_str(), size, format.c_str(), args ...);
    }

    void split(const std::string& src, const std::string& separator, std::vector<std::string>& result);

    bool endsWith(const std::string& src, const std::string& suffix);

    bool startsWith(const std::string& src, const std::string& suffix);
};

#endif // STRINGHELPER_H
