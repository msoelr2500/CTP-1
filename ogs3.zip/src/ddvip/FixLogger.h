///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef FIXLOGGER_H
#define FIXLOGGER_H

#include "../OgsLogger.h"
#include "FixApiWrapper.h"
#include "FixSubManager.h"
#include <iostream>

#define fixLogger ogsLogger
#define fixDebug ogsDebug
#define fixInfo ogsInfo
#define fixError ogsError

OgsLogger& operator << (OgsLogger& logger, const QrySystemTimeInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySystemTimeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const HeartBeatOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryTradeNodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryTradeNodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const CheckTradePasswdInput& data);
OgsLogger& operator << (OgsLogger& logger, const CheckTradePasswdOutput& data);
OgsLogger& operator << (OgsLogger& logger, const ChangeTradePasswdInput& data);
OgsLogger& operator << (OgsLogger& logger, const ChangeTradePasswdOutput& data);
OgsLogger& operator << (OgsLogger& logger, const ChangeCapPasswdInput& data);
OgsLogger& operator << (OgsLogger& logger, const ChangeCapPasswdOutput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferInFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferInFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferOutFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferOutFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferInSecuInput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferInSecuOutput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferOutSecuInput& data);
OgsLogger& operator << (OgsLogger& logger, const TransferOutSecuOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryTradableVolInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryTradableVolOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryBuyableEtfSecuBacketCntInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryBuyableEtfSecuBacketCntOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryLockableOptionsCntInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryLockableOptionsCntOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const BatchSecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsLockOpsInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsLockOpsOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientPositionInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientPositionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientEntrustTodayInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientEntrustTodayOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientTickDealInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientTickDealOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRealTimeDealInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRealTimeDealOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenFundInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenFundInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenSecuInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFrozenSecuInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFundJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFundJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientSecuJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientSecuJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRationEquityInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRationEquityOutput& data);

/// ------------------------ subscribe ------------------ ///

OgsLogger& operator << (OgsLogger& logger, const SecuBargainInfo& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustAckInfo& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawAckInfo& data);

#endif // FIXLOGGER_H
