///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "DdImpl.h"
#include "../OgsApi.h"
#include "../ReadConfig.h"
#include "../StringHelper.h"
#include "../OrderStage.h"
#include <functional>
#include <algorithm>
#include "FixReader.h"
#include "FixConverter.h"
#include "FixLogger.h"

using std::cout;
using std::cin;
using std::endl;
using std::cerr;
using std::string;
using std::list;
using std::vector;
using std::find;

using ogs::PackBuffer;
using ogs::UnpackBuffer;
using ogs::ReadConfig;

FixClientManager DdImpl::mClients;

bool fixSecuBargainCallback(long connection, long session, long nSubs, void *pData)
{
    DdImpl* impl = (DdImpl*)((SubCallback*)pData)->subSecuBargainInfo.subReserve;
    FixReader reader(session);

    SecuBargainInfo info;
    info.FID_QRBZ_STR  = reader.get(FID_QRBZ);
    info.FID_GDH_STR   = reader.get(FID_GDH);
    info.FID_JYS_STR   = reader.get(FID_JYS);
    info.FID_BZ_STR    = reader.get(FID_BZ);
    info.FID_ZQDM_STR  = reader.get(FID_ZQDM);
    info.FID_ZQLB_STR  = reader.get(FID_ZQLB);
    info.FID_WTSL_STR  = reader.get(FID_WTSL);
    info.FID_CDSL_STR  = reader.get(FID_CDSL);
    info.FID_CXBZ_STR  = reader.get(FID_CXBZ);
    info.FID_WTH_STR   = reader.get(FID_WTH);
    info.FID_WTLB_STR  = reader.get(FID_WTLB);
    info.FID_WTPCH_STR = reader.get(FID_WTPCH);
    info.FID_CXBZ_STR  = reader.get(FID_CXBZ);
    info.FID_CJBH_STR  = reader.get(FID_CJBH);
    info.FID_CJSJ_STR  = reader.get(FID_CJSJ);
    info.FID_QSZJ_STR  = reader.get(FID_QSZJ);
    info.FID_ZCJSL_STR = reader.get(FID_ZCJSL);
    info.FID_ZCJJE_STR = reader.get(FID_ZCJJE);
    info.FID_CJSL_STR  = reader.get(FID_CJSL);
    info.FID_CJJG_STR  = reader.get(FID_CJJG);
    info.FID_WTJG_STR  = reader.get(FID_WTJG);
    info.FID_CJJE_STR  = reader.get(FID_CJJE);
    fixLogger() << info;

    return impl->subSecuBargainCallback(info, nullptr);
}

bool fixSecuEntrustAckCallback(long connection, long session, long nSubs, void *pData)
{
    DdImpl* impl = (DdImpl*)((SubCallback*)pData)->subSecuEntrustAckInfo.subReserve;
    FixReader reader(session);

    SecuEntrustAckInfo info;
    info.FID_QRBZ_STR  = reader.get(FID_QRBZ);
    info.FID_GDH_STR   = reader.get(FID_GDH);
    info.FID_JYS_STR   = reader.get(FID_JYS);
    info.FID_BZ_STR    = reader.get(FID_BZ);
    info.FID_ZQDM_STR  = reader.get(FID_ZQDM);
    info.FID_ZQLB_STR  = reader.get(FID_ZQLB);
    info.FID_WTSL_STR  = reader.get(FID_WTSL);
    info.FID_CDSL_STR  = reader.get(FID_CDSL);
    info.FID_CXBZ_STR  = reader.get(FID_CXBZ);
    info.FID_DJZJ_STR  = reader.get(FID_DJZJ);
    info.FID_WTH_STR   = reader.get(FID_WTH);
    info.FID_WTLB_STR  = reader.get(FID_WTLB);
    info.FID_SBJG_STR  = reader.get(FID_SBJG);
    info.FID_JGSM_STR  = reader.get(FID_JGSM);
    info.FID_WTPCH_STR = reader.get(FID_WTPCH);
    info.FID_HZSJ_STR  = reader.get(FID_HZSJ);
    fixLogger() << info;

    return impl->subSecuEntrustAckCallback(info, nullptr);
}

bool fixSecuEntrustWithdrawAckCallback(long connection, long session, long nSubs, void *pData)
{
    DdImpl* impl = (DdImpl*)((SubCallback*)pData)->subSecuEntrustWithdrawAckInfo.subReserve;
    FixReader reader(session);

    SecuEntrustWithdrawAckInfo info;
    info.FID_GDH_STR   = reader.get(FID_GDH);
    info.FID_JYS_STR   = reader.get(FID_JYS);
    info.FID_BZ_STR    = reader.get(FID_BZ);
    info.FID_ZQDM_STR  = reader.get(FID_ZQDM);
    info.FID_ZQLB_STR  = reader.get(FID_ZQLB);
    info.FID_WTSL_STR  = reader.get(FID_WTSL);
    info.FID_CDSL_STR  = reader.get(FID_CDSL);
    info.FID_CJSL_STR  = reader.get(FID_CJSL);
    info.FID_CXBZ_STR  = reader.get(FID_CXBZ);
    info.FID_DJZJ_STR  = reader.get(FID_DJZJ);
    info.FID_WTH_STR   = reader.get(FID_WTH);
    info.FID_WTLB_STR  = reader.get(FID_WTLB);
    info.FID_WTPCH_STR = reader.get(FID_WTPCH);
    info.FID_HZSJ_STR  = reader.get(FID_HZSJ);
    fixLogger() << info;

    return impl->subSecuEntrustWithdrawAckCallback(info, nullptr);
}

DdImpl::DdImpl()
{
    FixConfig config;

    //! \todo 添加多线程同步策略。
    config.mCertFilePath      = ogs::ReadConfig::localOption.LicensePath;
    config.mCertPwd           = ogs::ReadConfig::localOption.Reserve1;
    config.mCAFilePath        = ogs::ReadConfig::localOption.Reserve2;
    config.mProtocol          = ogs::ReadConfig::localOption.Reserve3;
    config.mDefaultOperator   = ogs::ReadConfig::localOption.Reserve4;
    config.mSiteInfo          = ogs::ReadConfig::localOption.Reserve6;
    config.mRequestStation    = ogs::ReadConfig::localOption.Reserve7;
    config.mOpStation         = ogs::ReadConfig::localOption.Reserve9;
    config.mDefaultNodeIp     = ogs::ReadConfig::localOption.ClientIp;
    config.mDefaultNodeMac    = ogs::ReadConfig::localOption.ClientMac;
    config.mDefaultNodeDiskSn = ogs::ReadConfig::localOption.ClientDiskSn;
    config.mEntrustMode       = ogs::ReadConfig::localOption.EntrustMode;
    config.mSiteInfoFormat    = ogs::ReadConfig::localOption.SiteInfoFormat;

    FixApiWrapper::createAddr(config.mServerAddr,
                              ReadConfig::localOption.BrokerAddr.c_str(),
                              ReadConfig::localOption.BrokerPort.c_str());

    mConnection.setConfig(config);

    // 检查配置项有效性。
    if (config.mDefaultNodeIp.empty()) config.mDefaultNodeIp = ogs::ReadConfig::localOption.LocalAddr;
    if (config.mDefaultNodeMac.empty()) ogs::HardwareAddress(config.mDefaultNodeMac);
    if (config.mDefaultNodeDiskSn.empty()) ogs::HardDriveSerialNo(config.mDefaultNodeDiskSn);

    // 可用的资金帐户。
    vector<string> bacids;
    StringHelper::split(ogs::ReadConfig::localOption.Reserve5, ",", bacids);
    mEnabledBacids.resize(bacids.size());
    for (size_t i = 0; i < bacids.size(); i++) {
        mEnabledBacids[i] = std::atol(bacids[i].c_str());
    }
}

DdImpl::~DdImpl()
{

}

bool DdImpl::isBacidEnabled(const char* bacid) const
{
    if (!isBacidRestrictionEnabled()) return true;
    string tmpBacid = bacid;
    return find(mEnabledBacids.begin(), mEnabledBacids.end(), tmpBacid) != mEnabledBacids.end();
}

Intf_RetType DdImpl::checkPassword(const std::string &FID_KHH_STR, const std::string &FID_JYMM_STR, const std::string &node)
{
    CheckTradePasswdInput checkIn;
    std::list<CheckTradePasswdOutput> checkOut;
    checkIn.FID_KHH_STR  = FID_KHH_STR;
    checkIn.FID_JYMM_STR = FID_JYMM_STR;
    string errMsg;
    return mConnection.fixCheckTradePasswd(checkIn, checkOut, errMsg, node);
}

Intf_RetType DdImpl::initSubscribe()
{
    return kIntfSuccess;
}

Intf_RetType DdImpl::heartBeatToBroker()
{
    std::list<HeartBeatOutput> output;
    string error;
    Intf_RetType result = mConnection.fixHeartBeat(output, error);
    if (result != kIntfSuccess) {
        fixDebug << "[ddvip] heart beat failed(" << result << "): " << error;
    }
    return result;
}

void DdImpl::setCallBack(int (*fn)(ogs::QueryOrderAns))
{
    mQueryOrderCallbackFunc = fn;
}

bool DdImpl::isBacidRestrictionEnabled() const
{
    return !mEnabledBacids.empty();
}

/*!
 * \brief 认证登陆并获取资金账户及交易账户（股东账户）。
 * \param in 查询股东账号需要输入正确的客户号（不能错误或者为空）和交易密码。
 * \param out 用于接收输入客户号下的所有资金账号。
 * \param errMsg 用于接收错误信息。
 * \return 操作执行结果类型。
 */
Intf_RetType DdImpl::ogsLogin(const ogs::LoginQry &in, std::list<ogs::LoginAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    // 设置输入。
    QryClientStkAcctInput input;
    input.FID_KHH_STR  = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);

    // 调用接口。
    std::list<QryClientStkAcctOutput> output;
    string node = createNode(args);

    Intf_RetType result = mConnection.fixQryClientStkAcct(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    FixClient client;
    client.client_id = input.FID_KHH_STR;

    for (QryClientStkAcctOutput& item : output) {
        if (item.FID_GDZT_STR != "0") {
            cerr << "[ddvip] 发现了异常状态(FID_GDZT = " << item.FID_GDZT_STR << ")的股东账号。" << endl;
        }

        fixLogger() << item;

        int fIndex = client.indexOf(item.FID_ZJZH_STR);
        if (fIndex < 0) {
            FixFundAccount fundAccount;
            fundAccount.fund_account = item.FID_ZJZH_STR;
            fIndex = client.addNewFundAccount(fundAccount);

            // 仅当出现了新的资金账号时才会加入新的LoginAns。
            ogs::LoginAns ans;
            FixConverter::CONV_FID_ZJZH(item.FID_ZJZH_STR, ans.bacid);
            out.push_back(ans);
        }

        FixFundAccount& fundAccount = client[fIndex];

        qtp::MarketCode market;
        FixConverter::CONV_FID_JYS(item.FID_JYS_STR, market);
        Exchange exchange = AccountHelper::toExchange(market);

        if (AccountHelper::isExchangeValid(exchange)) {
            FixTradeAccount& account = fundAccount[exchange];
            account.stock_account = item.FID_GDH_STR;
            account.exchange_type = item.FID_JYS_STR;
            account.enabled = true;
        }
    }

    // 保存客户账号记录。
    mClients.addNewClient(client);

    // 订阅消息。如果已经订阅，则不再重复订阅。连接断开重连FixApi内部会自动重新订阅。
    // 检查是否已经订阅各项信息。
    bool secuBargainSubed, secuEntrustAckSubed, secuEntrustWithdrawSubed;
    SubCallback* item = FixSubManager::Instance().getSubCallback(input.FID_KHH_STR);
    if (!item) {
        fixDebug << "[kdvip] new client logs in, hasn't subscribed yet.";
        secuBargainSubed         = false;
        secuEntrustAckSubed      = false;
        secuEntrustWithdrawSubed = false;
    } else {
        secuBargainSubed         = FixApiWrapper::isSubHandleValid(item->subSecuBargainInfo.subHandle);
        secuEntrustAckSubed      = FixApiWrapper::isSubHandleValid(item->subSecuEntrustAckInfo.subHandle);
        secuEntrustWithdrawSubed = FixApiWrapper::isSubHandleValid(item->subSecuEntrustWithdrawAckInfo.subHandle);
        fixDebug << "[kdvip] old client logs in, subscribe info: "
                 << "secuBargainSubed(" <<  secuBargainSubed << "), "
                 << "secuEntrustAckSubed(" << secuEntrustAckSubed << "), "
                 << "secuEntrustWithdrawSubed(" << secuEntrustWithdrawSubed << ").";
    }

    SubscribeInput subIn;
    SubscribeOutput subOut;
    subIn.FID_KHH_STR  = input.FID_KHH_STR;
    subIn.FID_JYMM_STR = in.password; // 订阅输入密码不能加密！

    if (!secuBargainSubed) {
        if ((result = fixSubSecuBargain(subIn, subOut, errMsg)) != kIntfSuccess) {
            return result;
        }
    }
    if (!secuEntrustAckSubed) {
        if ((result = fixSubSecuEntrustAck(subIn, subOut, errMsg)) != kIntfSuccess) {
            return result;
        }
    }
    if (!secuEntrustWithdrawSubed) {
        if ((result = fixSubSecuEntrustWithdrawAck(subIn, subOut, errMsg)) != kIntfSuccess) {
            return result;
        }
    }

    return result;
}

Intf_RetType DdImpl::ogsSendOrder(const ogs::SendOrderQry &in, std::list<ogs::SendOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    out.clear();

    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);
    string node = createNode(args);

    // 设置输入。
    SecuEntrustInput input;
    input.FID_GDH_STR  = mClients.stockAccount(FixConverter::FID_ZJZH_STR(in.bacid), market);
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);
    input.FID_JYS_STR  = FixConverter::FID_JYS_STR(market);
    input.FID_KHH_STR  = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_WTJG_STR = FixConverter::FID_WTJG_STR(in.price);
    input.FID_WTLB_STR = FixConverter::FID_WTLB_STR(in.directive);
    input.FID_WTSL_STR = FixConverter::FID_WTSL_STR(in.volume);
    input.FID_ZQDM_STR = FixConverter::FID_ZQDM_STR(code);
    input.FID_DDLX_STR = FixConverter::FID_DDLX_STR(in.execution);
    // 未使用输入项：input.FID_WTPCH_STR
    // 未使用输入项：input.FID_DFXW_STR

    // 调用接口。
    std::list<SecuEntrustOutput> output;
    Intf_RetType result = mConnection.fixSecuEntrust(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        // pack invalid ans.
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        out.push_back(ans);
        return result;
    }

    // 处理输出。
    for (SecuEntrustOutput& item : output) {
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        FixConverter::CONV_FID_WTH(item.FID_WTH_STR, ans.sysOrderId);
        out.push_back(ans);
    }
    return result;
}

Intf_RetType DdImpl::ogsCancelOrder(const ogs::CancelOrderQry &in, std::list<ogs::CancelOrderAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);
    string node = createNode(args);

    // 设置输入。
    SecuEntrustWithdrawInput input;
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);
    input.FID_KHH_STR  = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_WTH_STR  = FixConverter::FID_WTH_STR(in.sysOrderId);

    // 调用接口。
    std::list<SecuEntrustWithdrawOutput> output;
    Intf_RetType result = mConnection.fixSecuEntrustWithdraw(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustWithdrawOutput& item : output) {
        ogs::CancelOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        FixConverter::CONV_FID_WTH(item.FID_WTH_STR, ans.sysOrderId);
        out.push_back(ans);
    }
    return result;
}

Intf_RetType DdImpl::ogsQueryOrder(const ogs::QueryOrderQry &in, std::list<ogs::QueryOrderAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);
    string node = createNode(args);

    // 设置输入。
    QryClientEntrustTodayInput input;
    input.FID_KHH_STR  = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);
    input.FID_JYS_STR  = FixConverter::FID_JYS_STR(market);
    input.FID_GDH_STR  = mClients.stockAccount(FixConverter::FID_ZJZH_STR(in.bacid), market);
    input.FID_WTH_STR  = FixConverter::FID_WTH_STR(in.sysOrderId);
    input.FID_WTLB_STR = FixConverter::FID_WTLB_STR(in.directive);
    input.FID_ZQDM_STR = FixConverter::FID_ZQDM_STR(code);
    input.FID_FLAG_STR = "0"; // 查询标志（0所有委托，1可撤单委托）
    input.FID_CXBZ_STR = FixConverter::FID_CXBZ_STR(FID_CXBZ_ENUM::ENTRUST_RECORD);
    // input.FID_BROWINDEX_STR 被设为空。
    input.FID_ROWCOUNT_STR = FixConverter::FID_ROWCOUNT_STR();

    // 调用接口。
    std::list<QryClientEntrustTodayOutput> output;
    Intf_RetType result = mConnection.fixQryClientEntrustToday(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (QryClientEntrustTodayOutput& item : output) {
        ogs::QueryOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        FixConverter::CONV_FID_WTH(item.FID_WTH_STR, ans.sysOrderId);
        FixConverter::CONV_FID_WTJG(item.FID_WTJG_STR, ans.price);
        FixConverter::CONV_FID_WTSL(item.FID_WTSL_STR, ans.volume);
        FixConverter::CONV_FID_SBJG(item.FID_SBJG_STR, ans.orderStatus);
        FixConverter::CONV_FID_CJSL(item.FID_CJSL_STR, ans.dealVolume);
        FixConverter::CONV_FID_CJJE(item.FID_CJJE_STR, ans.dealBalance);
        FixConverter::CONV_FID_CJJG(item.FID_CJJG_STR, ans.dealPrice);
        FixConverter::CONV_FID_CDSL(item.FID_CDSL_STR, ans.withdrawVolume);
        FixConverter::CONV_FID_WTLB(item.FID_WTLB_STR, ans.directive);
        FixConverter::CONV_FID_ZQDM(item.FID_ZQDM_STR, ans.innerCode);
        FixConverter::CONV_FID_WTRQ(item.FID_WTRQ_STR, ans.tradeDate);
        FixConverter::CONV_FID_WTSJ(item.FID_WTSJ_STR, ans.orderTime);
        out.push_back(ans);
    }
    return result;
}

Intf_RetType DdImpl::ogsQueryPosition(const ogs::QueryPositionQry &in, std::list<ogs::QueryPositionAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);
    string node = createNode(args);

    // 设置输入。
    QryClientPositionInput input;
    input.FID_KHH_STR  = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);
    input.FID_GDH_STR  = mClients.stockAccount(FixConverter::FID_ZJZH_STR(in.bacid), market);
    input.FID_JYS_STR  = FixConverter::FID_JYS_STR(market);
    input.FID_ZQDM_STR = FixConverter::FID_ZQDM_STR(code);
    // input.FID_EXFLG_STR 被设为空。
    // input.FID_BROWINDEX_STR 被设为空。
    // input.FID_ROWCOUNT_STR 被设为空。
    // input.FID_FLAG_STR 被设为空。

    // 调用接口。
    std::list<QryClientPositionOutput> output;
    Intf_RetType result = mConnection.fixQryClientPosition(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (QryClientPositionOutput& item : output) {
        ogs::QueryPositionAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        strcpy(ans.bacid, in.bacid);
        FixConverter::CONV_FID_ZQDM(item.FID_ZQDM_STR, ans.innerCode);
        FixConverter::CONV_FID_ZQSL(item.FID_ZQSL_STR, ans.currentVolume);
        FixConverter::CONV_FID_KMCSL(item.FID_KMCSL_STR, ans.usableVolume);
        out.push_back(ans);
    }

    return result;
}

Intf_RetType DdImpl::ogsQueryBargain(const ogs::QueryBargainQry &in, std::list<ogs::QueryBargainAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);
    string node = createNode(args);

    // 设置输入。
    QryClientTickDealInput input;
    input.FID_KHH_STR = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);
    input.FID_GDH_STR  = mClients.stockAccount(FixConverter::FID_ZJZH_STR(in.bacid), market);
    input.FID_JYS_STR = FixConverter::FID_JYS_STR(market);
    input.FID_WTH_STR = FixConverter::FID_WTH_STR(in.sysOrderId);
    input.FID_ZQDM_STR = FixConverter::FID_ZQDM_STR(code);
    // input.FID_EXFLG_STR 被设为空。
    // input.FID_BROWINDEX_STR 被设为空。
    // input.FID_ROWCOUNT_STR 被设为空。
    // input.FID_FLAG_STR 被设为空。

    // 调用接口。
    std::list<QryClientTickDealOutput> output;
    Intf_RetType result = mConnection.fixQryClientTickDeal(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (QryClientTickDealOutput& item : output) {
        ogs::QueryBargainAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        FixConverter::CONV_FID_WTH(item.FID_WTH_STR, ans.sysOrderId);
        FixConverter::CONV_FID_ZJZH(item.FID_ZJZH_STR, ans.bacid);
        FixConverter::CONV_FID_ZQDM(item.FID_ZQDM_STR, ans.innerCode);
        FixConverter::CONV_FID_CJJE(item.FID_CJJE_STR, ans.dealBalance);
        FixConverter::CONV_FID_CJJG(item.FID_CJJG_STR, ans.dealPrice);
        FixConverter::CONV_FID_CJSL(item.FID_CJSL_STR, ans.dealVolume);
        FixConverter::CONV_FID_HBXH(item.FID_HBXH_STR, ans.dealId);
        out.push_back(ans);
    }

    return result;
}

Intf_RetType DdImpl::ogsQueryFundInfo(const ogs::QueryFundInfoQry &in, std::list<ogs::QueryFundInfoAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    string node = createNode(args);

    // 设置输入。
    QryClientFundInput input;
    input.FID_KHH_STR = FixConverter::FID_KHH_STR(in.acidcard);
    input.FID_JYMM_STR = FixConverter::FID_JYMM_STR(in.password);
    // input.FID_EXFLG_STR 被设为空。

    // 调用接口。
    std::list<QryClientFundOutput> output;
    Intf_RetType result = mConnection.fixQryClientFund(input, output, errMsg, node);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (QryClientFundOutput& item : output) {
        ogs::QueryFundInfoAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        FixConverter::CONV_FID_ZJZH(item.FID_ZJZH_STR, ans.bacid);
        FixConverter::CONV_FID_ZZC(item.FID_ZZC_STR, ans.balance);
        FixConverter::CONV_FID_DJJE(item.FID_DJJE_STR, ans.frozenBalance);
        FixConverter::CONV_FID_KYZJ(item.FID_KYZJ_STR, ans.useableBalance);
        out.push_back(ans);
    }

    return result;
}

Intf_RetType DdImpl::ogsPaybackSecurity(const ogs::PaybackSecurityQry &in, std::list<ogs::PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    return kIntfNotSupport;
}

Intf_RetType DdImpl::ogsPaybackFunds(const ogs::PaybackFundsQry &in, std::list<ogs::PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    return kIntfNotSupport;
}

bool DdImpl::subSecuBargainCallback(const SecuBargainInfo &info, void *reserve)
{
    ogs::QueryOrderAns ans = {0};

    FixConverter::CONV_FID_WTH(info.FID_WTH_STR, ans.sysOrderId);
    FixConverter::CONV_FID_ZQDM(info.FID_ZQDM_STR, ans.innerCode);
    FixConverter::CONV_FID_WTLB(info.FID_WTLB_STR, ans.directive);
    FixConverter::CONV_FID_WTSL(info.FID_WTSL_STR, ans.volume);
    FixConverter::CONV_FID_CDSL(info.FID_CDSL_STR, ans.withdrawVolume);
    FixConverter::CONV_FID_ZCJSL(info.FID_ZCJSL_STR, ans.dealVolume);
    FixConverter::CONV_FID_ZCJJE(info.FID_ZCJJE_STR, ans.dealBalance);
    FixConverter::CONV_FID_CJJG(info.FID_CJJG_STR, ans.dealPrice);
    FixConverter::CONV_FID_WTJG(info.FID_WTJG_STR, ans.price);

    ans.orderStatus = ogs::determinOrderStatus(ans.volume, ans.dealVolume, ans.withdrawVolume);

    return ogs::OrderStage::CallBack(ans, std::string()) == kIntfSuccess;
}

bool DdImpl::subSecuEntrustAckCallback(const SecuEntrustAckInfo &info, void *reserve)
{
    ogs::QueryOrderAns ans = {0};

    FixConverter::CONV_FID_WTH(info.FID_WTH_STR, ans.sysOrderId);
    FixConverter::CONV_FID_ZQDM(info.FID_ZQDM_STR, ans.innerCode);
    FixConverter::CONV_FID_WTLB(info.FID_WTLB_STR, ans.directive);
    FixConverter::CONV_FID_WTSL(info.FID_WTSL_STR, ans.volume);
    FixConverter::CONV_FID_CDSL(info.FID_CDSL_STR, ans.withdrawVolume);
    FixConverter::CONV_FID_SBJG(info.FID_SBJG_STR, ans.orderStatus);

    return ogs::OrderStage::CallBack(ans, StringHelper::convertCodec(info.FID_JGSM_STR)) == kIntfSuccess;
}

bool DdImpl::subSecuEntrustWithdrawAckCallback(const SecuEntrustWithdrawAckInfo &info, void *reserve)
{
    ogs::QueryOrderAns ans = {0};

    FixConverter::CONV_FID_WTPCH(info.FID_WTPCH_STR, ans.sysOrderId);
    FixConverter::CONV_FID_ZQDM(info.FID_ZQDM_STR, ans.innerCode);
    FixConverter::CONV_FID_WTLB(info.FID_WTLB_STR, ans.directive);
    FixConverter::CONV_FID_WTSL(info.FID_WTSL_STR, ans.volume);
    FixConverter::CONV_FID_CDSL(info.FID_CDSL_STR, ans.withdrawVolume);
    FixConverter::CONV_FID_CJSL(info.FID_CJSL_STR, ans.dealVolume);

    ans.orderStatus = ogs::determinOrderStatus(ans.volume, ans.dealVolume, ans.withdrawVolume);

    return ogs::OrderStage::CallBack(ans, std::string()) == kIntfSuccess;
}

Intf_RetType DdImpl::fixSubSecuBargain(const SubscribeInput &subIn, SubscribeOutput &subOut, std::string &errMsg)
{
    if (mConnection.fixSubSecuBargainInfo(subIn, subOut, ((void*)&fixSecuBargainCallback), this) <= 0) {
        errMsg = "委托成交消息订阅失败，请重新登陆。";
        fixError << "[fix] " << errMsg;
        return kIntfWorkFail;
    }
    return kIntfSuccess;
}

Intf_RetType DdImpl::fixSubSecuEntrustAck(const SubscribeInput &subIn, SubscribeOutput &subOut, std::string &errMsg)
{
    if (mConnection.fixSubSecuEntrustAckInfo(subIn, subOut, ((void*)&fixSecuEntrustAckCallback), this) <= 0) {
        errMsg = "委托申报确认消息订阅失败，请重新登陆。";
        fixError << "[fix] " << errMsg;
        return kIntfWorkFail;
    }
    return kIntfSuccess;
}

Intf_RetType DdImpl::fixSubSecuEntrustWithdrawAck(const SubscribeInput &subIn, SubscribeOutput &subOut, std::string &errMsg)
{
    if (mConnection.fixSubSecuEntrustWithdrawAckInfo(subIn, subOut, ((void*)&fixSecuEntrustWithdrawAckCallback), this) <= 0) {
        errMsg = "委托撤单确认消息订阅失败，请重新登陆。";
        fixError << "[fix] " << errMsg;
        return kIntfWorkFail;
    }
    return kIntfSuccess;
}

std::string DdImpl::createNode(std::map<int, std::string> &args)
{
    // 默认使用配置文件中的站点信息格式。
    if (!mConnection.config().mSiteInfoFormat.empty()) {
        return ogs::SiteInfo(mConnection.config().mSiteInfoFormat, args);
    }

    // 配置文件中未制定站点信息格式，则使用默认格式。
    string client_ip = args[1];
    string mac       = args[2];
    string disksn    = args[3];

    return mConnection.createNode(client_ip.c_str(), mac.c_str(), disksn.c_str());
}

bool DdImpl::initialize() { return mConnection.initialize(); }
bool DdImpl::connect() { return mConnection.connect(); }
bool DdImpl::isConnected() const { return mConnection.isConnected(); }
