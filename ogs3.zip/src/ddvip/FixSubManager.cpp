#include "FixSubManager.h"
#include "FixApiWrapper.h"

bool FixSubManager::containsClient(const std::string &FID_KHH_STR) const
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    return containsClientLockless(FID_KHH_STR);
}

bool FixSubManager::containsClient(SubCallback *item) const
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    for (size_t i = 0; i < mSubItems.size(); ++i) {
        if (mSubItems[i] == item) {
            return true;
        }
    }
    return false;
}

SubCallback *FixSubManager::getSubCallback(const std::string &FID_KHH_STR)
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    int index = indexOfClientLockless(FID_KHH_STR);
    if (index >= 0) {
        return mSubItems[index];
    }
    return nullptr;
}

std::vector<SubCallback *> FixSubManager::subItems() const
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    return mSubItems;
}

void FixSubManager::addSubItem(SubCallback *item)
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    addSubItemLockless(item);
}

#if 0

SubCallback* FixSubManager::addCallbackItem(const std::string &FID_KHH_STR, const SubCallbackItem<SecuBargainInfo> &item)
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    int index = indexOfClientLockless(FID_KHH_STR);
    if (index >= 0) {
        mSubItems[index]->subSecuBargainInfo = item;
        return mSubItems[index];
    }

    SubCallback* callbackItem = new SubCallback;
    callbackItem->FID_KHH_STR = FID_KHH_STR;
    callbackItem->subSecuBargainInfo = item;
    addSubItemLockless(callbackItem);
}

SubCallback* FixSubManager::addCallbackItem(const std::string &FID_KHH_STR, const SubCallbackItem<SecuEntrustAckInfo> &item)
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    int index = indexOfClientLockless(FID_KHH_STR);
    if (index >= 0) {
        mSubItems[index]->subSecuEntrustAckInfo = item;
        return mSubItems[index];
    }

    SubCallback* callbackItem = new SubCallback;
    callbackItem->subSecuEntrustAckInfo = item;
    addSubItemLockless(callbackItem);
}

SubCallback* FixSubManager::addCallbackItem(const std::string &FID_KHH_STR, const SubCallbackItem<SecuEntrustWithdrawAckInfo> &item)
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    int index = indexOfClientLockless(FID_KHH_STR);
    if (index >= 0) {
        mSubItems[index]->subSecuEntrustWithdrawAckInfo = item;
        return mSubItems[index];
    }

    SubCallback* callbackItem = new SubCallback;
    callbackItem->subSecuEntrustWithdrawAckInfo = item;
    return addSubItemLockless(callbackItem);
}

#endif

void FixSubManager::invalidate()
{
    std::lock_guard<std::mutex> dataLock(mMutex);
    for (SubCallback* item : mSubItems) {
        if (FixApiWrapper::isSubHandleValid(item->subSecuBargainInfo.subHandle)) {
            FixApiWrapper::fixUnsubscribe(item->subSecuBargainInfo.subHandle);
            item->subSecuBargainInfo.subHandle = -1;
        }
        if (FixApiWrapper::isSubHandleValid(item->subSecuEntrustAckInfo.subHandle)) {
            FixApiWrapper::fixUnsubscribe(item->subSecuEntrustAckInfo.subHandle);
            item->subSecuEntrustAckInfo.subHandle = -1;
        }
        if (FixApiWrapper::isSubHandleValid(item->subSecuEntrustWithdrawAckInfo.subHandle)) {
            FixApiWrapper::fixUnsubscribe(item->subSecuEntrustWithdrawAckInfo.subHandle);
            item->subSecuEntrustWithdrawAckInfo.subHandle = -1;
        }
    }
}

SubCallback *FixSubManager::addSubItemLockless(SubCallback *item)
{
    if (!containsClientLockless(item->FID_KHH_STR)) {
        mSubItems.push_back(item);
        return item;
    }
    return nullptr;
}

bool FixSubManager::containsClientLockless(const std::string &FID_KHH_STR) const
{
    for (size_t i = 0; i < mSubItems.size(); ++i) {
        if (mSubItems[i]->FID_KHH_STR == FID_KHH_STR) {
            return true;
        }
    }
    return false;
}

int FixSubManager::indexOfClientLockless(const std::string &FID_KHH_STR) const
{
    for (size_t i = 0; i < mSubItems.size(); ++i) {
        if (mSubItems[i]->FID_KHH_STR == FID_KHH_STR) {
            return i;
        }
    }
    return -1;
}

FixSubManager::~FixSubManager()
{
    for (SubCallback* item : mSubItems) {
        delete item;
    }
}
