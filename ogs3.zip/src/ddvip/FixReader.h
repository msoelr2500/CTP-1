///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef FIXREADER_H
#define FIXREADER_H

#include <ddvip/FixApi_mdb.h>
#include <string>

class FixReader
{
public:
    FixReader(HANDLE_SESSION session, int size = DEFAULT_FIELD_SIZE);
    virtual ~FixReader();

    const char* get(long id, long row = -1);

    void reset(int size, HANDLE_SESSION session);

    void setSession(HANDLE_SESSION session);
    HANDLE_SESSION session() const;

    void setBufferSize(int size);
    int bufferSize() const;

    static void getErrorInfo(HANDLE_SESSION session, std::string& errMsg);

    //! 用于读取单条数据项的缓冲区的默认长度。
    static const int DEFAULT_FIELD_SIZE = 300;

private:
    char* mBuffer;
    int mBufferSize;
    HANDLE_SESSION mSession;
};

#endif // FIXREADER_H
