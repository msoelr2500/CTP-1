///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef DDIMPL_H
#define DDIMPL_H

#include <iostream>
#include <vector>
#include <functional>

#include "../universal_code.h"
#include "../DataStruct.h"
#include "../OrderStage.h"
#include "../ogs_dict.h"
#include "FixAccount.h"
#include "FixApiWrapper.h"

/*!
 * \brief [100064] 委托成交消息处理函数。
 */
bool fixSecuBargainCallback(HANDLE_CONN connection, HANDLE_SESSION session, long nSubs, void* pData);
/*!
 * \brief [100065] 委托申报确认消息处理函数。
 */
bool fixSecuEntrustAckCallback(HANDLE_CONN connection, HANDLE_SESSION session, long nSubs, void* pData);
/*!
 * \brief [100066] 委托撤单确认消息处理函数。
 */
bool fixSecuEntrustWithdrawAckCallback(HANDLE_CONN connection, HANDLE_SESSION session, long nSubs, void* pData);

class DdImpl
{
public:
    explicit DdImpl();

    virtual ~DdImpl();

    ////////////////////////////////////////////////////////////////////////////
    /// 工具函数
    ////////////////////////////////////////////////////////////////////////////

    /*! \return 如果允许指定的资金帐户执行操作，返回true；否则返回false。*/
    bool isBacidEnabled(const char* bacid) const;

    Intf_RetType checkPassword(const std::string& FID_KHH_STR, const std::string& FID_JYMM_STR, const std::string& node);

    ////////////////////////////////////////////////////////////////////////////
    /// 基础方法
    ////////////////////////////////////////////////////////////////////////////

    bool initialize();

    bool connect();

    void disconnect();

    ////////////////////////////////////////////////////////////////////////////
    /// ogs 标准接口方法
    ////////////////////////////////////////////////////////////////////////////

    Intf_RetType initSubscribe();

    /*! \brief 心跳 */
    Intf_RetType heartBeatToBroker();

    /*! \brief 设置查单过程的回调函数。*/
    void setCallBack(int (*fn)(ogs::QueryOrderAns));

    ////////////////////////////////////////////////////////////////////////////
    /// 状态
    ////////////////////////////////////////////////////////////////////////////

    bool isConnected() const;

    /*! \return 是否启用资金账户限制（禁止指定范围以外的资金账户执行操作）。*/
    bool isBacidRestrictionEnabled() const;

    Intf_RetType ogsLogin(const ogs::LoginQry& in, std::list<ogs::LoginAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsSendOrder(const ogs::SendOrderQry& in, std::list<ogs::SendOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsCancelOrder(const ogs::CancelOrderQry& in, std::list<ogs::CancelOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryOrder(const ogs::QueryOrderQry& in, std::list<ogs::QueryOrderAns>& out, std::string &errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryPosition(const ogs::QueryPositionQry& in, std::list<ogs::QueryPositionAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryBargain(const ogs::QueryBargainQry& in, std::list<ogs::QueryBargainAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryFundInfo(const ogs::QueryFundInfoQry& in, std::list<ogs::QueryFundInfoAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsPaybackSecurity(const ogs::PaybackSecurityQry &in, std::list<ogs::PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsPaybackFunds(const ogs::PaybackFundsQry &in, std::list<ogs::PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args);

    bool subSecuBargainCallback(const SecuBargainInfo& info, void* reserve);
    bool subSecuEntrustAckCallback(const SecuEntrustAckInfo& info, void* reserve);
    bool subSecuEntrustWithdrawAckCallback(const SecuEntrustWithdrawAckInfo& info, void* reserve);

    Intf_RetType fixSubSecuBargain(const SubscribeInput &subIn, SubscribeOutput &subOut, std::string& errMsg);
    Intf_RetType fixSubSecuEntrustAck(const SubscribeInput &subIn, SubscribeOutput &subOut, std::string& errMsg);
    Intf_RetType fixSubSecuEntrustWithdrawAck(const SubscribeInput &subIn, SubscribeOutput &subOut, std::string& errMsg);

protected:
    std::string createNode(std::map<int, std::string>& args);

private:
    //! 订阅获取到成交回报时的回调函数
    std::function<int(ogs::QueryOrderAns)> mQueryOrderCallbackFunc;

    //! 已登陆客户的基本信息
    static FixClientManager mClients;

    //! 允许操作的资金账户。如果为空，则允许所有资金账户执行操作。
    std::vector<std::string> mEnabledBacids;

    FixApiWrapper mConnection;
};

#endif // DDIMPL_H
