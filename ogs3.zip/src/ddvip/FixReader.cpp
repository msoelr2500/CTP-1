///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-21
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "FixReader.h"
#include "../StringHelper.h"
#include <iostream>

using std::string;

FixReader::FixReader(long session, int size)
{
    mSession = session;
    mBufferSize = size;
    mBuffer = new char [mBufferSize];
}

FixReader::~FixReader()
{
    delete [] mBuffer;
}

const char *FixReader::get(long id, long row)
{
    Fix_GetItem(mSession, id, mBuffer, mBufferSize, row);
    return mBuffer;
}

void FixReader::getErrorInfo(long session, std::string &errMsg)
{
    errMsg.resize(DEFAULT_FIELD_SIZE);
    Fix_GetErrMsg(session, (char*)errMsg.c_str(), errMsg.size());
    errMsg = StringHelper::convertCodec(errMsg);
}
