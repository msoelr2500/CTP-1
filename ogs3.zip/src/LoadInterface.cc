//
// Created by lwk on 16-8-8.
//

#include "LoadInterface.h"

namespace ogs {

    static void *pLibHandle = NULL;

    PFn_InterfaceCreate Fn_InterfaceCreate = NULL;
    PFn_LoadLocalOption Fn_LoadLocalOption = NULL;
    PFn_LogLibVersion Fn_LogLibVersion = NULL;

    int LoadInterafceLib(const char *LibPath) {
        pLibHandle = dlopen(LibPath, RTLD_LAZY);

        if (pLibHandle == NULL) {
            VLOG(100) << "Load library failed";
            char *pError = dlerror();
            printf("Load library failed:%s\n",pError);
            return -1;
        }

        char *pError;
        Fn_InterfaceCreate = (PFn_InterfaceCreate)dlsym(pLibHandle, "InterfaceCreate");
        pError = dlerror();
        if (pError != NULL) {
            VLOG(100) << "Load function error" << pError;
            printf("Load function error:%s\n", pError);
            dlclose(pLibHandle);
            return -1;
        }

        Fn_LoadLocalOption = (PFn_LoadLocalOption)dlsym(pLibHandle, "LoadLocalOption");
        pError = dlerror();
        if (pError != NULL) {
            VLOG(100) << "Load function error" << pError;
            printf("Load function error:%s\n", pError);
            dlclose(pLibHandle);
            return -1;
        }

        Fn_LogLibVersion = (PFn_LogLibVersion)dlsym(pLibHandle, "LogLibVersion");
        pError = dlerror();
        if (pError != NULL) {
            VLOG(100) << "Load function error" << pError;
            printf("Load function error:%s\n", pError);
            dlclose(pLibHandle);
            return -1;
        }

        return 0;
    }

}