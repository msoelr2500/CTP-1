#ifndef _BASICTYPE_H_
#define _BASICTYPE_H_

#include <stdint.h>

namespace ogs {

    typedef int8_t INT8;
    typedef uint8_t UINT8;
    typedef int16_t INT16;
    typedef uint16_t UINT16;
    typedef int32_t INT32;
    typedef uint32_t UINT32;
    typedef int64_t INT64;
    typedef uint64_t UINT64;
    typedef char CHAR;

//////////////////////////////////////////////

    typedef UINT8 OGS_ACTYPE;
    typedef CHAR OGS_BACID;
    typedef CHAR OGS_ACIDCARD;
    typedef CHAR OGS_PASSWORD;
    typedef UINT8 OGS_MARKET;
    typedef CHAR OGS_ACARD;
    typedef CHAR OGS_CONPROP;
    typedef UINT64 OGS_INNERCODE;
    typedef UINT16 OGS_DIRECTIVE;
    typedef UINT8 OGS_EXECUTION;
    typedef UINT32 OGS_PRICE;
    typedef UINT32 OGS_VOLUME;
    typedef UINT64 OGS_OGSORDERID;
    typedef CHAR OGS_SYSORDERID;
    typedef UINT8 OGS_ORDERSTATUS;
    typedef UINT32 OGS_DEALVOLUME;
    typedef UINT64 OGS_DEALBALANCE;
    typedef UINT32 OGS_DEALPRICE;
    typedef UINT32 OGS_WITHDRAWVOLUME;
    typedef UINT32 OGS_TRADEDATE;
    typedef UINT32 OGS_ORDERTIME;
    typedef CHAR OGS_DEALID;
    typedef UINT64 OGS_BALANCE;
    typedef UINT64 OGS_USEABLEBALANCE;
    typedef UINT64 OGS_FROZENBALANCE;
    typedef UINT32 OGS_CURRENTVOLUME;
    typedef UINT32 OGS_USABLEVOLUME;
    typedef UINT64 OGS_CUSTORDERID;
    typedef CHAR OGS_IPADDR;
    typedef CHAR OGS_MACADDR;
    typedef CHAR OGS_DISKSN;

    typedef UINT16 OGS_ERRORCODE;
    typedef CHAR OGS_ERRORINFO;

    typedef UINT16 OGS_SYSSTATUS;
    typedef UINT32 OGS_SYSDATE;
    typedef UINT32 OGS_SYSTIME;

    typedef UINT16 OGS_MESSAGETYPE;
    typedef UINT64 OGS_SESSIONID;

    typedef UINT32 OGS_REPAYVOLUME;
    typedef UINT32 OGS_REPAYVOLUMEREAL;
    typedef UINT64 OGS_REPAYAMT;
    typedef UINT64 OGS_REPAYAMTREAL;
    typedef UINT64 OGS_OMSORDERID;

    typedef UINT16 OGS_TAGSYSORDERIDISEMPTY;
    typedef UINT16 OGS_TAGISCALLBACK;
}
#endif
