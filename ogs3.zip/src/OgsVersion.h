//
// Created by lwk on 16-7-19.
//

#ifndef OGS_OGSVERSION_H
#define OGS_OGSVERSION_H

#include "qtp_version.h"

#include "OgsGlobal.h"

#endif //OGS_OGSVERSION_H
