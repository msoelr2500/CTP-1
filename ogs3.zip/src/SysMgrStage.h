//
// Created by lwk on 16-5-13.
//

#ifndef OGS_SYSMGRSTAGE_H
#define OGS_SYSMGRSTAGE_H

#include "qtp_session.h"
#include "qtp_log.h"
#include "qtp_stage.h"
#include "DataStruct.h"
#include "OgsApi.h"
#include "BufferHandle.h"

namespace ogs{

    class SysMgrStage :public qtp::QtpStage
    {
    public:
        SysMgrStage();
        ~SysMgrStage();

        int OnEvent(qtp::QtpMessagePtr message);

        int HandleHeartBeat(qtp::QtpMessagePtr message);

    private:

    };

}

#endif //OGS_SYSMGRSTAGE_H
