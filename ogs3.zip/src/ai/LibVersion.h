//
// Created by lwk on 16-8-19.
//

#ifndef OGS_LIBVERSION_H
#define OGS_LIBVERSION_H

#include "qtp_version.h"

namespace ogs {

#define LIBNAME "AI"

    DECLARE_VERSION(ai, 0, 2, 0)

}

#endif //OGS_LIBVERSION_H
