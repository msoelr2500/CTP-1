//
// Created by lwk on 16-5-11.
//

#include "InterfaceCreate.h"

namespace ogs {
    //LocalOption ReadConfig::localOption;
#ifdef __cplusplus
extern "C"
{
#endif

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr) {
        if ((strcmp(brokerType.c_str(), "AI") == 0) || (strcmp(brokerType.c_str(), "ai") == 0)) {
            //printf("AI interface create.\n");
            std::shared_ptr<Interface> InAiPtr(new InterfaceAi());
            inPtr = InAiPtr;
        }
        else if ((strcmp(brokerType.c_str(), "KDMID") == 0) || (strcmp(brokerType.c_str(), "kdmid") == 0)) {

        }
        else if ((strcmp(brokerType.c_str(), "KDVIP") == 0) || (strcmp(brokerType.c_str(), "kdvip") == 0)) {

        }
        else if ((strcmp(brokerType.c_str(), "O32") == 0) || (strcmp(brokerType.c_str(), "o32") == 0)) {

        }
        else if ((strcmp(brokerType.c_str(), "KDKCBP") == 0) || (strcmp(brokerType.c_str(), "kdkcbp") == 0)) {

        }
        else if ((strcmp(brokerType.c_str(), "DDVIP") == 0) || (strcmp(brokerType.c_str(), "ddvip") == 0)) {

        }
        else if ((strcmp(brokerType.c_str(), "UFX20") == 0) || (strcmp(brokerType.c_str(), "ufx20") == 0)) {

        }
        else {
            //std::shared_ptr<Interface> InAiPtr(new InterfaceAi());
            //inPtr = InAiPtr;
        }
    }

    int LoadLocalOption(void* src,size_t size){
        if(size!= sizeof(ogs::ReadConfig::localOption)){
            return -1;
        }
        memcpy(&ogs::ReadConfig::localOption,src,size);
        return 0;
    }

    void LogLibVersion() {
        std::string version_str = GET_VERSION_STR(ai);
        LOG(info) << "lib version:" << LIBNAME << " " << version_str;
    }

#ifdef __cplusplus
}
#endif
}

