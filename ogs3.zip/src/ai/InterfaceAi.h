#ifndef _INTERFACE_AI_H_
#define _INTERFACE_AI_H_

#include <memory>
#include <string.h>
#include <sstream>
#include <map>

#include "Interface.h"
#include "DataStruct.h"
#include "BufferHandle.h"
#include "OgsApi.h"
#include "ogs_dict.h"
#include "OgsLogger.h"

namespace ogs {
	class InterfaceAi : public Interface {
	public:
		InterfaceAi();

		~InterfaceAi();

		bool getConnectStatus();

		INTF_RETURNTYPE initCommon();

		INTF_RETURNTYPE initSubscribe();

		INTF_RETURNTYPE setSubscribe(INTF_PARAMSTYPE vSubParams);

		INTF_RETURNTYPE connectBroker();

		INTF_RETURNTYPE reConnectBroker();

		INTF_RETURNTYPE login(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                              INTF_ERRMSGTYPE errMsg, INTF_PARAMSTYPE vSubParams, std::map<int, std::string>& args);//quybuf = count + LoginQry * n;ansBuf = count + LoginAns * n
        INTF_RETURNTYPE sendOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE cancelOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryBargain(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryFundInfo(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryPosition(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

		INTF_RETURNTYPE heartBeatToBroker();

		void setCallBack(int (*fn)(QueryOrderAns));

		uint64_t MakeOrderId();

        INTF_RETURNTYPE paybackSecurity(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,	INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE paybackFunds(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

	private:
		bool isConnect;
		static uint32_t m_orderIdSon;
		static std::map<std::string , std::shared_ptr<ogs::OrderInfo>> m_OrderMap;
		static std::function<int(ogs::QueryOrderAns)> func;
	};

}

#endif
