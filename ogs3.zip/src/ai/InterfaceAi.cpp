#include "InterfaceAi.h"

namespace ogs {

	uint32_t InterfaceAi::m_orderIdSon = 0;
	std::map<std::string, std::shared_ptr<ogs::OrderInfo>> InterfaceAi::m_OrderMap;
	std::function<int(ogs::QueryOrderAns)> InterfaceAi::func;

	InterfaceAi::InterfaceAi() {
		isConnect = false;
	}

	InterfaceAi::~InterfaceAi() {
	}

	INTF_RETURNTYPE InterfaceAi::initCommon() {
		return kIntfNotSupport;
	}

	INTF_RETURNTYPE InterfaceAi::initSubscribe() {
		return kIntfNotSupport;
	}

	INTF_RETURNTYPE InterfaceAi::setSubscribe(INTF_PARAMSTYPE vSubParams) {
		return kIntfNotSupport;
	}

	INTF_RETURNTYPE InterfaceAi::connectBroker() {
		//printf("InterfaceAi connectBroker is in running\n");
		isConnect = true;
		return kIntfSuccess;
	}

	INTF_RETURNTYPE InterfaceAi::reConnectBroker() {
		return kIntfNotSupport;
	}

    INTF_RETURNTYPE InterfaceAi::login(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, INTF_PARAMSTYPE vSubParams, std::map<int, std::string>& args) {
		UnpackBuffer<LoginQry> m_Unpack(&qryBuf);
		PackBuffer<LoginAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();

        Intf_RetType result = kIntfSuccess;
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			for (int m = 1; m < 2; m++) {
				LoginAns loginAns = {0};
                VLOG(200) << "login = " << m_Unpack.GetDataObjPtr()->acidcard << m_Unpack.GetDataObjPtr()->bacid;
                bool verifyResult = strcmp(m_Unpack.GetDataObjPtr()->acidcard, "000000123456") == 0 &&
                                    strcmp(m_Unpack.GetDataObjPtr()->bacid, "000000123456") == 0 &&
                                    strcmp(m_Unpack.GetDataObjPtr()->password, "123456") == 0;
                if (true)
                {
                    strcpy(loginAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
                } else {
                    result = kIntfFail;
                }

				m_Pack.AddNewObj(&loginAns);
			}
			m_Unpack.Next();
		}
        return result;
	}

    INTF_RETURNTYPE InterfaceAi::sendOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
		UnpackBuffer<SendOrderQry> m_Unpack(&qryBuf);
		PackBuffer<SendOrderAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			SendOrderAns sendOrderAns = {0};
            strcpy(sendOrderAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
			sendOrderAns.custOrderId = m_Unpack.GetDataObjPtr()->custOrderId;

			std::stringstream ss;
			ss << MakeOrderId();
			std::string orderIdStr;
			ss >> orderIdStr;
			strcpy(sendOrderAns.sysOrderId, orderIdStr.c_str());

			std::shared_ptr<ogs::OrderInfo> orderInfoPtr(new OrderInfo);
            strcpy(orderInfoPtr->acidcard, m_Unpack.GetDataObjPtr()->acidcard);
            strcpy(orderInfoPtr->bacid, m_Unpack.GetDataObjPtr()->bacid);
			orderInfoPtr->actype = m_Unpack.GetDataObjPtr()->actype;
			strcpy(orderInfoPtr->password, m_Unpack.GetDataObjPtr()->password);
			orderInfoPtr->innerCode = m_Unpack.GetDataObjPtr()->innerCode;
			orderInfoPtr->directive = m_Unpack.GetDataObjPtr()->directive;
			orderInfoPtr->execution = m_Unpack.GetDataObjPtr()->execution;
			orderInfoPtr->price = m_Unpack.GetDataObjPtr()->price;
			orderInfoPtr->volume = m_Unpack.GetDataObjPtr()->volume;
			orderInfoPtr->custOrderId = m_Unpack.GetDataObjPtr()->custOrderId;
			strcpy(orderInfoPtr->sysOrderId, sendOrderAns.sysOrderId);
			orderInfoPtr->orderStatus = ogs_dict::kOtMatchedAll;
			orderInfoPtr->dealVolume = orderInfoPtr->volume;
			orderInfoPtr->dealBalance = orderInfoPtr->volume * orderInfoPtr->price;
			orderInfoPtr->dealPrice = orderInfoPtr->price;
			orderInfoPtr->withdrawVolume = 0;
			orderInfoPtr->tradeDate = GetDateYMD();
			orderInfoPtr->orderTime = GetTimeHMS();
			orderInfoPtr->sessionid = 0;
			m_OrderMap.insert(
					std::pair<std::string, std::shared_ptr<OrderInfo>>(orderInfoPtr->sysOrderId, orderInfoPtr));

			m_Pack.AddNewObj(&sendOrderAns);
			m_Unpack.Next();
		}
        return kIntfSuccess;
	}

    INTF_RETURNTYPE InterfaceAi::cancelOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
		UnpackBuffer<CancelOrderQry> m_Unpack(&qryBuf);
		PackBuffer<CancelOrderAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			CancelOrderAns cancelOrderAns = {0};
            strcpy(cancelOrderAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
			cancelOrderAns.custOrderId = m_Unpack.GetDataObjPtr()->custOrderId;
			strcpy(cancelOrderAns.sysOrderId, m_Unpack.GetDataObjPtr()->sysOrderId);

			m_Pack.AddNewObj(&cancelOrderAns);
			m_Unpack.Next();
		}
		return kIntfSuccess;
	}

    INTF_RETURNTYPE InterfaceAi::queryOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
		UnpackBuffer<QueryOrderQry> m_Unpack(&qryBuf);
		PackBuffer<QueryOrderAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			if (strlen(m_Unpack.GetDataObjPtr()->sysOrderId) > 0) { //query with sysorderid, query specified order.
				if (m_OrderMap.find(m_Unpack.GetDataObjPtr()->sysOrderId) != m_OrderMap.end()) {
                    QueryOrderAns queryOrderAns = {0};
                    strcpy(queryOrderAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
					queryOrderAns.custOrderId = m_Unpack.GetDataObjPtr()->custOrderId;
					strcpy(queryOrderAns.sysOrderId, m_Unpack.GetDataObjPtr()->sysOrderId);
					queryOrderAns.price = m_OrderMap[queryOrderAns.sysOrderId]->price;
					queryOrderAns.volume = m_OrderMap[queryOrderAns.sysOrderId]->volume;
					queryOrderAns.orderStatus = m_OrderMap[queryOrderAns.sysOrderId]->orderStatus;
					queryOrderAns.dealVolume = m_OrderMap[queryOrderAns.sysOrderId]->dealVolume;
					queryOrderAns.dealBalance = m_OrderMap[queryOrderAns.sysOrderId]->dealBalance;
					queryOrderAns.dealPrice = m_OrderMap[queryOrderAns.sysOrderId]->dealPrice;
					queryOrderAns.innerCode = m_OrderMap[queryOrderAns.sysOrderId]->innerCode;
					queryOrderAns.withdrawVolume = m_OrderMap[queryOrderAns.sysOrderId]->withdrawVolume;
					queryOrderAns.directive = m_OrderMap[queryOrderAns.sysOrderId]->directive;
					queryOrderAns.tradeDate = m_OrderMap[queryOrderAns.sysOrderId]->tradeDate;
					queryOrderAns.orderTime = m_OrderMap[queryOrderAns.sysOrderId]->orderTime;

					m_Pack.AddNewObj(&queryOrderAns);
					m_Unpack.Next();

					//queryOrderAns.orderStatus = ogs_dict::kOtMatchedAll;
					//this->func(queryOrderAns);
				}
				else {
					std::stringstream ss;
					ss << m_Unpack.GetDataObjPtr()->sysOrderId;
					ss >> errMsg;
					errMsg.append(" [not found this order]");
					return kIntfWorkFail;
				}
			}
			else {  //query without sysorderid,should return all matched order
				std::map<std::string, std::shared_ptr<ogs::OrderInfo>>::iterator it;
				for (it = m_OrderMap.begin(); it != m_OrderMap.end(); it++) {
					printf("get a order:%s\n", it->second->sysOrderId);
                    if (strcmp(m_Unpack.GetDataObjPtr()->acidcard, it->second->acidcard) == 0 ||
                        strlen(m_Unpack.GetDataObjPtr()->acidcard) == 0) {
                        if (strcmp(m_Unpack.GetDataObjPtr()->bacid, it->second->bacid) == 0 ||
                            strlen(m_Unpack.GetDataObjPtr()->bacid) == 0) {
							if (m_Unpack.GetDataObjPtr()->innerCode == it->second->innerCode ||
								m_Unpack.GetDataObjPtr()->innerCode == 0) {
								QueryOrderAns queryOrderAns = {0};
                                strcpy(queryOrderAns.bacid, it->second->bacid);
								queryOrderAns.custOrderId = it->second->custOrderId;
								strcpy(queryOrderAns.sysOrderId, it->second->sysOrderId);
								queryOrderAns.price = it->second->price;
								queryOrderAns.volume = it->second->volume;
								queryOrderAns.orderStatus = it->second->orderStatus;
								queryOrderAns.dealVolume = it->second->dealVolume;
								queryOrderAns.dealBalance = it->second->dealBalance;
								queryOrderAns.dealPrice = it->second->dealPrice;
								queryOrderAns.innerCode = it->second->innerCode;
								queryOrderAns.withdrawVolume = it->second->withdrawVolume;
								queryOrderAns.directive = it->second->directive;
								queryOrderAns.tradeDate = it->second->tradeDate;
								queryOrderAns.orderTime = it->second->orderTime;

								m_Pack.AddNewObj(&queryOrderAns);
								printf("add new record:%s\n", queryOrderAns.sysOrderId);
								VLOG(200) << "1111111111111111bacid: " << queryOrderAns.bacid << " custOrderId: " <<
										  queryOrderAns.custOrderId << " sysOrderId: " << queryOrderAns.sysOrderId <<
										  " price: " <<
										  queryOrderAns.price << " volume: " << queryOrderAns.volume <<
										  " orderStatus: " <<
										  queryOrderAns.orderStatus << " dealVolume: " << queryOrderAns.dealVolume <<
										  " dealBanlance: " << queryOrderAns.dealBalance << " dealPrice: " <<
										  queryOrderAns.dealPrice << " innerCode: " << queryOrderAns.innerCode <<
										  " withdrawVolume: " << queryOrderAns.withdrawVolume << " directive: " <<
										  queryOrderAns.directive << " tradeDate: " <<
										  queryOrderAns.tradeDate << " orderTime: " << queryOrderAns.orderTime;
							}
							else { continue; }
						}
						else { continue; }
					}
					else { continue; }
				}
				m_Unpack.Next();
			}
		}
        return kIntfSuccess;
	}

    INTF_RETURNTYPE InterfaceAi::queryBargain(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
		UnpackBuffer<QueryBargainQry> m_Unpack(&qryBuf);
		PackBuffer<QueryBargainAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			if (m_OrderMap.find(m_Unpack.GetDataObjPtr()->sysOrderId) != m_OrderMap.end()) {
				QueryBargainAns queryBargainAns = {0};
                strcpy(queryBargainAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
				queryBargainAns.custOrderId = m_Unpack.GetDataObjPtr()->custOrderId;
				strcpy(queryBargainAns.sysOrderId, m_Unpack.GetDataObjPtr()->sysOrderId);
				queryBargainAns.innerCode = m_Unpack.GetDataObjPtr()->innerCode;
				strcpy(queryBargainAns.dealId, queryBargainAns.sysOrderId);
				strcat(queryBargainAns.dealId, "d");
				queryBargainAns.dealVolume = m_OrderMap[queryBargainAns.sysOrderId]->dealVolume;
				queryBargainAns.dealBalance = m_OrderMap[queryBargainAns.sysOrderId]->dealBalance;
				queryBargainAns.dealPrice = m_OrderMap[queryBargainAns.sysOrderId]->dealPrice;

				m_Pack.AddNewObj(&queryBargainAns);
			}
			m_Unpack.Next();
		}
		return kIntfSuccess;
	}

    INTF_RETURNTYPE InterfaceAi::queryFundInfo(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
		UnpackBuffer<QueryFundInfoQry> m_Unpack(&qryBuf);
		PackBuffer<QueryFundInfoAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			QueryFundInfoAns queryFundInfoAns = {0};
            strcpy(queryFundInfoAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
            strcpy(queryFundInfoAns.acidcard, m_Unpack.GetDataObjPtr()->acidcard);
			queryFundInfoAns.balance = 9999999;
			queryFundInfoAns.frozenBalance = 1111111;
			queryFundInfoAns.useableBalance = 8888888;

			m_Pack.AddNewObj(&queryFundInfoAns);
			m_Unpack.Next();
		}
		return kIntfSuccess;
	}

    INTF_RETURNTYPE InterfaceAi::queryPosition(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
		UnpackBuffer<QueryPositionQry> m_Unpack(&qryBuf);
		PackBuffer<QueryPositionAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			QueryPositionAns queryPositionAns = {0};
            strcpy(queryPositionAns.acidcard, m_Unpack.GetDataObjPtr()->acidcard);
            strcpy(queryPositionAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
			queryPositionAns.innerCode=m_Unpack.GetDataObjPtr()->innerCode;
			queryPositionAns.currentVolume=100000;
			queryPositionAns.usableVolume=5000;

			m_Pack.AddNewObj(&queryPositionAns);
			m_Unpack.Next();
		}
		return kIntfSuccess;
	}

	INTF_RETURNTYPE InterfaceAi::heartBeatToBroker() {
		return kIntfNotSupport;
	}

	uint64_t InterfaceAi::MakeOrderId() {
		return GetTimeHMS() * 1000 + (m_orderIdSon++ > 999 ? m_orderIdSon = 0 : m_orderIdSon);
	}

	bool InterfaceAi::getConnectStatus() {
		return isConnect;
	}

	void InterfaceAi::setCallBack(int (*fn)(QueryOrderAns)) {
		func = fn;
	}

    INTF_RETURNTYPE InterfaceAi::paybackSecurity(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,	INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args){

	}

    INTF_RETURNTYPE InterfaceAi::paybackFunds(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args){
		UnpackBuffer<PaybackFundsQry> m_Unpack(&qryBuf);
		PackBuffer<PaybackFundsAns> m_Pack(&ansBuf);
		BUF_HANDLE_COUNTTYPE count = m_Unpack.GetDataCount();
		m_Unpack.First();
		for (BUF_HANDLE_COUNTTYPE i = 0; i < count; i++) {
			PaybackFundsAns paybackFundsAns = {0};
            strcpy(paybackFundsAns.acidcard, m_Unpack.GetDataObjPtr()->acidcard);
            strcpy(paybackFundsAns.bacid, m_Unpack.GetDataObjPtr()->bacid);
			paybackFundsAns.repayAmtReal = m_Unpack.GetDataObjPtr()->repayAmt;
			paybackFundsAns.omsOrderId = m_Unpack.GetDataObjPtr()->omsOrderId;

			m_Pack.AddNewObj(&paybackFundsAns);
			m_Unpack.Next();
		}
		return kIntfSuccess;
	}
}
