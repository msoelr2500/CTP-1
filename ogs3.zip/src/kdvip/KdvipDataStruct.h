/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-08
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIPDATASTRUCT_H
#define KDVIPDATASTRUCT_H

#include <string>

#define FIXCODE_ACCT_TYPE         "8987"
#define FIXCODE_ACCT_ID           "9081"
#define FIXCODE_USE_SCOPE         "9082"
#define FIXCODE_ENCRYPT_KEY       "9086"
#define FIXCODE_AUTH_TYPE         "9083"
#define FIXCODE_AUTH_DATA         "9084"
#define FIXCODE_CUST_CODE         "8902"
#define FIXCODE_CUACCT_CODE       "8920"
#define FIXCODE_STKEX             "207"
#define FIXCODE_STKBD             "625"
#define FIXCODE_STK_TRDACCT       "448"
#define FIXCODE_TRDACCT_SN        "8928"
#define FIXCODE_TRDACCT_EXID      "8929"
#define FIXCODE_TRDACCT_STATUS    "8933"
#define FIXCODE_TREG_STATUS       "8934"
#define FIXCODE_BREG_STATUS       "8935"
#define FIXCODE_STKPBU            "8843"
#define FIXCODE_TRDACCT_NAME      "8932"
#define FIXCODE_CHANNEL_ID        "9082"
#define FIXCODE_SESSION_ID        "8814"
#define FIXCODE_INT_ORG           "8911"
#define FIXCODE_STK_CODE          "48"
#define FIXCODE_ORDER_PRICE       "44"
#define FIXCODE_ORDER_QTY         "38"
#define FIXCODE_STK_BIZ           "8842"
#define FIXCODE_STK_BIZ_ACTION    "40"
#define FIXCODE_ORDER_BSN         "66"
#define FIXCODE_ORDER_TEXT        "58"
#define FIXCODE_CLIENT_INFO       "9039"
#define FIXCODE_SECURITY_LEVEL    "9080"
#define FIXCODE_SECURITY_INFO     "9081"
#define FIXCODE_COMPONET_STK_CODE "8911"
#define FIXCODE_COMPONET_STKBD    "8962"
#define FIXCODE_STKBD_LINK        "17"
#define FIXCODE_TRDACCT           "448"
#define FIXCODE_CUACCT_SN         "8928"
#define FIXCODE_ORDER_ID          "11"
#define FIXCODE_ORDER_AMT         "8830"
#define FIXCODE_ORDER_FRZ_AMT     "8831"
#define FIXCODE_STK_NAME          "55"
#define FIXCODE_CANCEL_STATUS     "9080"
#define FIXCODE_QUERY_FLAG        "9080"
#define FIXCODE_QUERY_POS         "8991"
#define FIXCODE_QUERY_NUM         "8992"
#define FIXCODE_QRY_POS           "8991"
#define FIXCODE_TRD_DATE          "8844"
#define FIXCODE_ORDER_DATE        "8834"
#define FIXCODE_ORDER_TIME        "8845"
#define FIXCODE_ORDER_STATUS      "39"
#define FIXCODE_ORDER_VALID_FLAG  "8833"
#define FIXCODE_CURRENCY          "15"
#define FIXCODE_BOND_INT          "8960"
#define FIXCODE_ORDER_UFZ_AMT     "8835"
#define FIXCODE_OFFER_QTY         "37"
#define FIXCODE_OFFER_STIME       "8500"
#define FIXCODE_WITHDRAWN_QTY     "8837"
#define FIXCODE_MATCHED_QTY       "387"
#define FIXCODE_IS_WITHDRAW       "8836"
#define FIXCODE_IS_WITHDRAWN      "8838"
#define FIXCODE_MATCHED_AMT       "8504"
#define FIXCODE_MATCHED_TIME      "8840"
#define FIXCODE_ORDER_SN          "8832"
#define FIXCODE_MATCHED_SN        "17"
#define FIXCODE_MATCHED_PRICE     "8841"
#define FIXCODE_MATCHED_TYPE      "9080"
#define FIXCODE_VALUE_FLAG        "9080"
#define FIXCODE_MARKET_VALUE      "9081"
#define FIXCODE_FUND_VALUE        "9082"
#define FIXCODE_STK_VALUE         "9083"
#define FIXCODE_FUND_LOAN         "9084"
#define FIXCODE_FUND_PREBLN       "8860"
#define FIXCODE_FUND_BLN          "8984"
#define FIXCODE_FUND_AVL          "8861"
#define FIXCODE_FUND_FRZ          "8862"
#define FIXCODE_FUND_UFZ          "8863"
#define FIXCODE_FUND_TRD_FRZ      "8864"
#define FIXCODE_FUND_TRD_UFZ      "8865"
#define FIXCODE_FUND_TRD_OTD      "8866"
#define FIXCODE_FUND_TRD_BLN      "8867"
#define FIXCODE_FUND_STATUS       "8868"
#define FIXCODE_STK_CLS           "461"
#define FIXCODE_STK_PREBLN        "8501"
#define FIXCODE_STK_BLN           "8985"
#define FIXCODE_STK_AVL           "8869"
#define FIXCODE_STK_FRZ           "8870"
#define FIXCODE_STK_UFZ           "8871"
#define FIXCODE_STK_TRD_FRZ       "8872"
#define FIXCODE_STK_TRD_UFZ       "8873"
#define FIXCODE_STK_TRD_OTD       "8874"
#define FIXCODE_STK_BCOST         "8875"
#define FIXCODE_STK_BCOST_RLT     "8876"
#define FIXCODE_STK_PLAMT         "8877"
#define FIXCODE_STK_PLAMT_RLT     "8878"
#define FIXCODE_MKT_VAL           "8879"
#define FIXCODE_COST_PRICE        "9090"
#define FIXCODE_PRO_INCOME        "9091"
#define FIXCODE_STK_CAL_MKTVAL    "9092"
#define FIXCODE_STK_QTY           "9093"
#define FIXCODE_CURRENT_PRICE     "9094"
#define FIXCODE_PROFIT_PRICE      "9095"
#define FIXCODE_STK_DIFF          "9096"
#define FIXCODE_STK_TRD_UNFRZ     "9097"

#define FIXCODE_OP_USER           "8810"
#define FIXCODE_OP_ROLE           "8811"
#define FIXCODE_OP_SITE           "8812"
#define FIXCODE_CHANNEL           "8813"
#define FIXCODE_SESSION           "8814"
#define FIXCODE_FUNCTION          "8815"
#define FIXCODE_RUNTIME           "8816"
#define FIXCODE_OP_ORG            "8821"

#define FIXCODE_MSG_CODE          "8817"
#define FIXCODE_MSG_LEVEL         "8818"
#define FIXCODE_MSG_TEXT          "8819"
#define FIXCODE_MSG_DEBUG         "8820"


struct ClientLoginInput {
    std::string ACCT_TYPE;              //!< 账户类型(8987)
    std::string ACCT_ID;                //!< 账户标识(9081)
    std::string USE_SCOPE;              //!< 使用范围(9082)
    std::string ENCRYPT_KEY;            //!< 加密因子(9086)
    std::string AUTH_TYPE;              //!< 认证类型(9083)
    std::string AUTH_DATA;              //!< 认证数据(9084)
};
struct ClientLoginOutput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKEX;                  //!< 交易市场(207)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_TRDACCT;            //!< 证券账户(448)
    std::string TRDACCT_SN;             //!< 账户序号(8928)
    std::string TRDACCT_EXID;           //!< 报盘账户(8929)
    std::string TRDACCT_STATUS;         //!< 账户状态(8933)
    std::string TREG_STATUS;            //!< 指定状态(8934)
    std::string BREG_STATUS;            //!< 回购状态(8935)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string ACCT_TYPE;              //!< 账户类型(8987)
    std::string ACCT_ID;                //!< 账户标识(9081)
    std::string TRDACCT_NAME;           //!< 交易账户名称(8932)
    std::string CHANNEL_ID;             //!< 通道号(9082)
    std::string SESSION_ID;             //!< 会话凭证(8814)
    std::string INT_ORG;                //!< 内部机构(8911)
};
struct SecuEntrustInput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string ORDER_PRICE;            //!< 委托价格(44)
    std::string ORDER_QTY;              //!< 委托数量(38)
    std::string STK_BIZ;                //!< 证券业务(8842)
    std::string STK_BIZ_ACTION;         //!< 业务行为(40)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string ORDER_TEXT;             //!< 委托扩展(58)
    std::string CLIENT_INFO;            //!< 终端信息(9039)
    std::string SECURITY_LEVEL;         //!< 安全手段(9080)
    std::string SECURITY_INFO;          //!< 安全信息(9081)
    std::string COMPONET_STK_CODE;      //!< 成份股代码(8911)
    std::string COMPONET_STKBD;         //!< 成份股板块(8962)
    std::string STKBD_LINK;             //!< 关联板块(17)
    std::string TRDACCT;                //!< 证券账户(448)
    std::string CUACCT_SN;              //!< 账户序号(8928)
};
struct SecuEntrustOutput {
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string ORDER_PRICE;            //!< 委托价格(44)
    std::string ORDER_QTY;              //!< 委托数量(38)
    std::string ORDER_AMT;              //!< 委托金额(8830)
    std::string ORDER_FRZ_AMT;          //!< 冻结金额(8831)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string STK_NAME;               //!< 证券名称(55)
    std::string STK_BIZ;                //!< 证券业务(8842)
    std::string STK_BIZ_ACTION;         //!< 业务行为(40)
    std::string TRDACCT;                //!< 证券账户(448)
    std::string CUACCT_SN;              //!< 账户序号(8928)
};
struct SecuEntrustWithdrawInput {
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string ORDER_BSN;              //!< 委托批号(66)
};
struct SecuEntrustWithdrawOutput {
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string ORDER_PRICE;            //!< 委托价格(44)
    std::string ORDER_QTY;              //!< 委托数量(38)
    std::string ORDER_AMT;              //!< 委托金额(8830)
    std::string ORDER_FRZ_AMT;          //!< 冻结金额(8831)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string STK_NAME;               //!< 证券名称(55)
    std::string STK_BIZ;                //!< 证券业务(8842)
    std::string STK_BIZ_ACTION;         //!< 业务行为(40)
    std::string CANCEL_STATUS;          //!< 内部撤单标志(9080)
    std::string TRDACCT;                //!< 证券账户(448)
};
struct SecuEntrustQryInput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string TRDACCT;                //!< 交易账户(448)
    std::string QUERY_FLAG;             //!< 查询方向(9080)
    std::string QUERY_POS;              //!< 定位串(8991)
    std::string QUERY_NUM;              //!< 查询行数(8992)
    std::string CUACCT_SN;              //!< 账户序号(8928)
};
struct SecuEntrustQryOutput {
    std::string QRY_POS;                //!< 定位串(8991)
    std::string INT_ORG;                //!< 内部机构(8911)
    std::string TRD_DATE;               //!< 交易日期(8844)
    std::string ORDER_DATE;             //!< 委托日期(8834)
    std::string ORDER_TIME;             //!< 委托时间(8845)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string ORDER_STATUS;           //!< 委托状态(39)
    std::string ORDER_VALID_FLAG;       //!< 委托有效标志(8833)
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string STK_BIZ;                //!< 证券业务(8842)
    std::string STK_BIZ_ACTION;         //!< 业务行为(40)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string STK_NAME;               //!< 证券名称(55)
    std::string CURRENCY;               //!< 货币代码(15)
    std::string BOND_INT;               //!< 债券利息(8960)
    std::string ORDER_PRICE;            //!< 委托价格(44)
    std::string ORDER_QTY;              //!< 委托数量(38)
    std::string ORDER_AMT;              //!< 委托金额(8830)
    std::string ORDER_FRZ_AMT;          //!< 委托冻结金额(8831)
    std::string ORDER_UFZ_AMT;          //!< 委托解冻金额(8835)
    std::string OFFER_QTY;              //!< 申报数量(37)
    std::string OFFER_STIME;            //!< 申报时间(8500)
    std::string WITHDRAWN_QTY;          //!< 已撤单数量(8837)
    std::string MATCHED_QTY;            //!< 已成交数量(387)
    std::string IS_WITHDRAW;            //!< 撤单标志(8836)
    std::string IS_WITHDRAWN;           //!< 已撤单标志(8838)
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string MATCHED_AMT;            //!< 成交金额(8504)
    std::string TRDACCT;                //!< 交易账户(448)
    std::string CUACCT_SN;              //!< 账户序号(8928)
};
struct SecuRealDealQryInput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string TRDACCT;                //!< 交易账户(448)
    std::string QUERY_FLAG;             //!< 查询方向(9080)
    std::string QUERY_POS;              //!< 定位串(8991)
    std::string QUERY_NUM;              //!< 查询行数(8992)
    std::string CUACCT_SN;              //!< 账户序号(8928)
};
struct SecuRealDealQryOutput {
    std::string QRY_POS;                //!< 定位串(8991)
    std::string MATCHED_TIME;           //!< 成交时间(8840)
    std::string ORDER_DATE;             //!< 委托日期(8834)
    std::string ORDER_SN;               //!< 委托序号(8832)
    std::string ORDER_BSN;              //!< 委托批号(66)
    std::string ORDER_ID;               //!< 合同序号(11)
    std::string INT_ORG;                //!< 内部机构(8911)
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string STK_TRDACCT;            //!< 证券账户(448)
    std::string STK_BIZ;                //!< 证券业务(8842)
    std::string STK_BIZ_ACTION;         //!< 证券业务行为(40)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string STK_NAME;               //!< 证券名称(55)
    std::string CURRENCY;               //!< 货币代码(15)
    std::string BOND_INT;               //!< 债券利息(8960)
    std::string ORDER_PRICE;            //!< 委托价格(44)
    std::string ORDER_QTY;              //!< 委托数量(38)
    std::string ORDER_AMT;              //!< 委托金额(8830)
    std::string ORDER_FRZ_AMT;          //!< 委托冻结金额(8831)
    std::string MATCHED_SN;             //!< 成交编号(17)
    std::string MATCHED_PRICE;          //!< 成交价格(8841)
    std::string MATCHED_QTY;            //!< 已成交数量(387)
    std::string MATCHED_AMT;            //!< 已成交金额(8504)
    std::string MATCHED_TYPE;           //!< 成交类型(9080)
    std::string CUACCT_SN;              //!< 账户序号(8928)
};
struct FundAssetQryInput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string CURRENCY;               //!< 货币代码(15)
    std::string VALUE_FLAG;             //!< 取值标志(9080)
};
struct FundAssetQryOutput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string CURRENCY;               //!< 货币代码(15)
    std::string INT_ORG;                //!< 内部机构(8911)
    std::string MARKET_VALUE;           //!< 资产总值(9081)
    std::string FUND_VALUE;             //!< 资金资产(9082)
    std::string STK_VALUE;              //!< 市值(9083)
    std::string FUND_LOAN;              //!< 融资总金额(9084)
    std::string FUND_PREBLN;            //!< 资金昨日余额(8860)
    std::string FUND_BLN;               //!< 资金余额(8984)
    std::string FUND_AVL;               //!< 资金可用金额(8861)
    std::string FUND_FRZ;               //!< 资金冻结金额(8862)
    std::string FUND_UFZ;               //!< 资金解冻金额(8863)
    std::string FUND_TRD_FRZ;           //!< 资金交易冻结金额(8864)
    std::string FUND_TRD_UFZ;           //!< 资金交易解冻金额(8865)
    std::string FUND_TRD_OTD;           //!< 资金交易在途金额(8866)
    std::string FUND_TRD_BLN;           //!< 资金交易轧差金额(8867)
    std::string FUND_STATUS;            //!< 资金状态(8868)
};
struct SecuUnitStkQryInput {
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string QUERY_FLAG;             //!< 查询方向(9080)
    std::string TRDACCT;                //!< 交易账户(448)
    std::string QUERY_POS;              //!< 定位串(8991)
    std::string QUERY_NUM;              //!< 查询行数(8992)
};
struct SecuUnitStkQryOutput {
    std::string QRY_POS;                //!< 定位串(8991)
    std::string INT_ORG;                //!< 内部机构(8911)
    std::string CUST_CODE;              //!< 客户代码(8902)
    std::string CUACCT_CODE;            //!< 资产账户(8920)
    std::string STKBD;                  //!< 交易板块(625)
    std::string STKPBU;                 //!< 交易单元(8843)
    std::string CURRENCY;               //!< 货币代码(15)
    std::string STK_CODE;               //!< 证券代码(48)
    std::string STK_NAME;               //!< 证券名称(55)
    std::string STK_CLS;                //!< 证券类别(461)
    std::string STK_PREBLN;             //!< 证券昨日余额(8501)
    std::string STK_BLN;                //!< 证券余额(8985)
    std::string STK_AVL;                //!< 证券可用数量(8869)
    std::string STK_FRZ;                //!< 证券冻结数量(8870)
    std::string STK_UFZ;                //!< 证券解冻数量(8871)
    std::string STK_TRD_FRZ;            //!< 证券交易冻结数量(8872)
    std::string STK_TRD_UFZ;            //!< 证券交易解冻数量(8873)
    std::string STK_TRD_OTD;            //!< 证券交易在途数量(8874)
    std::string STK_BCOST;              //!< 证券买入成本(8875)
    std::string STK_BCOST_RLT;          //!< 证券买入成本（实时）(8876)
    std::string STK_PLAMT;              //!< 证券盈亏金额(8877)
    std::string STK_PLAMT_RLT;          //!< 证券盈亏金额（实时）(8878)
    std::string MKT_VAL;                //!< 市值(8879)
    std::string COST_PRICE;             //!< 成本价格(9090)
    std::string PRO_INCOME;             //!< 参考盈亏(9091)
    std::string STK_CAL_MKTVAL;         //!< 市值计算标识(9092)
    std::string STK_QTY;                //!< 当前拥股数(9093)
    std::string CURRENT_PRICE;          //!< 最新价格(9094)
    std::string PROFIT_PRICE;           //!< 参考成本价(9095)
    std::string STK_DIFF;               //!< 可申赎数量(9096)
    std::string STK_TRD_UNFRZ;          //!< 已申赎数量(9097)
    std::string TRDACCT;                //!< 交易账户(448)
};

#endif // KDVIPDATASTRUCT_H
