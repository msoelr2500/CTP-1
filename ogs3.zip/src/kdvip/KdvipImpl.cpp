﻿/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipImpl.h"
#include <qtp_log.h>
#include <iostream>
#include "../BufferHandle.h"
#include "../ReadConfig.h"
#include "../OgsApi.h"
#include "KdvipConverter.h"
#include <qtp_log.h>

using ogs::PackBuffer;
using ogs::UnpackBuffer;
using ogs::ReadConfig;
using std::vector;
using std::string;
using std::map;

KdvipClientManager KdvipImpl::mClients;

KdvipImpl::KdvipImpl()
{
    KdvipConfig config;
    config.mSiteInfoFormat = ReadConfig::localOption.SiteInfoFormat;
    config.mBrokerAddr     = ReadConfig::localOption.BrokerAddr;
    config.mBrokerPort     = ReadConfig::localOption.BrokerPort;
    config.mEncryptKey     = ReadConfig::localOption.Reserve1;
    config.mChannel        = ReadConfig::localOption.EntrustMode;
    mConnection.setConfig(config);
}

KdvipImpl::~KdvipImpl() {}

bool KdvipImpl::initialize()
{
    return mConnection.initialize();
}

bool KdvipImpl::connect()
{
    return mConnection.connect();
}

void KdvipImpl::disconnect()
{
    mConnection.disconnect();
}

Intf_RetType KdvipImpl::heartBeatToBroker()
{
    return kIntfNotSupport;
}

void KdvipImpl::setCallBack(int (*fn)(ogs::QueryOrderAns))
{
    func = fn;
}

bool KdvipImpl::isConnected() const
{
    return mConnection.isConnected();
}

Intf_RetType KdvipImpl::ogsLogin(const ogs::LoginQry &in, std::list<ogs::LoginAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    // 设置输入。
    ClientLoginInput input;
    if (strlen(in.bacid) != 0) {
        input.ACCT_ID = in.bacid;
        input.ACCT_TYPE = "Z";
    } else if (strlen(in.acidcard) != 0) {
        input.ACCT_ID = in.acidcard;
        input.ACCT_TYPE = "U";
    }

    input.USE_SCOPE   = "0";
    input.ENCRYPT_KEY = mConnection.config().mEncryptKey;
    input.AUTH_TYPE   = "0";
    input.AUTH_DATA   = mConnection.TO_AUTH_DATA(in.password);

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = "[OP_SITE]";
    fixInput.OP_USER = input.ACCT_ID;
    fixInput.OP_ORG  = "0";
    fixInput.SESSION = "[SESSION]";

    std::list<ClientLoginOutput> output;
    Intf_RetType result = mConnection.kdvipClientLogin(fixInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    map<string, KdvipClient> clients;
    for (ClientLoginOutput& item : output) {
        KdvipClient& client = clients[item.CUST_CODE];
        client.client_id = item.CUST_CODE;
        client.mData.ACCT_ID = item.ACCT_ID;
        client.mData.ACCT_TYPE = item.ACCT_TYPE;
        client.mData.CHANNEL_ID = item.CHANNEL_ID;
        client.mData.INT_ORG = item.INT_ORG;
        client.mData.SESSION_ID = item.SESSION_ID;

        int fIndex = client.indexOf(item.CUACCT_CODE);
        if (fIndex < 0) {
            KdvipFundAccount fundAccount;
            fundAccount.fund_account = item.CUACCT_CODE;
            fIndex = client.addNewFundAccount(fundAccount);

            // 仅当出现了新的资金账号时才会加入新的LoginAns。
            ogs::LoginAns ans;
            KdvipConverter::FROM_CUACCT_ID(ans.bacid, item.CUACCT_CODE);
            out.push_back(ans);
        }

        KdvipFundAccount& fundAccount = client[fIndex];
        Exchange exchange = KdvipConverter::toExchange(item.STKEX, item.STKBD);

        if (AccountHelper::isExchangeValid(exchange)) {
            KdvipTradeAccount& account = fundAccount[exchange];
            account.stock_account = item.STK_TRDACCT;
            account.STKBD = item.STKBD;
            account.STKEX = item.STKEX;
            account.TRDACCT_EXID = item.TRDACCT_EXID;
            account.TRDACCT_NAME = item.TRDACCT_NAME;
            account.TRDACCT_SN = item.TRDACCT_SN;
            account.TRDACCT_STATUS = item.TRDACCT_STATUS;
            account.TREG_STATUS = item.TREG_STATUS;
            account.BREG_STATUS = item.BREG_STATUS;
            account.STKPBU      = item.STKPBU;
            account.enabled = true;
        }
    }

    for (map<string, KdvipClient>::const_iterator i = clients.begin(); i != clients.end(); ++i) {
        mClients.addNewClient(i->second);
    }

    mClients.printAccounts();

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsSendOrder(const ogs::SendOrderQry &in, std::list<ogs::SendOrderAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    std::string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    KdvipClientData clientData = mClients.clientDataByFundAccount(KdvipConverter::TO_CUACCT_CODE(in.bacid));
    KdvipTradeAccount tradeAccount = mClients.tradeAccount(KdvipConverter::TO_CUACCT_CODE(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    SecuEntrustInput input;
    input.CUST_CODE = KdvipConverter::TO_CUST_CODE(in.acidcard);
    input.CUACCT_CODE = KdvipConverter::TO_CUACCT_CODE(in.bacid);
    input.STKBD = tradeAccount.STKBD;
    input.STK_CODE = code;
    input.ORDER_PRICE = KdvipConverter::TO_ORDER_PRICE(in.price);
    input.ORDER_QTY = KdvipConverter::TO_ORDER_QTY(in.volume);
    input.STK_BIZ = KdvipConverter::TO_STK_BIZ(in.directive);
    input.STK_BIZ_ACTION = KdvipConverter::TO_STK_BIZ_ACTION(in.execution);
    input.STKPBU = tradeAccount.STKPBU;
    input.SECURITY_LEVEL = "1"; // 1: 校验会话凭证
    input.TRDACCT = tradeAccount.stock_account;

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = TO_OP_SITE(args);
    fixInput.OP_USER = input.CUST_CODE;
    fixInput.OP_ORG  = clientData.INT_ORG;
    fixInput.SESSION = clientData.SESSION_ID;

    std::list<SecuEntrustOutput> output;
    Intf_RetType result = mConnection.kdvipSecuEntrust(fixInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustOutput& item : output) {
        ogs::SendOrderAns ans = {0};
        ans.custOrderId = in.custOrderId;
        strcpy(ans.bacid, in.bacid);
        KdvipConverter::FROM_ORDER_BSN(item.ORDER_BSN, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsCancelOrder(const ogs::CancelOrderQry &in, std::list<ogs::CancelOrderAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    std::string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    string CUACCT_CODE = KdvipConverter::TO_CUACCT_CODE(in.bacid);
    KdvipClientData clientData = mClients.clientDataByFundAccount(CUACCT_CODE);
    KdvipTradeAccount tradeAccount = mClients.tradeAccount(CUACCT_CODE, AccountHelper::toExchange(market));

    // 设置输入。
    SecuEntrustWithdrawInput input;
    input.CUACCT_CODE = CUACCT_CODE;
    input.ORDER_BSN   = KdvipConverter::TO_ORDER_BSN(in.sysOrderId);
    input.STKBD       = tradeAccount.STKBD;

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = TO_OP_SITE(args);
    fixInput.OP_USER = input.CUACCT_CODE;
    fixInput.OP_ORG  = clientData.INT_ORG;
    fixInput.SESSION = clientData.SESSION_ID;

    std::list<SecuEntrustWithdrawOutput> output;
    Intf_RetType result = mConnection.kdvipSecuEntrustWithdraw(fixInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustWithdrawOutput& item : output) {
        ogs::CancelOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        KdvipConverter::FROM_ORDER_BSN(item.ORDER_BSN, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsQueryOrder(const ogs::QueryOrderQry &in, std::list<ogs::QueryOrderAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    std::string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    string CUACCT_CODE = KdvipConverter::TO_CUACCT_CODE(in.bacid);
    KdvipClientData clientData = mClients.clientDataByFundAccount(CUACCT_CODE);
    KdvipTradeAccount tradeAccount = mClients.tradeAccount(CUACCT_CODE, AccountHelper::toExchange(market));

    // 设置输入。
    SecuEntrustQryInput input;
    input.CUST_CODE   = KdvipConverter::TO_CUST_CODE(in.acidcard);
    input.CUACCT_CODE = CUACCT_CODE;
    input.STKBD       = tradeAccount.STKBD;
    input.STK_CODE    = code;
    input.ORDER_BSN   = KdvipConverter::TO_ORDER_BSN(in.sysOrderId);
    input.TRDACCT     = tradeAccount.stock_account;

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = TO_OP_SITE(args);
    fixInput.OP_USER = input.CUST_CODE;
    fixInput.OP_ORG  = clientData.INT_ORG;
    fixInput.SESSION = clientData.SESSION_ID;

    std::list<SecuEntrustQryOutput> output;
    Intf_RetType result = mConnection.kdvipSecuEntrustQry(fixInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustQryOutput& item : output) {
        ogs::QueryOrderAns ans = {0};
        KdvipConverter::FROM_CUACCT_ID(ans.bacid, item.CUACCT_CODE);
        ans.custOrderId    = in.custOrderId;
        ans.price          = KdvipConverter::FROM_ORDER_PRICE(item.ORDER_PRICE);
        ans.volume         = KdvipConverter::FROM_ORDER_QTY(item.ORDER_QTY);
        ans.withdrawVolume = KdvipConverter::FROM_WITHDRAWN_QTY(item.WITHDRAWN_QTY);
        ans.dealBalance    = KdvipConverter::FROM_MATCHED_AMT(item.MATCHED_AMT);
        ans.dealVolume     = KdvipConverter::FROM_MATCHED_QTY(item.MATCHED_QTY);
        // 当dealVolume等于0时，直接相除会导致程序崩溃。
        ans.dealPrice      = (ans.dealVolume == 0) ? ans.price : ans.dealBalance / ans.dealVolume;
        ans.directive      = KdvipConverter::FROM_STK_BIZ(item.STK_BIZ);
        ans.innerCode      = qtp::UniversalCode::SymbolToUC(item.STK_CODE, market);;
        ans.orderStatus    = KdvipConverter::FROM_ORDER_STATUS(item.ORDER_STATUS);
        ans.orderTime      = KdvipConverter::FROM_ORDER_TIME(item.ORDER_TIME);
        KdvipConverter::FROM_ORDER_BSN(item.ORDER_BSN, ans.sysOrderId);
        ans.tradeDate      = KdvipConverter::FROM_TRD_DATE(item.TRD_DATE);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsQueryPosition(const ogs::QueryPositionQry &in, std::list<ogs::QueryPositionAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    std::string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    string CUACCT_CODE = KdvipConverter::TO_CUACCT_CODE(in.bacid);
    KdvipClientData clientData = mClients.clientDataByFundAccount(CUACCT_CODE);
    KdvipTradeAccount tradeAccount = mClients.tradeAccount(CUACCT_CODE, AccountHelper::toExchange(market));

    // 设置输入。
    SecuUnitStkQryInput input;
    input.CUST_CODE   = KdvipConverter::TO_CUST_CODE(in.acidcard);
    input.CUACCT_CODE = CUACCT_CODE;
    input.STKBD       = tradeAccount.STKBD;
    input.STK_CODE    = code;
    input.TRDACCT     = tradeAccount.stock_account;

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = TO_OP_SITE(args);
    fixInput.OP_USER = input.CUST_CODE;
    fixInput.OP_ORG  = clientData.INT_ORG;
    fixInput.SESSION = clientData.SESSION_ID;

    std::list<SecuUnitStkQryOutput> output;
    Intf_RetType result = mConnection.kdvipSecuUnitStkQry(fixInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuUnitStkQryOutput& item : output) {
        ogs::QueryPositionAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        strcpy(ans.bacid, in.bacid);
        ans.currentVolume  = KdvipConverter::FROM_STK_BLN(item.STK_BLN);
        ans.innerCode      = qtp::UniversalCode::SymbolToUC(item.STK_CODE, market);
        ans.usableVolume   = KdvipConverter::FROM_STK_AVL(item.STK_AVL);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsQueryBargain(const ogs::QueryBargainQry &in, std::list<ogs::QueryBargainAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    std::string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    string CUACCT_CODE = KdvipConverter::TO_CUACCT_CODE(in.bacid);
    KdvipClientData clientData = mClients.clientDataByFundAccount(CUACCT_CODE);
    KdvipTradeAccount tradeAccount = mClients.tradeAccount(CUACCT_CODE, AccountHelper::toExchange(market));

    // 设置输入。
    SecuRealDealQryInput input;
    input.CUST_CODE   = KdvipConverter::TO_CUST_CODE(in.acidcard);
    input.CUACCT_CODE = CUACCT_CODE;
    input.STKBD       = tradeAccount.STKBD;
    input.STK_CODE    = code;
    input.ORDER_BSN   = KdvipConverter::TO_ORDER_BSN(in.sysOrderId);
    input.TRDACCT     = tradeAccount.stock_account;

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = TO_OP_SITE(args);
    fixInput.OP_USER = input.CUST_CODE;
    fixInput.OP_ORG  = clientData.INT_ORG;
    fixInput.SESSION = clientData.SESSION_ID;

    std::list<SecuRealDealQryOutput> output;
    Intf_RetType result = mConnection.kdvipSecuRealDealQry(fixInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuRealDealQryOutput& item : output) {
        ogs::QueryBargainAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId    = in.custOrderId;
        ans.dealBalance    = KdvipConverter::FROM_MATCHED_AMT(item.MATCHED_AMT);
        ans.dealVolume     = KdvipConverter::FROM_MATCHED_QTY(item.MATCHED_QTY);
        ans.dealPrice      = KdvipConverter::FROM_MATCHED_PRICE(item.MATCHED_PRICE);
        ans.innerCode      = qtp::UniversalCode::SymbolToUC(item.STK_CODE, market);
        KdvipConverter::FROM_ORDER_BSN(item.ORDER_BSN, ans.sysOrderId);
        KdvipConverter::FROM_MATCHED_SN(item.MATCHED_SN, ans.dealId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsQueryFundInfo(const ogs::QueryFundInfoQry &in, std::list<ogs::QueryFundInfoAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    out.clear();

    // 查找指定账户。
    string CUACCT_CODE = KdvipConverter::TO_CUACCT_CODE(in.bacid);
    KdvipClientData clientData = mClients.clientDataByFundAccount(CUACCT_CODE);

    // 设置输入。
    FundAssetQryInput input;
    input.CUST_CODE   = KdvipConverter::TO_CUST_CODE(in.acidcard);
    input.CUACCT_CODE = CUACCT_CODE;
    input.VALUE_FLAG  = "2"; // 2：取FUND_VALUE值

    // 调用接口。
    KdvipFixedInput fixInput;
    fixInput.CHANNEL = mConnection.config().mChannel;
    fixInput.OP_SITE = TO_OP_SITE(args);
    fixInput.OP_USER = input.CUST_CODE;
    fixInput.OP_ORG  = clientData.INT_ORG;
    fixInput.SESSION = clientData.SESSION_ID;

    std::list<FundAssetQryOutput> output;
    Intf_RetType result = mConnection.kdvipFundAssetQry(fixInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (FundAssetQryOutput& item : output) {
        ogs::QueryFundInfoAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        KdvipConverter::FROM_CUACCT_ID(ans.bacid, item.CUACCT_CODE);
        ans.balance        = KdvipConverter::FROM_FUND_BLN(item.FUND_BLN);
        ans.frozenBalance  = KdvipConverter::FROM_FUND_FRZ(item.FUND_FRZ);
        ans.useableBalance = KdvipConverter::FROM_FUND_AVL(item.FUND_AVL);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KdvipImpl::ogsPaybackSecurity(const ogs::PaybackSecurityQry &in, std::list<ogs::PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    return kIntfNotSupport;
}

Intf_RetType KdvipImpl::ogsPaybackFunds(const ogs::PaybackFundsQry &in, std::list<ogs::PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string> &args)
{
    return kIntfNotSupport;
}

std::string KdvipImpl::TO_OP_SITE(std::map<int, std::string> &args)
{
    // 默认使用配置文件中的站点信息格式。
    return ogs::SiteInfo(mConnection.config().mSiteInfoFormat, args);
}
