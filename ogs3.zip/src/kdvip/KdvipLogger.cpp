/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipLogger.h"

OgsLogger &operator << (OgsLogger &logger, const KdvipFixedInput &data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[KdvipFixedInput]======================";
    ogsDebug << "|OP_USER                      |" << data.OP_USER;
    ogsDebug << "|OP_ROLE                      |" << data.OP_ROLE;
    ogsDebug << "|OP_SITE;                     |" << data.OP_SITE;
    ogsDebug << "|CHANNEL;                     |" << data.CHANNEL;
    ogsDebug << "|SESSION;                     |" << data.SESSION;
    ogsDebug << "|OP_ORG;                      |" << data.OP_ORG;
    return logger;
}

OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[ClientLoginInput]=====================";
    ogsDebug << "|ACCT_TYPE                    |" << data.ACCT_TYPE;
    ogsDebug << "|ACCT_ID                      |" << data.ACCT_ID;
    ogsDebug << "|USE_SCOPE                    |" << data.USE_SCOPE;
    ogsDebug << "|ENCRYPT_KEY                  |" << data.ENCRYPT_KEY;
    ogsDebug << "|AUTH_TYPE                    |" << data.AUTH_TYPE;
    ogsDebug << "|AUTH_DATA                    |" << data.AUTH_DATA;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[ClientLoginOutput]=====================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKEX                        |" << data.STKEX;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_TRDACCT                  |" << data.STK_TRDACCT;
    ogsDebug << "|TRDACCT_SN                   |" << data.TRDACCT_SN;
    ogsDebug << "|TRDACCT_EXID                 |" << data.TRDACCT_EXID;
    ogsDebug << "|TRDACCT_STATUS               |" << data.TRDACCT_STATUS;
    ogsDebug << "|TREG_STATUS                  |" << data.TREG_STATUS;
    ogsDebug << "|BREG_STATUS                  |" << data.BREG_STATUS;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|ACCT_TYPE                    |" << data.ACCT_TYPE;
    ogsDebug << "|ACCT_ID                      |" << data.ACCT_ID;
    ogsDebug << "|TRDACCT_NAME                 |" << data.TRDACCT_NAME;
    ogsDebug << "|CHANNEL_ID                   |" << data.CHANNEL_ID;
    ogsDebug << "|SESSION_ID                   |" << data.SESSION_ID;
    ogsDebug << "|INT_ORG                      |" << data.INT_ORG;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[SecuEntrustInput]=====================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|ORDER_PRICE                  |" << data.ORDER_PRICE;
    ogsDebug << "|ORDER_QTY                    |" << data.ORDER_QTY;
    ogsDebug << "|STK_BIZ                      |" << data.STK_BIZ;
    ogsDebug << "|STK_BIZ_ACTION               |" << data.STK_BIZ_ACTION;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|ORDER_TEXT                   |" << data.ORDER_TEXT;
    ogsDebug << "|CLIENT_INFO                  |" << data.CLIENT_INFO;
    ogsDebug << "|SECURITY_LEVEL               |" << data.SECURITY_LEVEL;
    ogsDebug << "|SECURITY_INFO                |" << data.SECURITY_INFO;
    ogsDebug << "|COMPONET_STK_CODE            |" << data.COMPONET_STK_CODE;
    ogsDebug << "|COMPONET_STKBD               |" << data.COMPONET_STKBD;
    ogsDebug << "|STKBD_LINK                   |" << data.STKBD_LINK;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    ogsDebug << "|CUACCT_SN                    |" << data.CUACCT_SN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEntrustOutput]=====================";
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|ORDER_PRICE                  |" << data.ORDER_PRICE;
    ogsDebug << "|ORDER_QTY                    |" << data.ORDER_QTY;
    ogsDebug << "|ORDER_AMT                    |" << data.ORDER_AMT;
    ogsDebug << "|ORDER_FRZ_AMT                |" << data.ORDER_FRZ_AMT;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|STK_NAME                     |" << data.STK_NAME;
    ogsDebug << "|STK_BIZ                      |" << data.STK_BIZ;
    ogsDebug << "|STK_BIZ_ACTION               |" << data.STK_BIZ_ACTION;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    ogsDebug << "|CUACCT_SN                    |" << data.CUACCT_SN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustWithdrawInput]=================";
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuEntrustWithdrawOutput]=================";
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|ORDER_PRICE                  |" << data.ORDER_PRICE;
    ogsDebug << "|ORDER_QTY                    |" << data.ORDER_QTY;
    ogsDebug << "|ORDER_AMT                    |" << data.ORDER_AMT;
    ogsDebug << "|ORDER_FRZ_AMT                |" << data.ORDER_FRZ_AMT;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|STK_NAME                     |" << data.STK_NAME;
    ogsDebug << "|STK_BIZ                      |" << data.STK_BIZ;
    ogsDebug << "|STK_BIZ_ACTION               |" << data.STK_BIZ_ACTION;
    ogsDebug << "|CANCEL_STATUS                |" << data.CANCEL_STATUS;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryInput]====================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    ogsDebug << "|QUERY_FLAG                   |" << data.QUERY_FLAG;
    ogsDebug << "|QUERY_POS                    |" << data.QUERY_POS;
    ogsDebug << "|QUERY_NUM                    |" << data.QUERY_NUM;
    ogsDebug << "|CUACCT_SN                    |" << data.CUACCT_SN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryOutput]===================";
    ogsDebug << "|QRY_POS                      |" << data.QRY_POS;
    ogsDebug << "|INT_ORG                      |" << data.INT_ORG;
    ogsDebug << "|TRD_DATE                     |" << data.TRD_DATE;
    ogsDebug << "|ORDER_DATE                   |" << data.ORDER_DATE;
    ogsDebug << "|ORDER_TIME                   |" << data.ORDER_TIME;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|ORDER_STATUS                 |" << data.ORDER_STATUS;
    ogsDebug << "|ORDER_VALID_FLAG             |" << data.ORDER_VALID_FLAG;
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|STK_BIZ                      |" << data.STK_BIZ;
    ogsDebug << "|STK_BIZ_ACTION               |" << data.STK_BIZ_ACTION;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|STK_NAME                     |" << data.STK_NAME;
    ogsDebug << "|CURRENCY                     |" << data.CURRENCY;
    ogsDebug << "|BOND_INT                     |" << data.BOND_INT;
    ogsDebug << "|ORDER_PRICE                  |" << data.ORDER_PRICE;
    ogsDebug << "|ORDER_QTY                    |" << data.ORDER_QTY;
    ogsDebug << "|ORDER_AMT                    |" << data.ORDER_AMT;
    ogsDebug << "|ORDER_FRZ_AMT                |" << data.ORDER_FRZ_AMT;
    ogsDebug << "|ORDER_UFZ_AMT                |" << data.ORDER_UFZ_AMT;
    ogsDebug << "|OFFER_QTY                    |" << data.OFFER_QTY;
    ogsDebug << "|OFFER_STIME                  |" << data.OFFER_STIME;
    ogsDebug << "|WITHDRAWN_QTY                |" << data.WITHDRAWN_QTY;
    ogsDebug << "|MATCHED_QTY                  |" << data.MATCHED_QTY;
    ogsDebug << "|IS_WITHDRAW                  |" << data.IS_WITHDRAW;
    ogsDebug << "|IS_WITHDRAWN                 |" << data.IS_WITHDRAWN;
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|MATCHED_AMT                  |" << data.MATCHED_AMT;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    ogsDebug << "|CUACCT_SN                    |" << data.CUACCT_SN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuRealDealQryInput]===================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    ogsDebug << "|QUERY_FLAG                   |" << data.QUERY_FLAG;
    ogsDebug << "|QUERY_POS                    |" << data.QUERY_POS;
    ogsDebug << "|QUERY_NUM                    |" << data.QUERY_NUM;
    ogsDebug << "|CUACCT_SN                    |" << data.CUACCT_SN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuRealDealQryOutput]===================";
    ogsDebug << "|QRY_POS                      |" << data.QRY_POS;
    ogsDebug << "|MATCHED_TIME                 |" << data.MATCHED_TIME;
    ogsDebug << "|ORDER_DATE                   |" << data.ORDER_DATE;
    ogsDebug << "|ORDER_SN                     |" << data.ORDER_SN;
    ogsDebug << "|ORDER_BSN                    |" << data.ORDER_BSN;
    ogsDebug << "|ORDER_ID                     |" << data.ORDER_ID;
    ogsDebug << "|INT_ORG                      |" << data.INT_ORG;
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|STK_TRDACCT                  |" << data.STK_TRDACCT;
    ogsDebug << "|STK_BIZ                      |" << data.STK_BIZ;
    ogsDebug << "|STK_BIZ_ACTION               |" << data.STK_BIZ_ACTION;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|STK_NAME                     |" << data.STK_NAME;
    ogsDebug << "|CURRENCY                     |" << data.CURRENCY;
    ogsDebug << "|BOND_INT                     |" << data.BOND_INT;
    ogsDebug << "|ORDER_PRICE                  |" << data.ORDER_PRICE;
    ogsDebug << "|ORDER_QTY                    |" << data.ORDER_QTY;
    ogsDebug << "|ORDER_AMT                    |" << data.ORDER_AMT;
    ogsDebug << "|ORDER_FRZ_AMT                |" << data.ORDER_FRZ_AMT;
    ogsDebug << "|MATCHED_SN                   |" << data.MATCHED_SN;
    ogsDebug << "|MATCHED_PRICE                |" << data.MATCHED_PRICE;
    ogsDebug << "|MATCHED_QTY                  |" << data.MATCHED_QTY;
    ogsDebug << "|MATCHED_AMT                  |" << data.MATCHED_AMT;
    ogsDebug << "|MATCHED_TYPE                 |" << data.MATCHED_TYPE;
    ogsDebug << "|CUACCT_SN                    |" << data.CUACCT_SN;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FundAssetQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[FundAssetQryInput]=====================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|CURRENCY                     |" << data.CURRENCY;
    ogsDebug << "|VALUE_FLAG                   |" << data.VALUE_FLAG;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FundAssetQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[FundAssetQryOutput]====================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|CURRENCY                     |" << data.CURRENCY;
    ogsDebug << "|INT_ORG                      |" << data.INT_ORG;
    ogsDebug << "|MARKET_VALUE                 |" << data.MARKET_VALUE;
    ogsDebug << "|FUND_VALUE                   |" << data.FUND_VALUE;
    ogsDebug << "|STK_VALUE                    |" << data.STK_VALUE;
    ogsDebug << "|FUND_LOAN                    |" << data.FUND_LOAN;
    ogsDebug << "|FUND_PREBLN                  |" << data.FUND_PREBLN;
    ogsDebug << "|FUND_BLN                     |" << data.FUND_BLN;
    ogsDebug << "|FUND_AVL                     |" << data.FUND_AVL;
    ogsDebug << "|FUND_FRZ                     |" << data.FUND_FRZ;
    ogsDebug << "|FUND_UFZ                     |" << data.FUND_UFZ;
    ogsDebug << "|FUND_TRD_FRZ                 |" << data.FUND_TRD_FRZ;
    ogsDebug << "|FUND_TRD_UFZ                 |" << data.FUND_TRD_UFZ;
    ogsDebug << "|FUND_TRD_OTD                 |" << data.FUND_TRD_OTD;
    ogsDebug << "|FUND_TRD_BLN                 |" << data.FUND_TRD_BLN;
    ogsDebug << "|FUND_STATUS                  |" << data.FUND_STATUS;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryInput]====================";
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|QUERY_FLAG                   |" << data.QUERY_FLAG;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    ogsDebug << "|QUERY_POS                    |" << data.QUERY_POS;
    ogsDebug << "|QUERY_NUM                    |" << data.QUERY_NUM;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryOutput]===================";
    ogsDebug << "|QRY_POS                      |" << data.QRY_POS;
    ogsDebug << "|INT_ORG                      |" << data.INT_ORG;
    ogsDebug << "|CUST_CODE                    |" << data.CUST_CODE;
    ogsDebug << "|CUACCT_CODE                  |" << data.CUACCT_CODE;
    ogsDebug << "|STKBD                        |" << data.STKBD;
    ogsDebug << "|STKPBU                       |" << data.STKPBU;
    ogsDebug << "|CURRENCY                     |" << data.CURRENCY;
    ogsDebug << "|STK_CODE                     |" << data.STK_CODE;
    ogsDebug << "|STK_NAME                     |" << data.STK_NAME;
    ogsDebug << "|STK_CLS                      |" << data.STK_CLS;
    ogsDebug << "|STK_PREBLN                   |" << data.STK_PREBLN;
    ogsDebug << "|STK_BLN                      |" << data.STK_BLN;
    ogsDebug << "|STK_AVL                      |" << data.STK_AVL;
    ogsDebug << "|STK_FRZ                      |" << data.STK_FRZ;
    ogsDebug << "|STK_UFZ                      |" << data.STK_UFZ;
    ogsDebug << "|STK_TRD_FRZ                  |" << data.STK_TRD_FRZ;
    ogsDebug << "|STK_TRD_UFZ                  |" << data.STK_TRD_UFZ;
    ogsDebug << "|STK_TRD_OTD                  |" << data.STK_TRD_OTD;
    ogsDebug << "|STK_BCOST                    |" << data.STK_BCOST;
    ogsDebug << "|STK_BCOST_RLT                |" << data.STK_BCOST_RLT;
    ogsDebug << "|STK_PLAMT                    |" << data.STK_PLAMT;
    ogsDebug << "|STK_PLAMT_RLT                |" << data.STK_PLAMT_RLT;
    ogsDebug << "|MKT_VAL                      |" << data.MKT_VAL;
    ogsDebug << "|COST_PRICE                   |" << data.COST_PRICE;
    ogsDebug << "|PRO_INCOME                   |" << data.PRO_INCOME;
    ogsDebug << "|STK_CAL_MKTVAL               |" << data.STK_CAL_MKTVAL;
    ogsDebug << "|STK_QTY                      |" << data.STK_QTY;
    ogsDebug << "|CURRENT_PRICE                |" << data.CURRENT_PRICE;
    ogsDebug << "|PROFIT_PRICE                 |" << data.PROFIT_PRICE;
    ogsDebug << "|STK_DIFF                     |" << data.STK_DIFF;
    ogsDebug << "|STK_TRD_UNFRZ                |" << data.STK_TRD_UNFRZ;
    ogsDebug << "|TRDACCT                      |" << data.TRDACCT;
    return logger;
}

