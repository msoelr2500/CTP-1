/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipApiWrapper.h"
#include "../StringHelper.h"
#include "KdvipReader.h"
#include <cstring>
#include "KdvipLogger.h"
#include "KdvipSettings.h"
#include <time.h>

using namespace std;

mutex KdvipApiWrapper::mInitMutex;
ST_MACLI_CONNECT_OPTION KdvipApiWrapper::stConnectOption = {0};
ST_MACLI_USERINFO KdvipApiWrapper::stMacliUserInfo = {0};
char KdvipApiWrapper::mEncryptKey[32] = {0};
char KdvipApiWrapper::mChannel[12] = {0};

KdvipApiWrapper::KdvipApiWrapper() {}

KdvipApiWrapper::KdvipApiWrapper(const KdvipConfig &config)
{
    setConfig(config);
}

KdvipApiWrapper::~KdvipApiWrapper()
{
    maCli_Close(hHandle);
    maCli_Exit(hHandle);
}

bool KdvipApiWrapper::initialize()
{
    lock_guard<mutex> initLock(mInitMutex);
    static bool initialized = false;

    // 只在第一次调用时执行初始化操作。
    if (!initialized) {
        cout << "[kdvip] 初始化..." << endl;

        GetConnectOption((char*)"./maCliApiOpt.ini", &stConnectOption);
        memcpy(stConnectOption.szSvrAddress, mConfig.mBrokerAddr.c_str(), mConfig.mBrokerAddr.length());
        stConnectOption.nSvrPort = stoi(mConfig.mBrokerPort);
        memcpy(mEncryptKey, mConfig.mEncryptKey.c_str(), mConfig.mEncryptKey.length());
        memcpy(mChannel, mConfig.mChannel.c_str(), mConfig.mChannel.length());

        string msg = "[kdvip] 初始化成功。";
        kdvipDebug << msg;
        cout << msg << endl;
        initialized = true;
    }
    return true;
}

bool KdvipApiWrapper::isConnected() const
{
    return mConnected;
}

bool KdvipApiWrapper::connect()
{
    if(!resetConnection(hHandle)) {
        string msg = "[kdvip] 连接失败。";
        kdvipError << msg;
        cout << msg << endl;
        return false;
    }

    string msg = "[kdvip] 连接成功！";
    kdvipError << msg;
    cout << msg << endl;
    mConnected = true;
    return true;
}

void KdvipApiWrapper::sleepFor(int s)
{
#ifdef WIN32
    Sleep(s * 1000);
#else
    sleep(s);
#endif
}

void KdvipApiWrapper::disconnect()
{
    maCli_Close(hHandle);
    mConnected = false;
}

void KdvipApiWrapper::setConfig(const KdvipConfig &config)
{
    mConfig = config;
}

const KdvipConfig &KdvipApiWrapper::config() const
{
    return mConfig;
}

void KdvipApiWrapper::safeAssign(string &target, const char *source)
{
    if(!source){
        target.clear();
    }else{
        target.assign(source);
    }
}

/*!
 * 业务请求包内容中包括两部分，固定入参+业务参数；业务参数由具体业务功能确定；固定参数为系统约定每个业务功能模块必送，本函数用于初始化固定参数
 */
string KdvipApiWrapper::initPackHead(const string &func_code, const KdvipFixedInput& input)
{
    char szApiVer[25] = {0};
    char szMsgId[33] = {0};

    maCli_BeginWrite(hHandle);
    maCli_GetVersion(hHandle, szApiVer, sizeof(szApiVer));

    std::string time_stamp = KdvipApiWrapper::timeStamp();

    maCli_GetUuid(hHandle, szMsgId, sizeof(szMsgId));

    maCli_SetHdrValueC(hHandle, 'R',                                MACLI_HEAD_FID_MSG_TYPE);
    maCli_SetHdrValueC(hHandle, 'B',                                MACLI_HEAD_FID_PKT_TYPE);
    maCli_SetHdrValueC(hHandle, 'Q',                                MACLI_HEAD_FID_FUNC_TYPE);
    maCli_SetHdrValueS(hHandle, "01",                               MACLI_HEAD_FID_PKT_VER);
    maCli_SetHdrValueS(hHandle, func_code.c_str(),                  MACLI_HEAD_FID_FUNC_ID);
    maCli_SetHdrValueS(hHandle, szMsgId,                            MACLI_HEAD_FID_MSG_ID);
    maCli_SetHdrValueS(hHandle, time_stamp.c_str(),                 MACLI_HEAD_FID_TIMESTAMP);
    maCli_SetHdrValueS(hHandle, "12345678901234567890123456789012", MACLI_HEAD_FID_USER_SESSION);

    maCli_SetValueS(hHandle, input.OP_USER.c_str(), FIXCODE_OP_USER);
    maCli_SetValueS(hHandle, input.OP_ROLE.c_str(), FIXCODE_OP_ROLE);
    maCli_SetValueS(hHandle, input.OP_SITE.c_str(), FIXCODE_OP_SITE);
    maCli_SetValueS(hHandle, input.CHANNEL.c_str(), FIXCODE_CHANNEL);
    maCli_SetValueS(hHandle, input.SESSION.c_str(), FIXCODE_SESSION);
    maCli_SetValueS(hHandle, func_code.c_str(),     FIXCODE_FUNCTION);
    maCli_SetValueS(hHandle, time_stamp.c_str(),    FIXCODE_RUNTIME);
    maCli_SetValueS(hHandle, input.OP_ORG.c_str(),  FIXCODE_OP_ORG);

    return szMsgId;
}

string KdvipApiWrapper::timeStamp()
{
    char result[30] = {0};
    time_t timep;
    struct tm *p;
    time(&timep); // 获得time_t结构的时间，UTC时间
    p = localtime(&timep); // 转换为struct tm结构的当地时间
    sprintf(result, "%04d%02d%02d%02d%02d%02d%03d", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday, p->tm_hour, p->tm_min, p->tm_sec, 0);
    return result;
}

string KdvipApiWrapper::TO_AUTH_DATA(const char *password)
{
    char authdata[128] = {0};
    maCli_ComEncrypt(hHandle, authdata, sizeof(authdata), password, mConfig.mEncryptKey.c_str());
    return authdata;
}

/*!
 * \brief [10301105] 用户登录(API)
 */
Intf_RetType KdvipApiWrapper::kdvipClientLogin(const KdvipFixedInput& fixInput, const ClientLoginInput& input, std::list<ClientLoginOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10301105", fixInput);

    maCli_SetValueS(hHandle, input.ACCT_TYPE.c_str(),   FIXCODE_ACCT_TYPE);
    maCli_SetValueS(hHandle, input.ACCT_ID.c_str(),     FIXCODE_ACCT_ID);
    maCli_SetValueS(hHandle, input.USE_SCOPE.c_str(),   FIXCODE_USE_SCOPE);
    maCli_SetValueS(hHandle, input.ENCRYPT_KEY.c_str(), FIXCODE_ENCRYPT_KEY);
    maCli_SetValueS(hHandle, input.AUTH_TYPE.c_str(),   FIXCODE_AUTH_TYPE);
    maCli_SetValueS(hHandle, input.AUTH_DATA.c_str(),   FIXCODE_AUTH_DATA);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10301105");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            ClientLoginOutput item;
            reader.get(FIXCODE_CUST_CODE,       item.CUST_CODE);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_STKEX,           item.STKEX);
            reader.get(FIXCODE_STKBD,           item.STKBD);
            reader.get(FIXCODE_STK_TRDACCT,     item.STK_TRDACCT);
            reader.get(FIXCODE_TRDACCT_SN,      item.TRDACCT_SN);
            reader.get(FIXCODE_TRDACCT_EXID,    item.TRDACCT_EXID);
            reader.get(FIXCODE_TRDACCT_STATUS,  item.TRDACCT_STATUS);
            reader.get(FIXCODE_TREG_STATUS,     item.TREG_STATUS);
            reader.get(FIXCODE_BREG_STATUS,     item.BREG_STATUS);
            reader.get(FIXCODE_STKPBU,          item.STKPBU);
            reader.get(FIXCODE_ACCT_TYPE,       item.ACCT_TYPE);
            reader.get(FIXCODE_ACCT_ID,         item.ACCT_ID);
            reader.get(FIXCODE_TRDACCT_NAME,    item.TRDACCT_NAME);
            reader.get(FIXCODE_CHANNEL_ID,      item.CHANNEL_ID);
            reader.get(FIXCODE_SESSION_ID,      item.SESSION_ID);
            reader.get(FIXCODE_INT_ORG,         item.INT_ORG);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}
/*!
 * \brief [10302001] 买卖委托
 */
Intf_RetType KdvipApiWrapper::kdvipSecuEntrust(const KdvipFixedInput& fixInput, const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10302001", fixInput);

    maCli_SetValueS(hHandle, input.CUST_CODE.c_str(),   FIXCODE_CUST_CODE);
    maCli_SetValueS(hHandle, input.CUACCT_CODE.c_str(), FIXCODE_CUACCT_CODE);
    maCli_SetValueS(hHandle, input.STKBD.c_str(),       FIXCODE_STKBD);
    maCli_SetValueS(hHandle, input.STK_CODE.c_str(),    FIXCODE_STK_CODE);
    maCli_SetValueS(hHandle, input.ORDER_PRICE.c_str(), FIXCODE_ORDER_PRICE);
    maCli_SetValueS(hHandle, input.ORDER_QTY.c_str(),   FIXCODE_ORDER_QTY);
    maCli_SetValueS(hHandle, input.STK_BIZ.c_str(),     FIXCODE_STK_BIZ);
    maCli_SetValueS(hHandle, input.STK_BIZ_ACTION.c_str(), FIXCODE_STK_BIZ_ACTION);
    maCli_SetValueS(hHandle, input.STKPBU.c_str(),      FIXCODE_STKPBU);
    maCli_SetValueS(hHandle, input.ORDER_BSN.c_str(),   FIXCODE_ORDER_BSN);
    maCli_SetValueS(hHandle, input.ORDER_TEXT.c_str(),  FIXCODE_ORDER_TEXT);
    maCli_SetValueS(hHandle, input.CLIENT_INFO.c_str(), FIXCODE_CLIENT_INFO);
    maCli_SetValueS(hHandle, input.SECURITY_LEVEL.c_str(), FIXCODE_SECURITY_LEVEL);
    maCli_SetValueS(hHandle, input.SECURITY_INFO.c_str(), FIXCODE_SECURITY_INFO);
    maCli_SetValueS(hHandle, input.COMPONET_STK_CODE.c_str(), FIXCODE_COMPONET_STK_CODE);
    maCli_SetValueS(hHandle, input.COMPONET_STKBD.c_str(), FIXCODE_COMPONET_STKBD);
    maCli_SetValueS(hHandle, input.STKBD_LINK.c_str(),  FIXCODE_STKBD_LINK);
    maCli_SetValueS(hHandle, input.TRDACCT.c_str(),     FIXCODE_TRDACCT);
    maCli_SetValueS(hHandle, input.CUACCT_SN.c_str(),   FIXCODE_CUACCT_SN);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10302001");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            SecuEntrustOutput item;
            reader.get(FIXCODE_ORDER_BSN,       item.ORDER_BSN);
            reader.get(FIXCODE_ORDER_ID,        item.ORDER_ID);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_ORDER_PRICE,     item.ORDER_PRICE);
            reader.get(FIXCODE_ORDER_QTY,       item.ORDER_QTY);
            reader.get(FIXCODE_ORDER_AMT,       item.ORDER_AMT);
            reader.get(FIXCODE_ORDER_FRZ_AMT,   item.ORDER_FRZ_AMT);
            reader.get(FIXCODE_STKPBU,          item.STKPBU);
            reader.get(FIXCODE_STKBD,           item.STKBD);
            reader.get(FIXCODE_STK_CODE,        item.STK_CODE);
            reader.get(FIXCODE_STK_NAME,        item.STK_NAME);
            reader.get(FIXCODE_STK_BIZ,         item.STK_BIZ);
            reader.get(FIXCODE_STK_BIZ_ACTION,  item.STK_BIZ_ACTION);
            reader.get(FIXCODE_TRDACCT,         item.TRDACCT);
            reader.get(FIXCODE_CUACCT_SN,       item.CUACCT_SN);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}
/*!
 * \brief [10302004] 委托撤单
 */
Intf_RetType KdvipApiWrapper::kdvipSecuEntrustWithdraw(const KdvipFixedInput& fixInput, const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10302004", fixInput);

    maCli_SetValueS(hHandle, input.CUACCT_CODE.c_str(), FIXCODE_CUACCT_CODE);
    maCli_SetValueS(hHandle, input.STKBD.c_str(),       FIXCODE_STKBD);
    maCli_SetValueS(hHandle, input.ORDER_ID.c_str(),    FIXCODE_ORDER_ID);
    maCli_SetValueS(hHandle, input.ORDER_BSN.c_str(),   FIXCODE_ORDER_BSN);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10302004");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            SecuEntrustWithdrawOutput item;
            reader.get(FIXCODE_ORDER_BSN,       item.ORDER_BSN);
            reader.get(FIXCODE_ORDER_ID,        item.ORDER_ID);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_ORDER_PRICE,     item.ORDER_PRICE);
            reader.get(FIXCODE_ORDER_QTY,       item.ORDER_QTY);
            reader.get(FIXCODE_ORDER_AMT,       item.ORDER_AMT);
            reader.get(FIXCODE_ORDER_FRZ_AMT,   item.ORDER_FRZ_AMT);
            reader.get(FIXCODE_STKPBU,          item.STKPBU);
            reader.get(FIXCODE_STKBD,           item.STKBD);
            reader.get(FIXCODE_STK_CODE,        item.STK_CODE);
            reader.get(FIXCODE_STK_NAME,        item.STK_NAME);
            reader.get(FIXCODE_STK_BIZ,         item.STK_BIZ);
            reader.get(FIXCODE_STK_BIZ_ACTION,  item.STK_BIZ_ACTION);
            reader.get(FIXCODE_CANCEL_STATUS,   item.CANCEL_STATUS);
            reader.get(FIXCODE_TRDACCT,         item.TRDACCT);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}
/*!
 * \brief [10303003] 当日委托查询
 */
Intf_RetType KdvipApiWrapper::kdvipSecuEntrustQry(const KdvipFixedInput& fixInput, const SecuEntrustQryInput& input, std::list<SecuEntrustQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10303003", fixInput);

    maCli_SetValueS(hHandle, input.CUST_CODE.c_str(),   FIXCODE_CUST_CODE);
    maCli_SetValueS(hHandle, input.CUACCT_CODE.c_str(), FIXCODE_CUACCT_CODE);
    maCli_SetValueS(hHandle, input.STKBD.c_str(),       FIXCODE_STKBD);
    maCli_SetValueS(hHandle, input.STK_CODE.c_str(),    FIXCODE_STK_CODE);
    maCli_SetValueS(hHandle, input.ORDER_ID.c_str(),    FIXCODE_ORDER_ID);
    maCli_SetValueS(hHandle, input.ORDER_BSN.c_str(),   FIXCODE_ORDER_BSN);
    maCli_SetValueS(hHandle, input.TRDACCT.c_str(),     FIXCODE_TRDACCT);
    maCli_SetValueS(hHandle, input.QUERY_FLAG.c_str(),  FIXCODE_QUERY_FLAG);
    maCli_SetValueS(hHandle, input.QUERY_POS.c_str(),   FIXCODE_QUERY_POS);
    maCli_SetValueS(hHandle, input.QUERY_NUM.c_str(),   FIXCODE_QUERY_NUM);
    maCli_SetValueS(hHandle, input.CUACCT_SN.c_str(),   FIXCODE_CUACCT_SN);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10303003");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            SecuEntrustQryOutput item;
            reader.get(FIXCODE_QRY_POS,         item.QRY_POS);
            reader.get(FIXCODE_INT_ORG,         item.INT_ORG);
            reader.get(FIXCODE_TRD_DATE,        item.TRD_DATE);
            reader.get(FIXCODE_ORDER_DATE,      item.ORDER_DATE);
            reader.get(FIXCODE_ORDER_TIME,      item.ORDER_TIME);
            reader.get(FIXCODE_ORDER_ID,        item.ORDER_ID);
            reader.get(FIXCODE_ORDER_STATUS,    item.ORDER_STATUS);
            reader.get(FIXCODE_ORDER_VALID_FLAG, item.ORDER_VALID_FLAG);
            reader.get(FIXCODE_CUST_CODE,       item.CUST_CODE);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_STKBD,           item.STKBD);
            reader.get(FIXCODE_STKPBU,          item.STKPBU);
            reader.get(FIXCODE_STK_BIZ,         item.STK_BIZ);
            reader.get(FIXCODE_STK_BIZ_ACTION,  item.STK_BIZ_ACTION);
            reader.get(FIXCODE_STK_CODE,        item.STK_CODE);
            reader.get(FIXCODE_STK_NAME,        item.STK_NAME);
            reader.get(FIXCODE_CURRENCY,        item.CURRENCY);
            reader.get(FIXCODE_BOND_INT,        item.BOND_INT);
            reader.get(FIXCODE_ORDER_PRICE,     item.ORDER_PRICE);
            reader.get(FIXCODE_ORDER_QTY,       item.ORDER_QTY);
            reader.get(FIXCODE_ORDER_AMT,       item.ORDER_AMT);
            reader.get(FIXCODE_ORDER_FRZ_AMT,   item.ORDER_FRZ_AMT);
            reader.get(FIXCODE_ORDER_UFZ_AMT,   item.ORDER_UFZ_AMT);
            reader.get(FIXCODE_OFFER_QTY,       item.OFFER_QTY);
            reader.get(FIXCODE_OFFER_STIME,     item.OFFER_STIME);
            reader.get(FIXCODE_WITHDRAWN_QTY,   item.WITHDRAWN_QTY);
            reader.get(FIXCODE_MATCHED_QTY,     item.MATCHED_QTY);
            reader.get(FIXCODE_IS_WITHDRAW,     item.IS_WITHDRAW);
            reader.get(FIXCODE_IS_WITHDRAWN,    item.IS_WITHDRAWN);
            reader.get(FIXCODE_ORDER_BSN,       item.ORDER_BSN);
            reader.get(FIXCODE_MATCHED_AMT,     item.MATCHED_AMT);
            reader.get(FIXCODE_TRDACCT,         item.TRDACCT);
            reader.get(FIXCODE_CUACCT_SN,       item.CUACCT_SN);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}
/*!
 * \brief [10303004] 当日成交查询
 */
Intf_RetType KdvipApiWrapper::kdvipSecuRealDealQry(const KdvipFixedInput& fixInput, const SecuRealDealQryInput& input, std::list<SecuRealDealQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10303004", fixInput);

    maCli_SetValueS(hHandle, input.CUST_CODE.c_str(),   FIXCODE_CUST_CODE);
    maCli_SetValueS(hHandle, input.CUACCT_CODE.c_str(), FIXCODE_CUACCT_CODE);
    maCli_SetValueS(hHandle, input.STKBD.c_str(),       FIXCODE_STKBD);
    maCli_SetValueS(hHandle, input.STK_CODE.c_str(),    FIXCODE_STK_CODE);
    maCli_SetValueS(hHandle, input.ORDER_ID.c_str(),    FIXCODE_ORDER_ID);
    maCli_SetValueS(hHandle, input.ORDER_BSN.c_str(),   FIXCODE_ORDER_BSN);
    maCli_SetValueS(hHandle, input.TRDACCT.c_str(),     FIXCODE_TRDACCT);
    maCli_SetValueS(hHandle, input.QUERY_FLAG.c_str(),  FIXCODE_QUERY_FLAG);
    maCli_SetValueS(hHandle, input.QUERY_POS.c_str(),   FIXCODE_QUERY_POS);
    maCli_SetValueS(hHandle, input.QUERY_NUM.c_str(),   FIXCODE_QUERY_NUM);
    maCli_SetValueS(hHandle, input.CUACCT_SN.c_str(),   FIXCODE_CUACCT_SN);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10303004");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            SecuRealDealQryOutput item;
            reader.get(FIXCODE_QRY_POS,         item.QRY_POS);
            reader.get(FIXCODE_MATCHED_TIME,    item.MATCHED_TIME);
            reader.get(FIXCODE_ORDER_DATE,      item.ORDER_DATE);
            reader.get(FIXCODE_ORDER_SN,        item.ORDER_SN);
            reader.get(FIXCODE_ORDER_BSN,       item.ORDER_BSN);
            reader.get(FIXCODE_ORDER_ID,        item.ORDER_ID);
            reader.get(FIXCODE_INT_ORG,         item.INT_ORG);
            reader.get(FIXCODE_CUST_CODE,       item.CUST_CODE);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_STKBD,           item.STKBD);
            reader.get(FIXCODE_STKPBU,          item.STKPBU);
            reader.get(FIXCODE_STK_TRDACCT,     item.STK_TRDACCT);
            reader.get(FIXCODE_STK_BIZ,         item.STK_BIZ);
            reader.get(FIXCODE_STK_BIZ_ACTION,  item.STK_BIZ_ACTION);
            reader.get(FIXCODE_STK_CODE,        item.STK_CODE);
            reader.get(FIXCODE_STK_NAME,        item.STK_NAME);
            reader.get(FIXCODE_CURRENCY,        item.CURRENCY);
            reader.get(FIXCODE_BOND_INT,        item.BOND_INT);
            reader.get(FIXCODE_ORDER_PRICE,     item.ORDER_PRICE);
            reader.get(FIXCODE_ORDER_QTY,       item.ORDER_QTY);
            reader.get(FIXCODE_ORDER_AMT,       item.ORDER_AMT);
            reader.get(FIXCODE_ORDER_FRZ_AMT,   item.ORDER_FRZ_AMT);
            reader.get(FIXCODE_MATCHED_SN,      item.MATCHED_SN);
            reader.get(FIXCODE_MATCHED_PRICE,   item.MATCHED_PRICE);
            reader.get(FIXCODE_MATCHED_QTY,     item.MATCHED_QTY);
            reader.get(FIXCODE_MATCHED_AMT,     item.MATCHED_AMT);
            reader.get(FIXCODE_MATCHED_TYPE,    item.MATCHED_TYPE);
            reader.get(FIXCODE_CUACCT_SN,       item.CUACCT_SN);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}
/*!
 * \brief [10303001] 可用资金查询
 */
Intf_RetType KdvipApiWrapper::kdvipFundAssetQry(const KdvipFixedInput& fixInput, const FundAssetQryInput& input, std::list<FundAssetQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10303001", fixInput);

    maCli_SetValueS(hHandle, input.CUST_CODE.c_str(),   FIXCODE_CUST_CODE);
    maCli_SetValueS(hHandle, input.CUACCT_CODE.c_str(), FIXCODE_CUACCT_CODE);
    maCli_SetValueS(hHandle, input.CURRENCY.c_str(),    FIXCODE_CURRENCY);
    maCli_SetValueS(hHandle, input.VALUE_FLAG.c_str(),  FIXCODE_VALUE_FLAG);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10303001");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            FundAssetQryOutput item;
            reader.get(FIXCODE_CUST_CODE,       item.CUST_CODE);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_CURRENCY,        item.CURRENCY);
            reader.get(FIXCODE_INT_ORG,         item.INT_ORG);
            reader.get(FIXCODE_MARKET_VALUE,    item.MARKET_VALUE);
            reader.get(FIXCODE_FUND_VALUE,      item.FUND_VALUE);
            reader.get(FIXCODE_STK_VALUE,       item.STK_VALUE);
            reader.get(FIXCODE_FUND_LOAN,       item.FUND_LOAN);
            reader.get(FIXCODE_FUND_PREBLN,     item.FUND_PREBLN);
            reader.get(FIXCODE_FUND_BLN,        item.FUND_BLN);
            reader.get(FIXCODE_FUND_AVL,        item.FUND_AVL);
            reader.get(FIXCODE_FUND_FRZ,        item.FUND_FRZ);
            reader.get(FIXCODE_FUND_UFZ,        item.FUND_UFZ);
            reader.get(FIXCODE_FUND_TRD_FRZ,    item.FUND_TRD_FRZ);
            reader.get(FIXCODE_FUND_TRD_UFZ,    item.FUND_TRD_UFZ);
            reader.get(FIXCODE_FUND_TRD_OTD,    item.FUND_TRD_OTD);
            reader.get(FIXCODE_FUND_TRD_BLN,    item.FUND_TRD_BLN);
            reader.get(FIXCODE_FUND_STATUS,     item.FUND_STATUS);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}
/*!
 * \brief [10303002] 可用股份查询
 */
Intf_RetType KdvipApiWrapper::kdvipSecuUnitStkQry(const KdvipFixedInput& fixInput, const SecuUnitStkQryInput& input, std::list<SecuUnitStkQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kdvipLogger() << fixInput << input;

    int msgCode = 0;
    char szMsgText[256 + 1] = {0};
    char szMsgDebug[1024 + 1] = {0};
    char szErrorMsg[8] = {0};

    string msg_id = KdvipApiWrapper::initPackHead("10303002", fixInput);

    maCli_SetValueS(hHandle, input.CUST_CODE.c_str(),   FIXCODE_CUST_CODE);
    maCli_SetValueS(hHandle, input.CUACCT_CODE.c_str(), FIXCODE_CUACCT_CODE);
    maCli_SetValueS(hHandle, input.STKBD.c_str(),       FIXCODE_STKBD);
    maCli_SetValueS(hHandle, input.STK_CODE.c_str(),    FIXCODE_STK_CODE);
    maCli_SetValueS(hHandle, input.STKPBU.c_str(),      FIXCODE_STKPBU);
    maCli_SetValueS(hHandle, input.QUERY_FLAG.c_str(),  FIXCODE_QUERY_FLAG);
    maCli_SetValueS(hHandle, input.TRDACCT.c_str(),     FIXCODE_TRDACCT);
    maCli_SetValueS(hHandle, input.QUERY_POS.c_str(),   FIXCODE_QUERY_POS);
    maCli_SetValueS(hHandle, input.QUERY_NUM.c_str(),   FIXCODE_QUERY_NUM);

    maCli_EndWrite(hHandle);

    ST_MACLI_SYNCCALL callSettings = {0};
    strcpy(callSettings.szFuncId, "10303002");
    strcpy(callSettings.szMsgId,  msg_id.c_str());
    int result = maCli_SyncCall(hHandle, &callSettings);

    if (0 != result) {
        maCli_GetLastErrorMsg(hHandle, szErrorMsg, sizeof(szErrorMsg));
        StringHelper::string_format(errMsg, "[kdvip] maCli_SyncCall() returns %d: %s", result, szErrorMsg);
        kdvipError << errMsg;
        cout << errMsg << endl;
        return kIntfSendFail;
    }

    maCli_OpenTable(hHandle, 1);
    maCli_ReadRow(hHandle, 1);
    maCli_GetValueN(hHandle, &msgCode, FIXCODE_MSG_CODE);
    maCli_GetValueS(hHandle, szMsgText, sizeof(szMsgText), FIXCODE_MSG_TEXT);
    maCli_GetValueS(hHandle, szMsgDebug, sizeof(szMsgDebug), FIXCODE_MSG_DEBUG);

    if (msgCode == 0) {
        // process output
        if (maCli_OpenTable(hHandle, 2) != 0) {
            return kIntfError;
        }
        int rowCount = 0;
        maCli_GetRowCount(hHandle, &rowCount);
        KdvipReader reader(hHandle);
        for (int row = 0; row < rowCount; ++row) {
            reader.loadRow(row);
            SecuUnitStkQryOutput item;
            reader.get(FIXCODE_QRY_POS,         item.QRY_POS);
            reader.get(FIXCODE_INT_ORG,         item.INT_ORG);
            reader.get(FIXCODE_CUST_CODE,       item.CUST_CODE);
            reader.get(FIXCODE_CUACCT_CODE,     item.CUACCT_CODE);
            reader.get(FIXCODE_STKBD,           item.STKBD);
            reader.get(FIXCODE_STKPBU,          item.STKPBU);
            reader.get(FIXCODE_CURRENCY,        item.CURRENCY);
            reader.get(FIXCODE_STK_CODE,        item.STK_CODE);
            reader.get(FIXCODE_STK_NAME,        item.STK_NAME);
            reader.get(FIXCODE_STK_CLS,         item.STK_CLS);
            reader.get(FIXCODE_STK_PREBLN,      item.STK_PREBLN);
            reader.get(FIXCODE_STK_BLN,         item.STK_BLN);
            reader.get(FIXCODE_STK_AVL,         item.STK_AVL);
            reader.get(FIXCODE_STK_FRZ,         item.STK_FRZ);
            reader.get(FIXCODE_STK_UFZ,         item.STK_UFZ);
            reader.get(FIXCODE_STK_TRD_FRZ,     item.STK_TRD_FRZ);
            reader.get(FIXCODE_STK_TRD_UFZ,     item.STK_TRD_UFZ);
            reader.get(FIXCODE_STK_TRD_OTD,     item.STK_TRD_OTD);
            reader.get(FIXCODE_STK_BCOST,       item.STK_BCOST);
            reader.get(FIXCODE_STK_BCOST_RLT,   item.STK_BCOST_RLT);
            reader.get(FIXCODE_STK_PLAMT,       item.STK_PLAMT);
            reader.get(FIXCODE_STK_PLAMT_RLT,   item.STK_PLAMT_RLT);
            reader.get(FIXCODE_MKT_VAL,         item.MKT_VAL);
            reader.get(FIXCODE_COST_PRICE,      item.COST_PRICE);
            reader.get(FIXCODE_PRO_INCOME,      item.PRO_INCOME);
            reader.get(FIXCODE_STK_CAL_MKTVAL,  item.STK_CAL_MKTVAL);
            reader.get(FIXCODE_STK_QTY,         item.STK_QTY);
            reader.get(FIXCODE_CURRENT_PRICE,   item.CURRENT_PRICE);
            reader.get(FIXCODE_PROFIT_PRICE,    item.PROFIT_PRICE);
            reader.get(FIXCODE_STK_DIFF,        item.STK_DIFF);
            reader.get(FIXCODE_STK_TRD_UNFRZ,   item.STK_TRD_UNFRZ);
            reader.get(FIXCODE_TRDACCT,         item.TRDACCT);
            output.push_back(item);
            kdvipLogger() << item;
        }
        errMsg = "业务操作成功。";
    } else {
        errMsg = StringHelper::convertCodec(szMsgText);
        return kIntfWorkFail;
    }

    return kIntfSuccess;
}

bool KdvipApiWrapper::resetConnection(MACLIHANDLE& hHandle)
{
    lock_guard<mutex> initLock(mInitMutex);

    int result = 0;
    if ((result = maCli_Init(&hHandle)) != 0) {
        cout << "[kdvip] maCli_Init() failed, code = " << result << endl;
        return false;
    }

    unsigned int timeout = 30;
    if (maCli_SetOptions(hHandle, MACLI_OPTION_CONNECT_PARAM, &stConnectOption, sizeof(stConnectOption)) != 0) {
        cout << "[kdvip] failed to set connect option." << endl;
        return false;
    }
    if (maCli_SetOptions(hHandle, MACLI_OPTION_SYNCCALL_TIMEOUT, &timeout, sizeof(timeout)) != 0) {
        cout << "[kdvip] failed to set syncCall timeout option." << endl;
        return false;
    }
    if (maCli_SetOptions(hHandle, MACLI_OPTION_ASYNCALL_TIMEOUT, &timeout, sizeof(timeout)) != 0) {
        cout << "[kdvip] failed to set asyncCall timeout option." << endl;
        return false;
    }

    strcpy(stMacliUserInfo.szServerName, stConnectOption.szServerName);
    strcpy(stMacliUserInfo.szUserId,     "KMAP00");
    strcpy(stMacliUserInfo.szPassword,   "888888");
    strcpy(stMacliUserInfo.szAppId,      "KD_FORTUNE_2");

    result = maCli_Open(hHandle, &stMacliUserInfo);
    if (result != 0) {
        kdvipError << "[kdvip] connect error: maCli_Open() returns " << result;
    }
    mConnected = (result == 0);

    return result == 0;
}
