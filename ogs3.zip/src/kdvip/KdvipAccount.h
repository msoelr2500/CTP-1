/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIPACCOUNT_H
#define KDVIPACCOUNT_H

#include "../AccountManager.h"

class KdvipTradeAccount : public TradeAccount
{
public:
    std::string TRDACCT_STATUS;         //!< 账户状态(8933)
    std::string TREG_STATUS;            //!< 指定状态(8934)
    std::string BREG_STATUS;            //!< 回购状态(8935)
    std::string STKEX;                  //!< 交易市场(207)
    std::string STKBD;                  //!< 交易板块(625)
    std::string TRDACCT_SN;             //!< 账户序号(8928)
    std::string TRDACCT_EXID;           //!< 报盘账户(8929)
    std::string TRDACCT_NAME;           //!< 交易账户名称(8932)
    std::string STKPBU;                 //!< 交易单元(8843)
};

class KdvipFundAccount : public FundAccount<KdvipTradeAccount>
{
public:
};

struct KdvipClientData {
    std::string ACCT_TYPE;              //!< 账户类型(8987)
    std::string ACCT_ID;                //!< 账户标识(9081)
    std::string CHANNEL_ID;             //!< 通道号(9082)
    std::string SESSION_ID;             //!< 会话凭证(8814)
    std::string INT_ORG;                //!< 内部机构(8911)
};

class KdvipClient : public Client<KdvipFundAccount>
{
public:
    KdvipClientData mData;
};

class KdvipClientManager : public ClientManager<KdvipClient>
{
public:
    KdvipClientData clientData(const std::string client_id) {
        lock_data(this);
        int index = findClientById(client_id);
        if (index < 0) {
            return KdvipClientData();
        }
        return this->at(index).mData;
    }

    KdvipClientData clientDataByFundAccount(const std::string fund_account) {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0) {
            return KdvipClientData();
        }
        return this->at(index).mData;
    }

    KdvipTradeAccount tradeAccount(const std::string& fund_account, Exchange exchange)
    {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0 || !AccountHelper::isExchangeValid(exchange)) {
            return KdvipTradeAccount();
        }
        return this->at(index).at(this->at(index).indexOf(fund_account))[exchange];
    }

    std::string fundAccountByTradeAccount(const std::string& trade_account)
    {
        lock_data(this);
        int index = findClientByTradeAccount(trade_account);
        if (index > 0) {
            const KdvipClient& client = this->at(index);
            int fIndex = client.fundAccountIndexByTradeAccount(trade_account);
            if (fIndex > 0) {
                return client.at(fIndex).fund_account;
            }
        }
        return std::string();
    }
};

#endif // KDVIPACCOUNT_H
