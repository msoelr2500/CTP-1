/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipConverter.h"
#include <string.h>

using std::string;

using ogs::ogs_dict::ExecutionType;
using ogs::ogs_dict::OrderStatusType;
using qtp::MarketCode;
using ogs::ogs_dict::DirectiveType;

Exchange KdvipConverter::toExchange(std::string &STKEX, std::string &STKBD)
{
    if (STKBD == "00") {
        return Exchange::SZE;
    } else if (STKBD == "01") {
        return Exchange::SZ_B;
    } else if (STKBD == "02") {
        return Exchange::TZ_A;
    } else if (STKBD == "10") {
        return Exchange::SSE;
    } else if (STKBD == "11") {
        return Exchange::SH_B;
    } else {
        if (STKEX == "0") {
            return Exchange::SZE;
        } else if (STKEX == "1") {
            return Exchange::SSE;
        }
    }
    return Exchange::ExchangeCount;
}

std::string KdvipConverter::TO_ORDER_BSN(const char *sysOrderId) { return string(sysOrderId); }

std::string KdvipConverter::to_stock_account(KdvipFundAccount &account, qtp::MarketCode market)
{
    Exchange exchange = AccountHelper::toExchange(market);
    if (AccountHelper::isExchangeValid(exchange)) {
        return account[exchange].stock_account;
    }
    return string("");
}

std::string KdvipConverter::to_input_content(ogs::OGS_ACTYPE actype)
{
    return std::to_string(actype);
}

std::string KdvipConverter::to_exchange_type(qtp::MarketCode code)
{
    switch(code){
    case qtp::kMC_SSE: return string("1");
    case qtp::kMC_CFFE: return string("F4");
    case qtp::kMC_SZE: return string("2");
    case qtp::kMC_UNKNOW: dafault: return string();
    }
}

std::string KdvipConverter::to_stock_code(const std::string &code)
{
    if (code == "000000") {
        return string("");
    }
    return code;
}

std::string KdvipConverter::TO_STK_BIZ_ACTION(ogs::OGS_EXECUTION execution)
{
    switch (execution) {
    case ogs::ogs_dict::kExeLimit: return string("100");
    default: return string();
    }
}

std::string KdvipConverter::TO_STK_BIZ(ogs::OGS_DIRECTIVE type)
{
    switch (type) {
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtGuaranteeBuy:
        return string("100");
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtGuaranteeSell:
        return string("101");
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtMarketMarginSell:
        return string("151");
    case ogs::ogs_dict::kDtLoanBuy:
        return string("150");
    default: return string();
    }
}

ogs::OGS_DIRECTIVE KdvipConverter::FROM_STK_BIZ(std::string &STK_BIZ)
{
    if (STK_BIZ == "100") {
        return ogs::ogs_dict::kDtBuy;
    } else if (STK_BIZ == "101") {
        return ogs::ogs_dict::kDtSell;
    } else if (STK_BIZ == "151") {
        return ogs::ogs_dict::kDtMarginSell;
    } else if (STK_BIZ == "150") {
        return ogs::ogs_dict::kDtLoanBuy;
    }
    return ogs::OGS_DIRECTIVE(-1);
}

Exchange KdvipConverter::to_exchange_index(const std::string &market_no)
{
    if (market_no == "1") {
        return Exchange::SSE;
    } else if (market_no == "2") {
        return Exchange::SZE;
    } else if (market_no == "7") {
        return Exchange::CFFE;
    }
    return Exchange::ExchangeCount;
}

std::string KdvipConverter::TO_PRICE(uint32_t ogs_price)
{
    return std::to_string(ogs_price / 10000.0);
}

int KdvipConverter::FROM_PRICE(const std::string &price)
{
    return (int)(std::stod(price) * 10000);
}

ogs::OGS_VOLUME KdvipConverter::FROM_AMOUNT(const std::string &amount)
{
    return std::stoi(amount);
}

ogs::OGS_BALANCE KdvipConverter::FROM_BALANCE(const std::string &balance)
{
    return std::atof(balance.c_str()) * 10000;
}

void KdvipConverter::FROM_STRING_TO_CHAR_ARRAY(const std::string &STRING, char *CHAR_ARRAY)
{
    memcpy(CHAR_ARRAY, STRING.c_str(), STRING.size());
}

/*! maCliApi返回时间格式为："yyyy-MM-dd HH:mm:ss.z" */
uint32_t KdvipConverter::FROM_ORDER_TIME(const std::string &time)
{
    int hour = std::stoi(time.substr(12, 2));
    int minute = std::stoi(time.substr(15, 2));
    int second = std::stoi(time.substr(18, 2));

    return hour * 10000 + minute * 100 + second;
}

/*! maCliApi返回日期格式为："yyyyMMdd" */
uint32_t KdvipConverter::FROM_TRD_DATE(const std::string &date)
{
    int year = std::stoi(date.substr(0, 4));
    int month = std::stoi(date.substr(4, 2));
    int day = std::stoi(date.substr(6, 2));

    return year * 10000 + (month + 1) * 100 + day;
}

qtp::MarketCode KdvipConverter::FROM_STKEX(const std::string &exchange_type)
{
    if(exchange_type == "1"){
        return qtp::kMC_SSE;
    }else if(exchange_type == "F4"){
        return qtp::kMC_CFFE;
    }else if(exchange_type == "2"){
        return qtp::kMC_SZE;
    }else{
        return qtp::kMC_UNKNOW;
    }
}

ogs::ogs_dict::OrderStatusType KdvipConverter::FROM_ORDER_STATUS(const std::string &ORDER_STATUS)
{
    if(ORDER_STATUS == "0"){
        return ogs::ogs_dict::kOtNotReported;
    }else if(ORDER_STATUS == "1" ||
             ORDER_STATUS == "A"){
        return ogs::ogs_dict::kOtWaitReporting;
    }else if(ORDER_STATUS == "2"){
        return ogs::ogs_dict::kOtReported;
    }else if(ORDER_STATUS == "3"){
        return ogs::ogs_dict::kOtCanceling;
    }else if(ORDER_STATUS == "4"){
        return ogs::ogs_dict::kOtMatchedCanceling;
    }else if(ORDER_STATUS == "5"){
        return ogs::ogs_dict::kOtCanceling;
    }else if(ORDER_STATUS == "6"){
        return ogs::ogs_dict::kOtCanceled;
    }else if(ORDER_STATUS == "7"){
        return ogs::ogs_dict::kOtMatchedCanceled;
    }else if(ORDER_STATUS == "8"){
        return ogs::ogs_dict::kOtMatchedAll;
    }else if(ORDER_STATUS == "9"){
        return ogs::ogs_dict::kOtBad;
    }
    return ogs::ogs_dict::kOtNotApproved;
}

ogs::OGS_INNERCODE KdvipConverter::from_stock_code(const std::string &stock_code)
{
    return qtp::UniversalCode::SymbolToUC(stock_code);
}

void KdvipConverter::from_entrust_no(const std::string &entrust_no, char *sysOrderId)
{
    memcpy(sysOrderId, entrust_no.c_str(), entrust_no.size());
}

void KdvipConverter::from_deal_no(const std::string &deal_no, char *dealId)
{
    memcpy(dealId, deal_no.c_str(), deal_no.size());
}
