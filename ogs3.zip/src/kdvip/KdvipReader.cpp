/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipReader.h"
#include <cstring>

KdvipReader::KdvipReader(MACLIHANDLE handle, int size)
{
    mHandle = handle;
    mBufferSize = size;
    mBuffer = new char[mBufferSize];
}

KdvipReader::~KdvipReader()
{
    delete [] mBuffer;
}

void KdvipReader::get(const char *fix_value, std::string &target)
{
    memset(mBuffer, '\0', mBufferSize);
    maCli_GetValueS(mHandle, mBuffer, mBufferSize, fix_value);
    target.assign(mBuffer);
}

void KdvipReader::loadRow(int index)
{
    maCli_ReadRow(mHandle, index + 1);
}
