/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipGlobal.h"
#include "KdvipInterface.h"

namespace ogs {

#ifdef __cplusplus
extern "C"
{
#endif

    DEFINE_VERSION(kdvip)

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr) {
        if ((strcmp(brokerType.c_str(), "KDVIP") == 0) || (strcmp(brokerType.c_str(), "kdvip") == 0)) {
            inPtr = std::shared_ptr<Interface>(new KdvipInterface());
        }
    }

    int LoadLocalOption(void* src,size_t size){
        if(size!= sizeof(ogs::ReadConfig::localOption)){
            return -1;
        }
        memcpy(&ogs::ReadConfig::localOption,src,size);
        return 0;
    }

    void LogLibVersion()
    {
        LOG(info) << "KDVIP 接口库版本：" << GET_VERSION_STR(kdvip);
    }

#ifdef __cplusplus
}
#endif
}

