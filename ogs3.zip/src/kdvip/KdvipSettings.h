/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-06
/////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <kdvip/maCliApi.h>

#define MAX_FILE_SIZE 1024*16
#define LEFT_BRACE '['
#define RIGHT_BRACE ']'

static int newline(char c);
static int end_of_string(char c);
static int left_barce(char c);
static int isright_brace(char c);
static int parse_file(const char *section, const char *key, const char *buf, int *sec_s, int *sec_e, int *key_s, int *key_e, int *value_s, int *value_e);
static int load_ini_file(const char *file, char *buf, int *file_size);
int read_profile_string(const char *section, const char *key, char *value, int size, const char *default_value, const char *file);
int read_profile_int(const char *section, const char *key, int default_value, const char *file);
void GetConnectOption(char* pszFile, ST_MACLI_CONNECT_OPTION* pstConnectOption);
