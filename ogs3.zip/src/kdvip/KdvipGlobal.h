/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIP_GLOBAL_H
#define KDVIP_GLOBAL_H

#include <memory>
#include <string.h>
#include <qtp_version.h>
#include "../ReadConfig.h"
#include "../Interface.h"

namespace ogs {

#ifdef __cplusplus
    extern "C"
    {
#endif

    /*! \brief kdvip接口库版本声明。*/
    DECLARE_VERSION(kdvip, 0, 2, 0)

    /*!
     * \brief 构造本模块的接口。
     * \param brokerType [IN] 券商类型。
     * \param inPtr [OUT] 接口指针。
     */
    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr);

    /*!
     * \brief 从给定的数据块中初始化接口。
     * \param src 数据块。
     * \param size 数据块的大小。
     * \return 如果一切顺利，返回0；出现错误则返回-1。
     */
    int LoadLocalOption(void *src, size_t size);

    void LogLibVersion();

#ifdef __cplusplus
    }
#endif

}

#endif //KDVIP_GLOBAL_H
