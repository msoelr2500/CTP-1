/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-06
/////////////////////////////////////////////////////////////////////////////

#include "KdvipSettings.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>

static int newline(char c)
{
	return ('\n' == c || '\r' == c) ? 1 : 0;
}
static int end_of_string(char c)
{
	return '\0' == c ? 1 : 0;
}
static int left_barce(char c)
{
	return LEFT_BRACE == c ? 1 : 0;
}
static int isright_brace(char c)
{
	return RIGHT_BRACE == c ? 1 : 0;
}

static int parse_file(const char *section, const char *key, const char *buf, int *sec_s, int *sec_e, int *key_s, int *key_e, int *value_s, int *value_e)
{
	const char *p = buf;
	int i = 0;
	if (buf == NULL || section == NULL || key == NULL)
	{
		return -1;
	}

	*sec_e = *sec_s = *key_e = *key_s = *value_s = *value_e = -1;

	while (!end_of_string(p[i])) {
		//find the section
		if ((0 == i || newline(p[i - 1])) && left_barce(p[i]))
		{
			int section_start = i + 1;

			//find the ']'
			do {
				i++;
			} while (!isright_brace(p[i]) && !end_of_string(p[i]));

			if (0 == strncmp(p + section_start, section, i - section_start)) {
				int newline_start = 0;

				i++;

				//Skip over space char after ']'
				while (isspace(p[i])) {
					i++;
				}

				//find the section
				*sec_s = section_start;
				*sec_e = i;

				while (!(newline(p[i - 1]) && left_barce(p[i]))
					&& !end_of_string(p[i])) {
					int j = 0;
					//get a new line
					newline_start = i;

					while (!newline(p[i]) && !end_of_string(p[i])) {
						i++;
					}

					//now i  is equal to end of the line
					j = newline_start;

					if (';' != p[j]) //skip over comment
					{
						while (j < i && p[j] != '=') {
							j++;
							if ('=' == p[j]) {
								//	if(strncmp(key,p+newline_start,j-newline_start)==0)
									{
										int iLength = j - newline_start;
										if ((int)strlen(key) > iLength)
										{
											iLength = strlen(key);
										}
										if (strncmp(key, p + newline_start, iLength) == 0)
										{
											//find the key ok
											*key_s = newline_start;
											*key_e = j - 1;

											*value_s = j + 1;
											*value_e = i;

											return 1;
										}
									}
							}
						}
					}

					i++;
				}
			}
		}
		else
		{
			i++;
		}
	}
	return 0;
}


static int load_ini_file(const char *file, char *buf, int *file_size)
{
	FILE *in = NULL;
	int i = 0;
	*file_size = 0;
	if (file == NULL || buf == NULL)
	{
		return -1;
	}

	in = fopen(file, "r");
	if (NULL == in) {
		return 0;
	}

	buf[i] = fgetc(in);

	//load initialization file
	while (buf[i] != (char)EOF) {
		i++;
		//	assert( i < MAX_FILE_SIZE ); //file too big, you can redefine MAX_FILE_SIZE to fit the big file 
		if (i < MAX_FILE_SIZE)
		{
			buf[i] = fgetc(in);
		}
	}

	buf[i] = '\0';
	*file_size = i;

	fclose(in);
	return i;
}


/*! \fn read_profile_string( const char *section, const char *key,char *value,
int size, const char *default_value, const char *file)
* \brief read string in initialization file

* \param[in] 	section					name of the section containing the key name
* \param[in] 	key						name of the key pairs to value
* \param[in] 	value						size of result's buffer
* \param[in] 	size						path of the initialization file
* \param[in] 	default_value				default value of result
* \param[in] 	file						path of the initialization file
* \return 		return 1 : read success; \n 0 : read fail
*/
int read_profile_string(const char *section, const char *key, char *value, int size, const char *default_value, const char *file)
{
	char buf[MAX_FILE_SIZE] = { 0 };
	int file_size;
	int sec_s, sec_e, key_s, key_e, value_s, value_e;
	if (section == NULL || key == NULL || value == NULL || file == NULL)
	{
		return -1;
	}
	if (!load_ini_file(file, buf, &file_size))
	{
		if (default_value != NULL)
		{
			strncpy(value, default_value, size);
		}
		return 0;
	}

	if (!parse_file(section, key, buf, &sec_s, &sec_e, &key_s, &key_e, &value_s, &value_e))
	{
		if (default_value != NULL)
		{
			strncpy(value, default_value, size);
		}
		return 0; //not find the key
	}
	else
	{
		int cpcount = value_e - value_s;

		if (size - 1 < cpcount)
		{
			cpcount = size - 1;
		}

		memset(value, 0, size);
		memcpy(value, buf + value_s, cpcount);
		value[cpcount] = '\0';

		return 1;
	}
}

/*! \fn read_profile_int( const char *section, const char *key,int default_value,
const char *file)
* \brief read int value in initialization file

* \param[in] 	section					name of the section containing the key name
* \param[in] 	key						name of the key pairs to value
* \param[in] 	default_value				default value of result
* \param[in] 	file						path of the initialization file
* \return 		profile int value,if read fail, return default value
*/
int read_profile_int(const char *section, const char *key, int default_value, const char *file)
{
	char value[32] = { 0 };
	if (!read_profile_string(section, key, value, sizeof(value), NULL, file))
	{
		return default_value;
	}
	else
	{
		return atoi(value);
	}
}


void GetConnectOption(char* pszFile, ST_MACLI_CONNECT_OPTION* pstConnectOption)
{
	read_profile_string("maCliApi", "servername", pstConnectOption->szServerName, sizeof(pstConnectOption->szServerName), "server", pszFile);

	pstConnectOption->nCommType = read_profile_int("maCliApi", "commtype", COMM_TYPE_SOCKET, pszFile);
	pstConnectOption->nProtocal = read_profile_int("maCliApi", "protocal", 1, pszFile);
	read_profile_string("maCliApi", "serveraddr", pstConnectOption->szSvrAddress, sizeof(pstConnectOption->szSvrAddress), "127.0.0.1", pszFile);
	pstConnectOption->nSvrPort = read_profile_int("maCliApi", "serverport", 21000, pszFile);
	read_profile_string("maCliApi", "localaddr", pstConnectOption->szLocalAddress, sizeof(pstConnectOption->szLocalAddress), "127.0.0.1", pszFile);
	pstConnectOption->nLocalPort = read_profile_int("maCliApi", "localport", 32001, pszFile);
	pstConnectOption->nReqId = read_profile_int("maCliApi", "req_queue_id", 1001, pszFile);
	pstConnectOption->nAnsId = read_profile_int("maCliApi", "ans_queue_id", 1002, pszFile);
	read_profile_string("maCliApi", "req_queue_name", pstConnectOption->szReqName, sizeof(pstConnectOption->szReqName), "req_stds", pszFile);
	read_profile_string("maCliApi", "ans_queue_name", pstConnectOption->szAnsName, sizeof(pstConnectOption->szAnsName), "ans_stds", pszFile);
	read_profile_string("maCliApi", "sub_queue", pstConnectOption->szSubId, sizeof(pstConnectOption->szSubId), "req_pub", pszFile);
	read_profile_string("maCliApi", "termcode", pstConnectOption->szTermCode, sizeof(pstConnectOption->szTermCode), "1B3098F9", pszFile);
	read_profile_string("maCliApi", "req_queue_connstr", pstConnectOption->szReqConnstr, sizeof(pstConnectOption->szReqConnstr), "IPC/@@IP", pszFile);
	read_profile_string("maCliApi", "ans_queue_connstr", pstConnectOption->szAnsConnstr, sizeof(pstConnectOption->szAnsConnstr), "IPC/@@IP", pszFile);
	pstConnectOption->nReqMaxDepth = read_profile_int("maCliApi", "req_queue_max_depth", 1000, pszFile);
	pstConnectOption->nAnsMaxDepth = read_profile_int("maCliApi", "ans_queue_max_depth", 1000, pszFile);

	read_profile_string("maCliApi", "servername", pstConnectOption->szServerName, sizeof(pstConnectOption->szServerName), "server", pszFile);

	read_profile_string("maCliApi", "req_monitor_queue_name", pstConnectOption->szMonitorReqName, sizeof(pstConnectOption->szMonitorReqName), "sendmonitor", pszFile);
	read_profile_string("maCliApi", "ans_monitor_queue_name", pstConnectOption->szMonitorAnsName, sizeof(pstConnectOption->szMonitorAnsName), "recvmonitor", pszFile);
	read_profile_string("maCliApi", "req_monitor_queue", pstConnectOption->szMonitorReqConnstr, sizeof(pstConnectOption->szMonitorReqConnstr), "31003/PUB/EPGM/@@IP;239.192.1.1", pszFile);
	read_profile_string("maCliApi", "ans_monitor_queue", pstConnectOption->szMonitorAnsConnstr, sizeof(pstConnectOption->szMonitorAnsConnstr), "31002/SUB/EPGM/@@IP;239.192.1.1", pszFile);

	read_profile_string("maCliApi", "gtu_socket_pub", pstConnectOption->szSocketSubConnstr, sizeof(pstConnectOption->szSocketSubConnstr), "41002/CLIENT/TCP/10.10.10.1/8", pszFile);
}
