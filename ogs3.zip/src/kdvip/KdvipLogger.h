/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIPLOGGER_H
#define KDVIPLOGGER_H

#include "../OgsLogger.h"
#include "KdvipApiWrapper.h"
#include <iostream>

#define kdvipLogger ogsLogger
#define kdvipDebug ogsDebug
#define kdvipInfo ogsInfo
#define kdvipError ogsError

OgsLogger& operator << (OgsLogger& logger, const KdvipFixedInput& data);
OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data);
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FundAssetQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FundAssetQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data);

#endif // KDVIPLOGGER_H
