/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIPREADER_H
#define KDVIPREADER_H

#include <kdvip/maCliApi.h>
#include <string>

class KdvipReader
{
public:
    KdvipReader(MACLIHANDLE handle, int size = DEFAULT_FIELD_SIZE);
    virtual ~KdvipReader();

    void get(const char* fix_value, std::string& target);
    void loadRow(int index);

    //! 用于读取单条数据项的缓冲区的默认长度。
    static const int DEFAULT_FIELD_SIZE = 1024;

private:
    char* mBuffer;
    int mBufferSize;
    MACLIHANDLE mHandle;
};

#endif // KDVIPREADER_H
