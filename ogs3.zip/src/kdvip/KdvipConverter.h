/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIPCONVERTER_H
#define KDVIPCONVERTER_H

#include <string>
#include "../DataStruct.h"
#include "../ogs_dict.h"
#include "../universal_code.h"
#include "KdvipAccount.h"
#include <string.h>

class KdvipConverter
{
public:
    static std::string PCHAR_TO_STRING(const char* target) { return target; }
    #define TO_ACCT_ID PCHAR_TO_STRING     // acidcard
    #define TO_CUACCT_CODE PCHAR_TO_STRING // bacid
    #define TO_CUST_CODE PCHAR_TO_STRING   // acidcard

    static std::string STRING_TO_PCHAR(char* target, const std::string& source) { strcpy(target, source.c_str()); }
    #define FROM_CUST_CODE STRING_TO_PCHAR // to acidcard
    #define FROM_CUACCT_ID STRING_TO_PCHAR // to bacid;

    static Exchange toExchange(std::string& STKEX, std::string& STKBD);

    template<class T> static std::string TO_STRING(const T& t) { return std::to_string(t); }
    static std::string TO_ORDER_BSN(const char* sysOrderId);

    static std::string to_stock_account(KdvipFundAccount& account, qtp::MarketCode market);

    static std::string to_input_content(ogs::OGS_ACTYPE actype);

    static std::string to_exchange_type(qtp::MarketCode code);
    static std::string to_stock_code(const std::string& code);
    static std::string TO_STK_BIZ_ACTION(ogs::OGS_EXECUTION execution);

    static std::string TO_STK_BIZ(ogs::OGS_DIRECTIVE type);
    static ogs::OGS_DIRECTIVE FROM_STK_BIZ(std::string& STK_BIZ);

    static Exchange to_exchange_index(const std::string& market_no);

    static std::string TO_PRICE(uint32_t ogs_price);
    #define TO_ORDER_PRICE TO_PRICE
    #define TO_MATCHED_PRICE TO_PRICE
    #define TO_COST_PRICE TO_PRICE
    #define TO_CURRENT_PRICE TO_PRICE
    #define TO_PROFIT_PRICE TO_PRICE

    // 价格
    static int FROM_PRICE(const std::string& price);
    #define FROM_ORDER_PRICE FROM_PRICE
    #define FROM_MATCHED_PRICE FROM_PRICE
    #define FROM_COST_PRICE FROM_PRICE
    #define FROM_CURRENT_PRICE TO_PRICE
    #define FROM_PROFIT_PRICE TO_PRICE

    // 数量
    static ogs::OGS_VOLUME FROM_AMOUNT(const std::string& amount);
    #define FROM_ORDER_QTY FROM_AMOUNT
    #define FROM_OFFER_QTY FROM_AMOUNT
    #define FROM_WITHDRAWN_QTY FROM_AMOUNT
    #define FROM_MATCHED_QTY FROM_AMOUNT
    #define FROM_STK_QTY FROM_AMOUNT
    #define FROM_STK_BLN FROM_AMOUNT
    #define FROM_STK_AVL FROM_AMOUNT
    #define FROM_STK_FRZ FROM_AMOUNT
    #define FROM_STK_UFZ FROM_AMOUNT

    #define TO_AMOUNT TO_STRING
    #define TO_ORDER_QTY TO_AMOUNT
    #define TO_OFFER_QTY TO_AMOUNT
    #define TO_WITHDRAWN_QTY TO_AMOUNT
    #define TO_MATCHED_QTY TO_AMOUNT
    #define TO_STK_QTY TO_AMOUNT

    // 金额
    static ogs::OGS_BALANCE FROM_BALANCE(const std::string& balance);
    #define FROM_ORDER_AMT FROM_BALANCE
    #define FROM_ORDER_FRZ_AMT FROM_BALANCE
    #define FROM_ORDER_UFZ_AMT FROM_BALANCE
    #define FROM_MATCHED_AMT FROM_BALANCE
    #define FROM_STK_PLAMT FROM_BALANCE
    #define FROM_STK_PLAMT_RLT FROM_BALANCE
    #define FROM_ORDER_UFZ_AMT FROM_BALANCE
    #define FROM_FUND_AVL FROM_BALANCE
    #define FROM_FUND_BLN FROM_BALANCE
    #define FROM_FUND_FRZ FROM_BALANCE
    #define FROM_FUND_UFZ FROM_BALANCE

    static void FROM_STRING_TO_CHAR_ARRAY(const std::string& STRING, char *CHAR_ARRAY);
    #define FROM_ORDER_BSN FROM_STRING_TO_CHAR_ARRAY
    #define FROM_MATCHED_SN FROM_STRING_TO_CHAR_ARRAY

    // time
    static uint32_t FROM_ORDER_TIME(const std::string& time);

    // date
    static uint32_t FROM_TRD_DATE(const std::string& date);

    static qtp::MarketCode FROM_STKEX(const std::string& exchange_type);
    static ogs::ogs_dict::OrderStatusType FROM_ORDER_STATUS(const std::string& ORDER_STATUS);

    static ogs::OGS_INNERCODE from_stock_code(const std::string& stock_code);
    static void from_entrust_no(const std::string& entrust_no, char* sysOrderId);
    static void from_deal_no(const std::string& deal_no, char* dealId);
};

#endif // KDVIPCONVERTER_H
