/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#ifndef KDVIPAPIWRAPPER_H
#define KDVIPAPIWRAPPER_H

#define KDVIP_CONNECT_TIMEOUT_MS 1000

#include <kdvip/maCliApi.h>
#include <kdvip/maCliFix.h>
#include <string>
#include <list>
#include <mutex>
#include "../Interface.h" // for Intf_RetType
#include "KdvipDataStruct.h"
#include <unistd.h>

struct KdvipFixedInput
{
    std::string OP_USER;        //!< 操作用户代码
    std::string OP_ROLE = "1";  //!< 操作用户角色
    std::string OP_SITE;        //!< 操作站点
    std::string CHANNEL;        //!< 操作渠道
    std::string SESSION;        //!< 会话凭证
    std::string OP_ORG;         //!< 操作机构
};

struct KdvipConfig {
    std::string mSiteInfoFormat;    //!<
    std::string mBrokerAddr;        //!<
    std::string mBrokerPort;        //!<
    std::string mEncryptKey;        //!< 加密因子
    std::string mChannel;           //!< 操作渠道
    std::string mOpSite;            //!< 操作站点
    std::string mOpOrg;             //!< 被操作者的分支机构（营业部代码）
};

class KdvipApiWrapper
{
public:
    explicit KdvipApiWrapper();
    explicit KdvipApiWrapper(const KdvipConfig& config);
    virtual ~KdvipApiWrapper();

    ////////////////////////////////////////////////////////////////////////////
    /// 初始化，配置选项和网络连接
    ////////////////////////////////////////////////////////////////////////////

    bool connect();

    static void sleepFor(int s);

    /*! \brief 初始化或重初始化lpconfig，在主线程读完配置文件后执行一次，不能在其他线程使用 */
    bool initialize();

    bool isConnected() const;

    bool resetConnection(MACLIHANDLE& hHandle);

    void disconnect();
    void setConfig(const KdvipConfig& config);
    const KdvipConfig& config() const;

    static void safeAssign(std::string& target, const char* source);

    static std::string timeStamp();

    std::string TO_AUTH_DATA(const char *password);

    ///--------------------------------------------------------------------------------------------------------
    /// KDVIP API // 业务范围：实时交易
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType kdvipSecuEntrust(const KdvipFixedInput& fixInput, const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg);
    Intf_RetType kdvipSecuEntrustWithdraw(const KdvipFixedInput& fixInput, const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// KDVIP API // 业务范围：辅助功能
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType kdvipClientLogin(const KdvipFixedInput& fixInput, const ClientLoginInput& input, std::list<ClientLoginOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// KDVIP API // 业务范围：实时查询
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType kdvipSecuEntrustQry(const KdvipFixedInput& fixInput, const SecuEntrustQryInput& input, std::list<SecuEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType kdvipSecuRealDealQry(const KdvipFixedInput& fixInput, const SecuRealDealQryInput& input, std::list<SecuRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType kdvipFundAssetQry(const KdvipFixedInput& fixInput, const FundAssetQryInput& input, std::list<FundAssetQryOutput>& output, std::string& errMsg);
    Intf_RetType kdvipSecuUnitStkQry(const KdvipFixedInput& fixInput, const SecuUnitStkQryInput& input, std::list<SecuUnitStkQryOutput>& output, std::string& errMsg);

protected:
    std::string initPackHead(const std::string &func_code, const KdvipFixedInput& input);

private:
    bool mConnected = false;
    KdvipConfig mConfig;

    MACLIHANDLE hHandle = NULL;
    static ST_MACLI_CONNECT_OPTION stConnectOption;
    static ST_MACLI_USERINFO stMacliUserInfo;
    static char mEncryptKey[32];
    static char mChannel[12];

    static std::mutex mInitMutex;
};

#endif // KDVIPAPIWRAPPER_H
