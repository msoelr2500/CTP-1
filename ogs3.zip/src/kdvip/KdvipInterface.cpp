/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "KdvipInterface.h"

using std::string;
using std::vector;

namespace ogs {

KdvipInterface::KdvipInterface()
{
    LOG(info) << "创建了一个KDVIP接口对象";
}

KdvipInterface::~KdvipInterface()
{

}

bool KdvipInterface::getConnectStatus()
{
    return kdvipImpl.isConnected();
}

Intf_RetType KdvipInterface::initCommon()
{
    static int counter = 1;

    if(kdvipImpl.initialize()){
        LOG(info) << "[kdvip] 初始化[" << counter << "]:成功";
        counter++;
        return kIntfSuccess;
    }
    LOG(info) << "[kdvip] 初始化失败";
    return kIntfFail;
}

Intf_RetType KdvipInterface::initSubscribe()
{
    LOG(info) << "[kdvip] 初始化订阅功能";
    return kIntfFail;
}

Intf_RetType KdvipInterface::connectBroker()
{
    if(kdvipImpl.connect()){
        LOG(info) << "[kdvip] 已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType KdvipInterface::reConnectBroker()
{
    if(kdvipImpl.isConnected()){
        kdvipImpl.disconnect();
    }
    return connectBroker();
}

Intf_RetType KdvipInterface::heartBeatToBroker()
{
    LOG(info) << "[kdvip] heartBeatToBroker";
    return kdvipImpl.heartBeatToBroker();
}

void KdvipInterface::setCallBack(int (*fn)(QueryOrderAns))
{
    kdvipImpl.setCallBack(fn);
}

Intf_RetType KdvipInterface::ogsLogin(const LoginQry &in, std::list<LoginAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsLogin(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsSendOrder(const SendOrderQry &in, std::list<SendOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsSendOrder(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsCancelOrder(const CancelOrderQry &in, std::list<CancelOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsCancelOrder(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsQueryOrder(const QueryOrderQry &in, std::list<QueryOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsQueryOrder(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsQueryPosition(const QueryPositionQry &in, std::list<QueryPositionAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsQueryPosition(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsQueryBargain(const QueryBargainQry &in, std::list<QueryBargainAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsQueryBargain(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, std::list<QueryFundInfoAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsQueryFundInfo(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, std::list<PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsPaybackSecurity(in, out, errMsg, args);
}

Intf_RetType KdvipInterface::ogsPaybackFunds(const PaybackFundsQry &in, std::list<PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kdvipImpl.ogsPaybackFunds(in, out, errMsg, args);
}

}
