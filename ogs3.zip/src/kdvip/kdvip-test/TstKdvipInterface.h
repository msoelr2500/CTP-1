///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TSTKDVIPINTERFACE_H
#define TSTKDVIPINTERFACE_H

#include <gtest/gtest.h>
#include <memory>

class TstKdvipInterface : public testing::Test
{
public:
    TstKdvipInterface();
    virtual void SetUp() override;
    virtual void TearDown() override;
    virtual ~TstKdvipInterface();
};



#endif // TSTKDVIPINTERFACE_H
