///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TSTMACLIAPI_H
#define TSTMACLIAPI_H

#include <gtest/gtest.h>
#include <kdvip/maCliApi.h>
#include <kdvip/maCliFix.h>
#include "../KdvipApiWrapper.h"
#include "../KdvipDataStruct.h"

class TstMaCliApi : public testing::Test
{
public:
    TstMaCliApi();
    virtual void SetUp() override;
    virtual void TearDown() override;
    virtual ~TstMaCliApi();

    KdvipApiWrapper mConnection;
};

TEST_F(TstMaCliApi, TestInit)
{
    KdvipConfig config;
    config.mBrokerAddr = "10.7.86.4";
    config.mBrokerPort = "41000";
    config.mChannel    = "3";
    config.mEncryptKey = "12345";

    mConnection.setConfig(config);

    ASSERT_TRUE(mConnection.initialize());
}

TEST_F(TstMaCliApi, TestConnect)
{
    ASSERT_FALSE(mConnection.isConnected());
    ASSERT_TRUE(mConnection.connect());
    ASSERT_TRUE(mConnection.isConnected());
}

TEST_F(TstMaCliApi, TestLogin)
{
    ClientLoginInput input;
    input.ACCT_ID = "";
    input.ACCT_TYPE = "";
    input.AUTH_DATA = "";
    input.AUTH_TYPE = "";
    input.ENCRYPT_KEY = "";
    input.USE_SCOPE = "";

    std::list<ClientLoginOutput> output;
    std::string errMsg;

    Intf_RetType result = mConnection.kdvipClientLogin(input, output, errMsg);
    ASSERT_TRUE(result == kIntfSuccess);
}

#endif // TSTMACLIAPI_H
