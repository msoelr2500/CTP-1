﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-07-19
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "UfxImpl.h"
#include <qtp_log.h>
#include <iostream>
#include "../BufferHandle.h"
#include "../ReadConfig.h"
#include "../OgsApi.h"
#include "UfxConverter.h"
#include "UfxLogger.h"
#include <qtp_log.h>

using namespace std;
using namespace ogs;

UfxClientManager UfxImpl::mClients;

UfxImpl::UfxImpl()
{
    mConfig.mOperatorPasswd = ReadConfig::localOption.Reserve1;
    mConfig.mConfigureFilePath = ReadConfig::localOption.Reserve3;
    mConfig.mSiteInfoFormat = ReadConfig::localOption.SiteInfoFormat;
    mConnection.setConfig(mConfig);
}

UfxImpl::~UfxImpl() {}

bool UfxImpl::initialize()
{
    return mConnection.initialize();
}

bool UfxImpl::connect()
{
    return mConnection.connect();
}

void UfxImpl::disconnect()
{
    mConnection.disconnect();
}

Intf_RetType UfxImpl::heartBeatToBroker()
{
    return kIntfNotSupport;
}

void UfxImpl::setCallBack(int (*fn)(QueryOrderAns))
{
    func = fn;
}

Intf_RetType UfxImpl::clientLoginWithQry(const LoginQry &in, std::list<LoginAns> &out, string &errMsg, std::map<int, string> &args)
{
    out.clear();

    // 设置输入。
    ClientLoginInput loginInput;
    loginInput.op_branch_no    = ReadConfig::localOption.BranchNo;
    loginInput.op_entrust_way  = ReadConfig::localOption.EntrustMode;
    loginInput.op_station      = op_station(args);
    loginInput.branch_no       = ReadConfig::localOption.BranchNo;
    loginInput.input_content   = UfxConverter::to_input_content(in.actype);
    loginInput.account_content = UfxConverter::to_account_content(in.bacid);
    loginInput.content_type    = "0";
    loginInput.password        = UfxConverter::to_password(in.password);
    loginInput.password_type   = ReadConfig::localOption.PwdType;

    mClients.invalidateClientByFundAccount(loginInput.account_content);

    // 调用接口。
    list<ClientLoginOutput> loginOutput;
    Intf_RetType loginResult = mConnection.ufxClientLogin(loginInput, loginOutput, errMsg);
    if(kIntfSuccess != loginResult){
        return loginResult;
    }

    // 处理输出。
    for (ClientLoginOutput& item : loginOutput) {
        if (mClients.hasClients(item.client_id)) continue;

        UfxClient client;
        client.client_id            = item.client_id;
        client.mData.branch_no      = item.branch_no;
        client.mData.user_token     = item.user_token;
        client.mData.op_branch_no   = ReadConfig::localOption.BranchNo;
        client.mData.op_entrust_way = ReadConfig::localOption.EntrustMode;
        client.mData.password_type  = ReadConfig::localOption.PwdType;
        client.mData.op_station     = op_station(args);

        // 查询资金账号。
        QryFundAccountInput fundAccountQryInput;
        fundAccountQryInput.op_branch_no   = client.mData.op_branch_no;
        fundAccountQryInput.op_entrust_way = client.mData.op_entrust_way;
        fundAccountQryInput.op_station     = client.mData.op_station;
        fundAccountQryInput.branch_no      = client.mData.branch_no;
        fundAccountQryInput.client_id      = client.client_id;
        fundAccountQryInput.password.assign(in.password);
        fundAccountQryInput.password_type  = client.mData.password_type;
        fundAccountQryInput.user_token     = client.mData.user_token;

        // 调用接口。
        list<QryFundAccountOutput> fundAccountQryOutput;
        Intf_RetType fundAccountQryResult = mConnection.ufxQryFundAccount(fundAccountQryInput, fundAccountQryOutput, errMsg);
        if(kIntfSuccess != fundAccountQryResult){
            return fundAccountQryResult;
        }

        // 处理输出。
        for(const QryFundAccountOutput& item : fundAccountQryOutput){
            UfxFundAccount account;
            account.mData.asset_prop = item.asset_prop;
            account.mData.asset_type = item.asset_type;
            account.fund_account     = item.fund_account;
            account.mData.sysnode_id = item.sysnode_id;

            if (!client.hasFundAccount(item.fund_account)) {
                LoginAns ans = {0};
                UfxConverter::from_fund_account(ans.bacid, item.fund_account);
                out.push_back(ans);
            } else {
                continue;
            }

            // 分别获取每个资金账户名下的股东账户。
            QryClientStkAcctInput stkAcctQryInput;
            stkAcctQryInput.op_branch_no   = client.mData.op_branch_no;
            stkAcctQryInput.op_entrust_way = client.mData.op_entrust_way;
            stkAcctQryInput.op_station     = client.mData.op_station;
            stkAcctQryInput.branch_no      = client.mData.branch_no;
            stkAcctQryInput.client_id      = client.client_id;
            stkAcctQryInput.fund_account   = account.fund_account;
            stkAcctQryInput.password.assign(in.password);
            stkAcctQryInput.password_type  = client.mData.password_type;
            stkAcctQryInput.user_token     = client.mData.user_token;

            // 调用接口。
            list<QryClientStkAcctOutput> stkAcctQryOutput;
            Intf_RetType clientStkAcctQryResult = mConnection.ufxQryClientStkAcct(stkAcctQryInput, stkAcctQryOutput, errMsg);
            if(kIntfSuccess != clientStkAcctQryResult){
                return clientStkAcctQryResult;
            }

            // 处理输出。
            for(const QryClientStkAcctOutput& item : stkAcctQryOutput){
                Exchange exchange = UfxConverter::to_exchange_index(item.exchange_type);
                if (!AccountHelper::isExchangeValid(exchange)) {
                    ufxWarn << "查询股东账户时出现了不支持的exchange_type：" << item.exchange_type;
                    continue;
                }

                UfxTradeAccount& tradeAccount = account[exchange];
                tradeAccount.exchange_type = item.exchange_type;
                tradeAccount.seat_no       = item.seat_no;
                tradeAccount.stock_account = item.stock_account;
                tradeAccount.enabled       = true;
            }
            // 保存资金帐户记录。
            client.addNewFundAccount(account);
        }

        // 保存客户记录。
        mClients.addNewClient(client);
    }

    mClients.printAccounts();
    return kIntfSuccess;
}

Intf_RetType UfxImpl::clientLogin(const LoginQry &in, std::list<LoginAns> &out, string &errMsg, std::map<int, string> &args)
{
    out.clear();

    // 设置输入。
    ClientLoginInput loginInput;
    loginInput.op_branch_no    = ReadConfig::localOption.BranchNo;
    loginInput.op_entrust_way  = ReadConfig::localOption.EntrustMode;
    loginInput.op_station      = op_station(args);
    loginInput.branch_no       = ReadConfig::localOption.BranchNo;
    loginInput.input_content   = UfxConverter::to_input_content(in.actype);
    loginInput.account_content = UfxConverter::to_account_content(in.bacid);
    loginInput.content_type    = "0";
    loginInput.password        = UfxConverter::to_password(in.password);
    loginInput.password_type   = ReadConfig::localOption.PwdType;

    mClients.invalidateClientByFundAccount(loginInput.account_content);

    // 调用接口。
    list<ClientLoginOutput> loginOutput;
    Intf_RetType loginResult = mConnection.ufxClientLogin(loginInput, loginOutput, errMsg);
    if (kIntfSuccess != loginResult) {
        return loginResult;
    }

    map<string, UfxClient> clients;
    // 处理输出。
    for (ClientLoginOutput& item : loginOutput) {
        UfxClient& client = clients[item.client_id];
        client.client_id            = item.client_id;
        client.mData.branch_no      = item.branch_no;
        client.mData.user_token     = item.user_token;
        client.mData.op_branch_no   = ReadConfig::localOption.BranchNo;
        client.mData.op_entrust_way = ReadConfig::localOption.EntrustMode;
        client.mData.password_type  = ReadConfig::localOption.PwdType;
        client.mData.op_station     = op_station(args);

        // 查询资金账号。
        int fIndex = client.indexOf(item.fund_account);
        if (fIndex < 0) {
            UfxFundAccount fundAccount;
            fundAccount.fund_account = item.fund_account;
            fundAccount.mData.asset_prop = item.asset_prop;
            fundAccount.fund_account     = item.fund_account;
            fundAccount.mData.sysnode_id = item.sysnode_id;
            fIndex = client.addNewFundAccount(fundAccount);

            // 仅当出现了新的资金账号时才会加入新的LoginAns。
            ogs::LoginAns ans;
            UfxConverter::from_fund_account(ans.bacid, item.fund_account);
            out.push_back(ans);
        }

        UfxFundAccount& fundAccount = client[fIndex];

        Exchange exchange = UfxConverter::to_exchange_index(item.exchange_type);
        if (!AccountHelper::isExchangeValid(exchange)) {
            ufxWarn << "查询股东账户时出现了不支持的exchange_type：" << item.exchange_type;
            continue;
        } else {
            UfxTradeAccount& tradeAccount = fundAccount[exchange];
            tradeAccount.exchange_type = item.exchange_type;
            tradeAccount.stock_account = item.stock_account;
            tradeAccount.enabled       = true;
        }
    }

    mClients.printAccounts();
    return kIntfSuccess;
}

bool UfxImpl::isConnected() const
{
    return mConnection.isConnected();
}

Intf_RetType UfxImpl::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string> &args)
{
#if defined(BUILD_INTERFACE_PBOX)
    return clientLogin(in, out, errMsg, args);
#elif defined(BUILD_INTERFACE_UFX)
    return clientLoginWithQry(in, out, errMsg, args);
#endif
}

Intf_RetType UfxImpl::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    UfxClientData clientData = mClients.clientData(UfxConverter::to_client_id(in.acidcard));

    // 设置输入。
    SecuEntrustInput input;
    input.op_branch_no   = clientData.op_branch_no;
    input.op_entrust_way = clientData.op_entrust_way;
    input.op_station     = op_station(args);
    input.branch_no      = clientData.branch_no;
    input.client_id      = UfxConverter::to_client_id(in.acidcard);
    input.fund_account   = UfxConverter::to_fund_account(in.bacid);
    input.password       = UfxConverter::to_password(in.password);
    input.password_type  = clientData.password_type;
    input.user_token     = clientData.user_token;
    input.exchange_type  = UfxConverter::to_exchange_type(market);
    input.stock_account  = mClients.stockAccount(input.fund_account, market);
    input.stock_code     = code;
    input.entrust_amount = UfxConverter::to_entrust_amount(in.volume);
    input.entrust_price  = UfxConverter::to_entrust_price(in.price);
    input.entrust_bs     = UfxConverter::to_entrust_bs(in.directive);
    input.entrust_prop   = UfxConverter::to_entrust_prop(in.directive);
    // input.entrust_type   = UfxConverter::to_entrust_type(in.directive);
    // input.asset_prop     = UfxConverter::to_asset_prop(in.directive);
    // input.compact_id;

    // 调用接口。
    list<SecuEntrustOutput> output;
    Intf_RetType result = mConnection.ufxSecuEntrust(input, output, errMsg);
    if(kIntfSuccess != result){
        return kIntfFail;
    }

    // 处理输出。
    for(const SecuEntrustOutput& item : output){
        SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        UfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType UfxImpl::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    UfxClientData clientData = mClients.clientData(UfxConverter::to_client_id(in.acidcard));

    // 设置输入。
    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    SecuEntrustWithdrawInput input;
    list<SecuEntrustWithdrawOutput> output;
    input.op_branch_no   = clientData.op_branch_no;
    input.op_entrust_way = clientData.op_entrust_way;
    input.op_station     = op_station(args);;
    input.branch_no      = clientData.branch_no;
    input.client_id      = UfxConverter::to_client_id(in.acidcard);
    input.fund_account   = UfxConverter::to_fund_account(in.bacid);
    input.password       = UfxConverter::to_password(in.password);
    input.entrust_no     = UfxConverter::to_entrust_no(in.sysOrderId);
    input.user_token     = clientData.user_token;
    input.exchange_type  = UfxConverter::to_exchange_type(market);

    Intf_RetType result = mConnection.ufxSecuEntrustWithdraw(input, output, errMsg);
    if(kIntfSuccess != result){
        return kIntfFail;
    }

    // 处理输出。
    for(const SecuEntrustWithdrawOutput& item : output){
        CancelOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        UfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType UfxImpl::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    UfxClientData clientData = mClients.clientData(UfxConverter::to_client_id(in.acidcard));

    // 设置输入。
    SecuQryEntrustInput input;

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 初始化输入。
    input.op_branch_no      = clientData.op_branch_no;
    input.op_entrust_way    = clientData.op_entrust_way;
    input.op_station        = op_station(args);;
    input.branch_no         = clientData.branch_no;
    input.client_id         = UfxConverter::to_client_id(in.acidcard);
    input.fund_account      = UfxConverter::to_fund_account(in.bacid);
    input.password          = string(in.password);
    input.password_type     = clientData.password_type;
    input.user_token        = clientData.user_token;
    input.exchange_type     = UfxConverter::to_exchange_type(market);
    input.stock_account     = mClients.stockAccount(input.fund_account, market);
    input.stock_code        = UfxConverter::to_stock_code(code);
    input.sort_direction    = "0";
    input.action_in         = "0";
    input.locate_entrust_no = UfxConverter::to_entrust_no(in.sysOrderId);
    // input.asset_prop        = UfxConverter::to_asset_prop(in.actype);
    input.query_type        = "1"; // 不查委托类型为撤单的委托。

    // 调用接口。
    list<SecuQryEntrustOutput> output;
    Intf_RetType result = mConnection.ufxSecuQryEntrust(input, output, errMsg);
    if(kIntfSuccess != result)
        return kIntfFail;

    // 处理输出。
    for(const SecuQryEntrustOutput& item : output){
        QueryOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId    = in.custOrderId;
        UfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        ans.price          = UfxConverter::from_entrust_price(item.entrust_price);
        ans.volume         = UfxConverter::from_entrust_amount(item.entrust_amount);
        ans.orderStatus    = UfxConverter::from_entrust_status(item.entrust_status);
        ans.dealVolume     = UfxConverter::from_business_amount(item.business_amount);
        ans.dealBalance    = ans.volume * ans.price;
        ans.dealPrice      = UfxConverter::from_business_price(item.business_price);
        ans.innerCode      = qtp::UniversalCode::SymbolToUC(item.stock_code, market);
        ans.withdrawVolume = isOrderFinished(ans.orderStatus) ? (ans.volume - ans.dealVolume) : 0;
        ans.tradeDate      = UfxConverter::from_entrust_date(item.entrust_date);
        ans.orderTime      = UfxConverter::from_entrust_time(item.entrust_time);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType UfxImpl::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    UfxClientData clientData = mClients.clientData(UfxConverter::to_client_id(in.acidcard));

    // 设置输入。
    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

#if 0
    SecuQryPositionInput input;
#else
    SecuFastQryStockInput input;
#endif

    input.op_branch_no   = clientData.op_branch_no;
    input.op_entrust_way = clientData.op_entrust_way;
    input.op_station     = op_station(args);
    input.branch_no      = clientData.branch_no;
    input.client_id      = UfxConverter::to_client_id(in.acidcard);
    input.fund_account   = UfxConverter::to_fund_account(in.bacid);
    input.password       = UfxConverter::to_password(in.password);
    input.password_type  = clientData.password_type;
    input.user_token     = clientData.user_token;
    input.exchange_type  = UfxConverter::to_exchange_type(market);
    input.stock_account  = mClients.stockAccount(input.fund_account, market);
    input.stock_code     = UfxConverter::to_stock_code(code);

    // 调用接口。
#if 0
    list<SecuQryPositionOutput> output;
    Intf_RetType result = mConnection.ufxSecuQryPosition(input, output, errMsg);
#else
    list<SecuFastQryStockOutput> output;
    Intf_RetType result = mConnection.ufxSecuFastQryStock(input, output, errMsg);
#endif
    if(kIntfSuccess != result)
        return result;

    // 处理输出。
#if 0
    for(SecuQryPositionOutput& item : output){
#else
    for(SecuFastQryStockOutput& item : output){
#endif
        QueryPositionAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        UfxConverter::from_fund_account(ans.bacid, item.fund_account);
        ans.currentVolume = UfxConverter::from_current_amount(item.current_amount);
        ans.usableVolume  = UfxConverter::from_enable_amount(item.enable_amount);
        ans.innerCode     = UfxConverter::from_stock_code(item.stock_code);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType UfxImpl::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    UfxClientData clientData = mClients.clientData(UfxConverter::to_client_id(in.acidcard));

    // 设置输入。
    SecuQryRealtimeDealInput input;

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    input.op_branch_no   = clientData.op_branch_no;
    input.op_entrust_way = clientData.op_entrust_way;
    input.op_station     = op_station(args);;
    input.branch_no      = clientData.branch_no;
    input.client_id      = UfxConverter::to_client_id(in.acidcard);
    input.fund_account   = UfxConverter::to_fund_account(in.bacid);
    input.password       = UfxConverter::to_password(in.password);
    input.password_type  = clientData.password_type;
    input.user_token     = clientData.user_token;
    input.exchange_type  = UfxConverter::to_exchange_type(market);
    input.stock_account  = mClients.stockAccount(input.fund_account, market);
    input.stock_code     = UfxConverter::to_stock_code(code);
    // input.asset_prop     = UfxConverter::to_asset_prop(in.actype);
    input.query_type     = "1"; // 不查委托类型为撤单的委托。

    // 调用接口。
    list<SecuQryRealtimeDealOutput> output;
    Intf_RetType result = mConnection.ufxSecuQryRealtimeDeal(input, output, errMsg);
    if(kIntfSuccess != result){
        return kIntfFail;
    }

    // 处理输出。
    for(const SecuQryRealtimeDealOutput& item : output){
        QueryBargainAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        UfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        ans.innerCode = UfxConverter::from_stock_code(item.stock_code);
        UfxConverter::from_business_no(item.business_no, ans.dealId);
        ans.dealVolume  = UfxConverter::from_business_price(item.business_amount);
        ans.dealBalance = UfxConverter::from_business_balance(item.business_balance);
        ans.dealPrice   = UfxConverter::from_business_price(item.business_price);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType UfxImpl::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    UfxClientData clientData = mClients.clientData(UfxConverter::to_client_id(in.acidcard));

    // 设置输入。
#if 0
    ClientFundAllQryExInput input;
    input.asset_prop     = UfxConverter::to_asset_prop(in.actype);
#else
    SecuFastQryFundInput input;
#endif
    input.op_branch_no   = clientData.op_branch_no;
    input.op_entrust_way = clientData.op_entrust_way;
    input.op_station     = op_station(args);;
    input.branch_no      = clientData.branch_no;
    input.client_id      = UfxConverter::to_client_id(in.acidcard);
    input.fund_account   = UfxConverter::to_fund_account(in.bacid);
    input.password       = UfxConverter::to_password(in.password);
    input.password_type  = clientData.password_type;
    input.user_token     = clientData.user_token;
    input.money_type     = ReadConfig::localOption.Currency;

    // 调用接口。
#if 0
    list<ClientFundAllQryExOutput> output;
    Intf_RetType result = mConnection.ufxClientFundAllQryEx(input, output, errMsg);
#else
    list<SecuFastQryFundOutput> output;
    Intf_RetType result = mConnection.ufxSecuFastQryFund(input, output, errMsg);
#endif
    if(kIntfSuccess != result) { return kIntfFail; }

    // 处理输出。
#if 0
    for(const ClientFundAllQryExOutput& item : output){
#else
    for(const SecuFastQryFundOutput& item : output){
#endif
        QueryFundInfoAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        strcpy(ans.bacid, in.bacid);
        ans.balance        = UfxConverter::from_current_balance(item.current_balance);
        ans.frozenBalance  = UfxConverter::from_frozen_balance(item.frozen_balance);
        ans.useableBalance = UfxConverter::from_enable_balance(item.enable_balance);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType UfxImpl::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

Intf_RetType UfxImpl::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

string UfxImpl::op_station(map<int, string> &args)
{
    // 默认使用配置文件中的站点信息格式。
    if (!mConfig.mSiteInfoFormat.empty()) {
        return ogs::SiteInfo(mConfig.mSiteInfoFormat, args);
    }

    // 配置文件中未制定站点信息格式，则使用默认格式。
    string client_ip = args[1];
    string mac       = args[2];
    string disksn    = args[3];
    string cpuid     = args[4];
    string wip       = args[5];

    return UfxConverter::op_station(wip, client_ip, mac, disksn, cpuid);
}
