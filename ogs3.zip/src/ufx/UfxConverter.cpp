///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "UfxConverter.h"
#include <string.h>

using std::string;

using ogs::ogs_dict::ExecutionType;
using ogs::ogs_dict::OrderStatusType;
using qtp::MarketCode;
using ogs::ogs_dict::DirectiveType;

string UfxConverter::op_station(const string &wip, const std::string& clientIp, const string &mac, const string &disksn, const string &cpuid)
{
    string result;
    StringHelper::string_format(result, "TYJR-LHHJ- IIP.%s LIP.%s MAC.%s HD.%s CPU.%s",
                                         wip.c_str(), clientIp.c_str(), mac.c_str(), disksn.c_str(), cpuid.c_str());
    return result;
}

std::string UfxConverter::to_input_content(ogs::OGS_ACTYPE actype)
{
    return std::to_string(actype);
}

std::string UfxConverter::to_password(const char *password)
{
    return string(password);
}

std::string UfxConverter::to_entrust_no(const char *sysOrderId)
{
    return string(sysOrderId);
}

std::string UfxConverter::to_amount(ogs::OGS_VOLUME volume)
{
    return std::to_string(volume);
}

std::string UfxConverter::to_entrust_type(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
        return string("0");
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
        return string("7");
    case ogs::ogs_dict::kDtLoanBuy:
        return string("6");
    default: return string();
    }
}

std::string UfxConverter::to_exchange_type(qtp::MarketCode code)
{
    switch(code){
    case qtp::kMC_SSE: return string("1");
    case qtp::kMC_CFFE: return string("F4");
    case qtp::kMC_SZE: return string("2");
    case qtp::kMC_UNKNOW: dafault: return string();
    }
}

std::string UfxConverter::to_stock_code(const std::string &code)
{
    if (code == "000000") {
        return string("");
    }
    return code;
}

std::string UfxConverter::to_entrust_bs(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtLoanBuy:
    case ogs::ogs_dict::kDtGuaranteeBuy:
    case ogs::ogs_dict::kDtBuy:
        return string("1");
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtGuaranteeSell:
        return string("2");
    default: return string();
    }
}

std::string UfxConverter::to_entrust_prop(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtLoanBuy:
        return string("0");
    case ogs::ogs_dict::kDtGuaranteeBuy:
    case ogs::ogs_dict::kDtGuaranteeSell:
    case ogs::ogs_dict::kDtMarketSecPayback:
    case ogs::ogs_dict::kDtSecPayback:
    case ogs::ogs_dict::kDtBuyPayback:
    /*! \todo ogs_dict出现了字段变动。
    case ogs::ogs_dict::kDtApplyParch:
        return string("3");
    case ogs::ogs_dict::kDTRedemption:
        return string("4");
    *********************************/
    default: return string();
    }
}

std::string UfxConverter::to_asset_prop(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
        return string("0");
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtLoanBuy:
        return string("7");
    case ogs::ogs_dict::kDtGuaranteeBuy:
    case ogs::ogs_dict::kDtGuaranteeSell:
    case ogs::ogs_dict::kDtMarketSecPayback:
    case ogs::ogs_dict::kDtSecPayback:
    case ogs::ogs_dict::kDtBuyPayback:
    /*! \todo ogs_dict出现了字段变动。
    case ogs::ogs_dict::kDtApplyParch:
        return string("3");
    case ogs::ogs_dict::kDTRedemption:
        return string("4");
    *********************************/
    default: return string();
    }
}

std::string UfxConverter::to_asset_prop(ogs::OGS_ACTYPE type)
{
    switch(type){
    case ogs::ogs_dict::kStockNoraml:
        return string("0");
    case ogs::ogs_dict::kStockCredit:
        return string("7");
    default: return string();
    }
}

Exchange UfxConverter::to_exchange_index(const std::string &exchange_type)
{
    if (exchange_type == "1") {
        return Exchange::SSE;
    } else if (exchange_type == "F4") {
        return Exchange::CFFE;
    } else if (exchange_type == "2") {
        return Exchange::SZE;
    } else if (exchange_type == "D") {
        return Exchange::SH_B;
    } else if (exchange_type == "G") {
        return Exchange::SH_HK;
    } else if (exchange_type == "H") {
        return Exchange::SZ_B;
    } else if (exchange_type == "9") {
        return Exchange::TZ_A;
    } else if (exchange_type == "A") {
        return Exchange::TZ_B;
    }
    return Exchange::ExchangeCount;
}

std::string UfxConverter::to_price(uint32_t ogs_price)
{
    string result;
    StringHelper::string_format(result, "%.3f", ogs_price / 10000.0);
    return result;
}

int UfxConverter::from_price(const std::string &price)
{
    return (int)(std::stod(price) * 10000);
}

ogs::OGS_VOLUME UfxConverter::from_amount(const std::string &amount)
{
    return std::stoll(amount);
}

/*! ufx返回时间格式为："HHmmss" */
uint32_t UfxConverter::from_time(const std::string &time)
{
    int hour = std::stoi(time.substr(0, 2));
    int minute = std::stoi(time.substr(2, 2));
    int second = std::stoi(time.substr(4, 2));

    return hour * 10000 + minute * 100 + second;
}

/*! ufx返回日期格式为："yyyyMMdd" */
uint32_t UfxConverter::from_date(const std::string &date)
{
    int year = std::stoi(date.substr(0, 4));
    int month = std::stoi(date.substr(4, 2));
    int day = std::stoi(date.substr(6, 2));

    return year * 10000 + (month + 1) * 100 + day;
}

ogs::OGS_BALANCE UfxConverter::from_balance(const std::string &balance)
{
    return std::atof(balance.c_str()) * 10000;
}

qtp::MarketCode UfxConverter::from_exchange_type(const std::string &exchange_type)
{
    if(exchange_type == "1"){
        return qtp::kMC_SSE;
    }else if(exchange_type == "F4"){
        return qtp::kMC_CFFE;
    }else if(exchange_type == "2"){
        return qtp::kMC_SZE;
    }else{
        return qtp::kMC_UNKNOW;
    }
}

ogs::ogs_dict::OrderStatusType UfxConverter::from_entrust_status(const std::string &entrust_status)
{
    if(entrust_status == "0"){
        return ogs::ogs_dict::kOtNotReported;
    }else if(entrust_status == "1"){
        return ogs::ogs_dict::kOtWaitReporting;
    }else if(entrust_status == "2"){
        return ogs::ogs_dict::kOtReported;
    }else if(entrust_status == "3"){
        return ogs::ogs_dict::kOtCanceling;
    }else if(entrust_status == "4"){
        return ogs::ogs_dict::kOtMatchedCanceling;
    }else if(entrust_status == "5"){
        return ogs::ogs_dict::kOtMatchedCanceled;
    }else if(entrust_status == "6"){
        return ogs::ogs_dict::kOtCanceled;
    }else if(entrust_status == "7"){
        return ogs::ogs_dict::kOtPartMatched;
    }else if(entrust_status == "8"){
        return ogs::ogs_dict::kOtMatchedAll;
    }else if(entrust_status == "9"){
        return ogs::ogs_dict::kOtBad;
    }else{
        return ogs::ogs_dict::kOtNotApproved;
    }
}

ogs::OGS_INNERCODE UfxConverter::from_stock_code(const std::string &stock_code)
{
    return qtp::UniversalCode::SymbolToUC(stock_code);
}

void UfxConverter::from_entrust_no(const std::string &entrust_no, char *sysOrderId)
{
    memcpy(sysOrderId, entrust_no.c_str(), entrust_no.size());
}

void UfxConverter::from_business_no(const std::string &business_no, char *dealId)
{
    memcpy(dealId, business_no.c_str(), business_no.size());
}
