///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "UfxLogger.h"

OgsLogger& operator << (OgsLogger& logger, const QryCityCodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[QryCityCodeInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|city_no                      |" << data.city_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryCityCodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryCityCodeOutput]=====================";
    ogsDebug << "|city_no                      |" << data.city_no;
    ogsDebug << "|city_name                    |" << data.city_name;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryBranchInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "======================[QryBranchInput]======================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryBranchOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[QryBranchOutput]======================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|branch_name                  |" << data.branch_name;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryNextTradeDateInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryNextTradeDateInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|finance_type                 |" << data.finance_type;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stage_num                    |" << data.stage_num;
    ogsDebug << "|init_date                    |" << data.init_date;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryNextTradeDateOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryNextTradeDateOutput]==================";
    ogsDebug << "|next_trade_date              |" << data.next_trade_date;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryUfxAccessStationInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryUfxAccessStationInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryUfxAccessStationOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryUfxAccessStationOutput]=================";
    ogsDebug << "|target_ar                    |" << data.target_ar;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|port_id                      |" << data.port_id;
    ogsDebug << "|protocol_type                |" << data.protocol_type;
    ogsDebug << "|encode_way                   |" << data.encode_way;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[ClientLoginInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|input_content                |" << data.input_content;
    ogsDebug << "|account_content              |" << data.account_content;
    ogsDebug << "|content_type                 |" << data.content_type;
    ogsDebug << "|auth_product_type            |" << data.auth_product_type;
    ogsDebug << "|auth_key                     |" << data.auth_key;
    ogsDebug << "|auth_bind_station            |" << data.auth_bind_station;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[ClientLoginOutput]=====================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|sys_status                   |" << data.sys_status;
    ogsDebug << "|company_name                 |" << data.company_name;
    ogsDebug << "|content_type                 |" << data.content_type;
    ogsDebug << "|account_content              |" << data.account_content;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|client_name                  |" << data.client_name;
    ogsDebug << "|corp_client_group            |" << data.corp_client_group;
    ogsDebug << "|corp_risk_level              |" << data.corp_risk_level;
    ogsDebug << "|corp_begin_date              |" << data.corp_begin_date;
    ogsDebug << "|corp_end_date                |" << data.corp_end_date;
    ogsDebug << "|valid_flag                   |" << data.valid_flag;
    ogsDebug << "|fundaccount_count            |" << data.fundaccount_count;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_rights                |" << data.client_rights;
    ogsDebug << "|last_login_date              |" << data.last_login_date;
    ogsDebug << "|last_login_time              |" << data.last_login_time;
    ogsDebug << "|last_op_entrust_way          |" << data.last_op_entrust_way;
    ogsDebug << "|last_op_station              |" << data.last_op_station;
    ogsDebug << "|money_count                  |" << data.money_count;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|square_flag                  |" << data.square_flag;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|sysnode_id                   |" << data.sysnode_id;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    ogsDebug << "|prestore_info                |" << data.prestore_info;
    ogsDebug << "|login_times                  |" << data.login_times;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|product_flag                 |" << data.product_flag;
    ogsDebug << "|message_flag                 |" << data.message_flag;
    ogsDebug << "|tabconfirm_flag              |" << data.tabconfirm_flag;
    ogsDebug << "|last_date                    |" << data.last_date;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddClientRightInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AddClientRightInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_rights                |" << data.client_rights;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddClientRightOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AddClientRightOutput]===================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelClientRightInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[DelClientRightInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_rights                |" << data.client_rights;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelClientRightOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[DelClientRightOutput]===================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddClientEntrustWayInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[AddClientEntrustWayInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|en_entrust_way               |" << data.en_entrust_way;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddClientEntrustWayOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[AddClientEntrustWayOutput]=================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelClientEntrustWayInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[DelClientEntrustWayInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|en_entrust_way               |" << data.en_entrust_way;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelClientEntrustWayOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[DelClientEntrustWayOutput]=================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddClientRestrictionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[AddClientRestrictionInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|restriction                  |" << data.restriction;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddClientRestrictionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[AddClientRestrictionOutput]================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelClientRestrictionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[DelClientRestrictionInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|restriction                  |" << data.restriction;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelClientRestrictionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[DelClientRestrictionOutput]================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryAcctSysNodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryAcctSysNodeInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|input_content                |" << data.input_content;
    ogsDebug << "|account_content              |" << data.account_content;
    ogsDebug << "|content_type                 |" << data.content_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryAcctSysNodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryAcctSysNodeOutput]===================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|sysnode_id                   |" << data.sysnode_id;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientBulletinInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientBulletinInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientBulletinOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientBulletinOutput]==================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|valid_date                   |" << data.valid_date;
    ogsDebug << "|message_notes                |" << data.message_notes;
    ogsDebug << "|send_times                   |" << data.send_times;
    ogsDebug << "|criterion_prop               |" << data.criterion_prop;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SetProfitFlagInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SetProfitFlagInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|profit_flag                  |" << data.profit_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SetProfitFlagOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SetProfitFlagOutput]====================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddAccountDataInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AddAccountDataInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_data_char            |" << data.account_data_char;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddAccountDataOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AddAccountDataOutput]===================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelAccountDataInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[DelAccountDataInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_data_char            |" << data.account_data_char;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelAccountDataOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[DelAccountDataOutput]===================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryClientInfoInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|query_mode                   |" << data.query_mode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientInfoOutput]====================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_name                  |" << data.client_name;
    ogsDebug << "|client_status                |" << data.client_status;
    ogsDebug << "|fund_card                    |" << data.fund_card;
    ogsDebug << "|id_kind                      |" << data.id_kind;
    ogsDebug << "|id_no                        |" << data.id_no;
    ogsDebug << "|id_address                   |" << data.id_address;
    ogsDebug << "|mobiletelephone              |" << data.mobiletelephone;
    ogsDebug << "|fax                          |" << data.fax;
    ogsDebug << "|zipcode                      |" << data.zipcode;
    ogsDebug << "|e_mail                       |" << data.e_mail;
    ogsDebug << "|open_date                    |" << data.open_date;
    ogsDebug << "|nationality                  |" << data.nationality;
    ogsDebug << "|address                      |" << data.address;
    ogsDebug << "|mail_name                    |" << data.mail_name;
    ogsDebug << "|risk_info                    |" << data.risk_info;
    ogsDebug << "|account_data                 |" << data.account_data;
    ogsDebug << "|organ_prop                   |" << data.organ_prop;
    ogsDebug << "|organ_name                   |" << data.organ_name;
    ogsDebug << "|client_group                 |" << data.client_group;
    ogsDebug << "|group_name                   |" << data.group_name;
    ogsDebug << "|full_name                    |" << data.full_name;
    ogsDebug << "|risk_name                    |" << data.risk_name;
    ogsDebug << "|account_data_name            |" << data.account_data_name;
    ogsDebug << "|phonecode                    |" << data.phonecode;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_rights                |" << data.client_rights;
    ogsDebug << "|corp_client_group            |" << data.corp_client_group;
    ogsDebug << "|corp_risk_level              |" << data.corp_risk_level;
    ogsDebug << "|corp_begin_date              |" << data.corp_begin_date;
    ogsDebug << "|corp_end_date                |" << data.corp_end_date;
    ogsDebug << "|aml_risk_level               |" << data.aml_risk_level;
    ogsDebug << "|paper_score                  |" << data.paper_score;
    ogsDebug << "|client_gender                |" << data.client_gender;
    ogsDebug << "|en_entrust_way               |" << data.en_entrust_way;
    ogsDebug << "|invest_advice                |" << data.invest_advice;
    ogsDebug << "|id_begindate                 |" << data.id_begindate;
    ogsDebug << "|id_enddate                   |" << data.id_enddate;
    ogsDebug << "|profit_flag                  |" << data.profit_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRightInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientRightInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRightOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientRightOutput]===================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_rights                |" << data.client_rights;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRestrictionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientRestrictionInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientRestrictionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientRestrictionOutput]================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|restriction                  |" << data.restriction;
    ogsDebug << "|restriction_name             |" << data.restriction_name;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundAccountInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryFundAccountInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundAccountOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryFundAccountOutput]===================";
    ogsDebug << "|client_branch_no             |" << data.client_branch_no;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|asset_type                   |" << data.asset_type;
    ogsDebug << "|main_flag                    |" << data.main_flag;
    ogsDebug << "|product_flag                 |" << data.product_flag;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|sysnode_id                   |" << data.sysnode_id;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientTransAmtLmtInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientTransAmtLmtInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientTransAmtLmtOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientTransAmtLmtOutput]================";
    ogsDebug << "|lower_limit_out              |" << data.lower_limit_out;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryBankTransferInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryBankTransferInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|query_type                   |" << data.query_type;
    ogsDebug << "|action_in                    |" << data.action_in;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryBankTransferOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryBankTransferOutput]===================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_name                    |" << data.bank_name;
    ogsDebug << "|trans_name                   |" << data.trans_name;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|business_type                |" << data.business_type;
    ogsDebug << "|source_flag                  |" << data.source_flag;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|clear_balance                |" << data.clear_balance;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|cancel_info                  |" << data.cancel_info;
    ogsDebug << "|bank_error_info              |" << data.bank_error_info;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankPreDrawJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QrySvrBankPreDrawJourInput]================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|treat_status                 |" << data.treat_status;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankPreDrawJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QrySvrBankPreDrawJourOutput]================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|draw_type                    |" << data.draw_type;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|precont_date                 |" << data.precont_date;
    ogsDebug << "|execute_date                 |" << data.execute_date;
    ogsDebug << "|valid_date                   |" << data.valid_date;
    ogsDebug << "|operator_code                |" << data.operator_code;
    ogsDebug << "|max_balance                  |" << data.max_balance;
    ogsDebug << "|treat_status                 |" << data.treat_status;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[QryFundJourInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|query_direction              |" << data.query_direction;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryFundJourOutput]=====================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|business_name                |" << data.business_name;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|post_balance                 |" << data.post_balance;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FastQryClientFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[FastQryClientFundInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|money_type                   |" << data.money_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FastQryClientFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[FastQryClientFundOutput]==================";
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    ogsDebug << "|fetch_balance                |" << data.fetch_balance;
    ogsDebug << "|frozen_balance               |" << data.frozen_balance;
    ogsDebug << "|unfrozen_balance             |" << data.unfrozen_balance;
    ogsDebug << "|fund_balance                 |" << data.fund_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFundInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientFundInfoInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|money_type                   |" << data.money_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientFundInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientFundInfoOutput]==================";
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|begin_balance                |" << data.begin_balance;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    ogsDebug << "|foregift_balance             |" << data.foregift_balance;
    ogsDebug << "|mortgage_balance             |" << data.mortgage_balance;
    ogsDebug << "|frozen_balance               |" << data.frozen_balance;
    ogsDebug << "|unfrozen_balance             |" << data.unfrozen_balance;
    ogsDebug << "|fetch_balance                |" << data.fetch_balance;
    ogsDebug << "|fetch_balance_old            |" << data.fetch_balance_old;
    ogsDebug << "|fetch_cash                   |" << data.fetch_cash;
    ogsDebug << "|entrust_buy_balance          |" << data.entrust_buy_balance;
    ogsDebug << "|market_value                 |" << data.market_value;
    ogsDebug << "|asset_balance                |" << data.asset_balance;
    ogsDebug << "|interest                     |" << data.interest;
    ogsDebug << "|integral_balance             |" << data.integral_balance;
    ogsDebug << "|fine_integral                |" << data.fine_integral;
    ogsDebug << "|pre_interest                 |" << data.pre_interest;
    ogsDebug << "|pre_fine                     |" << data.pre_fine;
    ogsDebug << "|pre_interest_tax             |" << data.pre_interest_tax;
    ogsDebug << "|correct_balance              |" << data.correct_balance;
    ogsDebug << "|fund_balance                 |" << data.fund_balance;
    ogsDebug << "|opfund_market_value          |" << data.opfund_market_value;
    ogsDebug << "|rate_kind                    |" << data.rate_kind;
    ogsDebug << "|real_buy_balance             |" << data.real_buy_balance;
    ogsDebug << "|real_sell_balance            |" << data.real_sell_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StockBankTransactionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StockBankTransactionInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|transfer_direction           |" << data.transfer_direction;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|fund_password                |" << data.fund_password;
    ogsDebug << "|bank_password                |" << data.bank_password;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StockBankTransactionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StockBankTransactionOutput]================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|bktrans_status               |" << data.bktrans_status;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QrySvrBankBkFundInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QrySvrBankBkFundOutput]==================";
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|main_flag                    |" << data.main_flag;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_name                    |" << data.bank_name;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|fetch_balance                |" << data.fetch_balance;
    ogsDebug << "|fund_balance                 |" << data.fund_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkExchAccountInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QrySvrBankBkExchAccountInput]===============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkExchAccountOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[QrySvrBankBkExchAccountOutput]===============";
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|bkaccount_status             |" << data.bkaccount_status;
    ogsDebug << "|square_flag                  |" << data.square_flag;
    ogsDebug << "|main_flag                    |" << data.main_flag;
    ogsDebug << "|holder_name                  |" << data.holder_name;
    ogsDebug << "|foreign_flag                 |" << data.foreign_flag;
    ogsDebug << "|id_kind                      |" << data.id_kind;
    ogsDebug << "|id_no                        |" << data.id_no;
    ogsDebug << "|authorize_code               |" << data.authorize_code;
    ogsDebug << "|upper_limit_out              |" << data.upper_limit_out;
    ogsDebug << "|lower_limit_out              |" << data.lower_limit_out;
    ogsDebug << "|upper_limit_in               |" << data.upper_limit_in;
    ogsDebug << "|lower_limit_in               |" << data.lower_limit_in;
    ogsDebug << "|control_model_no             |" << data.control_model_no;
    ogsDebug << "|bank_operator                |" << data.bank_operator;
    ogsDebug << "|open_date                    |" << data.open_date;
    ogsDebug << "|bkaccount_regflag            |" << data.bkaccount_regflag;
    ogsDebug << "|en_entrust_way               |" << data.en_entrust_way;
    ogsDebug << "|bkaccount_rights             |" << data.bkaccount_rights;
    ogsDebug << "|bkaccount_restrict           |" << data.bkaccount_restrict;
    ogsDebug << "|book_account                 |" << data.book_account;
    ogsDebug << "|province_branch              |" << data.province_branch;
    ogsDebug << "|city_branch                  |" << data.city_branch;
    ogsDebug << "|county_branch                |" << data.county_branch;
    ogsDebug << "|sub_branch                   |" << data.sub_branch;
    ogsDebug << "|client_group                 |" << data.client_group;
    ogsDebug << "|room_code                    |" << data.room_code;
    ogsDebug << "|remark                       |" << data.remark;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QrySvrBankBkFundJourInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QrySvrBankBkFundJourOutput]================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|aasexch_type                 |" << data.aasexch_type;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|join_date                    |" << data.join_date;
    ogsDebug << "|join_serial_no               |" << data.join_serial_no;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|ent_init_date                |" << data.ent_init_date;
    ogsDebug << "|ent_serial_no                |" << data.ent_serial_no;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkBalanceInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QrySvrBankBkBalanceInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|fund_password                |" << data.fund_password;
    ogsDebug << "|bank_password                |" << data.bank_password;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkBalanceOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QrySvrBankBkBalanceOutput]=================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|bktrans_status               |" << data.bktrans_status;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrBankBkExchAccountTransferInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[SvrBankBkExchAccountTransferInput]=============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_account_src           |" << data.client_account_src;
    ogsDebug << "|bank_no_src                  |" << data.bank_no_src;
    ogsDebug << "|client_account_dest          |" << data.client_account_dest;
    ogsDebug << "|bank_no_dest                 |" << data.bank_no_dest;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrBankBkExchAccountTransferOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[SvrBankBkExchAccountTransferOutput]============";
    ogsDebug << "|serial_no_src                |" << data.serial_no_src;
    ogsDebug << "|serial_no_dest               |" << data.serial_no_dest;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasClientInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SvrAasQryAasClientInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasClientOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SvrAasQryAasClientOutput]=================";
    ogsDebug << "|client_name                  |" << data.client_name;
    ogsDebug << "|nationality                  |" << data.nationality;
    ogsDebug << "|organ_flag                   |" << data.organ_flag;
    ogsDebug << "|cust_property                |" << data.cust_property;
    ogsDebug << "|norm_flag                    |" << data.norm_flag;
    ogsDebug << "|id_kind                      |" << data.id_kind;
    ogsDebug << "|id_no                        |" << data.id_no;
    ogsDebug << "|id_begindate                 |" << data.id_begindate;
    ogsDebug << "|id_enddate                   |" << data.id_enddate;
    ogsDebug << "|original_organ               |" << data.original_organ;
    ogsDebug << "|original_branch              |" << data.original_branch;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|first_open_date              |" << data.first_open_date;
    ogsDebug << "|open_date                    |" << data.open_date;
    ogsDebug << "|cancel_date                  |" << data.cancel_date;
    ogsDebug << "|client_status                |" << data.client_status;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundAcctInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SvrAasQryAasFundAcctInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|main_fund_account            |" << data.main_fund_account;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|fund_trustee_prop            |" << data.fund_trustee_prop;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundAcctOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SvrAasQryAasFundAcctOutput]================";
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|main_fund_account            |" << data.main_fund_account;
    ogsDebug << "|main_flag                    |" << data.main_flag;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|fund_trustee_prop            |" << data.fund_trustee_prop;
    ogsDebug << "|fundacct_status              |" << data.fundacct_status;
    ogsDebug << "|open_date                    |" << data.open_date;
    ogsDebug << "|cancel_date                  |" << data.cancel_date;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasTrustAcctInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SvrAasQryAasTrustAcctInput]================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|sdc_account                  |" << data.sdc_account;
    ogsDebug << "|busin_account                |" << data.busin_account;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|agency_no                    |" << data.agency_no;
    ogsDebug << "|share_trustee_prop           |" << data.share_trustee_prop;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasTrustAcctOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SvrAasQryAasTrustAcctOutput]================";
    ogsDebug << "|seat_no                      |" << data.seat_no;
    ogsDebug << "|aasexch_type                 |" << data.aasexch_type;
    ogsDebug << "|sdc_account                  |" << data.sdc_account;
    ogsDebug << "|busin_account                |" << data.busin_account;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|share_trustee_prop           |" << data.share_trustee_prop;
    ogsDebug << "|agency_no                    |" << data.agency_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasAdjustAasFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SvrAasAdjustAasFundInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|fund_account_src             |" << data.fund_account_src;
    ogsDebug << "|fund_account_dest            |" << data.fund_account_dest;
    ogsDebug << "|adjust_balance               |" << data.adjust_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasAdjustAasFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SvrAasAdjustAasFundOutput]=================";
    ogsDebug << "|serial_no1                   |" << data.serial_no1;
    ogsDebug << "|serial_no2                   |" << data.serial_no2;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SvrAasQryAasFundInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SvrAasQryAasFundOutput]==================";
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|asset_prop                   |" << data.asset_prop;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|frozen_balance               |" << data.frozen_balance;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    ogsDebug << "|fetch_balance                |" << data.fetch_balance;
    ogsDebug << "|uncome_balance               |" << data.uncome_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasEnableFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SvrAasQryAasEnableFundInput]================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|usable_date                  |" << data.usable_date;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|aasexch_type                 |" << data.aasexch_type;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|prod_code                    |" << data.prod_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasEnableFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SvrAasQryAasEnableFundOutput]===============";
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundRequestInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SvrAasQryAasFundRequestInput]===============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|en_business_flag             |" << data.en_business_flag;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|en_money_type                |" << data.en_money_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundRequestOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrAasQryAasFundRequestOutput]===============";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SvrAasQryAasFundJourInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|en_aas_change_type           |" << data.en_aas_change_type;
    ogsDebug << "|en_business_flag             |" << data.en_business_flag;
    ogsDebug << "|en_money_type                |" << data.en_money_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SvrAasQryAasFundJourOutput]================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|aas_change_type              |" << data.aas_change_type;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkTransferInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrBankQryHistBkTransferInput]===============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|action_in                    |" << data.action_in;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    ogsDebug << "|query_type                   |" << data.query_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkTransferOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrBankQryHistBkTransferOutput]==============";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|trans_name                   |" << data.trans_name;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_name                    |" << data.bank_name;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|business_type                |" << data.business_type;
    ogsDebug << "|trans_type                   |" << data.trans_type;
    ogsDebug << "|source_flag                  |" << data.source_flag;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|cancel_info                  |" << data.cancel_info;
    ogsDebug << "|bank_error_info              |" << data.bank_error_info;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|remark                       |" << data.remark;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AasExtQryAasFundRequestInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[AasExtQryAasFundRequestInput]===============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|en_business_flag             |" << data.en_business_flag;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|en_money_type                |" << data.en_money_type;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AasExtQryAasFundRequestOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[AasExtQryAasFundRequestOutput]===============";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryHistAasFundJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrAasQryHistAasFundJourInput]===============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|en_aas_change_type           |" << data.en_aas_change_type;
    ogsDebug << "|en_business_flag             |" << data.en_business_flag;
    ogsDebug << "|en_money_type                |" << data.en_money_type;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryHistAasFundJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrAasQryHistAasFundJourOutput]==============";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|businsys_id                  |" << data.businsys_id;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|aas_change_type              |" << data.aas_change_type;
    ogsDebug << "|surplus_days                 |" << data.surplus_days;
    ogsDebug << "|settle_time                  |" << data.settle_time;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkFundJourInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrBankQryHistBkFundJourInput]===============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkFundJourOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SvrBankQryHistBkFundJourOutput]==============";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|curr_date                    |" << data.curr_date;
    ogsDebug << "|curr_time                    |" << data.curr_time;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|client_account               |" << data.client_account;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_account                 |" << data.bank_account;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|join_date                    |" << data.join_date;
    ogsDebug << "|join_serial_no               |" << data.join_serial_no;
    ogsDebug << "|deal_flag                    |" << data.deal_flag;
    ogsDebug << "|ent_init_date                |" << data.ent_init_date;
    ogsDebug << "|ent_serial_no                |" << data.ent_serial_no;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryPriceInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuQryPriceInput]=====================";
    ogsDebug << "|version                      |" << data.version;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryPriceOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuQryPriceOutput]====================";
    ogsDebug << "|exchange_index               |" << data.exchange_index;
    ogsDebug << "|last_price                   |" << data.last_price;
    ogsDebug << "|open_price                   |" << data.open_price;
    ogsDebug << "|close_price                  |" << data.close_price;
    ogsDebug << "|high_price                   |" << data.high_price;
    ogsDebug << "|low_price                    |" << data.low_price;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|buy_price1                   |" << data.buy_price1;
    ogsDebug << "|buy_price2                   |" << data.buy_price2;
    ogsDebug << "|buy_price3                   |" << data.buy_price3;
    ogsDebug << "|buy_price4                   |" << data.buy_price4;
    ogsDebug << "|buy_price5                   |" << data.buy_price5;
    ogsDebug << "|sale_price1                  |" << data.sale_price1;
    ogsDebug << "|sale_price2                  |" << data.sale_price2;
    ogsDebug << "|sale_price3                  |" << data.sale_price3;
    ogsDebug << "|sale_price4                  |" << data.sale_price4;
    ogsDebug << "|sale_price5                  |" << data.sale_price5;
    ogsDebug << "|buy_amount1                  |" << data.buy_amount1;
    ogsDebug << "|buy_amount2                  |" << data.buy_amount2;
    ogsDebug << "|buy_amount3                  |" << data.buy_amount3;
    ogsDebug << "|buy_amount4                  |" << data.buy_amount4;
    ogsDebug << "|buy_amount5                  |" << data.buy_amount5;
    ogsDebug << "|sale_amount1                 |" << data.sale_amount1;
    ogsDebug << "|sale_amount2                 |" << data.sale_amount2;
    ogsDebug << "|sale_amount3                 |" << data.sale_amount3;
    ogsDebug << "|sale_amount4                 |" << data.sale_amount4;
    ogsDebug << "|sale_amount5                 |" << data.sale_amount5;
    ogsDebug << "|stock_interest               |" << data.stock_interest;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQrySzClosingPriceInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuQrySzClosingPriceInput]================";
    ogsDebug << "|version                      |" << data.version;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQrySzClosingPriceOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SecuQrySzClosingPriceOutput]================";
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|closing_price                |" << data.closing_price;
    ogsDebug << "|weightave_price              |" << data.weightave_price;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkCodeQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[StkCodeQryInput]======================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|query_type                   |" << data.query_type;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkCodeQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[StkCodeQryOutput]=====================";
    ogsDebug << "|internal_code                |" << data.internal_code;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|buy_unit                     |" << data.buy_unit;
    ogsDebug << "|price_step                   |" << data.price_step;
    ogsDebug << "|store_unit                   |" << data.store_unit;
    ogsDebug << "|up_price                     |" << data.up_price;
    ogsDebug << "|down_price                   |" << data.down_price;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|high_amount                  |" << data.high_amount;
    ogsDebug << "|low_amount                   |" << data.low_amount;
    ogsDebug << "|stock_real_back              |" << data.stock_real_back;
    ogsDebug << "|fund_real_back               |" << data.fund_real_back;
    ogsDebug << "|delist_flag                  |" << data.delist_flag;
    ogsDebug << "|delist_date                  |" << data.delist_date;
    ogsDebug << "|trade_plat                   |" << data.trade_plat;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|par_value                    |" << data.par_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const NewQryStkCodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[NewQryStkCodeInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const NewQryStkCodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[NewQryStkCodeOutput]====================";
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|buy_unit                     |" << data.buy_unit;
    ogsDebug << "|price_step                   |" << data.price_step;
    ogsDebug << "|store_unit                   |" << data.store_unit;
    ogsDebug << "|par_value                    |" << data.par_value;
    ogsDebug << "|stkcode_status               |" << data.stkcode_status;
    ogsDebug << "|up_price                     |" << data.up_price;
    ogsDebug << "|down_price                   |" << data.down_price;
    ogsDebug << "|high_amount                  |" << data.high_amount;
    ogsDebug << "|low_amount                   |" << data.low_amount;
    ogsDebug << "|collect_date                 |" << data.collect_date;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const WarrantQryCodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[WarrantQryCodeInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|warrant_code                 |" << data.warrant_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const WarrantQryCodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[WarrantQryCodeOutput]===================";
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|warrant_code                 |" << data.warrant_code;
    ogsDebug << "|apply_code                   |" << data.apply_code;
    ogsDebug << "|source_code                  |" << data.source_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|warrant_type                 |" << data.warrant_type;
    ogsDebug << "|settle_style                 |" << data.settle_style;
    ogsDebug << "|apply_style                  |" << data.apply_style;
    ogsDebug << "|encash_price                 |" << data.encash_price;
    ogsDebug << "|apply_price                  |" << data.apply_price;
    ogsDebug << "|apply_rate                   |" << data.apply_rate;
    ogsDebug << "|apply_begin_date             |" << data.apply_begin_date;
    ogsDebug << "|apply_end_date               |" << data.apply_end_date;
    ogsDebug << "|source_amount                |" << data.source_amount;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DebitQryCodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[DebitQryCodeInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DebitQryCodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[DebitQryCodeOutput]====================";
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|ratio                        |" << data.ratio;
    ogsDebug << "|stock_interest               |" << data.stock_interest;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|par_value                    |" << data.par_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientStkAcctInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|query_direction              |" << data.query_direction;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryClientStkAcctOutput]==================";
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|main_flag                    |" << data.main_flag;
    ogsDebug << "|holder_kind                  |" << data.holder_kind;
    ogsDebug << "|holder_status                |" << data.holder_status;
    ogsDebug << "|holder_rights                |" << data.holder_rights;
    ogsDebug << "|register                     |" << data.register_str;
    ogsDebug << "|seat_no                      |" << data.seat_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SetPriceCostInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SetPriceCostInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|cost_price                   |" << data.cost_price;
    ogsDebug << "|income_balance               |" << data.income_balance;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SetPriceCostOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SetPriceCostOutput]====================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddStockRightInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AddStockRightInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|holder_rights                |" << data.holder_rights;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AddStockRightOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AddStockRightOutput]====================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelStockRightInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[DelStockRightInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|holder_rights                |" << data.holder_rights;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const DelStockRightOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[DelStockRightOutput]====================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEnterCodeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEnterCodeInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEnterCodeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEnterCodeOutput]====================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|last_price                   |" << data.last_price;
    ogsDebug << "|up_price                     |" << data.up_price;
    ogsDebug << "|down_price                   |" << data.down_price;
    ogsDebug << "|cost_price                   |" << data.cost_price;
    ogsDebug << "|high_amount                  |" << data.high_amount;
    ogsDebug << "|low_amount                   |" << data.low_amount;
    ogsDebug << "|hand_flag                    |" << data.hand_flag;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|transmit_amount              |" << data.transmit_amount;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    ogsDebug << "|stock_interest               |" << data.stock_interest;
    ogsDebug << "|notice_no                    |" << data.notice_no;
    ogsDebug << "|notice_info                  |" << data.notice_info;
    ogsDebug << "|delist_flag                  |" << data.delist_flag;
    ogsDebug << "|delist_date                  |" << data.delist_date;
    ogsDebug << "|par_value                    |" << data.par_value;
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    ogsDebug << "|wit_type                     |" << data.wit_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuAffordableAmtInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuAffordableAmtInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|bk_enable_balance            |" << data.bk_enable_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuAffordableAmtOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuAffordableAmtOutput]==================";
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|store_unit                   |" << data.store_unit;
    ogsDebug << "|enable_buy_amount            |" << data.enable_buy_amount;
    ogsDebug << "|high_amount                  |" << data.high_amount;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[SecuEntrustInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEntrustOutput]=====================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|seat_no                      |" << data.seat_no;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRegTradeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuRegTradeInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRegTradeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuRegTradeOutput]====================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustWithdrawInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_flag                   |" << data.batch_flag;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuEntrustWithdrawOutput]=================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|entrust_no_old               |" << data.entrust_no_old;
    ogsDebug << "|report_no_old                |" << data.report_no_old;
    ogsDebug << "|seat_no                      |" << data.seat_no;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|entrust_status_old           |" << data.entrust_status_old;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFfareChargeInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuFfareChargeInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|ffare0_times                 |" << data.ffare0_times;
    ogsDebug << "|ffare1_times                 |" << data.ffare1_times;
    ogsDebug << "|ffare2_times                 |" << data.ffare2_times;
    ogsDebug << "|ffare3_times                 |" << data.ffare3_times;
    ogsDebug << "|login_time                   |" << data.login_time;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFfareChargeOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuFfareChargeOutput]===================";
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|error_info                   |" << data.error_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustBuyInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuBatchEntrustBuyInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_style                |" << data.entrust_style;
    ogsDebug << "|ordinal_start                |" << data.ordinal_start;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|entrust_count                |" << data.entrust_count;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustBuyOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuBatchEntrustBuyOutput]=================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_count                |" << data.entrust_count;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustSaleInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuBatchEntrustSaleInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_style                |" << data.entrust_style;
    ogsDebug << "|ordinal_start                |" << data.ordinal_start;
    ogsDebug << "|max_amount                   |" << data.max_amount;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_count                |" << data.entrust_count;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustSaleOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuBatchEntrustSaleOutput]================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_style                |" << data.entrust_style;
    ogsDebug << "|ordinal_start                |" << data.ordinal_start;
    ogsDebug << "|max_amount                   |" << data.max_amount;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_count                |" << data.entrust_count;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuCalEntrustFareInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuCalEntrustFareInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuCalEntrustFareOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuCalEntrustFareOutput]=================";
    ogsDebug << "|ffare_balance                |" << data.ffare_balance;
    ogsDebug << "|bfare_balance                |" << data.bfare_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuIssueOFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuIssueOFundInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuIssueOFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuIssueOFundOutput]===================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryWithdrawableEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[SecuQryWithdrawableEntrustInput]==============";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryWithdrawableEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[SecuQryWithdrawableEntrustOutput]=============";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|report_time                  |" << data.report_time;
    ogsDebug << "|entrust_type                 |" << data.entrust_type;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|cancel_info                  |" << data.cancel_info;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuQryEntrustInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|query_direction              |" << data.query_direction;
    ogsDebug << "|sort_direction               |" << data.sort_direction;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|action_in                    |" << data.action_in;
    ogsDebug << "|locate_entrust_no            |" << data.locate_entrust_no;
    ogsDebug << "|query_type                   |" << data.query_type;
    ogsDebug << "|query_mode                   |" << data.query_mode;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    ogsDebug << "|etf_flag                     |" << data.etf_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuQryEntrustOutput]===================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|report_time                  |" << data.report_time;
    ogsDebug << "|entrust_type                 |" << data.entrust_type;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|cancel_info                  |" << data.cancel_info;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryRealtimeDealInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuQryRealtimeDealInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|query_direction              |" << data.query_direction;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|query_mode                   |" << data.query_mode;
    ogsDebug << "|query_type                   |" << data.query_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    ogsDebug << "|etf_flag                     |" << data.etf_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryRealtimeDealOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuQryRealtimeDealOutput]=================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|date                         |" << data.date;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|real_type                    |" << data.real_type;
    ogsDebug << "|real_status                  |" << data.real_status;
    ogsDebug << "|business_times               |" << data.business_times;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|business_no                  |" << data.business_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryPositionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuFastQryPositionInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryPositionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuFastQryPositionOutput]=================";
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|ffare_kind                   |" << data.ffare_kind;
    ogsDebug << "|bfare_kind                   |" << data.bfare_kind;
    ogsDebug << "|profit_flag                  |" << data.profit_flag;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|hold_amount                  |" << data.hold_amount;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|cost_price                   |" << data.cost_price;
    ogsDebug << "|income_balance               |" << data.income_balance;
    ogsDebug << "|hand_flag                    |" << data.hand_flag;
    ogsDebug << "|frozen_amount                |" << data.frozen_amount;
    ogsDebug << "|unfrozen_amount              |" << data.unfrozen_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|real_buy_amount              |" << data.real_buy_amount;
    ogsDebug << "|real_sell_amount             |" << data.real_sell_amount;
    ogsDebug << "|uncome_buy_amount            |" << data.uncome_buy_amount;
    ogsDebug << "|uncome_sell_amount           |" << data.uncome_sell_amount;
    ogsDebug << "|entrust_sell_amount          |" << data.entrust_sell_amount;
    ogsDebug << "|asset_price                  |" << data.asset_price;
    ogsDebug << "|last_price                   |" << data.last_price;
    ogsDebug << "|market_value                 |" << data.market_value;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|sum_buy_amount               |" << data.sum_buy_amount;
    ogsDebug << "|sum_buy_balance              |" << data.sum_buy_balance;
    ogsDebug << "|sum_sell_amount              |" << data.sum_sell_amount;
    ogsDebug << "|sum_sell_balance             |" << data.sum_sell_balance;
    ogsDebug << "|real_buy_balance             |" << data.real_buy_balance;
    ogsDebug << "|real_sell_balance            |" << data.real_sell_balance;
    ogsDebug << "|delist_flag                  |" << data.delist_flag;
    ogsDebug << "|delist_date                  |" << data.delist_date;
    ogsDebug << "|par_value                    |" << data.par_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryPositionInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuQryPositionInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|query_mode                   |" << data.query_mode;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryPositionOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuQryPositionOutput]===================";
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|hold_amount                  |" << data.hold_amount;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|real_buy_amount              |" << data.real_buy_amount;
    ogsDebug << "|real_sell_amount             |" << data.real_sell_amount;
    ogsDebug << "|uncome_buy_amount            |" << data.uncome_buy_amount;
    ogsDebug << "|uncome_sell_amount           |" << data.uncome_sell_amount;
    ogsDebug << "|entrust_sell_amount          |" << data.entrust_sell_amount;
    ogsDebug << "|last_price                   |" << data.last_price;
    ogsDebug << "|cost_price                   |" << data.cost_price;
    ogsDebug << "|keep_cost_price              |" << data.keep_cost_price;
    ogsDebug << "|income_balance               |" << data.income_balance;
    ogsDebug << "|hand_flag                    |" << data.hand_flag;
    ogsDebug << "|market_value                 |" << data.market_value;
    ogsDebug << "|av_buy_price                 |" << data.av_buy_price;
    ogsDebug << "|av_income_balance            |" << data.av_income_balance;
    ogsDebug << "|cost_balance                 |" << data.cost_balance;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|delist_flag                  |" << data.delist_flag;
    ogsDebug << "|delist_date                  |" << data.delist_date;
    ogsDebug << "|par_value                    |" << data.par_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryImpawnAmtInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuQryImpawnAmtInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryImpawnAmtOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuQryImpawnAmtOutput]==================";
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|store_amount                 |" << data.store_amount;
    ogsDebug << "|pre_out_amount               |" << data.pre_out_amount;
    ogsDebug << "|pre_in_amount                |" << data.pre_in_amount;
    ogsDebug << "|exchange_name                |" << data.exchange_name;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryBatchEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuQryBatchEntrustInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|locate_entrust_no            |" << data.locate_entrust_no;
    ogsDebug << "|query_direction              |" << data.query_direction;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuQryBatchEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuQryBatchEntrustOutput]=================";
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|date                         |" << data.date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|seat_no                      |" << data.seat_no;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|entrust_way                  |" << data.entrust_way;
    ogsDebug << "|entrust_type                 |" << data.entrust_type;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|report_time                  |" << data.report_time;
    ogsDebug << "|entrust_num                  |" << data.entrust_num;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistDeliverInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryHistDeliverInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|deliver_type                 |" << data.deliver_type;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistDeliverOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryHistDeliverOutput]===================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|business_type                |" << data.business_type;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|seat_no                      |" << data.seat_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|post_balance                 |" << data.post_balance;
    ogsDebug << "|post_amount                  |" << data.post_amount;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|business_no                  |" << data.business_no;
    ogsDebug << "|report_time                  |" << data.report_time;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|business_name                |" << data.business_name;
    ogsDebug << "|fare0                        |" << data.fare0;
    ogsDebug << "|fare1                        |" << data.fare1;
    ogsDebug << "|fare2                        |" << data.fare2;
    ogsDebug << "|fare3                        |" << data.fare3;
    ogsDebug << "|farex                        |" << data.farex;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistMatchInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistMatchInfoInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistMatchInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistMatchInfoOutput]==================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistLuckyInfoInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistLuckyInfoOutput]==================";
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryHistEntrustInput]====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryHistEntrustOutput]===================";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|report_time                  |" << data.report_time;
    ogsDebug << "|entrust_type                 |" << data.entrust_type;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|error_no                     |" << data.error_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistBusinessInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryHistBusinessInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistBusinessOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistBusinessOutput]===================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|business_status              |" << data.business_status;
    ogsDebug << "|business_times               |" << data.business_times;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|post_balance                 |" << data.post_balance;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|post_amount                  |" << data.post_amount;
    ogsDebug << "|fare0                        |" << data.fare0;
    ogsDebug << "|fare1                        |" << data.fare1;
    ogsDebug << "|fare2                        |" << data.fare2;
    ogsDebug << "|fare3                        |" << data.fare3;
    ogsDebug << "|farex                        |" << data.farex;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistFundStockInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistFundStockOutput]==================";
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|business_name                |" << data.business_name;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|post_balance                 |" << data.post_balance;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockAllInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryHistFundStockAllInput]=================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|query_mode                   |" << data.query_mode;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockAllOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryHistFundStockAllOutput]=================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|standard_fare0               |" << data.standard_fare0;
    ogsDebug << "|fare0                        |" << data.fare0;
    ogsDebug << "|fare1                        |" << data.fare1;
    ogsDebug << "|fare2                        |" << data.fare2;
    ogsDebug << "|fare3                        |" << data.fare3;
    ogsDebug << "|farex                        |" << data.farex;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|business_name                |" << data.business_name;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|post_balance                 |" << data.post_balance;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|occur_amount                 |" << data.occur_amount;
    ogsDebug << "|occur_balance                |" << data.occur_balance;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|business_no                  |" << data.business_no;
    ogsDebug << "|report_time                  |" << data.report_time;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyMatchInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistLuckyMatchInput]==================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|begin_date                   |" << data.begin_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyMatchOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryHistLuckyMatchOutput]==================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistStatementInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistStatementInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|begin_date                   |" << data.begin_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|query_mode                   |" << data.query_mode;
    ogsDebug << "|position_str_long            |" << data.position_str_long;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryHistStatementOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[QryHistStatementOutput]==================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|business_flag                |" << data.business_flag;
    ogsDebug << "|business_type                |" << data.business_type;
    ogsDebug << "|business_name                |" << data.business_name;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|bank_no                      |" << data.bank_no;
    ogsDebug << "|bank_name                    |" << data.bank_name;
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|clear_balance                |" << data.clear_balance;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|standard_fare0               |" << data.standard_fare0;
    ogsDebug << "|fare0                        |" << data.fare0;
    ogsDebug << "|fare1                        |" << data.fare1;
    ogsDebug << "|fare2                        |" << data.fare2;
    ogsDebug << "|fare3                        |" << data.fare3;
    ogsDebug << "|farex                        |" << data.farex;
    ogsDebug << "|exchange_fare                |" << data.exchange_fare;
    ogsDebug << "|exchange_fare0               |" << data.exchange_fare0;
    ogsDebug << "|exchange_fare1               |" << data.exchange_fare1;
    ogsDebug << "|exchange_fare2               |" << data.exchange_fare2;
    ogsDebug << "|exchange_fare3               |" << data.exchange_fare3;
    ogsDebug << "|exchange_fare4               |" << data.exchange_fare4;
    ogsDebug << "|exchange_fare5               |" << data.exchange_fare5;
    ogsDebug << "|exchange_fare6               |" << data.exchange_fare6;
    ogsDebug << "|exchange_farex               |" << data.exchange_farex;
    ogsDebug << "|position_str_long            |" << data.position_str_long;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuIssueEtfInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuIssueEtfInput]=====================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_bs                   |" << data.entrust_bs;
    ogsDebug << "|entrust_prop                 |" << data.entrust_prop;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuIssueEtfOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuIssueEtfOutput]====================";
    ogsDebug << "|init_date                    |" << data.init_date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryFundInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuFastQryFundInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|money_type                   |" << data.money_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryFundOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuFastQryFundOutput]===================";
    ogsDebug << "|money_type                   |" << data.money_type;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|enable_balance               |" << data.enable_balance;
    ogsDebug << "|fetch_balance                |" << data.fetch_balance;
    ogsDebug << "|frozen_balance               |" << data.frozen_balance;
    ogsDebug << "|unfrozen_balance             |" << data.unfrozen_balance;
    ogsDebug << "|fund_balance                 |" << data.fund_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryStockInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuFastQryStockInput]===================";
    ogsDebug << "|op_branch_no                 |" << data.op_branch_no;
    ogsDebug << "|op_entrust_way               |" << data.op_entrust_way;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|branch_no                    |" << data.branch_no;
    ogsDebug << "|client_id                    |" << data.client_id;
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|password_type                |" << data.password_type;
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryStockOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuFastQryStockOutput]==================";
    ogsDebug << "|fund_account                 |" << data.fund_account;
    ogsDebug << "|ffare_kind                   |" << data.ffare_kind;
    ogsDebug << "|bfare_kind                   |" << data.bfare_kind;
    ogsDebug << "|profit_flag                  |" << data.profit_flag;
    ogsDebug << "|exchange_type                |" << data.exchange_type;
    ogsDebug << "|stock_account                |" << data.stock_account;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|hold_amount                  |" << data.hold_amount;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|cost_price                   |" << data.cost_price;
    ogsDebug << "|income_balance               |" << data.income_balance;
    ogsDebug << "|hand_flag                    |" << data.hand_flag;
    ogsDebug << "|frozen_amount                |" << data.frozen_amount;
    ogsDebug << "|unfrozen_amount              |" << data.unfrozen_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|real_buy_amount              |" << data.real_buy_amount;
    ogsDebug << "|real_sell_amount             |" << data.real_sell_amount;
    ogsDebug << "|uncome_buy_amount            |" << data.uncome_buy_amount;
    ogsDebug << "|uncome_sell_amount           |" << data.uncome_sell_amount;
    ogsDebug << "|entrust_sell_amount          |" << data.entrust_sell_amount;
    ogsDebug << "|asset_price                  |" << data.asset_price;
    ogsDebug << "|last_price                   |" << data.last_price;
    ogsDebug << "|market_value                 |" << data.market_value;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|price_step                   |" << data.price_step;
    ogsDebug << "|sum_buy_amount               |" << data.sum_buy_amount;
    ogsDebug << "|sum_buy_balance              |" << data.sum_buy_balance;
    ogsDebug << "|sum_sell_amount              |" << data.sum_sell_amount;
    ogsDebug << "|sum_sell_balance             |" << data.sum_sell_balance;
    ogsDebug << "|real_buy_balance             |" << data.real_buy_balance;
    ogsDebug << "|real_sell_balance            |" << data.real_sell_balance;
    ogsDebug << "|delist_flag                  |" << data.delist_flag;
    ogsDebug << "|delist_date                  |" << data.delist_date;
    return logger;
}
