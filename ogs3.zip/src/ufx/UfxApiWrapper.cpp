///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "UfxApiWrapper.h"
#include "../StringHelper.h"
#include "UfxReader.h"
#include "UfxLogger.h"

using namespace std;

CConfigInterface* UfxApiWrapper::lpConfig = nullptr;

std::mutex UfxApiWrapper::mInitMutex;

UfxApiWrapper::UfxApiWrapper()
{

}

UfxApiWrapper::UfxApiWrapper(const UfxConfig &config)
{
    setConfig(config);
}

UfxApiWrapper::~UfxApiWrapper()
{

}

bool UfxApiWrapper::initialize()
{
    std::lock_guard<std::mutex> initLock(mInitMutex);

    static bool initialized = false;

    // 只在第一次调用时执行初始化操作。
    if (!initialized) {
        ufxCout << "初始化..." << endl;
        if (lpConfig != NULL){
            lpConfig->Release();
        }
        // 通过T2SDK的引出函数，来获取一个新的CConfig对象
        // 此对象在创建连接对象时被传递，用于配置所创建的连接对象的各种属性（比如服务器IP地址、安全模式等）
        // 值得注意的是，在向配置对象设置配置信息时，配置信息既可以从ini文件中载入，
        // 也可以在程序代码中设定，或者是2者的混合，如果对同一个配置项设不同的值，则以最近一次设置为准
        lpConfig = NewConfig();

        // 通过T2SDK的引出函数NewXXXX返回的对象，需要调用对象的Release方法释放，而不能直接用delete
        // 因为t2sdk.dll和调用程序可能是由不同的编译器、编译模式生成，delete可能会导致异常
        // 为了适合Delphi等使用（Delphi对接口自动调用AddRef方法），用C/C++开发的代码，需要在NewXXXX之后调用一下AddRef
        // 以保证引用计数正确
        lpConfig->AddRef();

        if(lpConfig->Load(config().mConfigureFilePath.c_str())) {
            string error = "初始化时出现错误：加载Hsconfig.ini失败。";
            ufxError << error;
            ufxCout << error << endl;
            return false;
        }

        char buf[1024] = { 0 };
        Encode(buf, config().mOperatorPasswd.c_str(), 0);

        if(lpConfig->SetString("safe", "comm_pwd", buf)) {
            string error = "初始化时出现错误：设置操作员密码失败。";
            ufxError << error;
            ufxCout << error << endl;
            return false;
        }

        ufxDebug << "初始化成功。";
        ufxCout << "初始化成功。" << endl;
        initialized = true;
    }
    return true;
}

bool UfxApiWrapper::isConnected() const
{
    return mConnected;
}

bool UfxApiWrapper::connect()
{
    sleepFor(2);

    if(!resetConnection(&mConnection)) return false;

    ufxCout << "连接成功！" << std::endl;
    mConnected = true;
    return true;
}

void UfxApiWrapper::sleepFor(int s)
{
#ifdef WIN32
    Sleep(s * 1000);
#else
    sleep(s);
#endif
}

void UfxApiWrapper::disconnect()
{
    closeConnection(mConnection);
    mConnected = false;
}

void UfxApiWrapper::setConfig(const UfxConfig &config)
{
    mConfig = config;
}

const UfxConfig &UfxApiWrapper::config() const
{
    return mConfig;
}

Intf_RetType UfxApiWrapper::onRecvCommonError(int result, IF2UnPacker *unPacker)
{
    if (result == 2) {
        string input((const char*)unPacker);
        ufxCout << "非业务错误信息：" << StringHelper::convertCodec(input) << "。"<< std::endl;
        // 不能执行freeUnPacker操作。
        return kIntfError;
    } else if (result == 3) {
        ufxCout << "业务包解包失败。" << std::endl;
        UfxReader::freeUnPacker(unPacker);
        return kIntfFail;
    } else if (result < 0) {
        string input((const char*)unPacker);
        ufxCout << "RecvBiz操作失败：" << StringHelper::convertCodec(input) << "。"<< std::endl;
        UfxReader::freeUnPacker(unPacker);
        return kIntfRecvFail;
    }
    ufxCout << "出现了未定义的错误。" << std::endl;
    unPacker->Release();
    UfxReader::freeUnPacker(unPacker);
    return kIntfFail;
}

void UfxApiWrapper::safeAssign(std::string &target, const char *source)
{
    if(!source){
        target.clear();
    }else{
        target.assign(source);
    }
}

bool UfxApiWrapper::resetConnection(CConnectionInterface** connection, CCallbackInterface *callback)
{
    if (*connection != NULL){
        closeConnection(*connection);
    }

    *connection = NewConnection(lpConfig);
    (*connection)->AddRef();

    int result = (*connection)->Create(callback);
    if (result != 0){
        ufxCout << "无法创建连接: " << StringHelper::convertCodec((*connection)->GetErrorMsg(result));
        return false;
    }

    if (result = ((*connection)->Connect(UFX_CONNECT_TIMEOUT_MS))){
        ufxCout << "无法连接: " << StringHelper::convertCodec((*connection)->GetErrorMsg(result));
        return false;
    }

    return true;
}

bool UfxApiWrapper::closeConnection(CConnectionInterface *connection)
{
    if(connection->Close()) return false;
    connection->Release();
    connection = NULL;
    return true;
}

/*!
 * \brief [330009] 城市代码查询。
 * \details 获取城市代码。
 */
Intf_RetType UfxApiWrapper::ufxQryCityCode(const QryCityCodeInput& input, std::list<QryCityCodeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("city_no", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.city_no.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330009, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryCityCodeOutput item;

            safeAssign(item.city_no, unPacker->GetStr("city_no"));
            safeAssign(item.city_name, unPacker->GetStr("city_name"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330011] 营业部查询。
 * \details 获取指定营业部信息。
 */
Intf_RetType UfxApiWrapper::ufxQryBranch(const QryBranchInput& input, std::list<QryBranchOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330011, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryBranchOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.branch_name, unPacker->GetStr("branch_name"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330016] 下一交易日获取。
 * \details 获取下一交易日。
 */
Intf_RetType UfxApiWrapper::ufxQryNextTradeDate(const QryNextTradeDateInput& input, std::list<QryNextTradeDateOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("finance_type", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stage_num", 'S');
    packer->AddField("init_date", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.finance_type.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stage_num.c_str());
    packer->AddStr(input.init_date.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330016, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryNextTradeDateOutput item;

            safeAssign(item.next_trade_date, unPacker->GetStr("next_trade_date"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330900] 接入站点地址获取。
 * \details 用于第三方获取可接入的UFX服务器地址及端口列表。
 */
Intf_RetType UfxApiWrapper::ufxQryUfxAccessStation(const QryUfxAccessStationInput& input, std::list<QryUfxAccessStationOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330900, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryUfxAccessStationOutput item;

            safeAssign(item.target_ar, unPacker->GetStr("target_ar"));
            safeAssign(item.ip_address, unPacker->GetStr("ip_address"));
            safeAssign(item.port_id, unPacker->GetStr("port_id"));
            safeAssign(item.protocol_type, unPacker->GetStr("protocol_type"));
            safeAssign(item.encode_way, unPacker->GetStr("encode_way"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331100] 客户登录。
 * \details 客户登录（支持特殊模式）。
 */
Intf_RetType UfxApiWrapper::ufxClientLogin(const ClientLoginInput& input, std::list<ClientLoginOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("input_content", 'S');
    packer->AddField("account_content", 'S');
    packer->AddField("content_type", 'S');
    packer->AddField("auth_product_type", 'S');
    packer->AddField("auth_key", 'S');
    packer->AddField("auth_bind_station", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.input_content.c_str());
    packer->AddStr(input.account_content.c_str());
    packer->AddStr(input.content_type.c_str());
    packer->AddStr(input.auth_product_type.c_str());
    packer->AddStr(input.auth_key.c_str());
    packer->AddStr(input.auth_bind_station.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331100, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            ClientLoginOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.sys_status, unPacker->GetStr("sys_status"));
            safeAssign(item.company_name, unPacker->GetStr("company_name"));
            safeAssign(item.content_type, unPacker->GetStr("content_type"));
            safeAssign(item.account_content, unPacker->GetStr("account_content"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.client_id, unPacker->GetStr("client_id"));
            safeAssign(item.client_name, unPacker->GetStr("client_name"));
            safeAssign(item.corp_client_group, unPacker->GetStr("corp_client_group"));
            safeAssign(item.corp_risk_level, unPacker->GetStr("corp_risk_level"));
            safeAssign(item.corp_begin_date, unPacker->GetStr("corp_begin_date"));
            safeAssign(item.corp_end_date, unPacker->GetStr("corp_end_date"));
            safeAssign(item.valid_flag, unPacker->GetStr("valid_flag"));
            safeAssign(item.fundaccount_count, unPacker->GetStr("fundaccount_count"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.client_rights, unPacker->GetStr("client_rights"));
            safeAssign(item.last_login_date, unPacker->GetStr("last_login_date"));
            safeAssign(item.last_login_time, unPacker->GetStr("last_login_time"));
            safeAssign(item.last_op_entrust_way, unPacker->GetStr("last_op_entrust_way"));
            safeAssign(item.last_op_station, unPacker->GetStr("last_op_station"));
            safeAssign(item.money_count, unPacker->GetStr("money_count"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.square_flag, unPacker->GetStr("square_flag"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.sysnode_id, unPacker->GetStr("sysnode_id"));
            safeAssign(item.user_token, unPacker->GetStr("user_token"));
            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));
            safeAssign(item.prestore_info, unPacker->GetStr("prestore_info"));
            safeAssign(item.login_times, unPacker->GetStr("login_times"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.product_flag, unPacker->GetStr("product_flag"));
            safeAssign(item.message_flag, unPacker->GetStr("message_flag"));
            safeAssign(item.tabconfirm_flag, unPacker->GetStr("tabconfirm_flag"));
            safeAssign(item.last_date, unPacker->GetStr("last_date"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331104] 客户权限增加
 * \details 开通客户资产账户的权限
 */
Intf_RetType UfxApiWrapper::ufxAddClientRight(const AddClientRightInput& input, std::list<AddClientRightOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_rights", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_rights.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331104, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            AddClientRightOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331105] 客户权限取消
 * \details 去除客户资产账户的权限
 */
Intf_RetType UfxApiWrapper::ufxDelClientRight(const DelClientRightInput& input, std::list<DelClientRightOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_rights", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_rights.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331105, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            DelClientRightOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331106] 客户委托方式开通
 * \details 增加资产账户允许委托方式
 */
Intf_RetType UfxApiWrapper::ufxAddClientEntrustWay(const AddClientEntrustWayInput& input, std::list<AddClientEntrustWayOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("en_entrust_way", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.en_entrust_way.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331106, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            AddClientEntrustWayOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331107] 客户委托方式取消
 * \details 减少资产账户允许委托方式
 */
Intf_RetType UfxApiWrapper::ufxDelClientEntrustWay(const DelClientEntrustWayInput& input, std::list<DelClientEntrustWayOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("en_entrust_way", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.en_entrust_way.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331107, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            DelClientEntrustWayOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331108] 客户限制信息增加
 * \details 开通客户资产账户限制
 */
Intf_RetType UfxApiWrapper::ufxAddClientRestriction(const AddClientRestrictionInput& input, std::list<AddClientRestrictionOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("restriction", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.restriction.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331108, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            AddClientRestrictionOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331109] 客户限制信息取消
 * \details 去除客户资产账户限制
 */
Intf_RetType UfxApiWrapper::ufxDelClientRestriction(const DelClientRestrictionInput& input, std::list<DelClientRestrictionOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("restriction", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.restriction.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331109, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            DelClientRestrictionOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331112] 账号分支号查询
 * \details 获取账号所属分支机构
 */
Intf_RetType UfxApiWrapper::ufxQryAcctSysNode(const QryAcctSysNodeInput& input, std::list<QryAcctSysNodeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("input_content", 'S');
    packer->AddField("account_content", 'S');
    packer->AddField("content_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.input_content.c_str());
    packer->AddStr(input.account_content.c_str());
    packer->AddStr(input.content_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331112, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryAcctSysNodeOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.sysnode_id, unPacker->GetStr("sysnode_id"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331113] 客户公告信息查询
 * \details 获取客户公告信息
 */
Intf_RetType UfxApiWrapper::ufxQryClientBulletin(const QryClientBulletinInput& input, std::list<QryClientBulletinOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331113, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientBulletinOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.client_id, unPacker->GetStr("client_id"));
            safeAssign(item.valid_date, unPacker->GetStr("valid_date"));
            safeAssign(item.message_notes, unPacker->GetStr("message_notes"));
            safeAssign(item.send_times, unPacker->GetStr("send_times"));
            safeAssign(item.criterion_prop, unPacker->GetStr("criterion_prop"));
            safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331119] 证券成本价类型设置
 * \details 设置证券成本价类型
 */
Intf_RetType UfxApiWrapper::ufxSetProfitFlag(const SetProfitFlagInput& input, std::list<SetProfitFlagOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("profit_flag", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.profit_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331119, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SetProfitFlagOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331121] 客户开户规范信息增加
 * \details 增加客户开户规范信息
 */
Intf_RetType UfxApiWrapper::ufxAddAccountData(const AddAccountDataInput& input, std::list<AddAccountDataOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("account_data_char", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_data_char.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331121, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            AddAccountDataOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331122] 客户开户规范信息去除
 * \details 去除客户开户规范信息
 */
Intf_RetType UfxApiWrapper::ufxDelAccountData(const DelAccountDataInput& input, std::list<DelAccountDataOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("account_data_char", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_data_char.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331122, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            DelAccountDataOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331150] 客户信息查询
 * \details 获取客户信息
 */
Intf_RetType UfxApiWrapper::ufxQryClientInfo(const QryClientInfoInput& input, std::list<QryClientInfoOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("query_mode", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.query_mode.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331150, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientInfoOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.client_name, unPacker->GetStr("client_name"));
            safeAssign(item.client_status, unPacker->GetStr("client_status"));
            safeAssign(item.fund_card, unPacker->GetStr("fund_card"));
            safeAssign(item.id_kind, unPacker->GetStr("id_kind"));
            safeAssign(item.id_no, unPacker->GetStr("id_no"));
            safeAssign(item.id_address, unPacker->GetStr("id_address"));
            safeAssign(item.mobiletelephone, unPacker->GetStr("mobiletelephone"));
            safeAssign(item.fax, unPacker->GetStr("fax"));
            safeAssign(item.zipcode, unPacker->GetStr("zipcode"));
            safeAssign(item.e_mail, unPacker->GetStr("e_mail"));
            safeAssign(item.open_date, unPacker->GetStr("open_date"));
            safeAssign(item.nationality, unPacker->GetStr("nationality"));
            safeAssign(item.address, unPacker->GetStr("address"));
            safeAssign(item.mail_name, unPacker->GetStr("mail_name"));
            safeAssign(item.risk_info, unPacker->GetStr("risk_info"));
            safeAssign(item.account_data, unPacker->GetStr("account_data"));
            safeAssign(item.organ_prop, unPacker->GetStr("organ_prop"));
            safeAssign(item.organ_name, unPacker->GetStr("organ_name"));
            safeAssign(item.client_group, unPacker->GetStr("client_group"));
            safeAssign(item.group_name, unPacker->GetStr("group_name"));
            safeAssign(item.full_name, unPacker->GetStr("full_name"));
            safeAssign(item.risk_name, unPacker->GetStr("risk_name"));
            safeAssign(item.account_data_name, unPacker->GetStr("account_data_name"));
            safeAssign(item.phonecode, unPacker->GetStr("phonecode"));
            safeAssign(item.client_id, unPacker->GetStr("client_id"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.client_rights, unPacker->GetStr("client_rights"));
            safeAssign(item.corp_client_group, unPacker->GetStr("corp_client_group"));
            safeAssign(item.corp_risk_level, unPacker->GetStr("corp_risk_level"));
            safeAssign(item.corp_begin_date, unPacker->GetStr("corp_begin_date"));
            safeAssign(item.corp_end_date, unPacker->GetStr("corp_end_date"));
            safeAssign(item.aml_risk_level, unPacker->GetStr("aml_risk_level"));
            safeAssign(item.paper_score, unPacker->GetStr("paper_score"));
            safeAssign(item.client_gender, unPacker->GetStr("client_gender"));
            safeAssign(item.en_entrust_way, unPacker->GetStr("en_entrust_way"));
            safeAssign(item.invest_advice, unPacker->GetStr("invest_advice"));
            safeAssign(item.id_begindate, unPacker->GetStr("id_begindate"));
            safeAssign(item.id_enddate, unPacker->GetStr("id_enddate"));
            safeAssign(item.profit_flag, unPacker->GetStr("profit_flag"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331152] 客户权限信息查询
 * \details 获取客户权限信息
 */
Intf_RetType UfxApiWrapper::ufxQryClientRight(const QryClientRightInput& input, std::list<QryClientRightOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331152, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientRightOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.client_rights, unPacker->GetStr("client_rights"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331154] 客户限制信息查询
 * \details 获取客户限制信息
 */
Intf_RetType UfxApiWrapper::ufxQryClientRestriction(const QryClientRestrictionInput& input, std::list<QryClientRestrictionOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331154, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientRestrictionOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.restriction, unPacker->GetStr("restriction"));
            safeAssign(item.restriction_name, unPacker->GetStr("restriction_name"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331155] 资产账户获取
 * \details 根据客户号获取资产帐户信息（支持特殊模式）
 */
Intf_RetType UfxApiWrapper::ufxQryFundAccount(const QryFundAccountInput& input, std::list<QryFundAccountOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331155, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryFundAccountOutput item;

            safeAssign(item.client_branch_no, unPacker->GetStr("client_branch_no"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.client_id, unPacker->GetStr("client_id"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.asset_type, unPacker->GetStr("asset_type"));
            safeAssign(item.main_flag, unPacker->GetStr("main_flag"));
            safeAssign(item.product_flag, unPacker->GetStr("product_flag"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.sysnode_id, unPacker->GetStr("sysnode_id"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331159] 客户转账金额控制查询
 * \details 查询必须存放于证券公司的保底金额，即这部分资金不能转往银行存管账户
 */
Intf_RetType UfxApiWrapper::ufxQryClientTransAmtLmt(const QryClientTransAmtLmtInput& input, std::list<QryClientTransAmtLmtOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("bank_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331159, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientTransAmtLmtOutput item;

            safeAssign(item.lower_limit_out, unPacker->GetStr("lower_limit_out"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332250] 存管资金账户转账日志查询
 * \details 实现存管资金账户转账日志查询
 */
Intf_RetType UfxApiWrapper::ufxQryBankTransfer(const QryBankTransferInput& input, std::list<QryBankTransferOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("query_type", 'S');
    packer->AddField("action_in", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.query_type.c_str());
    packer->AddStr(input.action_in.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332250, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryBankTransferOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.bank_name, unPacker->GetStr("bank_name"));
            safeAssign(item.trans_name, unPacker->GetStr("trans_name"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.business_type, unPacker->GetStr("business_type"));
            safeAssign(item.source_flag, unPacker->GetStr("source_flag"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.clear_balance, unPacker->GetStr("clear_balance"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
            safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.cancel_info, unPacker->GetStr("cancel_info"));
            safeAssign(item.bank_error_info, unPacker->GetStr("bank_error_info"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332251] 预约取款登记流水查询
 * \details 预约取款登记流水查询
 */
Intf_RetType UfxApiWrapper::ufxQrySvrBankPreDrawJour(const QrySvrBankPreDrawJourInput& input, std::list<QrySvrBankPreDrawJourOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("password", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("bank_account", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("treat_status", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("serial_no", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.bank_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.treat_status.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.serial_no.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332251, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QrySvrBankPreDrawJourOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.client_id, unPacker->GetStr("client_id"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.op_branch_no, unPacker->GetStr("op_branch_no"));
            safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
            safeAssign(item.op_station, unPacker->GetStr("op_station"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.draw_type, unPacker->GetStr("draw_type"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.precont_date, unPacker->GetStr("precont_date"));
            safeAssign(item.execute_date, unPacker->GetStr("execute_date"));
            safeAssign(item.valid_date, unPacker->GetStr("valid_date"));
            safeAssign(item.operator_code, unPacker->GetStr("operator_code"));
            safeAssign(item.max_balance, unPacker->GetStr("max_balance"));
            safeAssign(item.treat_status, unPacker->GetStr("treat_status"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332252] 客户资金流水查询
 * \details 查询客户资金流水(不包含交易资金流水)
 */
Intf_RetType UfxApiWrapper::ufxQryFundJour(const QryFundJourInput& input, std::list<QryFundJourOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("query_direction", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.query_direction.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332252, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryFundJourOutput item;

            safeAssign(item.business_date, unPacker->GetStr("business_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.business_name, unPacker->GetStr("business_name"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.post_balance, unPacker->GetStr("post_balance"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.business_time, unPacker->GetStr("business_time"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332254] 客户资金快速查询
 * \details 查询客户关键资金信息（支持特殊模式）
 */
Intf_RetType UfxApiWrapper::ufxFastQryClientFund(const FastQryClientFundInput& input, std::list<FastQryClientFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("money_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332254, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            FastQryClientFundOutput item;

            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.fetch_balance, unPacker->GetStr("fetch_balance"));
            safeAssign(item.frozen_balance, unPacker->GetStr("frozen_balance"));
            safeAssign(item.unfrozen_balance, unPacker->GetStr("unfrozen_balance"));
            safeAssign(item.fund_balance, unPacker->GetStr("fund_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332255] 客户资金精确查询
 * \details 获取客户当前资金信息（支持特殊模式）
 */
Intf_RetType UfxApiWrapper::ufxQryClientFundInfo(const QryClientFundInfoInput& input, std::list<QryClientFundInfoOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("money_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332255, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientFundInfoOutput item;

            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.begin_balance, unPacker->GetStr("begin_balance"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.foregift_balance, unPacker->GetStr("foregift_balance"));
            safeAssign(item.mortgage_balance, unPacker->GetStr("mortgage_balance"));
            safeAssign(item.frozen_balance, unPacker->GetStr("frozen_balance"));
            safeAssign(item.unfrozen_balance, unPacker->GetStr("unfrozen_balance"));
            safeAssign(item.fetch_balance, unPacker->GetStr("fetch_balance"));
            safeAssign(item.fetch_balance_old, unPacker->GetStr("fetch_balance_old"));
            safeAssign(item.fetch_cash, unPacker->GetStr("fetch_cash"));
            safeAssign(item.entrust_buy_balance, unPacker->GetStr("entrust_buy_balance"));
            safeAssign(item.market_value, unPacker->GetStr("market_value"));
            safeAssign(item.asset_balance, unPacker->GetStr("asset_balance"));
            safeAssign(item.interest, unPacker->GetStr("interest"));
            safeAssign(item.integral_balance, unPacker->GetStr("integral_balance"));
            safeAssign(item.fine_integral, unPacker->GetStr("fine_integral"));
            safeAssign(item.pre_interest, unPacker->GetStr("pre_interest"));
            safeAssign(item.pre_fine, unPacker->GetStr("pre_fine"));
            safeAssign(item.pre_interest_tax, unPacker->GetStr("pre_interest_tax"));
            safeAssign(item.correct_balance, unPacker->GetStr("correct_balance"));
            safeAssign(item.fund_balance, unPacker->GetStr("fund_balance"));
            safeAssign(item.opfund_market_value, unPacker->GetStr("opfund_market_value"));
            safeAssign(item.rate_kind, unPacker->GetStr("rate_kind"));
            safeAssign(item.real_buy_balance, unPacker->GetStr("real_buy_balance"));
            safeAssign(item.real_sell_balance, unPacker->GetStr("real_sell_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332268] 存管资金账户银行资金转账
 * \details 实现存管资金账号银证转账（同步模式）
 */
Intf_RetType UfxApiWrapper::ufxStockBankTransaction(const StockBankTransactionInput& input, std::list<StockBankTransactionOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("transfer_direction", 'S');
    packer->AddField("occur_balance", 'S');
    packer->AddField("fund_password", 'S');
    packer->AddField("bank_password", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.transfer_direction.c_str());
    packer->AddStr(input.occur_balance.c_str());
    packer->AddStr(input.fund_password.c_str());
    packer->AddStr(input.bank_password.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332268, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            StockBankTransactionOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.bktrans_status, unPacker->GetStr("bktrans_status"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332269] 存管资金账户资金查询
 * \details 实现客户理财资金主账户关联的所有存管资金账号或单一存管资金账户的资金余额查询。
 */
Intf_RetType UfxApiWrapper::ufxQrySvrBankBkFund(const QrySvrBankBkFundInput& input, std::list<QrySvrBankBkFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("bank_account", 'S');
    packer->AddField("money_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.bank_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332269, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QrySvrBankBkFundOutput item;

            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.main_flag, unPacker->GetStr("main_flag"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.bank_name, unPacker->GetStr("bank_name"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.fetch_balance, unPacker->GetStr("fetch_balance"));
            safeAssign(item.fund_balance, unPacker->GetStr("fund_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332270] 存管资金账户查询
 * \details 实现存管资金账户查询
 */
Intf_RetType UfxApiWrapper::ufxQrySvrBankBkExchAccount(const QrySvrBankBkExchAccountInput& input, std::list<QrySvrBankBkExchAccountOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("bank_account", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.bank_account.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332270, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QrySvrBankBkExchAccountOutput item;

            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.bkaccount_status, unPacker->GetStr("bkaccount_status"));
            safeAssign(item.square_flag, unPacker->GetStr("square_flag"));
            safeAssign(item.main_flag, unPacker->GetStr("main_flag"));
            safeAssign(item.holder_name, unPacker->GetStr("holder_name"));
            safeAssign(item.foreign_flag, unPacker->GetStr("foreign_flag"));
            safeAssign(item.id_kind, unPacker->GetStr("id_kind"));
            safeAssign(item.id_no, unPacker->GetStr("id_no"));
            safeAssign(item.authorize_code, unPacker->GetStr("authorize_code"));
            safeAssign(item.upper_limit_out, unPacker->GetStr("upper_limit_out"));
            safeAssign(item.lower_limit_out, unPacker->GetStr("lower_limit_out"));
            safeAssign(item.upper_limit_in, unPacker->GetStr("upper_limit_in"));
            safeAssign(item.lower_limit_in, unPacker->GetStr("lower_limit_in"));
            safeAssign(item.control_model_no, unPacker->GetStr("control_model_no"));
            safeAssign(item.bank_operator, unPacker->GetStr("bank_operator"));
            safeAssign(item.open_date, unPacker->GetStr("open_date"));
            safeAssign(item.bkaccount_regflag, unPacker->GetStr("bkaccount_regflag"));
            safeAssign(item.en_entrust_way, unPacker->GetStr("en_entrust_way"));
            safeAssign(item.bkaccount_rights, unPacker->GetStr("bkaccount_rights"));
            safeAssign(item.bkaccount_restrict, unPacker->GetStr("bkaccount_restrict"));
            safeAssign(item.book_account, unPacker->GetStr("book_account"));
            safeAssign(item.province_branch, unPacker->GetStr("province_branch"));
            safeAssign(item.city_branch, unPacker->GetStr("city_branch"));
            safeAssign(item.county_branch, unPacker->GetStr("county_branch"));
            safeAssign(item.sub_branch, unPacker->GetStr("sub_branch"));
            safeAssign(item.client_group, unPacker->GetStr("client_group"));
            safeAssign(item.room_code, unPacker->GetStr("room_code"));
            safeAssign(item.remark, unPacker->GetStr("remark"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332271] 存管资金流水查询
 * \details 实现存管资金流水查询
 */
Intf_RetType UfxApiWrapper::ufxQrySvrBankBkFundJour(const QrySvrBankBkFundJourInput& input, std::list<QrySvrBankBkFundJourOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("occur_balance", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.occur_balance.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332271, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QrySvrBankBkFundJourOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.aasexch_type, unPacker->GetStr("aasexch_type"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.join_date, unPacker->GetStr("join_date"));
            safeAssign(item.join_serial_no, unPacker->GetStr("join_serial_no"));
            safeAssign(item.deal_flag, unPacker->GetStr("deal_flag"));
            safeAssign(item.ent_init_date, unPacker->GetStr("ent_init_date"));
            safeAssign(item.ent_serial_no, unPacker->GetStr("ent_serial_no"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332272] 存管资金账户银行资金查询
 * \details 实现向银行发起资金查询
 */
Intf_RetType UfxApiWrapper::ufxQrySvrBankBkBalance(const QrySvrBankBkBalanceInput& input, std::list<QrySvrBankBkBalanceOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("fund_password", 'S');
    packer->AddField("bank_password", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.fund_password.c_str());
    packer->AddStr(input.bank_password.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332272, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QrySvrBankBkBalanceOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.bktrans_status, unPacker->GetStr("bktrans_status"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332273] 存管资金账户主辅转账
 * \details 实现同一客户下两个存管资金账户之间的转账
 */
Intf_RetType UfxApiWrapper::ufxSvrBankBkExchAccountTransfer(const SvrBankBkExchAccountTransferInput& input, std::list<SvrBankBkExchAccountTransferOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_account_src", 'S');
    packer->AddField("bank_no_src", 'S');
    packer->AddField("client_account_dest", 'S');
    packer->AddField("bank_no_dest", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("occur_balance", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_account_src.c_str());
    packer->AddStr(input.bank_no_src.c_str());
    packer->AddStr(input.client_account_dest.c_str());
    packer->AddStr(input.bank_no_dest.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.occur_balance.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332273, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrBankBkExchAccountTransferOutput item;

            safeAssign(item.serial_no_src, unPacker->GetStr("serial_no_src"));
            safeAssign(item.serial_no_dest, unPacker->GetStr("serial_no_dest"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332950] 客户查询
 * \details 实现单客户基本信息查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasClient(const SvrAasQryAasClientInput& input, std::list<SvrAasQryAasClientOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332950, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasClientOutput item;

            safeAssign(item.client_name, unPacker->GetStr("client_name"));
            safeAssign(item.nationality, unPacker->GetStr("nationality"));
            safeAssign(item.organ_flag, unPacker->GetStr("organ_flag"));
            safeAssign(item.cust_property, unPacker->GetStr("cust_property"));
            safeAssign(item.norm_flag, unPacker->GetStr("norm_flag"));
            safeAssign(item.id_kind, unPacker->GetStr("id_kind"));
            safeAssign(item.id_no, unPacker->GetStr("id_no"));
            safeAssign(item.id_begindate, unPacker->GetStr("id_begindate"));
            safeAssign(item.id_enddate, unPacker->GetStr("id_enddate"));
            safeAssign(item.original_organ, unPacker->GetStr("original_organ"));
            safeAssign(item.original_branch, unPacker->GetStr("original_branch"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.first_open_date, unPacker->GetStr("first_open_date"));
            safeAssign(item.open_date, unPacker->GetStr("open_date"));
            safeAssign(item.cancel_date, unPacker->GetStr("cancel_date"));
            safeAssign(item.client_status, unPacker->GetStr("client_status"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332951] 理财资金账户查询
 * \details 实现理财资金账户查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasFundAcct(const SvrAasQryAasFundAcctInput& input, std::list<SvrAasQryAasFundAcctOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("account_name", 'S');
    packer->AddField("main_fund_account", 'S');
    packer->AddField("asset_prop", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("fund_trustee_prop", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.account_name.c_str());
    packer->AddStr(input.main_fund_account.c_str());
    packer->AddStr(input.asset_prop.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.fund_trustee_prop.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332951, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasFundAcctOutput item;

            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.account_name, unPacker->GetStr("account_name"));
            safeAssign(item.main_fund_account, unPacker->GetStr("main_fund_account"));
            safeAssign(item.main_flag, unPacker->GetStr("main_flag"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.businsys_id, unPacker->GetStr("businsys_id"));
            safeAssign(item.fund_trustee_prop, unPacker->GetStr("fund_trustee_prop"));
            safeAssign(item.fundacct_status, unPacker->GetStr("fundacct_status"));
            safeAssign(item.open_date, unPacker->GetStr("open_date"));
            safeAssign(item.cancel_date, unPacker->GetStr("cancel_date"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332952] 托管账户关系查询
 * \details 实现托管账户关系查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasTrustAcct(const SvrAasQryAasTrustAcctInput& input, std::list<SvrAasQryAasTrustAcctOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("sdc_account", 'S');
    packer->AddField("busin_account", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("asset_prop", 'S');
    packer->AddField("agency_no", 'S');
    packer->AddField("share_trustee_prop", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.sdc_account.c_str());
    packer->AddStr(input.busin_account.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.asset_prop.c_str());
    packer->AddStr(input.agency_no.c_str());
    packer->AddStr(input.share_trustee_prop.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332952, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasTrustAcctOutput item;

            safeAssign(item.seat_no, unPacker->GetStr("seat_no"));
            safeAssign(item.aasexch_type, unPacker->GetStr("aasexch_type"));
            safeAssign(item.sdc_account, unPacker->GetStr("sdc_account"));
            safeAssign(item.busin_account, unPacker->GetStr("busin_account"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.businsys_id, unPacker->GetStr("businsys_id"));
            safeAssign(item.share_trustee_prop, unPacker->GetStr("share_trustee_prop"));
            safeAssign(item.agency_no, unPacker->GetStr("agency_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332953] 理财资金账户余额调拨
 * \details 实现理财资金主从账户间余额调拨(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasAdjustAasFund(const SvrAasAdjustAasFundInput& input, std::list<SvrAasAdjustAasFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("fund_account_src", 'S');
    packer->AddField("fund_account_dest", 'S');
    packer->AddField("adjust_balance", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.fund_account_src.c_str());
    packer->AddStr(input.fund_account_dest.c_str());
    packer->AddStr(input.adjust_balance.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332953, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasAdjustAasFundOutput item;

            safeAssign(item.serial_no1, unPacker->GetStr("serial_no1"));
            safeAssign(item.serial_no2, unPacker->GetStr("serial_no2"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332954] 资产账务资金查询
 * \details 实现理财资金账号的资金余额查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasFund(const SvrAasQryAasFundInput& input, std::list<SvrAasQryAasFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("money_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332954, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasFundOutput item;

            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.account_name, unPacker->GetStr("account_name"));
            safeAssign(item.asset_prop, unPacker->GetStr("asset_prop"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.frozen_balance, unPacker->GetStr("frozen_balance"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.fetch_balance, unPacker->GetStr("fetch_balance"));
            safeAssign(item.uncome_balance, unPacker->GetStr("uncome_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332955] 可用资金查询
 * \details 实现理财资金账户可用资金查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasEnableFund(const SvrAasQryAasEnableFundInput& input, std::list<SvrAasQryAasEnableFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("usable_date", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("aasexch_type", 'S');
    packer->AddField("business_flag", 'S');
    packer->AddField("prod_code", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.usable_date.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.aasexch_type.c_str());
    packer->AddStr(input.business_flag.c_str());
    packer->AddStr(input.prod_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332955, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasEnableFundOutput item;

            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332956] 资金请求日志查询
 * \details 实现客户当前资金请求日志查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasFundRequest(const SvrAasQryAasFundRequestInput& input, std::list<SvrAasQryAasFundRequestOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("en_business_flag", 'S');
    packer->AddField("deal_flag", 'S');
    packer->AddField("en_money_type", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.en_business_flag.c_str());
    packer->AddStr(input.deal_flag.c_str());
    packer->AddStr(input.en_money_type.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332956, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasFundRequestOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.account_name, unPacker->GetStr("account_name"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.businsys_id, unPacker->GetStr("businsys_id"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.deal_flag, unPacker->GetStr("deal_flag"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [332957] 资金流水查询
 * \details 实现客户当前资金流水查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryAasFundJour(const SvrAasQryAasFundJourInput& input, std::list<SvrAasQryAasFundJourOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("en_aas_change_type", 'S');
    packer->AddField("en_business_flag", 'S');
    packer->AddField("en_money_type", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.en_aas_change_type.c_str());
    packer->AddStr(input.en_business_flag.c_str());
    packer->AddStr(input.en_money_type.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(332957, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryAasFundJourOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.account_name, unPacker->GetStr("account_name"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.businsys_id, unPacker->GetStr("businsys_id"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.aas_change_type, unPacker->GetStr("aas_change_type"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339204] 历史转账流水查询
 * \details 获取历史转账流水
 */
Intf_RetType UfxApiWrapper::ufxSvrBankQryHistBkTransfer(const SvrBankQryHistBkTransferInput& input, std::list<SvrBankQryHistBkTransferOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("action_in", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');
    packer->AddField("query_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.action_in.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->AddStr(input.query_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339204, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrBankQryHistBkTransferOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
            safeAssign(item.trans_name, unPacker->GetStr("trans_name"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.bank_name, unPacker->GetStr("bank_name"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.business_type, unPacker->GetStr("business_type"));
            safeAssign(item.trans_type, unPacker->GetStr("trans_type"));
            safeAssign(item.source_flag, unPacker->GetStr("source_flag"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.cancel_info, unPacker->GetStr("cancel_info"));
            safeAssign(item.bank_error_info, unPacker->GetStr("bank_error_info"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.remark, unPacker->GetStr("remark"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339207] 资金请求历史日志查询
 * \details 实现资金请求日志查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxAasExtQryAasFundRequest(const AasExtQryAasFundRequestInput& input, std::list<AasExtQryAasFundRequestOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("en_business_flag", 'S');
    packer->AddField("deal_flag", 'S');
    packer->AddField("en_money_type", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.en_business_flag.c_str());
    packer->AddStr(input.deal_flag.c_str());
    packer->AddStr(input.en_money_type.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339207, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            AasExtQryAasFundRequestOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.account_name, unPacker->GetStr("account_name"));
            safeAssign(item.businsys_id, unPacker->GetStr("businsys_id"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.deal_flag, unPacker->GetStr("deal_flag"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339208] 资金流水历史查询
 * \details 实现客户资金历史流水查询(06版占位，UF2.0未实现)
 */
Intf_RetType UfxApiWrapper::ufxSvrAasQryHistAasFundJour(const SvrAasQryHistAasFundJourInput& input, std::list<SvrAasQryHistAasFundJourOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("businsys_id", 'S');
    packer->AddField("en_aas_change_type", 'S');
    packer->AddField("en_business_flag", 'S');
    packer->AddField("en_money_type", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.businsys_id.c_str());
    packer->AddStr(input.en_aas_change_type.c_str());
    packer->AddStr(input.en_business_flag.c_str());
    packer->AddStr(input.en_money_type.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339208, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrAasQryHistAasFundJourOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.account_name, unPacker->GetStr("account_name"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.businsys_id, unPacker->GetStr("businsys_id"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.aas_change_type, unPacker->GetStr("aas_change_type"));
            safeAssign(item.surplus_days, unPacker->GetStr("surplus_days"));
            safeAssign(item.settle_time, unPacker->GetStr("settle_time"));
            safeAssign(item.deal_flag, unPacker->GetStr("deal_flag"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339209] 存管资金历史流水查询
 * \details 实现存管资金历史流水查询
 */
Intf_RetType UfxApiWrapper::ufxSvrBankQryHistBkFundJour(const SvrBankQryHistBkFundJourInput& input, std::list<SvrBankQryHistBkFundJourOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("client_account", 'S');
    packer->AddField("bank_no", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("occur_balance", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.client_account.c_str());
    packer->AddStr(input.bank_no.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.occur_balance.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339209, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SvrBankQryHistBkFundJourOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.curr_date, unPacker->GetStr("curr_date"));
            safeAssign(item.curr_time, unPacker->GetStr("curr_time"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.client_account, unPacker->GetStr("client_account"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.bank_account, unPacker->GetStr("bank_account"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.join_date, unPacker->GetStr("join_date"));
            safeAssign(item.join_serial_no, unPacker->GetStr("join_serial_no"));
            safeAssign(item.deal_flag, unPacker->GetStr("deal_flag"));
            safeAssign(item.ent_init_date, unPacker->GetStr("ent_init_date"));
            safeAssign(item.ent_serial_no, unPacker->GetStr("ent_serial_no"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [400] 证券行情查询
 * \details 获取指定证券代码的行情
 */
Intf_RetType UfxApiWrapper::ufxSecuQryPrice(const SecuQryPriceInput& input, std::list<SecuQryPriceOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("version", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.version.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(400, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryPriceOutput item;

            safeAssign(item.exchange_index, unPacker->GetStr("exchange_index"));
            safeAssign(item.last_price, unPacker->GetStr("last_price"));
            safeAssign(item.open_price, unPacker->GetStr("open_price"));
            safeAssign(item.close_price, unPacker->GetStr("close_price"));
            safeAssign(item.high_price, unPacker->GetStr("high_price"));
            safeAssign(item.low_price, unPacker->GetStr("low_price"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.buy_price1, unPacker->GetStr("buy_price1"));
            safeAssign(item.buy_price2, unPacker->GetStr("buy_price2"));
            safeAssign(item.buy_price3, unPacker->GetStr("buy_price3"));
            safeAssign(item.buy_price4, unPacker->GetStr("buy_price4"));
            safeAssign(item.buy_price5, unPacker->GetStr("buy_price5"));
            safeAssign(item.sale_price1, unPacker->GetStr("sale_price1"));
            safeAssign(item.sale_price2, unPacker->GetStr("sale_price2"));
            safeAssign(item.sale_price3, unPacker->GetStr("sale_price3"));
            safeAssign(item.sale_price4, unPacker->GetStr("sale_price4"));
            safeAssign(item.sale_price5, unPacker->GetStr("sale_price5"));
            safeAssign(item.buy_amount1, unPacker->GetStr("buy_amount1"));
            safeAssign(item.buy_amount2, unPacker->GetStr("buy_amount2"));
            safeAssign(item.buy_amount3, unPacker->GetStr("buy_amount3"));
            safeAssign(item.buy_amount4, unPacker->GetStr("buy_amount4"));
            safeAssign(item.buy_amount5, unPacker->GetStr("buy_amount5"));
            safeAssign(item.sale_amount1, unPacker->GetStr("sale_amount1"));
            safeAssign(item.sale_amount2, unPacker->GetStr("sale_amount2"));
            safeAssign(item.sale_amount3, unPacker->GetStr("sale_amount3"));
            safeAssign(item.sale_amount4, unPacker->GetStr("sale_amount4"));
            safeAssign(item.sale_amount5, unPacker->GetStr("sale_amount5"));
            safeAssign(item.stock_interest, unPacker->GetStr("stock_interest"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [394] 深圳盘后行情查询
 * \details 深圳盘后行情查询
 */
Intf_RetType UfxApiWrapper::ufxSecuQrySzClosingPrice(const SecuQrySzClosingPriceInput& input, std::list<SecuQrySzClosingPriceOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("version", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.version.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(394, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQrySzClosingPriceOutput item;

            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.closing_price, unPacker->GetStr("closing_price"));
            safeAssign(item.weightave_price, unPacker->GetStr("weightave_price"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330300] 证券代码信息查询
 * \details 获取证券代码信息
 */
Intf_RetType UfxApiWrapper::ufxStkCodeQry(const StkCodeQryInput& input, std::list<StkCodeQryOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("query_type", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.query_type.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330300, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            StkCodeQryOutput item;

            safeAssign(item.internal_code, unPacker->GetStr("internal_code"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.buy_unit, unPacker->GetStr("buy_unit"));
            safeAssign(item.price_step, unPacker->GetStr("price_step"));
            safeAssign(item.store_unit, unPacker->GetStr("store_unit"));
            safeAssign(item.up_price, unPacker->GetStr("up_price"));
            safeAssign(item.down_price, unPacker->GetStr("down_price"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.high_amount, unPacker->GetStr("high_amount"));
            safeAssign(item.low_amount, unPacker->GetStr("low_amount"));
            safeAssign(item.stock_real_back, unPacker->GetStr("stock_real_back"));
            safeAssign(item.fund_real_back, unPacker->GetStr("fund_real_back"));
            safeAssign(item.delist_flag, unPacker->GetStr("delist_flag"));
            safeAssign(item.delist_date, unPacker->GetStr("delist_date"));
            safeAssign(item.trade_plat, unPacker->GetStr("trade_plat"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.par_value, unPacker->GetStr("par_value"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330303] 新股申购信息查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxNewQryStkCode(const NewQryStkCodeInput& input, std::list<NewQryStkCodeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330303, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            NewQryStkCodeOutput item;

            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.buy_unit, unPacker->GetStr("buy_unit"));
            safeAssign(item.price_step, unPacker->GetStr("price_step"));
            safeAssign(item.store_unit, unPacker->GetStr("store_unit"));
            safeAssign(item.par_value, unPacker->GetStr("par_value"));
            safeAssign(item.stkcode_status, unPacker->GetStr("stkcode_status"));
            safeAssign(item.up_price, unPacker->GetStr("up_price"));
            safeAssign(item.down_price, unPacker->GetStr("down_price"));
            safeAssign(item.high_amount, unPacker->GetStr("high_amount"));
            safeAssign(item.low_amount, unPacker->GetStr("low_amount"));
            safeAssign(item.collect_date, unPacker->GetStr("collect_date"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330304] 权证信息查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxWarrantQryCode(const WarrantQryCodeInput& input, std::list<WarrantQryCodeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("warrant_code", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.warrant_code.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330304, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            WarrantQryCodeOutput item;

            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.warrant_code, unPacker->GetStr("warrant_code"));
            safeAssign(item.apply_code, unPacker->GetStr("apply_code"));
            safeAssign(item.source_code, unPacker->GetStr("source_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.warrant_type, unPacker->GetStr("warrant_type"));
            safeAssign(item.settle_style, unPacker->GetStr("settle_style"));
            safeAssign(item.apply_style, unPacker->GetStr("apply_style"));
            safeAssign(item.encash_price, unPacker->GetStr("encash_price"));
            safeAssign(item.apply_price, unPacker->GetStr("apply_price"));
            safeAssign(item.apply_rate, unPacker->GetStr("apply_rate"));
            safeAssign(item.apply_begin_date, unPacker->GetStr("apply_begin_date"));
            safeAssign(item.apply_end_date, unPacker->GetStr("apply_end_date"));
            safeAssign(item.source_amount, unPacker->GetStr("source_amount"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [330305] 国债利息查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxDebitQryCode(const DebitQryCodeInput& input, std::list<DebitQryCodeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(330305, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            DebitQryCodeOutput item;

            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.ratio, unPacker->GetStr("ratio"));
            safeAssign(item.stock_interest, unPacker->GetStr("stock_interest"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.par_value, unPacker->GetStr("par_value"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331300] 证券股东信息查询
 * \details 未指定资金帐号时，返回该客户的所有股东账号信息（支持特殊模式）
 */
Intf_RetType UfxApiWrapper::ufxQryClientStkAcct(const QryClientStkAcctInput& input, std::list<QryClientStkAcctOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("query_direction", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.query_direction.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331300, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryClientStkAcctOutput item;

            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.main_flag, unPacker->GetStr("main_flag"));
            safeAssign(item.holder_kind, unPacker->GetStr("holder_kind"));
            safeAssign(item.holder_status, unPacker->GetStr("holder_status"));
            safeAssign(item.holder_rights, unPacker->GetStr("holder_rights"));
            safeAssign(item.register_str, unPacker->GetStr("register"));
            safeAssign(item.seat_no, unPacker->GetStr("seat_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331301] 证券成本价设置
 * \details 重置证券持仓成本价
 */
Intf_RetType UfxApiWrapper::ufxSetPriceCost(const SetPriceCostInput& input, std::list<SetPriceCostOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("cost_price", 'S');
    packer->AddField("income_balance", 'S');
    packer->AddField("entrust_price", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.cost_price.c_str());
    packer->AddStr(input.income_balance.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331301, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SetPriceCostOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331304] 股东权限开通
 * \details 增加股东权限
 */
Intf_RetType UfxApiWrapper::ufxAddStockRight(const AddStockRightInput& input, std::list<AddStockRightOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("holder_rights", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.holder_rights.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331304, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            AddStockRightOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [331305] 股东权限取消
 * \details 取消股东权限
 */
Intf_RetType UfxApiWrapper::ufxDelStockRight(const DelStockRightInput& input, std::list<DelStockRightOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("holder_rights", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.holder_rights.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(331305, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            DelStockRightOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333000] 代码输入确认
 * \details 交易过程中，当输入代码之后，获取证券代码信息，客户证券余额信息。
 */
Intf_RetType UfxApiWrapper::ufxSecuEnterCode(const SecuEnterCodeInput& input, std::list<SecuEnterCodeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_prop", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333000, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuEnterCodeOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.last_price, unPacker->GetStr("last_price"));
            safeAssign(item.up_price, unPacker->GetStr("up_price"));
            safeAssign(item.down_price, unPacker->GetStr("down_price"));
            safeAssign(item.cost_price, unPacker->GetStr("cost_price"));
            safeAssign(item.high_amount, unPacker->GetStr("high_amount"));
            safeAssign(item.low_amount, unPacker->GetStr("low_amount"));
            safeAssign(item.hand_flag, unPacker->GetStr("hand_flag"));
            safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
            safeAssign(item.transmit_amount, unPacker->GetStr("transmit_amount"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.stock_interest, unPacker->GetStr("stock_interest"));
            safeAssign(item.notice_no, unPacker->GetStr("notice_no"));
            safeAssign(item.notice_info, unPacker->GetStr("notice_info"));
            safeAssign(item.delist_flag, unPacker->GetStr("delist_flag"));
            safeAssign(item.delist_date, unPacker->GetStr("delist_date"));
            safeAssign(item.par_value, unPacker->GetStr("par_value"));
            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));
            safeAssign(item.wit_type, unPacker->GetStr("wit_type"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333001] 大约可买获取
 * \details 获取客户大约可买指定代码的数量
 */
Intf_RetType UfxApiWrapper::ufxSecuAffordableAmt(const SecuAffordableAmtInput& input, std::list<SecuAffordableAmtOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_prop", 'S');
    packer->AddField("bk_enable_balance", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->AddStr(input.bk_enable_balance.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333001, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuAffordableAmtOutput item;

            safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
            safeAssign(item.store_unit, unPacker->GetStr("store_unit"));
            safeAssign(item.enable_buy_amount, unPacker->GetStr("enable_buy_amount"));
            safeAssign(item.high_amount, unPacker->GetStr("high_amount"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333002] 普通委托
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuEntrust(const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("entrust_prop", 'S');
    packer->AddField("batch_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333002, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuEntrustOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.seat_no, unPacker->GetStr("seat_no"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333009] 指定交易
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuRegTrade(const SecuRegTradeInput& input, std::list<SecuRegTradeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("entrust_prop", 'S');
    packer->AddField("batch_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333009, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuRegTradeOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333017] 委托撤单
 * \details 委托撤单，支持单笔撤单和批量撤单
 */
Intf_RetType UfxApiWrapper::ufxSecuEntrustWithdraw(const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("batch_flag", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("entrust_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_flag.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333017, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuEntrustWithdrawOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.entrust_no_old, unPacker->GetStr("entrust_no_old"));
            safeAssign(item.report_no_old, unPacker->GetStr("report_no_old"));
            safeAssign(item.seat_no, unPacker->GetStr("seat_no"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.entrust_status_old, unPacker->GetStr("entrust_status_old"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333018] 前台收费
 * \details 系统在客户退出，同时对客户的操作进行收费处理（如果有前台费用的设置）
 */
Intf_RetType UfxApiWrapper::ufxSecuFfareCharge(const SecuFfareChargeInput& input, std::list<SecuFfareChargeOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("ffare0_times", 'S');
    packer->AddField("ffare1_times", 'S');
    packer->AddField("ffare2_times", 'S');
    packer->AddField("ffare3_times", 'S');
    packer->AddField("login_time", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.ffare0_times.c_str());
    packer->AddStr(input.ffare1_times.c_str());
    packer->AddStr(input.ffare2_times.c_str());
    packer->AddStr(input.ffare3_times.c_str());
    packer->AddStr(input.login_time.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333018, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuFfareChargeOutput item;

            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.error_info, unPacker->GetStr("error_info"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333019] 批量委托买入
 * \details 批量委托买入
 */
Intf_RetType UfxApiWrapper::ufxSecuBatchEntrustBuy(const SecuBatchEntrustBuyInput& input, std::list<SecuBatchEntrustBuyOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_style", 'S');
    packer->AddField("ordinal_start", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("entrust_count", 'S');
    packer->AddField("enable_balance", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_style.c_str());
    packer->AddStr(input.ordinal_start.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.entrust_count.c_str());
    packer->AddStr(input.enable_balance.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333019, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuBatchEntrustBuyOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.entrust_count, unPacker->GetStr("entrust_count"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333020] 批量委托卖出
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuBatchEntrustSale(const SecuBatchEntrustSaleInput& input, std::list<SecuBatchEntrustSaleOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_style", 'S');
    packer->AddField("ordinal_start", 'S');
    packer->AddField("max_amount", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_count", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_style.c_str());
    packer->AddStr(input.ordinal_start.c_str());
    packer->AddStr(input.max_amount.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_count.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333020, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuBatchEntrustSaleOutput item;

            safeAssign(item.op_branch_no, unPacker->GetStr("op_branch_no"));
            safeAssign(item.op_entrust_way, unPacker->GetStr("op_entrust_way"));
            safeAssign(item.op_station, unPacker->GetStr("op_station"));
            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.client_id, unPacker->GetStr("client_id"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.password, unPacker->GetStr("password"));
            safeAssign(item.password_type, unPacker->GetStr("password_type"));
            safeAssign(item.user_token, unPacker->GetStr("user_token"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
            safeAssign(item.entrust_style, unPacker->GetStr("entrust_style"));
            safeAssign(item.ordinal_start, unPacker->GetStr("ordinal_start"));
            safeAssign(item.max_amount, unPacker->GetStr("max_amount"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.entrust_count, unPacker->GetStr("entrust_count"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333023] 委托费用计算
 * \details 委托前费用预算
 */
Intf_RetType UfxApiWrapper::ufxSecuCalEntrustFare(const SecuCalEntrustFareInput& input, std::list<SecuCalEntrustFareOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("entrust_prop", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333023, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuCalEntrustFareOutput item;

            safeAssign(item.ffare_balance, unPacker->GetStr("ffare_balance"));
            safeAssign(item.bfare_balance, unPacker->GetStr("bfare_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333026] 场内基金认购
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuIssueOFund(const SecuIssueOFundInput& input, std::list<SecuIssueOFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("entrust_prop", 'S');
    packer->AddField("batch_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333026, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuIssueOFundOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333100] 可撤单委托查询
 * \details 仅返回委托状态如下的委托：0:未报 1:待报 2:已报 3:已报待撤 4:部成待撤 7:部成 W:待确认
 */
Intf_RetType UfxApiWrapper::ufxSecuQryWithdrawableEntrust(const SecuQryWithdrawableEntrustInput& input, std::list<SecuQryWithdrawableEntrustOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("password", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333100, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryWithdrawableEntrustOutput item;

            safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.report_time, unPacker->GetStr("report_time"));
            safeAssign(item.entrust_type, unPacker->GetStr("entrust_type"));
            safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
            safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
            safeAssign(item.entrust_prop, unPacker->GetStr("entrust_prop"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.cancel_info, unPacker->GetStr("cancel_info"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333101] 证券委托查询
 * \details 获取客户所有证券委托信息
 */
Intf_RetType UfxApiWrapper::ufxSecuQryEntrust(const SecuQryEntrustInput& input, std::list<SecuQryEntrustOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("query_direction", 'S');
    packer->AddField("sort_direction", 'S');
    packer->AddField("report_no", 'S');
    packer->AddField("action_in", 'S');
    packer->AddField("locate_entrust_no", 'S');
    packer->AddField("query_type", 'S');
    packer->AddField("query_mode", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');
    packer->AddField("etf_flag", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.query_direction.c_str());
    packer->AddStr(input.sort_direction.c_str());
    packer->AddStr(input.report_no.c_str());
    packer->AddStr(input.action_in.c_str());
    packer->AddStr(input.locate_entrust_no.c_str());
    packer->AddStr(input.query_type.c_str());
    packer->AddStr(input.query_mode.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->AddStr(input.etf_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333101, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryEntrustOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.report_time, unPacker->GetStr("report_time"));
            safeAssign(item.entrust_type, unPacker->GetStr("entrust_type"));
            safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
            safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
            safeAssign(item.entrust_prop, unPacker->GetStr("entrust_prop"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.cancel_info, unPacker->GetStr("cancel_info"));
            safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333102] 证券成交查询
 * \details 获取客户证券成交流水
 */
Intf_RetType UfxApiWrapper::ufxSecuQryRealtimeDeal(const SecuQryRealtimeDealInput& input, std::list<SecuQryRealtimeDealOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("serial_no", 'S');
    packer->AddField("query_direction", 'S');
    packer->AddField("report_no", 'S');
    packer->AddField("query_mode", 'S');
    packer->AddField("query_type", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');
    packer->AddField("etf_flag", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.serial_no.c_str());
    packer->AddStr(input.query_direction.c_str());
    packer->AddStr(input.report_no.c_str());
    packer->AddStr(input.query_mode.c_str());
    packer->AddStr(input.query_type.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->AddStr(input.etf_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333102, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryRealtimeDealOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.date, unPacker->GetStr("date"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.business_time, unPacker->GetStr("business_time"));
            safeAssign(item.real_type, unPacker->GetStr("real_type"));
            safeAssign(item.real_status, unPacker->GetStr("real_status"));
            safeAssign(item.business_times, unPacker->GetStr("business_times"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.entrust_prop, unPacker->GetStr("entrust_prop"));
            safeAssign(item.business_no, unPacker->GetStr("business_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333103] 证券持仓快速查询
 * \details 不精确计算成本，而是将费用属性同步返回，让周边计算成本
 */
Intf_RetType UfxApiWrapper::ufxSecuFastQryPosition(const SecuFastQryPositionInput& input, std::list<SecuFastQryPositionOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333103, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuFastQryPositionOutput item;

            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.ffare_kind, unPacker->GetStr("ffare_kind"));
            safeAssign(item.bfare_kind, unPacker->GetStr("bfare_kind"));
            safeAssign(item.profit_flag, unPacker->GetStr("profit_flag"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.hold_amount, unPacker->GetStr("hold_amount"));
            safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
            safeAssign(item.cost_price, unPacker->GetStr("cost_price"));
            safeAssign(item.income_balance, unPacker->GetStr("income_balance"));
            safeAssign(item.hand_flag, unPacker->GetStr("hand_flag"));
            safeAssign(item.frozen_amount, unPacker->GetStr("frozen_amount"));
            safeAssign(item.unfrozen_amount, unPacker->GetStr("unfrozen_amount"));
            safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
            safeAssign(item.real_buy_amount, unPacker->GetStr("real_buy_amount"));
            safeAssign(item.real_sell_amount, unPacker->GetStr("real_sell_amount"));
            safeAssign(item.uncome_buy_amount, unPacker->GetStr("uncome_buy_amount"));
            safeAssign(item.uncome_sell_amount, unPacker->GetStr("uncome_sell_amount"));
            safeAssign(item.entrust_sell_amount, unPacker->GetStr("entrust_sell_amount"));
            safeAssign(item.asset_price, unPacker->GetStr("asset_price"));
            safeAssign(item.last_price, unPacker->GetStr("last_price"));
            safeAssign(item.market_value, unPacker->GetStr("market_value"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.sum_buy_amount, unPacker->GetStr("sum_buy_amount"));
            safeAssign(item.sum_buy_balance, unPacker->GetStr("sum_buy_balance"));
            safeAssign(item.sum_sell_amount, unPacker->GetStr("sum_sell_amount"));
            safeAssign(item.sum_sell_balance, unPacker->GetStr("sum_sell_balance"));
            safeAssign(item.real_buy_balance, unPacker->GetStr("real_buy_balance"));
            safeAssign(item.real_sell_balance, unPacker->GetStr("real_sell_balance"));
            safeAssign(item.delist_flag, unPacker->GetStr("delist_flag"));
            safeAssign(item.delist_date, unPacker->GetStr("delist_date"));
            safeAssign(item.par_value, unPacker->GetStr("par_value"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333104] 证券持仓查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuQryPosition(const SecuQryPositionInput& input, std::list<SecuQryPositionOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("query_mode", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.query_mode.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333104, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryPositionOutput item;

            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.hold_amount, unPacker->GetStr("hold_amount"));
            safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
            safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
            safeAssign(item.real_buy_amount, unPacker->GetStr("real_buy_amount"));
            safeAssign(item.real_sell_amount, unPacker->GetStr("real_sell_amount"));
            safeAssign(item.uncome_buy_amount, unPacker->GetStr("uncome_buy_amount"));
            safeAssign(item.uncome_sell_amount, unPacker->GetStr("uncome_sell_amount"));
            safeAssign(item.entrust_sell_amount, unPacker->GetStr("entrust_sell_amount"));
            safeAssign(item.last_price, unPacker->GetStr("last_price"));
            safeAssign(item.cost_price, unPacker->GetStr("cost_price"));
            safeAssign(item.keep_cost_price, unPacker->GetStr("keep_cost_price"));
            safeAssign(item.income_balance, unPacker->GetStr("income_balance"));
            safeAssign(item.hand_flag, unPacker->GetStr("hand_flag"));
            safeAssign(item.market_value, unPacker->GetStr("market_value"));
            safeAssign(item.av_buy_price, unPacker->GetStr("av_buy_price"));
            safeAssign(item.av_income_balance, unPacker->GetStr("av_income_balance"));
            safeAssign(item.cost_balance, unPacker->GetStr("cost_balance"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.delist_flag, unPacker->GetStr("delist_flag"));
            safeAssign(item.delist_date, unPacker->GetStr("delist_date"));
            safeAssign(item.par_value, unPacker->GetStr("par_value"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333105] 证券债券质押余额查询
 * \details 获取债券质押在库余额
 */
Intf_RetType UfxApiWrapper::ufxSecuQryImpawnAmt(const SecuQryImpawnAmtInput& input, std::list<SecuQryImpawnAmtOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333105, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryImpawnAmtOutput item;

            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.store_amount, unPacker->GetStr("store_amount"));
            safeAssign(item.pre_out_amount, unPacker->GetStr("pre_out_amount"));
            safeAssign(item.pre_in_amount, unPacker->GetStr("pre_in_amount"));
            safeAssign(item.exchange_name, unPacker->GetStr("exchange_name"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333107] 证券批量委托查询
 * \details 获取证券批量委托信息(按委托批号batch_no合笔)
 */
Intf_RetType UfxApiWrapper::ufxSecuQryBatchEntrust(const SecuQryBatchEntrustInput& input, std::list<SecuQryBatchEntrustOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("locate_entrust_no", 'S');
    packer->AddField("query_direction", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.locate_entrust_no.c_str());
    packer->AddStr(input.query_direction.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333107, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuQryBatchEntrustOutput item;

            safeAssign(item.branch_no, unPacker->GetStr("branch_no"));
            safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
            safeAssign(item.date, unPacker->GetStr("date"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.seat_no, unPacker->GetStr("seat_no"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.entrust_way, unPacker->GetStr("entrust_way"));
            safeAssign(item.entrust_type, unPacker->GetStr("entrust_type"));
            safeAssign(item.entrust_prop, unPacker->GetStr("entrust_prop"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
            safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
            safeAssign(item.report_time, unPacker->GetStr("report_time"));
            safeAssign(item.entrust_num, unPacker->GetStr("entrust_num"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339300] 历史交割信息查询
 * \details 获取历史交割信息
 */
Intf_RetType UfxApiWrapper::ufxQryHistDeliver(const QryHistDeliverInput& input, std::list<QryHistDeliverOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("deliver_type", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.deliver_type.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339300, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistDeliverOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.business_type, unPacker->GetStr("business_type"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.seat_no, unPacker->GetStr("seat_no"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.post_balance, unPacker->GetStr("post_balance"));
            safeAssign(item.post_amount, unPacker->GetStr("post_amount"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.business_no, unPacker->GetStr("business_no"));
            safeAssign(item.report_time, unPacker->GetStr("report_time"));
            safeAssign(item.business_time, unPacker->GetStr("business_time"));
            safeAssign(item.business_name, unPacker->GetStr("business_name"));
            safeAssign(item.fare0, unPacker->GetStr("fare0"));
            safeAssign(item.fare1, unPacker->GetStr("fare1"));
            safeAssign(item.fare2, unPacker->GetStr("fare2"));
            safeAssign(item.fare3, unPacker->GetStr("fare3"));
            safeAssign(item.farex, unPacker->GetStr("farex"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339301] 历史配号信息查询
 * \details 获取历史配号信息
 */
Intf_RetType UfxApiWrapper::ufxQryHistMatchInfo(const QryHistMatchInfoInput& input, std::list<QryHistMatchInfoOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339301, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistMatchInfoOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339302] 历史中签信息查询
 * \details 获取历史中签信息
 */
Intf_RetType UfxApiWrapper::ufxQryHistLuckyInfo(const QryHistLuckyInfoInput& input, std::list<QryHistLuckyInfoOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339302, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistLuckyInfoOutput item;

            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339303] 历史证券委托查询
 * \details 获取证券历史委托流水
 */
Intf_RetType UfxApiWrapper::ufxQryHistEntrust(const QryHistEntrustInput& input, std::list<QryHistEntrustOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339303, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistEntrustOutput item;

            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
            safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
            safeAssign(item.report_time, unPacker->GetStr("report_time"));
            safeAssign(item.entrust_type, unPacker->GetStr("entrust_type"));
            safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
            safeAssign(item.error_no, unPacker->GetStr("error_no"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339304] 历史证券成交查询
 * \details 获取证券历史成交信息
 */
Intf_RetType UfxApiWrapper::ufxQryHistBusiness(const QryHistBusinessInput& input, std::list<QryHistBusinessOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339304, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistBusinessOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.business_time, unPacker->GetStr("business_time"));
            safeAssign(item.business_status, unPacker->GetStr("business_status"));
            safeAssign(item.business_times, unPacker->GetStr("business_times"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.report_no, unPacker->GetStr("report_no"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.post_balance, unPacker->GetStr("post_balance"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.post_amount, unPacker->GetStr("post_amount"));
            safeAssign(item.fare0, unPacker->GetStr("fare0"));
            safeAssign(item.fare1, unPacker->GetStr("fare1"));
            safeAssign(item.fare2, unPacker->GetStr("fare2"));
            safeAssign(item.fare3, unPacker->GetStr("fare3"));
            safeAssign(item.farex, unPacker->GetStr("farex"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339305] 历史资金证券流水查询
 * \details 获取历史资金证券流水
 */
Intf_RetType UfxApiWrapper::ufxQryHistFundStock(const QryHistFundStockInput& input, std::list<QryHistFundStockOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339305, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistFundStockOutput item;

            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.business_date, unPacker->GetStr("business_date"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.business_name, unPacker->GetStr("business_name"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.post_balance, unPacker->GetStr("post_balance"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339306] 历史资金证券流水详细查询
 * \details 获取历史资金证券流水详细
 */
Intf_RetType UfxApiWrapper::ufxQryHistFundStockAll(const QryHistFundStockAllInput& input, std::list<QryHistFundStockAllOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("query_mode", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.query_mode.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339306, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistFundStockAllOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.standard_fare0, unPacker->GetStr("standard_fare0"));
            safeAssign(item.fare0, unPacker->GetStr("fare0"));
            safeAssign(item.fare1, unPacker->GetStr("fare1"));
            safeAssign(item.fare2, unPacker->GetStr("fare2"));
            safeAssign(item.fare3, unPacker->GetStr("fare3"));
            safeAssign(item.farex, unPacker->GetStr("farex"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.business_name, unPacker->GetStr("business_name"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.post_balance, unPacker->GetStr("post_balance"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.occur_amount, unPacker->GetStr("occur_amount"));
            safeAssign(item.occur_balance, unPacker->GetStr("occur_balance"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.entrust_bs, unPacker->GetStr("entrust_bs"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
            safeAssign(item.business_no, unPacker->GetStr("business_no"));
            safeAssign(item.report_time, unPacker->GetStr("report_time"));
            safeAssign(item.business_time, unPacker->GetStr("business_time"));
            safeAssign(item.remark, unPacker->GetStr("remark"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339309] 历史证券配号中签信息查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxQryHistLuckyMatch(const QryHistLuckyMatchInput& input, std::list<QryHistLuckyMatchOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("begin_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.begin_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339309, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistLuckyMatchOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.business_price, unPacker->GetStr("business_price"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [339310] 历史证券合并对账单查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxQryHistStatement(const QryHistStatementInput& input, std::list<QryHistStatementOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("begin_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("money_type", 'S');
    packer->AddField("query_mode", 'S');
    packer->AddField("position_str_long", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.begin_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->AddStr(input.query_mode.c_str());
    packer->AddStr(input.position_str_long.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(339310, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            QryHistStatementOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.business_flag, unPacker->GetStr("business_flag"));
            safeAssign(item.business_type, unPacker->GetStr("business_type"));
            safeAssign(item.business_name, unPacker->GetStr("business_name"));
            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.bank_no, unPacker->GetStr("bank_no"));
            safeAssign(item.bank_name, unPacker->GetStr("bank_name"));
            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
            safeAssign(item.clear_balance, unPacker->GetStr("clear_balance"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
            safeAssign(item.standard_fare0, unPacker->GetStr("standard_fare0"));
            safeAssign(item.fare0, unPacker->GetStr("fare0"));
            safeAssign(item.fare1, unPacker->GetStr("fare1"));
            safeAssign(item.fare2, unPacker->GetStr("fare2"));
            safeAssign(item.fare3, unPacker->GetStr("fare3"));
            safeAssign(item.farex, unPacker->GetStr("farex"));
            safeAssign(item.exchange_fare, unPacker->GetStr("exchange_fare"));
            safeAssign(item.exchange_fare0, unPacker->GetStr("exchange_fare0"));
            safeAssign(item.exchange_fare1, unPacker->GetStr("exchange_fare1"));
            safeAssign(item.exchange_fare2, unPacker->GetStr("exchange_fare2"));
            safeAssign(item.exchange_fare3, unPacker->GetStr("exchange_fare3"));
            safeAssign(item.exchange_fare4, unPacker->GetStr("exchange_fare4"));
            safeAssign(item.exchange_fare5, unPacker->GetStr("exchange_fare5"));
            safeAssign(item.exchange_fare6, unPacker->GetStr("exchange_fare6"));
            safeAssign(item.exchange_farex, unPacker->GetStr("exchange_farex"));
            safeAssign(item.position_str_long, unPacker->GetStr("position_str_long"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333027] ETF网上现金认购
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuIssueEtf(const SecuIssueEtfInput& input, std::list<SecuIssueEtfOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_bs", 'S');
    packer->AddField("entrust_prop", 'S');
    packer->AddField("batch_no", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_bs.c_str());
    packer->AddStr(input.entrust_prop.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333027, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuIssueEtfOutput item;

            safeAssign(item.init_date, unPacker->GetStr("init_date"));
            safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [335101] 客户资金信息查询。
 * \details 获取客户当前资金信息。业务范围：融资融券。
 */
Intf_RetType UfxApiWrapper::ufxClientFundAllQryEx(const ClientFundAllQryExInput& input, std::list<ClientFundAllQryExOutput>& output, string& errMsg){
    ufxCout << "+--------------------------[输 入]--------------------------" << std::endl;
    ufxCout << "|op_branch_no                 |" << input.op_branch_no << std::endl;
    ufxCout << "|op_entrust_way               |" << input.op_entrust_way << std::endl;
    ufxCout << "|op_station                   |" << input.op_station << std::endl;
    ufxCout << "|branch_no                    |" << input.branch_no << std::endl;
    ufxCout << "|client_id                    |" << input.client_id << std::endl;
    ufxCout << "|fund_account                 |" << input.fund_account << std::endl;
    ufxCout << "|password                     |" << input.password << std::endl;
    ufxCout << "|password_type                |" << input.password_type << std::endl;
    ufxCout << "|user_token                   |" << input.user_token << std::endl;
    ufxCout << "|asset_prop                   |" << input.asset_prop << std::endl;
    ufxCout << "|money_type                   |" << input.money_type << std::endl;
    ufxCout << "+-----------------------------+-----------------------------" << std::endl;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("asset_prop", 'S');
    packer->AddField("money_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.asset_prop.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(335101, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            ClientFundAllQryExOutput item;

            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.frozen_balance, unPacker->GetStr("frozen_balance"));
            safeAssign(item.unfrozen_balance, unPacker->GetStr("unfrozen_balance"));
            safeAssign(item.real_buy_balance, unPacker->GetStr("real_buy_balance"));
            safeAssign(item.real_sell_balance, unPacker->GetStr("real_sell_balance"));

            ufxCout << "+--------------------------[输 出]--------------------------" << std::endl;
            ufxCout << "|current_balance              |" << item.current_balance << std::endl;
            ufxCout << "|enable_balance               |" << item.enable_balance << std::endl;
            ufxCout << "|frozen_balance               |" << item.frozen_balance << std::endl;
            ufxCout << "|unfrozen_balance             |" << item.unfrozen_balance << std::endl;
            ufxCout << "|real_buy_balance             |" << item.real_buy_balance << std::endl;
            ufxCout << "|real_sell_balance            |" << item.real_sell_balance << std::endl;
            ufxCout << "+-----------------------------+-----------------------------" << std::endl;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333612] 极速交易客户资金快速查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuFastQryFund(const SecuFastQryFundInput& input, std::list<SecuFastQryFundOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("money_type", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.money_type.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333612, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuFastQryFundOutput item;

            safeAssign(item.money_type, unPacker->GetStr("money_type"));
            safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
            safeAssign(item.enable_balance, unPacker->GetStr("enable_balance"));
            safeAssign(item.fetch_balance, unPacker->GetStr("fetch_balance"));
            safeAssign(item.frozen_balance, unPacker->GetStr("frozen_balance"));
            safeAssign(item.unfrozen_balance, unPacker->GetStr("unfrozen_balance"));
            safeAssign(item.fund_balance, unPacker->GetStr("fund_balance"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
/*!
 * \brief [333620] 极速交易客户证券快速查询
 * \details
 */
Intf_RetType UfxApiWrapper::ufxSecuFastQryStock(const SecuFastQryStockInput& input, std::list<SecuFastQryStockOutput>& output, std::string& errMsg)
{
    ufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("op_branch_no", 'S');
    packer->AddField("op_entrust_way", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("branch_no", 'S');
    packer->AddField("client_id", 'S');
    packer->AddField("fund_account", 'S');
    packer->AddField("password", 'S');
    packer->AddField("password_type", 'S');
    packer->AddField("user_token", 'S');
    packer->AddField("exchange_type", 'S');
    packer->AddField("stock_account", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.op_branch_no.c_str());
    packer->AddStr(input.op_entrust_way.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.branch_no.c_str());
    packer->AddStr(input.client_id.c_str());
    packer->AddStr(input.fund_account.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.password_type.c_str());
    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.exchange_type.c_str());
    packer->AddStr(input.stock_account.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(333620, packer, 0)) <= 0){
        UfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0){
        errMsg.assign("业务操作成功。");
        ufxCout << errMsg << std::endl;
        while(!unPacker->IsEOF()){
            SecuFastQryStockOutput item;

            safeAssign(item.fund_account, unPacker->GetStr("fund_account"));
            safeAssign(item.ffare_kind, unPacker->GetStr("ffare_kind"));
            safeAssign(item.bfare_kind, unPacker->GetStr("bfare_kind"));
            safeAssign(item.profit_flag, unPacker->GetStr("profit_flag"));
            safeAssign(item.exchange_type, unPacker->GetStr("exchange_type"));
            safeAssign(item.stock_account, unPacker->GetStr("stock_account"));
            safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
            safeAssign(item.stock_type, unPacker->GetStr("stock_type"));
            safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
            safeAssign(item.hold_amount, unPacker->GetStr("hold_amount"));
            safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
            safeAssign(item.cost_price, unPacker->GetStr("cost_price"));
            safeAssign(item.income_balance, unPacker->GetStr("income_balance"));
            safeAssign(item.hand_flag, unPacker->GetStr("hand_flag"));
            safeAssign(item.frozen_amount, unPacker->GetStr("frozen_amount"));
            safeAssign(item.unfrozen_amount, unPacker->GetStr("unfrozen_amount"));
            safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
            safeAssign(item.real_buy_amount, unPacker->GetStr("real_buy_amount"));
            safeAssign(item.real_sell_amount, unPacker->GetStr("real_sell_amount"));
            safeAssign(item.uncome_buy_amount, unPacker->GetStr("uncome_buy_amount"));
            safeAssign(item.uncome_sell_amount, unPacker->GetStr("uncome_sell_amount"));
            safeAssign(item.entrust_sell_amount, unPacker->GetStr("entrust_sell_amount"));
            safeAssign(item.asset_price, unPacker->GetStr("asset_price"));
            safeAssign(item.last_price, unPacker->GetStr("last_price"));
            safeAssign(item.market_value, unPacker->GetStr("market_value"));
            safeAssign(item.position_str, unPacker->GetStr("position_str"));
            safeAssign(item.price_step, unPacker->GetStr("price_step"));
            safeAssign(item.sum_buy_amount, unPacker->GetStr("sum_buy_amount"));
            safeAssign(item.sum_buy_balance, unPacker->GetStr("sum_buy_balance"));
            safeAssign(item.sum_sell_amount, unPacker->GetStr("sum_sell_amount"));
            safeAssign(item.sum_sell_balance, unPacker->GetStr("sum_sell_balance"));
            safeAssign(item.real_buy_balance, unPacker->GetStr("real_buy_balance"));
            safeAssign(item.real_sell_balance, unPacker->GetStr("real_sell_balance"));
            safeAssign(item.delist_flag, unPacker->GetStr("delist_flag"));
            safeAssign(item.delist_date, unPacker->GetStr("delist_date"));

            ufxLogger() << item;

            output.push_back(item);
            unPacker->Next();
        }
    }else if(result == 1){
        UfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        ufxCout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker);
    }
    return kIntfSuccess;
}
