///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef UFXAPIWRAPPER_H
#define UFXAPIWRAPPER_H

#define UFX_CONFIGURE_FILE "Hsconfig.ini"
#define UFX_CONNECT_TIMEOUT_MS 1000

#include <string>
#include <list>
#include <mutex>
#include <ufx/t2sdk_interface.h>
#include <unistd.h>

#include "../Interface.h" // for Intf_RetType

struct UfxConfig {
    std::string mOperatorPasswd;
    std::string mSiteInfoFormat;
    std::string mConfigureFilePath;     //!< 配置文件（如t2sdk.ini,Hsconfig.ini等）的路径
};

struct QryCityCodeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string city_no;                //!< 城市编号
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryCityCodeOutput {
    std::string city_no;                //!< 城市编号
    std::string city_name;              //!< 市名
    std::string position_str;           //!< 定位串
};
struct QryBranchInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
};
struct QryBranchOutput {
    std::string branch_no;              //!< 分支机构
    std::string branch_name;            //!< 机构名称
};
struct QryNextTradeDateInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string finance_type;           //!< 金融品种类别 1-证券 3-开放式基金 （默认取证券）
    std::string exchange_type;          //!< 交易类别(默认取上海)
    std::string stage_num;              //!< 取N个交易日(默认取下一交易日)
    std::string init_date;              //!< 初始化日期
};
struct QryNextTradeDateOutput {
    std::string next_trade_date;        //!< 下一交易日
};
struct QryUfxAccessStationInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
};
struct QryUfxAccessStationOutput {
    std::string target_ar;              //!< AR名称
    std::string ip_address;             //!< IP地址
    std::string port_id;                //!< 连接端口
    std::string protocol_type;          //!< 接入协议0 类fast, 1 t2, 2 fix
    std::string encode_way;             //!< 通讯协议使用的加密方式 -- 0 SSL，1 PWD， 2 SAP（SSL AND PWD）, 3 其它
};
struct ClientLoginInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string input_content;          //!< 输入的客户标志类别，‘1’，‘2’，‘3’，4’，‘5’, ‘6’, ‘A’分别表示account_content代表资金帐号，股东内码，和资金卡号，银行帐号，股东帐号，客户编号，期货帐号。”特殊模式“下，只允许以客户号或资金账号登录。
    std::string account_content;        //!< 输入内容
    std::string content_type;           //!< 客户标识类型(银行号、市场类别)
    std::string auth_product_type;      //!< 认证产品类别　0:机器特征码 1:UKEY数字证书 2:动态密码 3:CA证书
    std::string auth_key;               //!< 认证串(当auth_product_type=1或3时，输入的证书号或签名，2时输入的是动态密码）
    std::string auth_bind_station;      //!< 硬件绑定地址(硬件机器码)
};
struct ClientLoginOutput {
    std::string init_date;              //!< 发生日期
    std::string sys_status;             //!< 系统状态
    std::string company_name;           //!< 公司名称
    std::string content_type;           //!< 银行号、市场类别(期货暂不支持)
    std::string account_content;        //!< 输入内容(期货暂不支持)
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string client_name;            //!< 客户姓名
    std::string corp_client_group;      //!< 公司客户类型(期货暂不支持)
    std::string corp_risk_level;        //!< 客户风险等级（账户V2.0，期货暂不支持）
    std::string corp_begin_date;        //!< 客户风险测评日（账户V2.0，期货暂不支持)
    std::string corp_end_date;          //!< 客户风险到期日（账户V2.0，期货暂不支持）
    std::string valid_flag;             //!< 客户风险等级有效标志（账户V2.0，期货暂不支持）
    std::string fundaccount_count;      //!< 资产账号个数，当客户号登录的时候返回资产账号个数，否则返回0(期货不返回)
    std::string fund_account;           //!< 资金账户
    std::string client_rights;          //!< 客户权限　参见动态数据字典-1021
    std::string last_login_date;        //!< 上次登录日期(期货暂不支持)
    std::string last_login_time;        //!< 上次登录时间(期货暂不支持)
    std::string last_op_entrust_way;    //!< 上次登陆委托方式(期货暂不支持)
    std::string last_op_station;        //!< 上次登陆站点/电话(期货暂不支持)
    std::string money_count;            //!< 币种数量(期货暂不支持)
    std::string money_type;             //!< 币种类别(期货暂不支持)
    std::string square_flag;            //!< 结算标志，用来标志资产账户的结算模式。0-本地客户，1-银证通客户，2-第三方存管客户(期货不返回)
    std::string enable_balance;         //!< 可用资金(期货暂不支持)
    std::string current_balance;        //!< 当前余额(期货暂不支持)
    std::string exchange_type;          //!< 交易类别(期货暂不支持)
    std::string stock_account;          //!< 证券账号(期货暂不支持)
    std::string bank_no;                //!< 银行代码(期货暂不支持)
    std::string sysnode_id;             //!< 系统节点编号
    std::string user_token;             //!< 用户口令
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
    std::string prestore_info;          //!< 预留信息(期货暂不支持)
    std::string login_times;            //!< 今日登录次数(期货暂不支持)
    std::string asset_prop;             //!< 资产属性 返回资金账号的资金属性（账户V2.0，期货暂不支持)
    std::string product_flag;           //!< 产品标志-数据字典1055(期货暂不支持)
    std::string message_flag;           //!< 消息标志，是否存在公告信息。若为'1'，通过331113接口取提示信息(期货暂不支持)
    std::string tabconfirm_flag;        //!< 强制帐单确认(仅期货接口支持)
    std::string last_date;              //!< 上一交易日(仅期货接口支持)
};
struct AddClientRightInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_rights;          //!< 客户权限　参见动态数据字典-1021
};
struct AddClientRightOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct DelClientRightInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_rights;          //!< 客户权限　参见动态数据字典-1021
};
struct DelClientRightOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct AddClientEntrustWayInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string en_entrust_way;         //!< 允许委托方式
};
struct AddClientEntrustWayOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct DelClientEntrustWayInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string en_entrust_way;         //!< 允许委托方式
};
struct DelClientEntrustWayOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct AddClientRestrictionInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string restriction;            //!< 特殊限制
};
struct AddClientRestrictionOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct DelClientRestrictionInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string restriction;            //!< 特殊限制
};
struct DelClientRestrictionOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct QryAcctSysNodeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string input_content;          //!< 输入的客户标志类别
    std::string account_content;        //!< 输入内容
    std::string content_type;           //!< 客户标识类型(银行号、市场类别)
};
struct QryAcctSysNodeOutput {
    std::string branch_no;              //!< 分支机构
    std::string sysnode_id;             //!< 系统节点编号（期货业务不支持）
};
struct QryClientBulletinInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资产账号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
};
struct QryClientBulletinOutput {
    std::string init_date;              //!< 发生日期
    std::string serial_no;              //!< 流水号
    std::string client_id;              //!< 客户号
    std::string valid_date;             //!< 有效日期
    std::string message_notes;          //!< 消息内容
    std::string send_times;             //!< 发送次数
    std::string criterion_prop;         //!< 客户公告待规范属性（自定义1090数据字典）
    std::string operator_no;            //!< 操作员编号
    std::string position_str;           //!< 定位串
};
struct SetProfitFlagInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string profit_flag;            //!< 盈亏计算方式
};
struct SetProfitFlagOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct AddAccountDataInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string account_data_char;      //!< 开户规范
};
struct AddAccountDataOutput {
    std::string serial_no;              //!< 流水序号
};
struct DelAccountDataInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string account_data_char;      //!< 开户规范
};
struct DelAccountDataOutput {
    std::string serial_no;              //!< 流水序号
};
struct QryClientInfoInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string query_mode;             //!< 查询模式
};
struct QryClientInfoOutput {
    std::string branch_no;              //!< 分支机构
    std::string client_name;            //!< 客户姓名
    std::string client_status;          //!< 客户状态(期货暂不支持)
    std::string fund_card;              //!< 资金卡号
    std::string id_kind;                //!< 证件类别
    std::string id_no;                  //!< 证件号码
    std::string id_address;             //!< 身份证地址
    std::string mobiletelephone;        //!< 手机号码
    std::string fax;                    //!< 传真号码
    std::string zipcode;                //!< 邮政编码
    std::string e_mail;                 //!< 电子信箱
    std::string open_date;              //!< 开户日期(期货暂不支持)
    std::string nationality;            //!< 国籍地区(期货暂不支持)
    std::string address;                //!< 联系地址
    std::string mail_name;              //!< 联系人
    std::string risk_info;              //!< 风险要素信息
    std::string account_data;           //!< 开户规范信息
    std::string organ_prop;             //!< 机构标志
    std::string organ_name;             //!< 机构名称
    std::string client_group;           //!< 客户分类
    std::string group_name;             //!< 组别名称
    std::string full_name;              //!< 账户全称
    std::string risk_name;              //!< 风险要素信息名称
    std::string account_data_name;      //!< 开户规范信息名称
    std::string phonecode;              //!< 联系电话
    std::string client_id;              //!< 客户编号(期货暂不支持)
    std::string fund_account;           //!< 资金账户(期货暂不支持)
    std::string client_rights;          //!< 客户权限(期货暂不支持)
    std::string corp_client_group;      //!< 公司客户类型(期货暂不支持)
    std::string corp_risk_level;        //!< 客户风险等级(期货暂不支持)
    std::string corp_begin_date;        //!< 客户风险测评日(期货暂不支持)
    std::string corp_end_date;          //!< 客户风险到期日(期货暂不支持)
    std::string aml_risk_level;         //!< 反洗钱风险等级(期货暂不支持)
    std::string paper_score;            //!< 试卷得分(期货暂不支持)
    std::string client_gender;          //!< 客户性别(期货暂不支持)
    std::string en_entrust_way;         //!< 允许委托方式　返回主资金账号委托方式(期货暂不支持)
    std::string invest_advice;          //!< 投资建议(账户20支持，UF20,期货暂时不支持)
    std::string id_begindate;           //!< 证件开始日期(账户20支持，UF20,期货暂时不支持)
    std::string id_enddate;             //!< 证件有效截止日期(账户20支持，UF20,期货暂时不支持)
    std::string profit_flag;            //!< 盈亏计算方式(账户20支持，UF20,期货暂时不支持)
};
struct QryClientRightInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
};
struct QryClientRightOutput {
    std::string branch_no;              //!< 分支机构
    std::string client_rights;          //!< 客户权限　参见动态数据字典-1021
};
struct QryClientRestrictionInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
};
struct QryClientRestrictionOutput {
    std::string branch_no;              //!< 分支机构
    std::string restriction;            //!< 特殊限制
    std::string restriction_name;       //!< 限止信息
};
struct QryFundAccountInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string fund_account;           //!< 资金账户
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryFundAccountOutput {
    std::string client_branch_no;       //!< 客户开户营业部
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string asset_type;             //!< 资产账号类别
    std::string main_flag;              //!< 主账标志
    std::string product_flag;           //!< 产品标志
    std::string asset_prop;             //!< 资产属性
    std::string sysnode_id;             //!< 系统节点编号
    std::string position_str;           //!< 定位串
};
struct QryClientTransAmtLmtInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string money_type;             //!< 币种类别
    std::string bank_no;                //!< 银行代码
};
struct QryClientTransAmtLmtOutput {
    std::string lower_limit_out;        //!< 转出金额下限
};
struct QryBankTransferInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string client_account;         //!< 存管资金账号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string bank_no;                //!< 银行代码(期货暂不支持)
    std::string entrust_no;             //!< 委托编号(期货暂不支持)
    std::string query_type;             //!< 查询类别（0：默认 1：对04银行余额查询特殊返回，中信做法）(期货暂不支持)
    std::string action_in;              //!< 操作确认(仅期货支持)
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryBankTransferOutput {
    std::string branch_no;              //!< 分支机构
    std::string fund_account;           //!< 资金账户
    std::string bank_no;                //!< 银行代码
    std::string bank_name;              //!< 银行名称
    std::string trans_name;             //!< 转换机名字
    std::string entrust_no;             //!< 委托编号
    std::string business_type;          //!< 业务类型（'1'-银行转存　'2'-银行转取　'3'-查证券余额　'4'-查银行余额　'5'-冲转帐存　'6'-冲转帐取　'7'-转帐开户　'8'-转帐销户　'Z'-银行资金冻结）
    std::string source_flag;            //!< 发起方
    std::string money_type;             //!< 币种类别
    std::string client_account;         //!< 存管资金账号
    std::string bank_account;           //!< 存管账号
    std::string occur_balance;          //!< 发生金额
    std::string clear_balance;          //!< 清算金额
    std::string entrust_time;           //!< 委托时间
    std::string entrust_status;         //!< 委托状态
    std::string error_no;               //!< 错误代码
    std::string cancel_info;            //!< 废单原因
    std::string bank_error_info;        //!< 银行错误信息
    std::string remark;                 //!< 备注
    std::string asset_prop;             //!< 资产属性
    std::string position_str;           //!< 定位串
};
struct QrySvrBankPreDrawJourInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password_type;          //!< 密码类别
    std::string password;               //!< 密码
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 资金账户
    std::string client_account;         //!< 存管资金账号
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string bank_no;                //!< 银行代码
    std::string bank_account;           //!< 银行账号
    std::string money_type;             //!< 币种
    std::string treat_status;           //!< 操作状态
    std::string end_date;               //!< 到期日期
    std::string serial_no;              //!< 流水序号
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QrySvrBankPreDrawJourOutput {
    std::string init_date;              //!< 发生日期
    std::string serial_no;              //!< 流水序号
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string client_account;         //!< 存管资金账户
    std::string money_type;             //!< 币种类别
    std::string curr_date;              //!< 发生日期
    std::string curr_time;              //!< 发生时间
    std::string op_branch_no;           //!< 操作分支机构
    std::string operator_no;            //!< 操作员编号
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string draw_type;              //!< 提成方式
    std::string bank_no;                //!< 银行代码
    std::string bank_account;           //!< 银行账号
    std::string precont_date;           //!< 预约日期
    std::string execute_date;           //!< 执行日期
    std::string valid_date;             //!< 限制有效日期
    std::string operator_code;          //!< 操作员代码
    std::string max_balance;            //!< 最大金额
    std::string treat_status;           //!< 操作状态
    std::string occur_balance;          //!< 发生金额
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串
};
struct QryFundJourInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string money_type;             //!< 币种类别
    std::string query_direction;        //!< 查询方向（期货暂不支持）
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryFundJourOutput {
    std::string business_date;          //!< 最后清算日期
    std::string serial_no;              //!< 流水序号
    std::string business_flag;          //!< 业务标志
    std::string business_name;          //!< 业务名称
    std::string occur_balance;          //!< 发生金额
    std::string post_balance;           //!< 后资金额
    std::string money_type;             //!< 币种类别
    std::string remark;                 //!< 备注
    std::string entrust_bs;             //!< 买卖方向
    std::string occur_amount;           //!< 发生数量
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string business_price;         //!< 成交价格
    std::string business_time;          //!< 成交时间（期货暂不支持）
    std::string asset_prop;             //!< 资产属性（期货暂不支持）
    std::string position_str;           //!< 定位串
    std::string bank_no;                //!< 银行代码（期货暂不支持）
};
struct FastQryClientFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string money_type;             //!< 币种类别
};
struct FastQryClientFundOutput {
    std::string money_type;             //!< 币种类别
    std::string current_balance;        //!< 当前余额
    std::string enable_balance;         //!< 可用资金
    std::string fetch_balance;          //!< 可取金额
    std::string frozen_balance;         //!< 冻结资金
    std::string unfrozen_balance;       //!< 解冻资金
    std::string fund_balance;           //!< 总资金余额（即当前金额 + 修正金额 + 回报买卖金额差值），和证券市值加在一起就是总资产
};
struct QryClientFundInfoInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string money_type;             //!< 币种类别
};
struct QryClientFundInfoOutput {
    std::string money_type;             //!< 币种类别
    std::string current_balance;        //!< 当前余额
    std::string begin_balance;          //!< 期初余额
    std::string enable_balance;         //!< 可用资金
    std::string foregift_balance;       //!< 禁取资金
    std::string mortgage_balance;       //!< 禁取资产
    std::string frozen_balance;         //!< 冻结资金
    std::string unfrozen_balance;       //!< 解冻资金
    std::string fetch_balance;          //!< 可取金额
    std::string fetch_balance_old;      //!< 可取金额
    std::string fetch_cash;             //!< 可取现金
    std::string entrust_buy_balance;    //!< 委托买入冻结金额
    std::string market_value;           //!< 证券市值
    std::string asset_balance;          //!< 资产值
    std::string interest;               //!< 待入账利息
    std::string integral_balance;       //!< 利息积数
    std::string fine_integral;          //!< 罚息积数
    std::string pre_interest;           //!< 预计利息
    std::string pre_fine;               //!< 预计罚息
    std::string pre_interest_tax;       //!< 资金管理用
    std::string correct_balance;        //!< 资产修正金额
    std::string fund_balance;           //!< 总资金余额
    std::string opfund_market_value;    //!< 基金市值
    std::string rate_kind;              //!< 利率类别
    std::string real_buy_balance;       //!< 回报买入金额
    std::string real_sell_balance;      //!< 回报卖出金额
};
struct StockBankTransactionInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 资金账号
    std::string client_account;         //!< 存管资金账号
    std::string money_type;             //!< 币种类别
    std::string bank_no;                //!< 银行代码
    std::string transfer_direction;     //!< 交易方向（1-银行转证券 2-证券转银行）
    std::string occur_balance;          //!< 发生金额
    std::string fund_password;          //!< 资金密码
    std::string bank_password;          //!< 银行密码
};
struct StockBankTransactionOutput {
    std::string serial_no;              //!< 委托编号
    std::string bktrans_status;         //!< 请求状态
};
struct QrySvrBankBkFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string user_token;             //!< 用户口令
    std::string op_entrust_way;         //!< 操作委托方式
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string client_account;         //!< 存管资金账号
    std::string bank_no;                //!< 银行代码
    std::string bank_account;           //!< 存管账号
    std::string money_type;             //!< 币种
};
struct QrySvrBankBkFundOutput {
    std::string client_account;         //!< 存管资金账号
    std::string main_flag;              //!< 主辅标识
    std::string bank_no;                //!< 银行代码
    std::string bank_name;              //!< 银行名称
    std::string bank_account;           //!< 存管账号
    std::string money_type;             //!< 币种类别
    std::string current_balance;        //!< 当前余额
    std::string fetch_balance;          //!< 可取金额
    std::string fund_balance;           //!< 总资金余额
};
struct QrySvrBankBkExchAccountInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string client_account;         //!< 存管资金账号
    std::string bank_no;                //!< 银行代码
    std::string money_type;             //!< 币种: 0-人民币、1-美元、2-港币
    std::string bank_account;           //!< 存管账号
};
struct QrySvrBankBkExchAccountOutput {
    std::string fund_account;           //!< 理财资金账号
    std::string branch_no;              //!< 分支机构
    std::string client_account;         //!< 存管资金账号
    std::string bank_no;                //!< 银行代码
    std::string money_type;             //!< 币种: 0-人民币、1-美元、2-港币
    std::string bank_account;           //!< 存管账号
    std::string bkaccount_status;       //!< 银行账户状态
    std::string square_flag;            //!< 存管标志：0-本地客户、2-三方存管
    std::string main_flag;              //!< 主账标志：0-非主账（辅账）、1-主账
    std::string holder_name;            //!< 账户姓名
    std::string foreign_flag;           //!< 境外标志
    std::string id_kind;                //!< 证件类别
    std::string id_no;                  //!< 证件号码
    std::string authorize_code;         //!< 授权码
    std::string upper_limit_out;        //!< 转出金额上限
    std::string lower_limit_out;        //!< 转出金额下限
    std::string upper_limit_in;         //!< 转进金额上限
    std::string lower_limit_in;         //!< 转进金额下限
    std::string control_model_no;       //!< 银行控制模板
    std::string bank_operator;          //!< 银行操作员
    std::string open_date;              //!< 开户日期
    std::string bkaccount_regflag;      //!< 存管指定标志：0-未指定、1-预指定、2-已指定
    std::string en_entrust_way;         //!< 允许委托方式
    std::string bkaccount_rights;       //!< 银行账户权限
    std::string bkaccount_restrict;     //!< 银行账户限制
    std::string book_account;           //!< 银行簿记账号
    std::string province_branch;        //!< 省级分行代码
    std::string city_branch;            //!< 地市级分行代码
    std::string county_branch;          //!< 县级分行代码
    std::string sub_branch;             //!< 储蓄所代码
    std::string client_group;           //!< 客户分类
    std::string room_code;              //!< 客户分组
    std::string remark;                 //!< 备注
};
struct QrySvrBankBkFundJourInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账户
    std::string client_account;         //!< 存管资金账号
    std::string bank_no;                //!< 银行代码
    std::string money_type;             //!< 币种
    std::string occur_balance;          //!< 发生金额
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QrySvrBankBkFundJourOutput {
    std::string init_date;              //!< 交易日期
    std::string serial_no;              //!< 流水序号
    std::string curr_date;              //!< 当前日期
    std::string curr_time;              //!< 当前时间
    std::string business_flag;          //!< 业务标志
    std::string aasexch_type;           //!< 交易类别
    std::string fund_account;           //!< 理财资金账户
    std::string client_account;         //!< 客户账号
    std::string branch_no;              //!< 分支机构
    std::string bank_no;                //!< 银行代码
    std::string money_type;             //!< 币种类别
    std::string bank_account;           //!< 银行账号
    std::string occur_balance;          //!< 发生金额
    std::string join_date;              //!< 关联日期
    std::string join_serial_no;         //!< 关联流水号
    std::string deal_flag;              //!< 处理标志
    std::string ent_init_date;          //!< 证券端发起交易日期
    std::string ent_serial_no;          //!< 证券端发起交易流水号
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串（长）
};
struct QrySvrBankBkBalanceInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 理财资金账户
    std::string client_account;         //!< 存管资金账号
    std::string money_type;             //!< 币种类别
    std::string bank_no;                //!< 银行代码
    std::string fund_password;          //!< 资金密码
    std::string bank_password;          //!< 银行密码
};
struct QrySvrBankBkBalanceOutput {
    std::string serial_no;              //!< 流水序号
    std::string occur_balance;          //!< 发生金额
    std::string bktrans_status;         //!< 请求状态
};
struct SvrBankBkExchAccountTransferInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_account_src;     //!< 转出存管资金账号
    std::string bank_no_src;            //!< 转出银行号
    std::string client_account_dest;    //!< 转入存管资金账号
    std::string bank_no_dest;           //!< 转入银行号
    std::string money_type;             //!< 币种
    std::string occur_balance;          //!< 发生金额
};
struct SvrBankBkExchAccountTransferOutput {
    std::string serial_no_src;          //!< 转出流水号
    std::string serial_no_dest;         //!< 转入流水号
};
struct SvrAasQryAasClientInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
};
struct SvrAasQryAasClientOutput {
    std::string client_name;            //!< 客户名称
    std::string nationality;            //!< 国籍地区
    std::string organ_flag;             //!< 客户类别：0-个人、1-机构、3-产品
    std::string cust_property;          //!< 客户性质：0-经纪、1-自营、2-资管、3-代销
    std::string norm_flag;              //!< "规范标识：0-规范、1-不合格"
    std::string id_kind;                //!< 证件类型
    std::string id_no;                  //!< 证件号码
    std::string id_begindate;           //!< 证件开始日期
    std::string id_enddate;             //!< 证件截止日期
    std::string original_organ;         //!< 原始机构（如：宏源证券、建行、工行）
    std::string original_branch;        //!< 原始机构网点（原始机构是宏源证券则填写值同开户机构网点）
    std::string branch_no;              //!< 开户机构网点（客户开户所在营业部代码）
    std::string first_open_date;        //!< 首次开户日期
    std::string open_date;              //!< 开户日期
    std::string cancel_date;            //!< 注销日期
    std::string client_status;          //!< "账户状态：0-正常、1-冻结、2-挂失、3-销户、4-未确定、G-内部休眠"
};
struct SvrAasQryAasFundAcctInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账号名称
    std::string main_fund_account;      //!< 理财资金主账号
    std::string asset_prop;             //!< 资产属性：0-普通客户、7-信用客户、9-期货客户
    std::string businsys_id;            //!< 业务系统编号：0-现金管理、1-场内集中交易
    std::string fund_trustee_prop;      //!< 托管属性：0-完全托管、1-镜像托管
};
struct SvrAasQryAasFundAcctOutput {
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账户名称
    std::string main_fund_account;      //!< 理财资金主账号
    std::string main_flag;              //!< 主副标志：0-非主账（从账）、1-主账
    std::string branch_no;              //!< 分支机构
    std::string asset_prop;             //!< 资产属性：0-普通客户、7-信用客户、9-期货客户
    std::string businsys_id;            //!< 业务系统编号：0-现金管理、1-场内集中交易
    std::string fund_trustee_prop;      //!< 托管属性：0-完全托管、1-镜像托管
    std::string fundacct_status;        //!< 理财资金账号状态
    std::string open_date;              //!< 开户日期
    std::string cancel_date;            //!< 注销日期
};
struct SvrAasQryAasTrustAcctInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string sdc_account;            //!< 登记注册账号
    std::string busin_account;          //!< 业务系统帐户
    std::string businsys_id;            //!< 业务系统编号：0-现金管理、1-场内集中交易
    std::string asset_prop;             //!< 资产属性：0-普通客户、7-信用客户、9-期货客户
    std::string agency_no;              //!< 销售机构代码
    std::string share_trustee_prop;     //!< 托管属性：0-完全托管、1-镜像托管
};
struct SvrAasQryAasTrustAcctOutput {
    std::string seat_no;                //!< 交易单元
    std::string aasexch_type;           //!< 市场类别
    std::string sdc_account;            //!< 登记注册账号
    std::string busin_account;          //!< 业务系统帐户
    std::string asset_prop;             //!< 资产属性：0-普通客户、7-信用客户、9-期货客户
    std::string businsys_id;            //!< 业务系统编号：0-现金管理、1-场内集中交易
    std::string share_trustee_prop;     //!< 托管属性：0-完全托管、1-镜像托管
    std::string agency_no;              //!< 销售机构代码
};
struct SvrAasAdjustAasFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string money_type;             //!< 币种
    std::string fund_account_src;       //!< 转出理财资金账号
    std::string fund_account_dest;      //!< 转入理财资金账号
    std::string adjust_balance;         //!< 调账金额
};
struct SvrAasAdjustAasFundOutput {
    std::string serial_no1;             //!< 转出流水序号
    std::string serial_no2;             //!< 转入流水序号
};
struct SvrAasQryAasFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string money_type;             //!< 币种
};
struct SvrAasQryAasFundOutput {
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账号名称
    std::string asset_prop;             //!< 资产属性
    std::string branch_no;              //!< 分支机构
    std::string money_type;             //!< 币种
    std::string current_balance;        //!< 余额
    std::string frozen_balance;         //!< 冻结金额
    std::string enable_balance;         //!< 可用金额
    std::string fetch_balance;          //!< 可取金额
    std::string uncome_balance;         //!< 待交收金额
};
struct SvrAasQryAasEnableFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string businsys_id;            //!< 业务系统编号
    std::string usable_date;            //!< 使用日期
    std::string fund_account;           //!< 理财资金账号
    std::string money_type;             //!< 币种
    std::string aasexch_type;           //!< 交易类别
    std::string business_flag;          //!< 业务标志
    std::string prod_code;              //!< 产品代码
};
struct SvrAasQryAasEnableFundOutput {
    std::string enable_balance;         //!< 可用金额
};
struct SvrAasQryAasFundRequestInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string businsys_id;            //!< 业务系统编号
    std::string en_business_flag;       //!< 包含的业务标志
    std::string deal_flag;              //!< 处理状态（0-未处理 1-处理成功 2-处理失败）
    std::string en_money_type;          //!< 币种类别
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct SvrAasQryAasFundRequestOutput {
    std::string init_date;              //!< 交易日期
    std::string serial_no;              //!< 流水序号
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账号名称
    std::string money_type;             //!< 币种类别
    std::string businsys_id;            //!< 业务系统编号
    std::string curr_date;              //!< 当前日期
    std::string curr_time;              //!< 当前时间
    std::string business_flag;          //!< 业务标志
    std::string occur_balance;          //!< 发生金额
    std::string deal_flag;              //!< 处理状态（0-未处理 1-处理成功 2-处理失败）
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串（长）
};
struct SvrAasQryAasFundJourInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string businsys_id;            //!< 业务系统编号
    std::string en_aas_change_type;     //!< 允许变动类别
    std::string en_business_flag;       //!< 包含的业务标志
    std::string en_money_type;          //!< 币种类别
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct SvrAasQryAasFundJourOutput {
    std::string init_date;              //!< 交易日期
    std::string serial_no;              //!< 流水序号
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账号名称
    std::string money_type;             //!< 币种类别
    std::string businsys_id;            //!< 业务系统编号
    std::string curr_date;              //!< 当前日期
    std::string curr_time;              //!< 当前时间
    std::string aas_change_type;        //!< 变动类别 0待交收 1可用 2冻结 3交收锁定
    std::string business_flag;          //!< 业务标志
    std::string occur_balance;          //!< 发生金额
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串（长）
};
struct SvrBankQryHistBkTransferInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string fund_account;           //!< 资产账户
    std::string client_account;         //!< 存管资金账号
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string bank_no;                //!< 银行代码
    std::string action_in;              //!< 操作确认(仅期货支持)
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
    std::string query_type;             //!< 查询类别（0：默认 1：对04银行余额查询特殊返回，中信做法）
};
struct SvrBankQryHistBkTransferOutput {
    std::string branch_no;              //!< 分支机构
    std::string fund_account;           //!< 理财资金账户
    std::string client_account;         //!< 存管资金账户
    std::string init_date;              //!< 发生日期
    std::string curr_date;              //!< 当前日期
    std::string entrust_time;           //!< 委托时间
    std::string trans_name;             //!< 银行业务类型（转换机名字）
    std::string bank_account;           //!< 银行账号
    std::string bank_no;                //!< 银行代码
    std::string bank_name;              //!< 银行名称
    std::string entrust_no;             //!< 委托编号
    std::string business_type;          //!< 业务类型
    std::string trans_type;             //!< 交易类型 （'1'-银行转存　'2'-银行转取　'3'-查证券余额　'4'-查银行余额　'5'-冲转帐存　'6'-冲转帐取　'7'-转帐开户　'8'-转帐销户　'Z'-银行资金冻结）
    std::string source_flag;            //!< 发起方
    std::string money_type;             //!< 币种类别
    std::string occur_balance;          //!< 发生金额
    std::string entrust_status;         //!< 委托状态
    std::string error_no;               //!< 错误代码
    std::string cancel_info;            //!< 废单原因
    std::string bank_error_info;        //!< 银行错误信息
    std::string position_str;           //!< 定位串
    std::string remark;                 //!< 备注
};
struct AasExtQryAasFundRequestInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string businsys_id;            //!< 业务系统编号
    std::string en_business_flag;       //!< 包含的业务标志
    std::string deal_flag;              //!< 处理状态（0-未处理 1-处理成功 2-处理失败）
    std::string en_money_type;          //!< 币种类别
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct AasExtQryAasFundRequestOutput {
    std::string init_date;              //!< 交易日期
    std::string serial_no;              //!< 流水序号
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账号名称
    std::string businsys_id;            //!< 业务系统编号
    std::string money_type;             //!< 币种类别
    std::string curr_date;              //!< 当前日期
    std::string curr_time;              //!< 当前时间
    std::string business_flag;          //!< 业务标志
    std::string occur_balance;          //!< 发生金额
    std::string deal_flag;              //!< 处理状态（0-未处理 1-处理成功 2-处理失败）
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串（长）
};
struct SvrAasQryHistAasFundJourInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账号
    std::string businsys_id;            //!< 业务系统编号
    std::string en_aas_change_type;     //!< 允许变动类别
    std::string en_business_flag;       //!< 包含的业务标志
    std::string en_money_type;          //!< 币种类别
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct SvrAasQryHistAasFundJourOutput {
    std::string init_date;              //!< 交易日期
    std::string serial_no;              //!< 流水序号
    std::string fund_account;           //!< 理财资金账号
    std::string account_name;           //!< 理财资金账号名称
    std::string money_type;             //!< 币种类别
    std::string businsys_id;            //!< 业务系统编号
    std::string curr_date;              //!< 当前日期
    std::string curr_time;              //!< 当前时间
    std::string aas_change_type;        //!< 变动类别 0待交收 1可用 2冻结 3交收锁定
    std::string surplus_days;           //!< 剩余天数
    std::string settle_time;            //!< 交收时点
    std::string deal_flag;              //!< 处理状态
    std::string business_flag;          //!< 业务标志
    std::string occur_balance;          //!< 发生金额
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串（长）
};
struct SvrBankQryHistBkFundJourInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string client_id;              //!< 客户号
    std::string fund_account;           //!< 理财资金账户
    std::string client_account;         //!< 存管资金账号
    std::string bank_no;                //!< 银行代码
    std::string money_type;             //!< 币种
    std::string occur_balance;          //!< 发生金额
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 结束日期
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct SvrBankQryHistBkFundJourOutput {
    std::string init_date;              //!< 交易日期
    std::string serial_no;              //!< 流水序号
    std::string curr_date;              //!< 当前日期
    std::string curr_time;              //!< 当前时间
    std::string business_flag;          //!< 业务标志
    std::string fund_account;           //!< 理财资金账户
    std::string client_account;         //!< 存管资金账户
    std::string branch_no;              //!< 分支机构
    std::string bank_no;                //!< 银行代码
    std::string money_type;             //!< 币种类别
    std::string bank_account;           //!< 银行账号
    std::string occur_balance;          //!< 发生金额
    std::string join_date;              //!< 关联日期
    std::string join_serial_no;         //!< 关联流水号
    std::string deal_flag;              //!< 处理标志
    std::string ent_init_date;          //!< 证券端发起交易日期
    std::string ent_serial_no;          //!< 证券端发起交易流水号
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串（长）
};
struct SecuQryPriceInput {
    std::string version;                //!< 版本号
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
};
struct SecuQryPriceOutput {
    std::string exchange_index;         //!< 交易指数
    std::string last_price;             //!< 最新价
    std::string open_price;             //!< 开盘价
    std::string close_price;            //!< 收盘价
    std::string high_price;             //!< 最高价
    std::string low_price;              //!< 最低价
    std::string business_balance;       //!< 成交金额
    std::string business_amount;        //!< 成交数量
    std::string buy_price1;             //!< 申买价一
    std::string buy_price2;             //!< 申买价二
    std::string buy_price3;             //!< 申买价三
    std::string buy_price4;             //!< 申买价四
    std::string buy_price5;             //!< 申买价五
    std::string sale_price1;            //!< 申卖价一
    std::string sale_price2;            //!< 申卖价二
    std::string sale_price3;            //!< 申卖价三
    std::string sale_price4;            //!< 申卖价四
    std::string sale_price5;            //!< 申卖价五
    std::string buy_amount1;            //!< 申买量一
    std::string buy_amount2;            //!< 申买量二
    std::string buy_amount3;            //!< 申买量三
    std::string buy_amount4;            //!< 申买量四
    std::string buy_amount5;            //!< 申买量五
    std::string sale_amount1;           //!< 申卖量一
    std::string sale_amount2;           //!< 申卖量二
    std::string sale_amount3;           //!< 申卖量三
    std::string sale_amount4;           //!< 申卖量四
    std::string sale_amount5;           //!< 申卖量五
    std::string stock_interest;         //!< 国债百元利息额，如果不是国债，则小于零
    std::string stock_name;             //!< 证券名称
};
struct SecuQrySzClosingPriceInput {
    std::string version;                //!< 版本号
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
};
struct SecuQrySzClosingPriceOutput {
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string closing_price;          //!< 收盘价
    std::string weightave_price;        //!< 加权平均价
};
struct StkCodeQryInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string query_type;             //!< 查询类型（0：默认，查询单个代码或重复代码；1：查询全部代码）
    std::string exchange_type;          //!< 交易类别
    std::string stock_type;             //!< 证券类别
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct StkCodeQryOutput {
    std::string internal_code;          //!< 证券内码
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string buy_unit;               //!< 买入单位
    std::string price_step;             //!< 最小价差(厘)
    std::string store_unit;             //!< 存放单位
    std::string up_price;               //!< 上限价
    std::string down_price;             //!< 下限价
    std::string stock_type;             //!< 证券类别
    std::string high_amount;            //!< 交易最高数量
    std::string low_amount;             //!< 交易最低数量
    std::string stock_real_back;        //!< 回报证券标志
    std::string fund_real_back;         //!< 回报资金标志
    std::string delist_flag;            //!< 退市整理标志 0-正常 1-退市整理股票
    std::string delist_date;            //!< 退市日期
    std::string trade_plat;             //!< 交易平台
    std::string position_str;           //!< 定位串
    std::string par_value;              //!< 证券面值
};
struct NewQryStkCodeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string stock_code;             //!< 证券代码
};
struct NewQryStkCodeOutput {
    std::string exchange_type;          //!< 交易类别
    std::string money_type;             //!< 币种类别
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string stock_type;             //!< 证券类别
    std::string buy_unit;               //!< 买入单位
    std::string price_step;             //!< 最小价差(厘)
    std::string store_unit;             //!< 存放单位
    std::string par_value;              //!< 证券面值
    std::string stkcode_status;         //!< 证券状态
    std::string up_price;               //!< 上限价
    std::string down_price;             //!< 下限价
    std::string high_amount;            //!< 交易最高数量
    std::string low_amount;             //!< 交易最低数量
    std::string collect_date;           //!< 申购日期
};
struct WarrantQryCodeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string exchange_type;          //!< 交易类别
    std::string warrant_code;           //!< 权证代码
    std::string entrust_amount;         //!< 委托数量
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct WarrantQryCodeOutput {
    std::string exchange_type;          //!< 交易类别
    std::string warrant_code;           //!< 权证代码
    std::string apply_code;             //!< 行权代码
    std::string source_code;            //!< 标的代码
    std::string stock_name;             //!< 证券名称
    std::string warrant_type;           //!< 权证类型（C认购权证 P认沽权证）
    std::string settle_style;           //!< 权证结算方式（C现金结算 S证券结算）
    std::string apply_style;            //!< 行权方式（A美式行权 B混合行权 E欧式行权）
    std::string encash_price;           //!< 现金结算价格
    std::string apply_price;            //!< 行权价格
    std::string apply_rate;             //!< 行权比例　上海3位、深圳4位精度
    std::string apply_begin_date;       //!< 行权开始日期
    std::string apply_end_date;         //!< 行权截至日期
    std::string source_amount;          //!< 标的数量
    std::string position_str;           //!< 定位串
};
struct DebitQryCodeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct DebitQryCodeOutput {
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string stock_type;             //!< 证券类别（9记账国债 U企业债 Y可转债 u公司债）
    std::string ratio;                  //!< 债券利率
    std::string stock_interest;         //!< 债券利息（百元利息）
    std::string position_str;           //!< 定位串
    std::string par_value;              //!< 证券面值
};
struct QryClientStkAcctInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string query_direction;        //!< 查询方向
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryClientStkAcctOutput {
    std::string position_str;           //!< 定位串
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string main_flag;              //!< 主账标志
    std::string holder_kind;            //!< 账户类别（0:普通账户 1:基金账户 2:法人账户 3:回购账户 4:机构账户 6:报价转让）
    std::string holder_status;          //!< 股东状态
    std::string holder_rights;          //!< 股东权限
    std::string register_str;           //!< 指定标志
    std::string seat_no;                //!< 席位编号
};
struct SetPriceCostInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号（将此股东帐号下的股票重置成本价）
    std::string stock_code;             //!< 证券代码
    std::string cost_price;             //!< 成本价，净成本价
    std::string income_balance;         //!< 盈亏金额，截止到今日，按上述成本，股民在该股票上的盈亏(实际买卖之后的盈亏,不包含浮动盈亏)
    std::string entrust_price;          //!< 委托价格: 截止到今日,考虑收益后摊薄的该股票的买入均价（暂不使用）
};
struct SetPriceCostOutput {
    std::string serial_no;              //!< 流水序号
};
struct AddStockRightInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string holder_rights;          //!< 股东权限（0:自动配股 1:自动配售 2:红利领取 3:市价委托 P:代理配售 D:代理配股 G:代理转配 H:代理转让 I:代理转转 K:代理申购 a:报价委托 f:质押回购 g:权证交易 j:创业板交易 n:ETF申赎 r:买断回购 ）
};
struct AddStockRightOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct DelStockRightInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string holder_rights;          //!< 股东权限（0:自动配股 1:自动配售 2:红利领取 3:市价委托 P:代理配售 D:代理配股 G:代理转配 H:代理转让 I:代理转转 K:代理申购 a:报价委托 f:质押回购 g:权证交易 j:创业板交易 n:ETF申赎 r:买断回购 ）
};
struct DelStockRightOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct SecuEnterCodeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string entrust_prop;           //!< 委托属性
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
};
struct SecuEnterCodeOutput {
    std::string branch_no;              //!< 分支机构
    std::string fund_account;           //!< 资金账户
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string stock_type;             //!< 证券类别
    std::string money_type;             //!< 币种类别
    std::string last_price;             //!< 最新价
    std::string up_price;               //!< 上限价
    std::string down_price;             //!< 下限价
    std::string cost_price;             //!< 成本价
    std::string high_amount;            //!< 交易最高数量
    std::string low_amount;             //!< 交易最低数量
    std::string hand_flag;              //!< 手标志，'0'--股   '1' -- 手
    std::string enable_amount;          //!< 可用数量
    std::string transmit_amount;        //!< 可转托管数量，质押式国债若输入的是出入库委托（证券代码），表示可出库标准券数量
    std::string enable_balance;         //!< 可用资金
    std::string stock_interest;         //!< 国债百元利息额，如果不是国债，则小于零；质押式国债若输入的是出入库委托（证券代码），表示质押比率
    std::string notice_no;              //!< 提示编号
    std::string notice_info;            //!< 提示信息
    std::string delist_flag;            //!< 退市标志
    std::string delist_date;            //!< 退市日期
    std::string par_value;              //!< 证券面值
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
    std::string wit_type;               //!< 发行方式（国债预发行）
};
struct SecuAffordableAmtInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_price;          //!< 委托价格
    std::string entrust_prop;           //!< 委托属性
    std::string bk_enable_balance;      //!< 银行可用金额
};
struct SecuAffordableAmtOutput {
    std::string enable_amount;          //!< 可用数量
    std::string store_unit;             //!< 存放单位
    std::string enable_buy_amount;      //!< 可买数量
    std::string high_amount;            //!< 交易最高数量
};
struct SecuEntrustInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_price;          //!< 委托价格
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_prop;           //!< 委托属性
    std::string batch_no;               //!< 委托批号
};
struct SecuEntrustOutput {
    std::string init_date;              //!< 交易日期，标示当日委托还是隔日委托
    std::string entrust_no;             //!< 委托编号
    std::string batch_no;               //!< 委托批号
    std::string report_no;              //!< 申报编号
    std::string seat_no;                //!< 席位号
    std::string entrust_time;           //!< 委接时间
};
struct SecuRegTradeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码（799999-指定交易　799998-撤销指定）
    std::string entrust_amount;         //!< 委托数量（1）
    std::string entrust_price;          //!< 委托价格（1.00）
    std::string entrust_bs;             //!< 买卖方向（1- 买入）
    std::string entrust_prop;           //!< 委托属性（6- 指定交易）
    std::string batch_no;               //!< 委托批号
};
struct SecuRegTradeOutput {
    std::string init_date;              //!< 交易日期，标示当日委托还是隔日委托
    std::string entrust_no;             //!< 委托编号
};
struct SecuEntrustWithdrawInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string batch_flag;             //!< 批量标志 '0'单笔 '1'批量
    std::string exchange_type;          //!< 交易类别
    std::string entrust_no;             //!< 委托编号（batch_flag-'0'，委托编号；batch_flag-'1'，委托批号（委托批号为0表示批量撤销客户指定市场所有订单））
};
struct SecuEntrustWithdrawOutput {
    std::string init_date;              //!< 交易日期，标示当日委托还是隔日委托
    std::string entrust_no;             //!< 委托编号
    std::string entrust_no_old;         //!< 原委托编号
    std::string report_no_old;          //!< 原申报编号
    std::string seat_no;                //!< 原委托席位号
    std::string exchange_type;          //!< 原委托交易类别
    std::string stock_account;          //!< 原委托证券账号
    std::string stock_code;             //!< 原委托证券代码
    std::string money_type;             //!< 原委托币种类型
    std::string entrust_status_old;     //!< 原委托委托状态
};
struct SecuFfareChargeInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string ffare0_times;           //!< 划卡次数
    std::string ffare1_times;           //!< 委托次数
    std::string ffare2_times;           //!< 撤单次数
    std::string ffare3_times;           //!< 超时次数
    std::string login_time;             //!< 登录时刻
};
struct SecuFfareChargeOutput {
    std::string error_no;               //!< 错误代码
    std::string error_info;             //!< 错误提示
};
struct SecuBatchEntrustBuyInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string entrust_bs;             //!< 买卖方向，必须填入’1’
    std::string exchange_type;          //!< 交易类别，必须输入确定的市场，不支持0或空格。
    std::string stock_code;             //!< 证券代码
    std::string entrust_price;          //!< 委托价格
    std::string entrust_style;          //!< 委托类型，0-多股东委托　2-单股东委托
    std::string ordinal_start;          //!< 起始股东序号（从第几个股东账号买起）
    std::string entrust_amount;         //!< 委托数量（entrust_style=0,每个股东账号上的数量；entrust_style=2，表示在单个股东账号上的每次委托数量）
    std::string stock_account;          //!< 证券账号（指定在此股东账号上进行单股东的多笔批量委托）
    std::string entrust_count;          //!< 生成委托数（选择在单个股东账号上进行批量买入的笔数）
    std::string enable_balance;         //!< 可用资金，总共动用的资金
};
struct SecuBatchEntrustBuyOutput {
    std::string init_date;              //!< 交易日期，标示当日委托还是隔日委托
    std::string entrust_amount;         //!< 委托数量（表示委托成功后返回成功数量）
    std::string entrust_count;          //!< 生成委托数，委托成功股数
    std::string entrust_no;             //!< 委托编号
};
struct SecuBatchEntrustSaleInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string entrust_bs;             //!< 买卖方向，必须填入’2’
    std::string exchange_type;          //!< 交易类别，必须输入确定的市场，不支持0或空格。
    std::string stock_code;             //!< 证券代码
    std::string entrust_price;          //!< 委托价格
    std::string entrust_style;          //!< 委托类型，0-多股东委托　2-单股东委托
    std::string ordinal_start;          //!< 起始股东序号（从第几个股东账号买起）
    std::string max_amount;             //!< 最大数量，限定了在任一股东帐号上最多卖出的股票数
    std::string stock_account;          //!< 证券账号（指定在此股东账号上进行单股东的多笔批量委托）
    std::string entrust_amount;         //!< 委托数量，总的卖出的数量
    std::string entrust_count;          //!< 最多生成委托笔数
};
struct SecuBatchEntrustSaleOutput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string entrust_bs;             //!< 买卖方向，必须填入’2’
    std::string exchange_type;          //!< 交易类别，必须输入确定的市场，不支持0或空格。
    std::string stock_code;             //!< 证券代码
    std::string entrust_price;          //!< 委托价格
    std::string entrust_style;          //!< 委托类型，0-多股东委托　2-单股东委托
    std::string ordinal_start;          //!< 起始股东序号（从第几个股东账号买起）
    std::string max_amount;             //!< 最大数量，限定了在任一股东帐号上最多卖出的股票数
    std::string stock_account;          //!< 证券账号（指定在此股东账号上进行单股东的多笔批量委托）
    std::string entrust_amount;         //!< 委托数量，总的卖出的数量
    std::string entrust_count;          //!< 最多生成委托笔数
};
struct SecuCalEntrustFareInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_price;          //!< 委托价格
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_prop;           //!< 委托属性
};
struct SecuCalEntrustFareOutput {
    std::string ffare_balance;          //!< 前台费用金额
    std::string bfare_balance;          //!< 后台费用金额
};
struct SecuIssueOFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_price;          //!< 委托价格
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_prop;           //!< 委托属性
    std::string batch_no;               //!< 委托批号
};
struct SecuIssueOFundOutput {
    std::string init_date;              //!< 交易日期，标示当日委托还是隔日委托
    std::string entrust_no;             //!< 委托编号
};
struct SecuQryWithdrawableEntrustInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password_type;          //!< 密码类别
    std::string password;               //!< 密码
    std::string user_token;             //!< 用户口令
    std::string entrust_no;             //!< 委托编号，如果该笔委托非fund_account和stock_account的委托，该笔将取不到
    std::string stock_account;          //!< 证券账号
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct SecuQryWithdrawableEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托编号
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string business_amount;        //!< 成交数量
    std::string business_price;         //!< 成交价格
    std::string report_no;              //!< 申请编号
    std::string report_time;            //!< 申报时间
    std::string entrust_type;           //!< 委托类别
    std::string entrust_status;         //!< 委托状态
    std::string entrust_time;           //!< 委托时间
    std::string entrust_date;           //!< 委托日期
    std::string entrust_prop;           //!< 委托属性
    std::string stock_name;             //!< 证券名称
    std::string cancel_info;            //!< 废单原因
    std::string position_str;           //!< 定位串
};
struct SecuQryEntrustInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string query_direction;        //!< 查询方向　'1'-正序　'0'-逆序
    std::string sort_direction;         //!< 返回排序方式 '0'-正常 '1'-倒序
    std::string report_no;              //!< 申请编号
    std::string action_in;              //!< 操作控制值，0-查询全部委托；1-查询可撤委托；2-按批号查询（通过locate_entrust_no送入）
    std::string locate_entrust_no;      //!< 指定编号，action_in：2-委托批号，非2-委托编号
    std::string query_type;             //!< 查询类别　'0'-全部；'1'-不查委托类型为撤单的委托
    std::string query_mode;             //!< 查询模式　0/空格-查明细，2-按交易类别、证券账号、证券代码、买卖类别汇总
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数，不送按50行处理
    std::string etf_flag;               //!< ETF标志: '0'-全部（默认）；'1'-不查ETF业务
};
struct SecuQryEntrustOutput {
    std::string init_date;              //!< 发生日期
    std::string fund_account;           //!< 资金账号（query_mode送'2'时返回' '）
    std::string batch_no;               //!< 委托批号（query_mode送'2'时返回0）
    std::string entrust_no;             //!< 委托编号（query_mode送'2'时返回0）
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string business_amount;        //!< 成交数量
    std::string business_price;         //!< 成交价格
    std::string report_no;              //!< 申请编号（query_mode送'2'时返回0）
    std::string report_time;            //!< 申报时间（query_mode送'2'时返回0）
    std::string entrust_type;           //!< 委托类别
    std::string entrust_status;         //!< 委托状态（query_mode送'2'时返回' '）
    std::string entrust_time;           //!< 委托时间（query_mode送'2'时返回0）
    std::string entrust_date;           //!< 委托日期（query_mode送'2'时返回0）
    std::string entrust_prop;           //!< 委托属性（query_mode送'2'时返回' '）
    std::string stock_name;             //!< 证券名称
    std::string cancel_info;            //!< 废单原因（query_mode送'2'时返回' '）
    std::string withdraw_amount;        //!< 撤单数量
    std::string position_str;           //!< 定位串
};
struct SecuQryRealtimeDealInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string serial_no;              //!< 流水序号（query_mode=4时，表示委托号）
    std::string query_direction;        //!< 查询方向　'1'-正序　'0'-逆序
    std::string report_no;              //!< 申请编号
    std::string query_mode;             //!< 查询模式，参见业务说明
    std::string query_type;             //!< 查询类别，查询成交类型，送'0'查全部，送'1'不查委托类型为撤单的成交，送'2'查询全部成交，包括废单成交，默认为空表示按后台3106开关规
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数，不送按50行处理
    std::string etf_flag;               //!< ETF标志: '0'-全部（默认）；'1'-不查ETF业务
};
struct SecuQryRealtimeDealOutput {
    std::string serial_no;              //!< 流水序号
    std::string date;                   //!< 日期
    std::string exchange_type;          //!< 交易类别
    std::string fund_account;           //!< 资金账户
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_bs;             //!< 买卖方向
    std::string business_price;         //!< 成交价格
    std::string business_amount;        //!< 成交数量
    std::string business_time;          //!< 成交时间
    std::string real_type;              //!< 成交类别 0：‘买卖’2：‘撤单’
    std::string real_status;            //!< 成交状态 0：‘成交’，2：‘废单’4：‘确认’
    std::string business_times;         //!< 分笔成交笔数
    std::string entrust_no;             //!< 委托编号
    std::string business_balance;       //!< 成交金额
    std::string stock_name;             //!< 证券名称
    std::string report_no;              //!< 申请编号
    std::string position_str;           //!< 定位串
    std::string entrust_prop;           //!< 委托属性
    std::string business_no;            //!< 成交编号
};
struct SecuFastQryPositionInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数（不能超过1000）
};
struct SecuFastQryPositionOutput {
    std::string fund_account;           //!< 资金账户
    std::string ffare_kind;             //!< 前台费用类型
    std::string bfare_kind;             //!< 后台费用类型
    std::string profit_flag;            //!< 盈亏计算方式
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_type;             //!< 证券类别
    std::string stock_name;             //!< 证券名称
    std::string hold_amount;            //!< 持有数量
    std::string current_amount;         //!< 当前数量
    std::string cost_price;             //!< 成本价
    std::string income_balance;         //!< 盈亏金额
    std::string hand_flag;              //!< 手标志
    std::string frozen_amount;          //!< 冻结数量
    std::string unfrozen_amount;        //!< 解冻数量
    std::string enable_amount;          //!< 可用数量
    std::string real_buy_amount;        //!< 今开仓买入持仓量
    std::string real_sell_amount;       //!< 今开仓卖出持仓量
    std::string uncome_buy_amount;      //!< 买入未交收持仓量
    std::string uncome_sell_amount;     //!< 卖出未交收持仓量
    std::string entrust_sell_amount;    //!< 今开仓委托卖出量
    std::string asset_price;            //!< 市值价
    std::string last_price;             //!< 最新价
    std::string market_value;           //!< 市值
    std::string position_str;           //!< 定位串
    std::string sum_buy_amount;         //!< 累计买入数量
    std::string sum_buy_balance;        //!< 累计买入金额
    std::string sum_sell_amount;        //!< 累计卖出数量
    std::string sum_sell_balance;       //!< 累计卖出数量
    std::string real_buy_balance;       //!< 回报买入金额
    std::string real_sell_balance;      //!< 回报卖出金额
    std::string delist_flag;            //!< 退市标志
    std::string delist_date;            //!< 退市日期
    std::string par_value;              //!< 证券面值
};
struct SecuQryPositionInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string query_mode;             //!< 查询模式，'0'-明细 '1'-汇总(营业部、交易类别和证券代码汇总证券信息)
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数（不能超过1000）
};
struct SecuQryPositionOutput {
    std::string fund_account;           //!< 资金账户（query_mode送入1时，返回' '）
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string stock_type;             //!< 证券类别
    std::string hold_amount;            //!< 持有数量
    std::string current_amount;         //!< 当前数量
    std::string enable_amount;          //!< 可用数量
    std::string real_buy_amount;        //!< 今开仓买入持仓量
    std::string real_sell_amount;       //!< 今开仓卖出持仓量
    std::string uncome_buy_amount;      //!< 买入未交收持仓量
    std::string uncome_sell_amount;     //!< 卖出未交收持仓量
    std::string entrust_sell_amount;    //!< 今开仓委托卖出量
    std::string last_price;             //!< 最新价
    std::string cost_price;             //!< 成本价
    std::string keep_cost_price;        //!< 保本价
    std::string income_balance;         //!< 盈亏金额
    std::string hand_flag;              //!< 手标志
    std::string market_value;           //!< 证券市值
    std::string av_buy_price;           //!< 买入均价
    std::string av_income_balance;      //!< 实现盈亏
    std::string cost_balance;           //!< 持仓成本（累积买+当日买-累积卖-当日卖）
    std::string position_str;           //!< 定位串
    std::string delist_flag;            //!< 退市标志
    std::string delist_date;            //!< 退市日期
    std::string par_value;              //!< 证券面值
};
struct SecuQryImpawnAmtInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct SecuQryImpawnAmtOutput {
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string store_amount;           //!< 交易所库存数量
    std::string pre_out_amount;         //!< 交易期间出库数量
    std::string pre_in_amount;          //!< 交易期间入库数量
    std::string exchange_name;          //!< 交易名称
    std::string stock_name;             //!< 证券名称
    std::string position_str;           //!< 定位串
};
struct SecuQryBatchEntrustInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_no;             //!< 委托编号（委托批号）
    std::string locate_entrust_no;      //!< 指定委托号
    std::string query_direction;        //!< 查询方向
    std::string request_num;            //!< 请求行数
};
struct SecuQryBatchEntrustOutput {
    std::string branch_no;              //!< 分支机构
    std::string batch_no;               //!< 委托批号
    std::string date;                   //!< 日期
    std::string entrust_no;             //!< 委托编号
    std::string report_no;              //!< 申请编号
    std::string fund_account;           //!< 资金账户
    std::string exchange_type;          //!< 交易类别
    std::string seat_no;                //!< 席位编号
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string money_type;             //!< 币种类别
    std::string entrust_way;            //!< 委托方式
    std::string entrust_type;           //!< 委托类别
    std::string entrust_prop;           //!< 委托属性
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_price;          //!< 委托价格
    std::string entrust_status;         //!< 委托状态
    std::string business_amount;        //!< 成交数量
    std::string business_balance;       //!< 成交金额
    std::string business_price;         //!< 成交价格
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string report_time;            //!< 申报时间
    std::string entrust_num;            //!< 读委托号笔数
    std::string position_str;           //!< 定位串
};
struct QryHistDeliverInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string deliver_type;           //!< 交割标志　'0'-打未交割　'1'-全部
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string money_type;             //!< 币种类别
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数，不送按50行处理
};
struct QryHistDeliverOutput {
    std::string init_date;              //!< 日期
    std::string entrust_date;           //!< 委托日期
    std::string business_flag;          //!< 业务标志
    std::string business_type;          //!< 业务类型
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string seat_no;                //!< 席位编号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string entrust_bs;             //!< 买卖方向
    std::string business_price;         //!< 成交价格
    std::string occur_amount;           //!< 发生数量
    std::string business_balance;       //!< 成交金额
    std::string occur_balance;          //!< 发生金额
    std::string post_balance;           //!< 后资金额
    std::string post_amount;            //!< 后证券额
    std::string entrust_no;             //!< 委托编号
    std::string business_no;            //!< 成交编号
    std::string report_time;            //!< 申报时间
    std::string business_time;          //!< 成交时间
    std::string business_name;          //!< 业务名称
    std::string fare0;                  //!< 佣金
    std::string fare1;                  //!< 印花税
    std::string fare2;                  //!< 过户费
    std::string fare3;                  //!< 费用3
    std::string farex;                  //!< 费用x
    std::string remark;                 //!< 备注
    std::string report_no;              //!< 申请编号
    std::string position_str;           //!< 定位串
};
struct QryHistMatchInfoInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string stock_account;          //!< 证券账号
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistMatchInfoOutput {
    std::string serial_no;              //!< 流水序号
    std::string occur_amount;           //!< 发生数量
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串
};
struct QryHistLuckyInfoInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string stock_account;          //!< 证券账号
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistLuckyInfoOutput {
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string business_price;         //!< 成交价格
    std::string occur_amount;           //!< 发生数量
    std::string init_date;              //!< 发生日期
    std::string position_str;           //!< 定位串
};
struct QryHistEntrustInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistEntrustOutput {
    std::string entrust_no;             //!< 委托编号
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string business_amount;        //!< 成交数量
    std::string business_price;         //!< 成交价格
    std::string report_no;              //!< 申请编号
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string report_time;            //!< 申报时间
    std::string entrust_type;           //!< 委托类别
    std::string entrust_status;         //!< 委托状态
    std::string error_no;               //!< 错误代码
    std::string position_str;           //!< 定位串
};
struct QryHistBusinessInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistBusinessOutput {
    std::string init_date;              //!< 发生日期
    std::string serial_no;              //!< 流水序号
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string entrust_bs;             //!< 买卖方向
    std::string business_price;         //!< 成交价格
    std::string business_time;          //!< 成交时间
    std::string business_status;        //!< 业务状态
    std::string business_times;         //!< 分笔成交笔数
    std::string entrust_no;             //!< 委托编号
    std::string report_no;              //!< 申请编号
    std::string occur_amount;           //!< 发生数量
    std::string post_balance;           //!< 后资金额
    std::string business_balance;       //!< 成交金额
    std::string occur_balance;          //!< 发生金额
    std::string post_amount;            //!< 后证券额
    std::string fare0;                  //!< 佣金
    std::string fare1;                  //!< 印花税
    std::string fare2;                  //!< 过户费
    std::string fare3;                  //!< 费用3
    std::string farex;                  //!< 费用x
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串
};
struct QryHistFundStockInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string money_type;             //!< 币种类别
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistFundStockOutput {
    std::string serial_no;              //!< 流水序号
    std::string business_date;          //!< 最后清算日期
    std::string business_flag;          //!< 业务标志
    std::string business_name;          //!< 业务名称
    std::string occur_balance;          //!< 发生金额
    std::string post_balance;           //!< 后资金额
    std::string money_type;             //!< 币种类别
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string entrust_bs;             //!< 买卖方向
    std::string business_price;         //!< 成交价格
    std::string occur_amount;           //!< 发生数量
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串
};
struct QryHistFundStockAllInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string branch_no;              //!< 分支机构
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string money_type;             //!< 币种类别
    std::string query_mode;             //!< 查询模式(参见业务说明)
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistFundStockAllOutput {
    std::string init_date;              //!< 发生日期
    std::string serial_no;              //!< 流水序号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string stock_account;          //!< 证券账号
    std::string business_balance;       //!< 成交金额
    std::string standard_fare0;         //!< 标准佣金
    std::string fare0;                  //!< 佣金
    std::string fare1;                  //!< 印花税
    std::string fare2;                  //!< 过户费
    std::string fare3;                  //!< 费用3
    std::string farex;                  //!< 费用x
    std::string business_flag;          //!< 业务标志
    std::string business_name;          //!< 业务名称
    std::string business_price;         //!< 成交价格
    std::string post_balance;           //!< 后资金额
    std::string exchange_type;          //!< 交易类别
    std::string occur_amount;           //!< 发生数量
    std::string occur_balance;          //!< 发生金额
    std::string money_type;             //!< 币种类别
    std::string bank_no;                //!< 银行代码
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_no;             //!< 委托编号
    std::string business_no;            //!< 成交编号
    std::string report_time;            //!< 申报时间
    std::string business_time;          //!< 成交时间
    std::string remark;                 //!< 备注
    std::string position_str;           //!< 定位串
};
struct QryHistLuckyMatchInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string begin_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string stock_account;          //!< 证券账号
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistLuckyMatchOutput {
    std::string init_date;              //!< 发生日期
    std::string exchange_type;          //!< 交易类别
    std::string stock_code;             //!< 证券代码
    std::string entrust_amount;         //!< 委托数量
    std::string business_amount;        //!< 成交数量
    std::string business_price;         //!< 成交价格
    std::string position_str;           //!< 定位串
};
struct QryHistStatementInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string begin_date;             //!< 开始日期
    std::string end_date;               //!< 到期日期
    std::string fund_account;           //!< 资金账户
    std::string money_type;             //!< 币种类别
    std::string query_mode;             //!< 查询模式（1-时间段内每日汇总；2-时间段内汇总）
    std::string position_str_long;      //!< 定位串
    std::string request_num;            //!< 请求行数
};
struct QryHistStatementOutput {
    std::string init_date;              //!< 发生日期
    std::string business_flag;          //!< 业务标志
    std::string business_type;          //!< 业务类型
    std::string business_name;          //!< 业务名称
    std::string fund_account;           //!< 资金账户
    std::string bank_no;                //!< 银行代码
    std::string bank_name;              //!< 银行名称
    std::string money_type;             //!< 币种类别
    std::string business_balance;       //!< 成交金额
    std::string clear_balance;          //!< 清算金额
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string business_amount;        //!< 成交价格
    std::string standard_fare0;         //!< 定位串
    std::string fare0;                  //!< 发生日期
    std::string fare1;                  //!< 交易类别
    std::string fare2;                  //!< 证券代码
    std::string fare3;                  //!< 委托数量
    std::string farex;                  //!< 成交数量
    std::string exchange_fare;          //!< 成交价格
    std::string exchange_fare0;         //!< 定位串
    std::string exchange_fare1;         //!< 发生日期
    std::string exchange_fare2;         //!< 交易类别
    std::string exchange_fare3;         //!< 证券代码
    std::string exchange_fare4;         //!< 委托数量
    std::string exchange_fare5;         //!< 成交数量
    std::string exchange_fare6;         //!< 成交价格
    std::string exchange_farex;         //!< 定位串
    std::string position_str_long;      //!< 定位串
};
struct SecuIssueEtfInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_price;          //!< 委托价格
    std::string entrust_bs;             //!< 买卖方向
    std::string entrust_prop;           //!< 委托属性
    std::string batch_no;               //!< 委托批号
};
struct SecuIssueEtfOutput {
    std::string init_date;              //!< 交易日期，标示当日委托还是隔日委托
    std::string entrust_no;             //!< 委托编号
};
struct SecuFastQryFundInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string money_type;             //!< 币种类别
};
struct SecuFastQryFundOutput {
    std::string money_type;             //!< 币种类别
    std::string current_balance;        //!< 当前余额
    std::string enable_balance;         //!< 可用资金
    std::string fetch_balance;          //!< 可取金额
    std::string frozen_balance;         //!< 冻结资金
    std::string unfrozen_balance;       //!< 解冻资金
    std::string fund_balance;           //!< 总资金余额（即当前金额 + 修正金额 + 回报买卖金额差值），和证券市值加在一起就是总资产
};
struct SecuFastQryStockInput {
    std::string op_branch_no;           //!< 操作分支机构
    std::string op_entrust_way;         //!< 委托方式
    std::string op_station;             //!< 站点地址
    std::string branch_no;              //!< 分支机构
    std::string client_id;              //!< 客户编号
    std::string fund_account;           //!< 资金账户
    std::string password;               //!< 密码
    std::string password_type;          //!< 密码类别
    std::string user_token;             //!< 用户口令
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求行数（不能超过1000）
};
struct SecuFastQryStockOutput {
    std::string fund_account;           //!< 资金账户
    std::string ffare_kind;             //!< 前台费用类型
    std::string bfare_kind;             //!< 后台费用类型
    std::string profit_flag;            //!< 盈亏计算方式
    std::string exchange_type;          //!< 交易类别
    std::string stock_account;          //!< 证券账号
    std::string stock_code;             //!< 证券代码
    std::string stock_type;             //!< 证券类别
    std::string stock_name;             //!< 证券名称
    std::string hold_amount;            //!< 持有数量
    std::string current_amount;         //!< 当前数量
    std::string cost_price;             //!< 成本价
    std::string income_balance;         //!< 盈亏金额
    std::string hand_flag;              //!< 手标志
    std::string frozen_amount;          //!< 冻结数量
    std::string unfrozen_amount;        //!< 解冻数量
    std::string enable_amount;          //!< 可用数量
    std::string real_buy_amount;        //!< 今开仓买入持仓量
    std::string real_sell_amount;       //!< 今开仓卖出持仓量
    std::string uncome_buy_amount;      //!< 买入未交收持仓量
    std::string uncome_sell_amount;     //!< 卖出未交收持仓量
    std::string entrust_sell_amount;    //!< 今开仓委托卖出量
    std::string asset_price;            //!< 市值价
    std::string last_price;             //!< 最新价
    std::string market_value;           //!< 市值
    std::string position_str;           //!< 定位串
    std::string price_step;             //!< 最小价差(厘)
    std::string sum_buy_amount;         //!< 累计买入数量
    std::string sum_buy_balance;        //!< 累计买入金额
    std::string sum_sell_amount;        //!< 累计卖出数量
    std::string sum_sell_balance;       //!< 累计卖出数量
    std::string real_buy_balance;       //!< 回报买入金额
    std::string real_sell_balance;      //!< 回报卖出金额
    std::string delist_flag;            //!< 退市标志
    std::string delist_date;            //!< 退市日期
};
struct ClientFundAllQryExInput{
    std::string op_branch_no;
    std::string op_entrust_way;
    std::string op_station;
    std::string branch_no;
    std::string client_id;
    std::string fund_account;
    std::string password;
    std::string password_type;
    std::string user_token;
    std::string asset_prop;
    std::string money_type;
};
struct ClientFundAllQryExOutput{
    std::string current_balance;
    std::string enable_balance;
    std::string frozen_balance;
    std::string unfrozen_balance;
    std::string real_buy_balance;
    std::string real_sell_balance;
};

class UfxApiWrapper
{
public:
    explicit UfxApiWrapper();
    explicit UfxApiWrapper(const UfxConfig& config);
    virtual ~UfxApiWrapper();

    ////////////////////////////////////////////////////////////////////////////
    /// 初始化，配置选项和网络连接
    ////////////////////////////////////////////////////////////////////////////

    bool connect();

    static void sleepFor(int s);

    /*! \brief 初始化或重初始化lpconfig，在主线程读完配置文件后执行一次，不能在其他线程使用 */
    bool initialize();

    bool isConnected() const;

    static bool resetConnection(CConnectionInterface** connection,
                                CCallbackInterface *callback = NULL);

    static bool closeConnection(CConnectionInterface* connection);

    void disconnect();
    void setConfig(const UfxConfig& config);
    const UfxConfig& config() const;

    static Intf_RetType onRecvCommonError(int result, IF2UnPacker *unPacker);

    static void safeAssign(std::string& target, const char* source);

    static std::string op_station(const std::string& wip,
                                  const std::string& clientIp,
                                  const std::string& mac,
                                  const std::string& disksn,
                                  const std::string& cpuid);

    ///--------------------------------------------------------------------------------------------------------
    /// UFX API // 业务范围：公用
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType ufxQryCityCode(const QryCityCodeInput& input, std::list<QryCityCodeOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryBranch(const QryBranchInput& input, std::list<QryBranchOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryNextTradeDate(const QryNextTradeDateInput& input, std::list<QryNextTradeDateOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryUfxAccessStation(const QryUfxAccessStationInput& input, std::list<QryUfxAccessStationOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// UFX API // 业务范围：账户
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType ufxClientLogin(const ClientLoginInput& input, std::list<ClientLoginOutput>& output, std::string& errMsg);
    Intf_RetType ufxAddClientRight(const AddClientRightInput& input, std::list<AddClientRightOutput>& output, std::string& errMsg);
    Intf_RetType ufxDelClientRight(const DelClientRightInput& input, std::list<DelClientRightOutput>& output, std::string& errMsg);
    Intf_RetType ufxAddClientEntrustWay(const AddClientEntrustWayInput& input, std::list<AddClientEntrustWayOutput>& output, std::string& errMsg);
    Intf_RetType ufxDelClientEntrustWay(const DelClientEntrustWayInput& input, std::list<DelClientEntrustWayOutput>& output, std::string& errMsg);
    Intf_RetType ufxAddClientRestriction(const AddClientRestrictionInput& input, std::list<AddClientRestrictionOutput>& output, std::string& errMsg);
    Intf_RetType ufxDelClientRestriction(const DelClientRestrictionInput& input, std::list<DelClientRestrictionOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryAcctSysNode(const QryAcctSysNodeInput& input, std::list<QryAcctSysNodeOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientBulletin(const QryClientBulletinInput& input, std::list<QryClientBulletinOutput>& output, std::string& errMsg);
    Intf_RetType ufxSetProfitFlag(const SetProfitFlagInput& input, std::list<SetProfitFlagOutput>& output, std::string& errMsg);
    Intf_RetType ufxAddAccountData(const AddAccountDataInput& input, std::list<AddAccountDataOutput>& output, std::string& errMsg);
    Intf_RetType ufxDelAccountData(const DelAccountDataInput& input, std::list<DelAccountDataOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientInfo(const QryClientInfoInput& input, std::list<QryClientInfoOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientRight(const QryClientRightInput& input, std::list<QryClientRightOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientRestriction(const QryClientRestrictionInput& input, std::list<QryClientRestrictionOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryFundAccount(const QryFundAccountInput& input, std::list<QryFundAccountOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientTransAmtLmt(const QryClientTransAmtLmtInput& input, std::list<QryClientTransAmtLmtOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// UFX API // 业务范围：存管
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType ufxQryBankTransfer(const QryBankTransferInput& input, std::list<QryBankTransferOutput>& output, std::string& errMsg);
    Intf_RetType ufxQrySvrBankPreDrawJour(const QrySvrBankPreDrawJourInput& input, std::list<QrySvrBankPreDrawJourOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryFundJour(const QryFundJourInput& input, std::list<QryFundJourOutput>& output, std::string& errMsg);
    Intf_RetType ufxFastQryClientFund(const FastQryClientFundInput& input, std::list<FastQryClientFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientFundInfo(const QryClientFundInfoInput& input, std::list<QryClientFundInfoOutput>& output, std::string& errMsg);
    Intf_RetType ufxStockBankTransaction(const StockBankTransactionInput& input, std::list<StockBankTransactionOutput>& output, std::string& errMsg);
    Intf_RetType ufxQrySvrBankBkFund(const QrySvrBankBkFundInput& input, std::list<QrySvrBankBkFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxQrySvrBankBkExchAccount(const QrySvrBankBkExchAccountInput& input, std::list<QrySvrBankBkExchAccountOutput>& output, std::string& errMsg);
    Intf_RetType ufxQrySvrBankBkFundJour(const QrySvrBankBkFundJourInput& input, std::list<QrySvrBankBkFundJourOutput>& output, std::string& errMsg);
    Intf_RetType ufxQrySvrBankBkBalance(const QrySvrBankBkBalanceInput& input, std::list<QrySvrBankBkBalanceOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrBankBkExchAccountTransfer(const SvrBankBkExchAccountTransferInput& input, std::list<SvrBankBkExchAccountTransferOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasClient(const SvrAasQryAasClientInput& input, std::list<SvrAasQryAasClientOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasFundAcct(const SvrAasQryAasFundAcctInput& input, std::list<SvrAasQryAasFundAcctOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasTrustAcct(const SvrAasQryAasTrustAcctInput& input, std::list<SvrAasQryAasTrustAcctOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasAdjustAasFund(const SvrAasAdjustAasFundInput& input, std::list<SvrAasAdjustAasFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasFund(const SvrAasQryAasFundInput& input, std::list<SvrAasQryAasFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasEnableFund(const SvrAasQryAasEnableFundInput& input, std::list<SvrAasQryAasEnableFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasFundRequest(const SvrAasQryAasFundRequestInput& input, std::list<SvrAasQryAasFundRequestOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryAasFundJour(const SvrAasQryAasFundJourInput& input, std::list<SvrAasQryAasFundJourOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrBankQryHistBkTransfer(const SvrBankQryHistBkTransferInput& input, std::list<SvrBankQryHistBkTransferOutput>& output, std::string& errMsg);
    Intf_RetType ufxAasExtQryAasFundRequest(const AasExtQryAasFundRequestInput& input, std::list<AasExtQryAasFundRequestOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrAasQryHistAasFundJour(const SvrAasQryHistAasFundJourInput& input, std::list<SvrAasQryHistAasFundJourOutput>& output, std::string& errMsg);
    Intf_RetType ufxSvrBankQryHistBkFundJour(const SvrBankQryHistBkFundJourInput& input, std::list<SvrBankQryHistBkFundJourOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// UFX API // 业务范围：证券
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType ufxSecuQryPrice(const SecuQryPriceInput& input, std::list<SecuQryPriceOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQrySzClosingPrice(const SecuQrySzClosingPriceInput& input, std::list<SecuQrySzClosingPriceOutput>& output, std::string& errMsg);
    Intf_RetType ufxStkCodeQry(const StkCodeQryInput& input, std::list<StkCodeQryOutput>& output, std::string& errMsg);
    Intf_RetType ufxNewQryStkCode(const NewQryStkCodeInput& input, std::list<NewQryStkCodeOutput>& output, std::string& errMsg);
    Intf_RetType ufxWarrantQryCode(const WarrantQryCodeInput& input, std::list<WarrantQryCodeOutput>& output, std::string& errMsg);
    Intf_RetType ufxDebitQryCode(const DebitQryCodeInput& input, std::list<DebitQryCodeOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryClientStkAcct(const QryClientStkAcctInput& input, std::list<QryClientStkAcctOutput>& output, std::string& errMsg);
    Intf_RetType ufxSetPriceCost(const SetPriceCostInput& input, std::list<SetPriceCostOutput>& output, std::string& errMsg);
    Intf_RetType ufxAddStockRight(const AddStockRightInput& input, std::list<AddStockRightOutput>& output, std::string& errMsg);
    Intf_RetType ufxDelStockRight(const DelStockRightInput& input, std::list<DelStockRightOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuEnterCode(const SecuEnterCodeInput& input, std::list<SecuEnterCodeOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuAffordableAmt(const SecuAffordableAmtInput& input, std::list<SecuAffordableAmtOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuEntrust(const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuRegTrade(const SecuRegTradeInput& input, std::list<SecuRegTradeOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuEntrustWithdraw(const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuFfareCharge(const SecuFfareChargeInput& input, std::list<SecuFfareChargeOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuBatchEntrustBuy(const SecuBatchEntrustBuyInput& input, std::list<SecuBatchEntrustBuyOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuBatchEntrustSale(const SecuBatchEntrustSaleInput& input, std::list<SecuBatchEntrustSaleOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuCalEntrustFare(const SecuCalEntrustFareInput& input, std::list<SecuCalEntrustFareOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuIssueOFund(const SecuIssueOFundInput& input, std::list<SecuIssueOFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQryWithdrawableEntrust(const SecuQryWithdrawableEntrustInput& input, std::list<SecuQryWithdrawableEntrustOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQryEntrust(const SecuQryEntrustInput& input, std::list<SecuQryEntrustOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQryRealtimeDeal(const SecuQryRealtimeDealInput& input, std::list<SecuQryRealtimeDealOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuFastQryPosition(const SecuFastQryPositionInput& input, std::list<SecuFastQryPositionOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQryPosition(const SecuQryPositionInput& input, std::list<SecuQryPositionOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQryImpawnAmt(const SecuQryImpawnAmtInput& input, std::list<SecuQryImpawnAmtOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuQryBatchEntrust(const SecuQryBatchEntrustInput& input, std::list<SecuQryBatchEntrustOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistDeliver(const QryHistDeliverInput& input, std::list<QryHistDeliverOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistMatchInfo(const QryHistMatchInfoInput& input, std::list<QryHistMatchInfoOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistLuckyInfo(const QryHistLuckyInfoInput& input, std::list<QryHistLuckyInfoOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistEntrust(const QryHistEntrustInput& input, std::list<QryHistEntrustOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistBusiness(const QryHistBusinessInput& input, std::list<QryHistBusinessOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistFundStock(const QryHistFundStockInput& input, std::list<QryHistFundStockOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistFundStockAll(const QryHistFundStockAllInput& input, std::list<QryHistFundStockAllOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistLuckyMatch(const QryHistLuckyMatchInput& input, std::list<QryHistLuckyMatchOutput>& output, std::string& errMsg);
    Intf_RetType ufxQryHistStatement(const QryHistStatementInput& input, std::list<QryHistStatementOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// UFX API // 业务范围：ETF业务
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType ufxSecuIssueEtf(const SecuIssueEtfInput& input, std::list<SecuIssueEtfOutput>& output, std::string& errMsg);
    Intf_RetType ufxClientFundAllQryEx(const ClientFundAllQryExInput& input, std::list<ClientFundAllQryExOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// UFX API // 业务范围：极速交易
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType ufxSecuFastQryFund(const SecuFastQryFundInput& input, std::list<SecuFastQryFundOutput>& output, std::string& errMsg);
    Intf_RetType ufxSecuFastQryStock(const SecuFastQryStockInput& input, std::list<SecuFastQryStockOutput>& output, std::string& errMsg);

private:
    CConnectionInterface *mConnection = NULL;
    bool mConnected = false;
    UfxConfig mConfig;

    //! ufx配置文件接口
    static CConfigInterface* lpConfig;

    static std::mutex mInitMutex;
};

#endif // UFXAPIWRAPPER_H
