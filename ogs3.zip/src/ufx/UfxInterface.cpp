#include "UfxInterface.h"
#include "UfxLogger.h"

using namespace std;

namespace ogs {

UfxInterface::UfxInterface()
{
    ufxInfo << "创建了一个UFX接口对象";
}

UfxInterface::~UfxInterface()
{

}

bool UfxInterface::getConnectStatus()
{
    return ufxImpl.isConnected();
}

Intf_RetType UfxInterface::initCommon()
{
    static int counter = 1;

    if(ufxImpl.initialize()){
        ufxInfo << "初始化[" << counter << "]:成功";
        counter++;
        return kIntfSuccess;
    }
    ufxInfo << "初始化失败";
    return kIntfFail;
}

Intf_RetType UfxInterface::initSubscribe()
{
    ufxInfo << "初始化订阅功能";
    return kIntfFail;
}

Intf_RetType UfxInterface::connectBroker()
{
    if(ufxImpl.connect()){
        ufxInfo << "已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType UfxInterface::reConnectBroker()
{
    if(ufxImpl.isConnected()){
        ufxImpl.disconnect();
    }
    return connectBroker();
}

Intf_RetType UfxInterface::heartBeatToBroker()
{
    ufxInfo << "heartBeatToBroker";
    return ufxImpl.heartBeatToBroker();
}

void UfxInterface::setCallBack(int (*fn)(QueryOrderAns))
{
    ufxImpl.setCallBack(fn);
}

Intf_RetType UfxInterface::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsLogin(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsSendOrder(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsCancelOrder(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsQueryOrder(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsQueryPosition(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsQueryBargain(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsQueryFundInfo(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsPaybackSecurity(in, out, errMsg, args);
}

Intf_RetType UfxInterface::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return ufxImpl.ogsPaybackFunds(in, out, errMsg, args);
}

}
