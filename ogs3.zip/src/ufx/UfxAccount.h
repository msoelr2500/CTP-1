///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef UFXACCOUNT_H
#define UFXACCOUNT_H

#include "../AccountManager.h"

class UfxTradeAccount : public TradeAccount
{
public:
    std::string exchange_type;
    std::string seat_no;
};

struct UfxFundAccountData {
    std::string asset_type;
    std::string asset_prop;
    std::string sysnode_id;
};

class UfxFundAccount : public FundAccount<UfxTradeAccount>
{
public:
    UfxFundAccountData mData;
};

struct UfxClientData {
    std::string branch_no;
    std::string op_branch_no;
    std::string op_entrust_way;
    std::string op_station;
    std::string user_token;
    std::string password_type;
};

class UfxClient : public Client<UfxFundAccount>
{
public:
    UfxClientData mData;
};

class UfxClientManager : public ClientManager<UfxClient>
{
public:
    UfxClientData clientData(const std::string client_id) {
        lock_data(this);
        int index = findClientById(client_id);
        if (index < 0) {
            return UfxClientData();
        }
        return this->at(index).mData;
    }
};

#endif // UFXACCOUNT_H
