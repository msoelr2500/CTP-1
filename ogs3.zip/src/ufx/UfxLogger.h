///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef UFXLOGGER_H
#define UFXLOGGER_H

#include "UfxGlobal.h"
#include "../OgsLogger.h"
#include "UfxApiWrapper.h"
#include <iostream>

#define ufxLogger ogsLogger
#define ufxDebug ogsDebug << "["<< INTERFACE_NAME << "] "
#define ufxInfo ogsInfo << "["<< INTERFACE_NAME << "] "
#define ufxError ogsError << "["<< INTERFACE_NAME << "] "
#define ufxWarn ogsWarn << "["<< INTERFACE_NAME << "] "
#define ufxCout std::cout << "[" << INTERFACE_NAME << "] "

OgsLogger& operator << (OgsLogger& logger, const QryCityCodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryCityCodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryBranchInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryBranchOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryNextTradeDateInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryNextTradeDateOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryUfxAccessStationInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryUfxAccessStationOutput& data);
OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data);
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AddClientRightInput& data);
OgsLogger& operator << (OgsLogger& logger, const AddClientRightOutput& data);
OgsLogger& operator << (OgsLogger& logger, const DelClientRightInput& data);
OgsLogger& operator << (OgsLogger& logger, const DelClientRightOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AddClientEntrustWayInput& data);
OgsLogger& operator << (OgsLogger& logger, const AddClientEntrustWayOutput& data);
OgsLogger& operator << (OgsLogger& logger, const DelClientEntrustWayInput& data);
OgsLogger& operator << (OgsLogger& logger, const DelClientEntrustWayOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AddClientRestrictionInput& data);
OgsLogger& operator << (OgsLogger& logger, const AddClientRestrictionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const DelClientRestrictionInput& data);
OgsLogger& operator << (OgsLogger& logger, const DelClientRestrictionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryAcctSysNodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryAcctSysNodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientBulletinInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientBulletinOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SetProfitFlagInput& data);
OgsLogger& operator << (OgsLogger& logger, const SetProfitFlagOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AddAccountDataInput& data);
OgsLogger& operator << (OgsLogger& logger, const AddAccountDataOutput& data);
OgsLogger& operator << (OgsLogger& logger, const DelAccountDataInput& data);
OgsLogger& operator << (OgsLogger& logger, const DelAccountDataOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRightInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRightOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRestrictionInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientRestrictionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryFundAccountInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryFundAccountOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientTransAmtLmtInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientTransAmtLmtOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryBankTransferInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryBankTransferOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankPreDrawJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankPreDrawJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryFundJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryFundJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FastQryClientFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const FastQryClientFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFundInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientFundInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StockBankTransactionInput& data);
OgsLogger& operator << (OgsLogger& logger, const StockBankTransactionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkExchAccountInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkExchAccountOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkFundJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkBalanceInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySvrBankBkBalanceOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrBankBkExchAccountTransferInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrBankBkExchAccountTransferOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasClientInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasClientOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundAcctInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundAcctOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasTrustAcctInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasTrustAcctOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasAdjustAasFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasAdjustAasFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasEnableFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasEnableFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundRequestInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundRequestOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryAasFundJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkTransferInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkTransferOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AasExtQryAasFundRequestInput& data);
OgsLogger& operator << (OgsLogger& logger, const AasExtQryAasFundRequestOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryHistAasFundJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrAasQryHistAasFundJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkFundJourInput& data);
OgsLogger& operator << (OgsLogger& logger, const SvrBankQryHistBkFundJourOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryPriceInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryPriceOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQrySzClosingPriceInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQrySzClosingPriceOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkCodeQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkCodeQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const NewQryStkCodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const NewQryStkCodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const WarrantQryCodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const WarrantQryCodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const DebitQryCodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const DebitQryCodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientStkAcctOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SetPriceCostInput& data);
OgsLogger& operator << (OgsLogger& logger, const SetPriceCostOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AddStockRightInput& data);
OgsLogger& operator << (OgsLogger& logger, const AddStockRightOutput& data);
OgsLogger& operator << (OgsLogger& logger, const DelStockRightInput& data);
OgsLogger& operator << (OgsLogger& logger, const DelStockRightOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEnterCodeInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEnterCodeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuAffordableAmtInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuAffordableAmtOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRegTradeInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRegTradeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFfareChargeInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFfareChargeOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustBuyInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustBuyOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustSaleInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuBatchEntrustSaleOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuCalEntrustFareInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuCalEntrustFareOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuIssueOFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuIssueOFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryWithdrawableEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryWithdrawableEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryRealtimeDealInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryRealtimeDealOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryPositionInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryPositionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryPositionInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryPositionOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryImpawnAmtInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryImpawnAmtOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryBatchEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuQryBatchEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistDeliverInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistDeliverOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistMatchInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistMatchInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyInfoInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistBusinessInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistBusinessOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockAllInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistFundStockAllOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyMatchInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistLuckyMatchOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistStatementInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryHistStatementOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuIssueEtfInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuIssueEtfOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryFundInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryFundOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryStockInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuFastQryStockOutput& data);

#endif
