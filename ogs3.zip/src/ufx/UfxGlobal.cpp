#include "UfxGlobal.h"
#include "UfxInterface.h"

namespace ogs {

#ifdef __cplusplus
extern "C"
{
#endif

    DEFINE_VERSION(TARGET_NAME)

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr) {
        if ((strcmp(brokerType.c_str(), INTERFACE_NAME) == 0) || (strcmp(brokerType.c_str(), INTERFACE_OPTIONAL_NAME) == 0)) {
            inPtr = std::shared_ptr<Interface>(new UfxInterface());
        }
    }

    int LoadLocalOption(void* src,size_t size){
        if(size!= sizeof(ogs::ReadConfig::localOption)){
            return -1;
        }
        memcpy(&ogs::ReadConfig::localOption,src,size);
        return 0;
    }

    void LogLibVersion()
    {
        LOG(info) << INTERFACE_NAME << " 接口库版本：" << GET_VERSION_STR(TARGET_NAME);
    }

#ifdef __cplusplus
}
#endif
}

