#ifndef FUNCPROP_H_
#define FUNCPROP_H_

#include <vector>
#include <string>
#include <string.h>
#include <map>
#include <iostream>

#include "TcpSocket.hpp"
#include "qtp_log.h"

#define SOCKET_ERROR -1

void MakePackStr(const char* CRCCode, const char* EditionNum, const char* UserCode, const char* Station, const char* Branch, const char* Channel, const char* SessionID, \
	const char* Reserved1, const char* Reserved2, const char* Reserved3, const char* ReqFuncNum, const std::vector<std::string> ReqData, std::string& OutStr);
std::string FillUpZero(int source, int len);
void ParseHead(const std::string SrcStr, std::vector<std::string>& OutDataVec);
void ParseBody(const std::string SrcStr, std::vector<std::string>& OutDataVec);

int Send(TcpSocket* socket,std::string& msg);
int Read(TcpSocket* s, std::vector<std::string> &msgheadout, std::map<int, std::map<std::string, std::string>>& msgbodyout);

std::vector<std::string> Split(const std::string& s, const std::string& delim);
void PrintBackData(std::string &head, std::string &body);
void PrintSendData(std::string reqFuncNum, std::string sendStr);

#endif
