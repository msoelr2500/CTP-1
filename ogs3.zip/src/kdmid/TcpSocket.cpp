//file: TcpSocket.cpp
//desc:
//author: Wen Zhang(wenz.zhang@gmail.com)
//create: 2008-12-31

#include "TcpSocket.hpp"

int TcpSocket::Listen(UInt32 addr, UInt16 port) {

	Close();

	int err;
	if ((err = Open()) < 0) return err;

	mLocalAddr.sin_family = AF_INET;
	mLocalAddr.sin_addr.s_addr = htonl(addr);
	mLocalAddr.sin_port = htons(port);

	//make binding successful even if the addr is on time-wait
	ReuseAddr();

	if (::bind(mFd, (struct sockaddr *) &mLocalAddr, sizeof(mLocalAddr)) < 0) {
		::perror("bind");
		Close();
		return -OS::GetLastError();
	}

	NonBlock();

	if (::listen(mFd, 1024) < 0) {
		::perror("listen");
		return -OS::GetLastError();
	}

	return 0;
}


TcpSocket* TcpSocket::Accept() {
	int fd;
	struct sockaddr_in	destAddr;
	TcpSocket *accSock;
	socklen_t destAddrLen = sizeof(destAddr);

	do {
		fd = ::accept(mFd, (struct sockaddr *) &destAddr, &destAddrLen);
	} while (fd < 0 && OS::GetLastError() == EINTR);

	if (fd < 0) return NULL;

	accSock = new TcpSocket(fd);

	accSock->SetDestAddr(destAddr);

	return accSock;
}

int TcpSocket::Open() {
	mFd = ::socket(PF_INET, SOCK_STREAM, 0);
	if (mFd == -1) {
		return -OS::GetLastError();
	}
	return 0;
}
