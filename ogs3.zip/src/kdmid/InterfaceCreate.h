//
// Created by lwk on 16-5-11.
//

#ifndef OGS_INTERFACECTEATE_H
#define OGS_INTERFACECTEATE_H

#include <memory>
#include <string.h>

#include "ReadConfig.h"
#include "Interface.h"
//#include "InterfaceAi.h"
#include "InterfaceKdmid.h"
#include "LibVersion.h"
#include "qtp_log.h"

namespace ogs {

#ifdef __cplusplus
extern "C"
{
#endif

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr);
    int LoadLocalOption(void* src,size_t size);
    void LogLibVersion();

#ifdef __cplusplus
}
#endif

}

#endif //OGS_INTERFACECTEATE_H
