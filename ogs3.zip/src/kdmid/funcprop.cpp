#include "funcprop.h"
#include "OgsLogger.h"
#include <errno.h>

/*
CRCУ����	CHAR(8), ��ע4,7
�汾��	    ��ǰЭ��汾���(�̶�����KDGATEWAY1.2��)
�û�����	CHAR(10), ��½���ͣ�Ϊ�����ߴ���
����վ��	CHAR(64)
������֧	CHAR(6), ��½����
��������	CHAR(1), �������ֵ�
�Ự���	CHAR(16), ��½����
�����ֶ�1	CHAR(20)             �û���ɫ OP_ROLE(2006-4-12) ע9
�����ֶ�2	CHAR(20)             ��������к�    (2006-4-12)
�����ֶ�3	CHAR(20)
�����ܺ�  CHAR(5)
����������
*/
void MakePackStr(const char* CRCCode, const char* EditionNum, const char* UserCode, const char* Station, const char* Branch, const char* Channel, const char* SessionID, \
	const char* Reserved1, const char* Reserved2, const char* Reserved3, const char* ReqFuncNum, const std::vector<std::string> ReqData, std::string& OutStr)
{
	int m_n_HeadSize = 0, m_n_DataSize = 0;
	m_n_HeadSize = 8 + strlen(CRCCode) + strlen(EditionNum) + strlen(UserCode) + strlen(Station) + strlen(Branch) + strlen(Channel) + strlen(SessionID) + \
		strlen(Reserved1) + strlen(Reserved2) + strlen(Reserved3) + 12;   //head char(4),data char(4), 12 "|"
	m_n_DataSize = strlen(ReqFuncNum) + 1 + ReqData.size(); // contain ReqData.size() "|"
	for (int i = 0; i < ReqData.size(); i++)
	{
		m_n_DataSize += ReqData[i].length();
	}
	OutStr.append(FillUpZero(m_n_HeadSize, 4));
	OutStr.append("|");
	OutStr.append(FillUpZero(m_n_DataSize, 4));
	OutStr.append("|");
	OutStr.append(CRCCode);
	OutStr.append("|");
	OutStr.append(EditionNum);
	OutStr.append("|");
	OutStr.append(UserCode);
	OutStr.append("|");
	OutStr.append(Station);
	OutStr.append("|");
	OutStr.append(Branch);
	OutStr.append("|");
	OutStr.append(Channel);
	OutStr.append("|");
	OutStr.append(SessionID);
	OutStr.append("|");
	OutStr.append(Reserved1);
	OutStr.append("|");
	OutStr.append(Reserved2);
	OutStr.append("|");
	OutStr.append(Reserved3);
	OutStr.append("|");
	OutStr.append(ReqFuncNum);
	OutStr.append("|");
	for (int i = 0; i < ReqData.size(); i++)
	{
		OutStr.append(ReqData[i].c_str());
		OutStr.append("|");
	}
}

/*
source->source int number
len->target length
*/
std::string FillUpZero(int source, int len)
{
	char target[17];
	char fstr[20];
	sprintf(fstr, "%%0%dd", len);
	sprintf(target, fstr, source);
	std::string Out(target, len);
	return Out;
}

/*
parse head section
*/
void ParseHead(const std::string SrcStr, std::vector<std::string>& OutDataVec)
{
	int local = 0;
	while (SrcStr.find_first_of('|', local) != SrcStr.npos)
	{
		int next_local = SrcStr.find_first_of('|', local);
		OutDataVec.push_back(SrcStr.substr(local, next_local - local));
		local = next_local + 1;
	}
}

/*
parse body section
*/
void ParseBody(const std::string SrcStr, std::vector<std::string>& OutDataVec)
{
	int local = 0;
	while (SrcStr.find_first_of('|', local) != SrcStr.npos)
	{
		int next_local = SrcStr.find_first_of('|', local);
		OutDataVec.push_back(SrcStr.substr(local, next_local - local));
		local = next_local + 1;
	}
}

int Send(TcpSocket* socket,std::string& msg) {
	int nendlen = msg.length();
	int sendlen = 0;
	while (sendlen < nendlen) {
		int ret = 0;
        if ((ret = send(socket->GetFd(), msg.c_str() + sendlen, msg.length() - sendlen, 0)) < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] send() returns " << ret << ", errno(" << errno << "): " << strerror(errno);
            return ret;
        }
        if (ret == 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] send() returns 0";
        }
		sendlen += ret;
        ogsInfo << "[kdmid] [SEND_PROGRESS] Total " << msg.length() << ", Sent " << sendlen;
	}
	return 0;
}

int GetTimeHMS() {
	time_t t = time(NULL);
	struct tm *current_time = localtime(&t);
	return current_time->tm_hour * 10000 + current_time->tm_min * 100 + current_time->tm_sec;
}

int TimeDiff(uint32_t begin,uint32_t end){
	return (end/10000*3600+(end%10000)/100*60+end%100)-(begin/10000*3600+(begin%10000)/100*60+begin%100);
}

std::vector<std::string> Split(const std::string& s, const std::string& delim)
{
    std::vector<std::string> elems;
    size_t pos = 0;
    size_t len = s.length();
    size_t delim_len = delim.length();
    if (delim_len == 0) return elems;
    while (pos < len)
    {
        int find_pos = s.find(delim, pos);
        if (find_pos < 0)
        {
            elems.push_back(s.substr(pos, len - pos));
            break;
        }
        elems.push_back(s.substr(pos, find_pos - pos));
        pos = find_pos + delim_len;
    }
    return elems;
}

void PrintBackData(std::string &head, std::string &body)
{
    std::vector<std::string> h = Split(head, "|");
    std::vector<std::string> b = Split(body, "|");

    int hSize = h.size();
    int bSize = b.size();

    if (hSize == 11)
    {
        VLOG(200) << "Head info: "
            << "RetCode = " << h.at(3)
            << " ,RetMsg = " << h.at(4)
            << " ,RetCount = " << h.at(7)
            << " ,RetFunc = " << h.at(8) ;

        VLOG(200) << "===������body info������===" ;
        int count = std::atoi(h.at(7).c_str());
        if (bSize % (count + 1) == 0)
        {
            for (int i = 0; i < count; i++)
            {
                VLOG(200) << "------ " << i + 1 << " ------" ;
                int t = bSize / (count + 1);
                for (int j = 0; j < t; j++)
                {
                    VLOG(200) << b.at(j) << " = " << b.at((i + 1) * t + j) ;
                }
            }
        }
        else
        {
            VLOG(200) << "Head = " << head << ", hSize = " << hSize ;
            VLOG(200) << "Body = " << body << ", bSize = " << bSize ;
        }
        VLOG(200) << "===������body info������===" ;
    }
    else
    {
        VLOG(200) << "Head = " << head << ", hSize = " << hSize ;
        VLOG(200) << "Body = " << body << ", bSize = " << bSize ;
    }
}

void PrintSendData(std::string reqFuncNum, std::string sendStr)
{
    std::map<std::string, std::string> fun;
    std::vector<std::string> s = Split(sendStr, "|");
    std::vector<std::string> parms;
    parms.push_back("HeadSize");
    parms.push_back("DataSize");
    parms.push_back("CRCCode");
    parms.push_back("EditionNum");
    parms.push_back("UserCode");
    parms.push_back("Station");
    parms.push_back("Branch");
    parms.push_back("Channel");
    parms.push_back("SessionID");
    parms.push_back("Reserved1");
    parms.push_back("Reserved2");
    parms.push_back("Reserved3");
    parms.push_back("ReqFuncNum");

    // �����ĵ����������θ�����ƥ�䲻һ�¡�������ȷ���ĵ���api֮���ٲ�ȫ
    if (reqFuncNum == "301")
    {
        fun[reqFuncNum] = "Login";
        parms.push_back("USER_ID_CLS");
        parms.push_back("USER_ID");
        parms.push_back("USER_PWD");
        parms.push_back("PROC_NAME");
        parms.push_back("CERT");
        parms.push_back("CERT_TYPE");
        parms.push_back("RNDCODE");
        parms.push_back("SIGNED_RNDCODE");
        parms.push_back("ETOKENPIN");
        parms.push_back("DYNETOKEN");
        parms.push_back("MAC");
        parms.push_back("CPUSN");
        parms.push_back("HARDISKSN");
    }
    else if (reqFuncNum == "403")
    {
        fun[reqFuncNum] = "SendOrder";

        parms.push_back("USER_CODE");
        parms.push_back("MARKET");
        parms.push_back("SECU_ACC");
        parms.push_back("ACCOUNT");
        parms.push_back("SEAT");
        parms.push_back("SECU_CODE");
        parms.push_back("TRD_ID");
        parms.push_back("PRICE");
        parms.push_back("QTY");
        parms.push_back("BIZ_NO");
        parms.push_back("EXT_INST");
        parms.push_back("EXT_REC_NUM");
        parms.push_back("OP_REMARK");
        parms.push_back("MATCH_SEAT");
        parms.push_back("MATCH_NUM");
        parms.push_back("ORDER_TYPE");
        parms.push_back("LINK_SECU_ACC");
        parms.push_back("MAC_ADDR");
        parms.push_back("HD_ID");
        parms.push_back("TRD_TERMCODE");
        parms.push_back("SERIAL_NO");
        parms.push_back("AUTO_BUY");
        parms.push_back("AUTO_BUY_DATE");
        parms.push_back("BJ_TRD_DATE");
        parms.push_back("MATCHED_SN");
        parms.push_back("YD_BOND_CODE");
        parms.push_back("YD_FEE_RATE");
        parms.push_back("YD_BB_AMT");
        parms.push_back("LOF_TACODE");
        parms.push_back("TIME_IN_FORCE");
    }
    else if (reqFuncNum == "404")
    {
        fun[reqFuncNum] = "CancelOrder";

        parms.push_back("MARKET");
        parms.push_back("ORDER_ID");
        parms.push_back("ACCOUNT");
        parms.push_back("MAC_ADDR");
        parms.push_back("HD_ID");
        parms.push_back("TRD_TERMCODE");
        parms.push_back("SECU_CLS");
        parms.push_back("TRD_ID");
    }
    else if (reqFuncNum == "430")
    {
        fun[reqFuncNum] = "paybackFunds";

        parms.push_back("ACCOUNT");
        parms.push_back("CURRENCY");
        parms.push_back("REPAYMENT_AMT");
        parms.push_back("CUST_CODE");
    }
    else if (reqFuncNum == "502")
    {
        fun[reqFuncNum] = "queryFundInfo";

        parms.push_back("USER_CODE");
        parms.push_back("USER_ROLES");
        parms.push_back("ACCOUNT");
        parms.push_back("CURRENCY");
        parms.push_back("RELATED_ACC_FLAG");
        parms.push_back("NO_CHECK_STATUS");
        parms.push_back("SECU_ASSERT_FLAG");
    }
    else if (reqFuncNum == "504")
    {
        fun[reqFuncNum] = "queryPosition";

        parms.push_back("USER_CODE");
        parms.push_back("ACCOUNT");
        parms.push_back("MARKET");
        parms.push_back("SECU_ACC");
        parms.push_back("SECU_CODE");
        parms.push_back("EXT_INST");
    }
    else if (reqFuncNum == "505")
    {
        fun[reqFuncNum] = "QueryOrder";

        parms.push_back("BEGIN_DATE");
        parms.push_back("END_DATE");
        parms.push_back("GET_ORDERS_MODE");
        parms.push_back("USER_CODE");
        parms.push_back("MARKETS");
        parms.push_back("SECU_ACC");
        parms.push_back("SECU_CODE");
        parms.push_back("TRD_IDS");
        parms.push_back("BIZ_NO");
        parms.push_back("ORDER_ID");
        parms.push_back("BRANCH");
        parms.push_back("ACCOUNT");
        parms.push_back("EXT_INST");
    }
    else if (reqFuncNum == "506")
    {
        fun[reqFuncNum] = "queryBargain";

        parms.push_back("BEGIN_DATE");
        parms.push_back("END_DATE");
        parms.push_back("USER_CODE");
        parms.push_back("MARKETS");
        parms.push_back("SECU_ACC");
        parms.push_back("SECU_CODE");
        parms.push_back("TRD_IDS");
        parms.push_back("ORDER_ID");
        parms.push_back("BIZ_NO");
        parms.push_back("BRANCH");
        parms.push_back("ACCOUNT");
        parms.push_back("EXT_INST");
    }

    int sSize = s.size();
    int pSize = parms.size();
    if (sSize == pSize)
    {
        VLOG(200) << "===������SendStr " << fun[reqFuncNum] << " Parms������===" ;
        VLOG(200) << parms.at(4) << " = " << s.at(4) ;	// ͷ��ֻ��ӡUserCode��reqFuncNum
        for (int i = 12; i < sSize; i++)
        {
            VLOG(200) << parms.at(i) << " = " << s.at(i) ;
        }
        VLOG(200) << "===������bSendStr " << fun[reqFuncNum] << " Parms������===" ;
    }
    else
    {
        VLOG(200) << sSize << " " << pSize << ", reqFuncNum = " << reqFuncNum << " , SendStr:" << sendStr ;
    }

}

int Read(TcpSocket* s, std::vector<std::string> &msgheadout, std::map<int, std::map<std::string, std::string>>& msgbodyout) {
	int timenow = GetTimeHMS();
	char headlen_c[5];
	int read_len = 0;
	int max_timegap = 3;
	while (read_len < 5) {
		int len = recv(s->GetFd(), headlen_c + read_len, 5 - read_len, 0);
        if (len < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] recv() returns " << len << ", errno(" << errno << "): " << strerror(errno);
			return -1;
		}
        if (len == 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] recv() returns 0";
        }

		int timegap = TimeDiff(timenow, GetTimeHMS());
		if (timegap > max_timegap || timegap < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] pre-read timeout.";
			return -2;
		}
		read_len += len;
        ogsInfo << "[kdmid] [RECV_PROGRESS] Total 5, Recv " << read_len;
	}
	int headlen_i = atoi(headlen_c) - 5;
	read_len = 0;
	std::string head(headlen_i, 0);
	while (read_len < headlen_i) {
		int len = recv(s->GetFd(), (char *) head.data() + read_len, headlen_i - read_len, 0);
        if (len < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] recv() returns " << len << ", errno(" << errno << "): " << strerror(errno);
            return -1;
		}
        if (len == 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] recv() returns 0";
        }
        int timegap = TimeDiff(timenow, GetTimeHMS());
		if (timegap > max_timegap || timegap < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] read head timeout.";
			return -2;
		}
		read_len += len;
        ogsInfo << "[kdmid] [RECV_PROGRESS] Total " << headlen_i << ", Recv " << read_len;
	}
	//std::cout << "head data:" << head << std::endl;
//	VLOG(200) << "head data:" << head;
	read_len = 0;
	int bodylen_posend = head.find_first_of('|', 0);
	int bodylen_i = atoi(head.substr(0, bodylen_posend).data());
	std::string body(bodylen_i, 0);
	while (read_len < bodylen_i) {
		int len = recv(s->GetFd(), (char *) body.data() + read_len, bodylen_i - read_len, 0);
        if (len < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] recv() returns " << len << ", errno(" << errno << "): " << strerror(errno);
            return -1;
		}
        if (len == 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] recv() returns 0";
        }
        int timegap = TimeDiff(timenow, GetTimeHMS());
		if (timegap > max_timegap || timegap < 0) {
            ogsError << "[kdmid] [NETWORK_ERROR] read body timeout.";
			return -2;
		}
		read_len += len;
        ogsInfo << "[kdmid] [RECV_PROGRESS] Total " << bodylen_i << ", Recv " << read_len;
	}
	read_len = 0;
	while (head.find_first_of('|', read_len) != head.npos) {
		int next_local = head.find_first_of('|', read_len);
		msgheadout.push_back(head.substr(read_len, next_local - read_len));
		read_len = next_local + 1;
	}
	read_len = 0;
	//std::cout << "body data:" << body << std::endl;
//	VLOG(200) << "body data:" << body;
    PrintBackData(head, body);
	std::vector<std::string> bodyvec;
	while (body.find_first_of('|', read_len) != body.npos) {
		int next_local = body.find_first_of('|', read_len);
		bodyvec.push_back(body.substr(read_len, next_local - read_len));
		read_len = next_local + 1;
	}
	int bodywordcount = atoi(msgheadout[6].c_str());
	int bodycount = atoi(msgheadout[7].c_str());
	read_len = bodywordcount;
	while (read_len < (bodycount + 1) * bodywordcount) {
		msgbodyout[read_len / bodywordcount][bodyvec[read_len % bodywordcount]] = bodyvec[read_len];
		read_len++;
	}
	return bodycount;
}
