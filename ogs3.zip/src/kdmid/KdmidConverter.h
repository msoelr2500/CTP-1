///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-27
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef KDMIDCONVERTER_H
#define KDMIDCONVERTER_H

#include "../ogs_dict.h"
#include "../DataStruct.h"
#include "../universal_code.h"
#include <string>

class KdmidConverter
{
public:
    static bool order_type(std::string& result, ogs::OGS_DIRECTIVE directive);
    static bool market(std::string& result, qtp::MarketCode ogsMarket);
    static bool trd_id(std::string& result, ogs::OGS_DIRECTIVE directive);
};

#endif
