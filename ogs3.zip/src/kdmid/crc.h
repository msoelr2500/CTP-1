#include "StdAfx.h"

uint32_t CRC_Reflect(uint32_t ref, char ch);
void CRC_Init();
void  CRC_Get(unsigned char* buffer, int nSize, unsigned char* lpoutbuf);