//file: Socket.cpp
//desc:
//author: Wen Zhang(wenz.zhang@gmail.com)
//create: 2008-11-23

#define _WINSOCK_DEPRECATED_NO_WARNINGS
#ifdef WIN32
#include "winsock2.h"
#else
#include <netdb.h>
#endif

#include "OS.hpp"
#include "Socket.hpp"

int Base_Socket::Connect(bool nonblocking) {
	int res = 0;

	Close();

	int err;
	if ((err = Open()) < 0) return err;

	if (nonblocking) {
		//it should return writable from epoll when succeced
		NonBlock();
	}

	res = ::connect(mFd, (struct sockaddr *)&mDestAddr, sizeof(struct sockaddr_in));
	if (res < 0 && (err = OS::GetLastError()) != EINPROGRESS) {
		::perror("connect");
		Close();
		return -err;
	}

	if (nonblocking)
		res = -err;
	return res;
}

int Base_Socket::Connect(UInt32 addr, UInt16 port, bool nonblocking) {
	mDestAddr.sin_family = AF_INET;
	mDestAddr.sin_addr.s_addr = addr;
	mDestAddr.sin_port = htons(port);
	return Connect(nonblocking);
}


int Base_Socket::Connect(std::string hostname, UInt16 port, bool nonblocking) {
	struct hostent *hostInfo;

	hostInfo = ::gethostbyname(hostname.c_str());

	if (hostInfo == NULL) {
		::perror("gethostbyname");
#ifdef WIN32
		return -OS::GetLastError();
#else
		return -h_errno;
#endif
	}

	::memcpy(&mDestAddr.sin_addr.s_addr, hostInfo->h_addr, sizeof(struct in_addr));
	mDestAddr.sin_port = htons(port);
	mDestAddr.sin_family = AF_INET;

	return Connect(nonblocking);
}

