//
// Created by lwk on 16-5-25.
//

#include <iconv.h>
#include "InterfaceKdmid.h"
#include "ReadConfig.h"
#include "BufferHandle.h"
#include "qtp_log.h"
#include "KdmidConverter.h"

#define KDMID_LOGLEVEL 300

namespace ogs {

#define CHANNEL ogs::ReadConfig::localOption.EntrustMode.c_str()
//#define STATION ogs::ReadConfig::localOption.ClientIp.c_str()
#define STATION op_site.c_str()
#define UNCHECKINERROR if (atoi(headVector[3].c_str()) == 110){ Close(); }
#define MAKESTATISON std::string op_site;op_site.append(unpackBuffer.GetDataObjPtr()->ipAddr);op_site.append(",");\
    op_site.append(unpackBuffer.GetDataObjPtr()->macAddr);op_site.append(",");\
    op_site.append(unpackBuffer.GetDataObjPtr()->diskSn);UpperCaseStr(op_site);

    std::map<std::string, std::map<std::string, UserInfo>> InterfaceKdmid::m_mapAccountInfo;
    std::function<int(ogs::QueryOrderAns)> InterfaceKdmid::func;

    bool iconv_msg(const char *tocode, const char *fromcode, std::string &inBuf, char *outBuf, size_t *outbytesleft) {
        iconv_t cd = iconv_open(tocode, fromcode);
        if (cd == (iconv_t) -1) {
            VLOG(KDMID_LOGLEVEL) << "[kdmid] iconv_open fail";
            //printf("iconv_open fail.\n");
        }
        else {
            char *inBufCh = const_cast<char *>(inBuf.data());
            size_t inbytesleft = inBuf.length();
            if (iconv(cd, &inBufCh, &inbytesleft, &outBuf, outbytesleft) == (size_t) -1) {
                VLOG(KDMID_LOGLEVEL) << "[kdmid] iconv fail.errno:" << errno;
                //printf("iconv fail.errno:%d\n", errno);
            }
        }
        iconv_close(cd);
        return true;
    }

    bool g2u(std::string &inStr, std::string &outStr) {
        size_t len = inStr.length() * 4;
        size_t len2 = len;
        outStr.assign(len, 0);
        iconv_msg("utf-8", "gb18030", inStr, const_cast<char *>(outStr.data()), &len);

        outStr.resize(len2 - len);
    }

    void UpperCaseStr(std::string &src) {
        char *local = (char *) src.c_str();
        for (int i = 0; i < src.length(); i++) {
            *local = toupper(*local);
            local++;
        }
    }

    InterfaceKdmid::InterfaceKdmid() {
        isConnect = false;
    }

    InterfaceKdmid::~InterfaceKdmid() {

    }

    bool InterfaceKdmid::getConnectStatus() {
        return isConnect;
    }

    INTF_RETURNTYPE InterfaceKdmid::initCommon() {
        return kIntfNotSupport;
    }

    INTF_RETURNTYPE InterfaceKdmid::initSubscribe() {
        return kIntfNotSupport;
    }

    INTF_RETURNTYPE InterfaceKdmid::setSubscribe(INTF_PARAMSTYPE vSubParams) {
        return kIntfNotSupport;
    }

    INTF_RETURNTYPE InterfaceKdmid::connectBroker() {
        m_tcpSocket = new TcpSocket();
        if (m_tcpSocket->Open() < 0) {
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [connectBroker] socket open fail";
            //printf("socket open fail\n");
            return kIntfFail;
        }
        //printf("socket open success\n");
        VLOG(300) << "[kdmid] [connectBroker] Tcp connect to:" << ogs::ReadConfig::localOption.BrokerAddr << ":" <<
                  ogs::ReadConfig::localOption.BrokerPort;
        int errorNo;
        //printf("addr:%s,port:%s\n",ogs::ReadConfig::localOption.BrokerAddr.c_str(),ogs::ReadConfig::localOption.BrokerPort.c_str());
        if ((errorNo = m_tcpSocket->Connect(ogs::ReadConfig::localOption.BrokerAddr,
                                            atoi(ogs::ReadConfig::localOption.BrokerPort.c_str()))) != 0) {
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [connectBroker] socket Connect fail";
            //printf("socket Connect fail\n");
            return kIntfFail;
        }
        //printf("socket Connect success\n");
        std::vector<std::string> send_vec;
        std::string sendstr;
        std::string op_site;
        op_site.append(ogs::ReadConfig::localOption.ClientIp.c_str());
        MakePackStr("", "KDGATEWAY1.2", "", STATION, "", CHANNEL, "", "1", "0", "", "100", send_vec, sendstr);
        VLOG(300) << "[kdmid] [connectBroker] Send:" << sendstr;
        if (Send(m_tcpSocket, sendstr) == SOCKET_ERROR) {
            Close();
            return kIntfError;
        }
        VLOG(300) << "[kdmid] [connectBroker] wait to read";
        std::vector<std::string> head_vec;
        std::map<int, std::map<std::string, std::string>> body_map;
        int count = 0;
        if ((count = Read(m_tcpSocket, head_vec, body_map)) < 0) {
            Close();
            return kIntfError;
        }
        std::string key = "SZKINGDOM";
        CBlowFish blowfish((unsigned char *) key.c_str(), key.length());
        memset(workkey, 0, sizeof(workkey));
        char workkey_fir[32] = {0};
        strcpy(workkey_fir, body_map[1]["WORKSKEY"].c_str());
        blowfish.Decrypt((const unsigned char *) workkey_fir, (unsigned char *) workkey, strlen(workkey_fir));
        VLOG(KDMID_LOGLEVEL) << "[kdmid] [connectBroker] workkey:" << workkey;
        //printf("workkey:%s\n", workkey);
        isConnect = true;
        return kIntfSuccess;
    }

    INTF_RETURNTYPE InterfaceKdmid::reConnectBroker() {
        isConnect = false;
        if (connectBroker() == kIntfSuccess) {
            return kIntfSuccess;
        }
        return kIntfFail;
    }

    INTF_RETURNTYPE InterfaceKdmid::login(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg,
                                          INTF_PARAMSTYPE vSubParams, std::map<int, std::string>& args) {
        UnpackBuffer<LoginQry> unpackBuffer(&qryBuf);
        PackBuffer<LoginAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            std::vector<std::string> sendVector;
            std::string sendStr;
            sendVector.push_back("Z");   //login as bacid
            sendVector.push_back(AllTOStr(unpackBuffer.GetDataObjPtr()->bacid));
            /*************encrypt password***********/
            std::string password(unpackBuffer.GetDataObjPtr()->password);
            char results[64] = {0};
            CBlowFish oBlowFish((unsigned char *) workkey, strlen(workkey));
            oBlowFish.Encrypt((unsigned char *) password.c_str(), (unsigned char *) results, password.length());
            std::string PwdFinal(results, strlen(results));
            sendVector.push_back(PwdFinal);
            /***********************************/
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->macAddr);   //mac
            sendVector.push_back("");   //cpu sn
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->diskSn);   //disk sn
            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "301",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "301",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [login] SendStr:" << sendStr;
            PrintSendData("301", sendStr);
            //printf("SendStr:%s\n", sendStr.c_str());
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/
            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("Login fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                std::string inputCustomerId = unpackBuffer.GetDataObjPtr()->acidcard;
                for (int j = 1; j <= dataCount; ++j) {
                    std::string market = AllTOStr(DecodeMarket(bodyMap[j]["MARKET"]));
                    if (market == AllTOStr(qtp::kMC_UNKNOW)) {
                        continue;
                    }
                    std::string bacid = bodyMap[j]["ACCOUNT"];
                    std::string acard = bodyMap[j]["SECU_ACC"];
                    std::string session = bodyMap[j]["SESSION"];
                    std::string acidcard = bodyMap[j]["USER_CODE"];

                    if (acidcard != inputCustomerId) {
                        retCode = kIntfWorkFail;
                        errMsg = "[kdmid] 输入客户号不正确：和登陆返回客户号不一致。";
                        std::cerr << errMsg << std::endl;
                        break;
                    }

                    m_mapAccountInfo[std::string(unpackBuffer.GetDataObjPtr()->bacid)][market] = {acard, session, bacid};
                }
                LoginAns loginAns;
                strcpy(loginAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                packBuffer.AddNewObj(&loginAns);
            }
            else {
                LoginAns loginAns;
                strcpy(loginAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                packBuffer.AddNewObj(&loginAns);
            }

            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::sendOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<SendOrderQry> unpackBuffer(&qryBuf);
        PackBuffer<SendOrderAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            OGS_INNERCODE innerCode = unpackBuffer.GetDataObjPtr()->innerCode;
            std::string code;
            qtp::MarketCode market;
            qtp::SecurityCategory sc;
            qtp::UniversalCode::UCToSymbol(innerCode, &code, &market, &sc);
            std::string bacid = unpackBuffer.GetDataObjPtr()->bacid;

            std::vector<std::string> sendVector;
            std::string sendStr;
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->acidcard);
            sendVector.push_back(EncodeMarket(market));
            sendVector.push_back(m_mapAccountInfo[bacid][AllTOStr(market)].acard);
            sendVector.push_back(AllTOStr(m_mapAccountInfo[bacid][AllTOStr(market)].bacid));
            sendVector.push_back("");
            sendVector.push_back(code);
            sendVector.push_back(
                    EncodeAction(unpackBuffer.GetDataObjPtr()->directive, unpackBuffer.GetDataObjPtr()->execution));
            sendVector.push_back(AllTOStr(((double) unpackBuffer.GetDataObjPtr()->price) / 10000));
            sendVector.push_back(AllTOStr(unpackBuffer.GetDataObjPtr()->volume));
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");

            std::string order_type;
            if (KdmidConverter::order_type(order_type, unpackBuffer.GetDataObjPtr()->directive)) {
                sendVector.push_back(order_type.c_str());
            } else {
                retCode = kIntfNotSupport;
                errMsg.assign("收到了无法识别的订单指令类型（directive）。");
                SendOrderAns sendOrderAns = {0};
                strcpy(sendOrderAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                sendOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                packBuffer.AddNewObj(&sendOrderAns);
                unpackBuffer.Next();
                continue;
            }

            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->macAddr);   //mac
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->diskSn);   //HD ID
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "403",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "403",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [sendOrder] SendStr:" << sendStr;
            PrintSendData("403", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                VLOG(KDMID_LOGLEVEL) << "[kdmid] [sendOrder] dataCount = " << dataCount;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("[kdmid] [sendOrder] SendOrder fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    SendOrderAns sendOrderAns;
                    strcpy(sendOrderAns.bacid, bodyMap[j]["ACCOUNT"].c_str());
                    sendOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                    strcpy(sendOrderAns.sysOrderId, bodyMap[j]["ORDER_ID"].c_str());

                    packBuffer.AddNewObj(&sendOrderAns);
                }
            }
            else {
                SendOrderAns sendOrderAns = {0};
                strcpy(sendOrderAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                sendOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                packBuffer.AddNewObj(&sendOrderAns);
            }
            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::cancelOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                                INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<CancelOrderQry> unpackBuffer(&qryBuf);
        PackBuffer<CancelOrderAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            OGS_INNERCODE innerCode = unpackBuffer.GetDataObjPtr()->innerCode;
            std::string code;
            qtp::MarketCode market;
            qtp::SecurityCategory sc;
            qtp::UniversalCode::UCToSymbol(innerCode, &code, &market, &sc);
            std::string bacid = unpackBuffer.GetDataObjPtr()->bacid;
            std::string sysOrderId(unpackBuffer.GetDataObjPtr()->sysOrderId);

            std::vector<std::string> sendVector;
            std::string sendStr;
            sendVector.push_back(AllTOStr(EncodeMarket(market)));
            sendVector.push_back(sysOrderId);
            sendVector.push_back(AllTOStr(m_mapAccountInfo[bacid][AllTOStr(market)].bacid));
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "404",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "404",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [cancelOrder] SendStr:" << sendStr;
            PrintSendData("404", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("CancelOrder Fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    CancelOrderAns cancelOrderAns;
                    strcpy(cancelOrderAns.bacid, bacid.c_str());
                    cancelOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                    strcpy(cancelOrderAns.sysOrderId, bodyMap[j]["ORDER_ID"].c_str());

                    packBuffer.AddNewObj(&cancelOrderAns);
                }
            }
            else {
                CancelOrderAns cancelOrderAns = {0};
                strcpy(cancelOrderAns.bacid, bacid.c_str());
                cancelOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                packBuffer.AddNewObj(&cancelOrderAns);
            }
            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::queryOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<QueryOrderQry> unpackBuffer(&qryBuf);
        PackBuffer<QueryOrderAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            std::string sysOrderId(unpackBuffer.GetDataObjPtr()->sysOrderId);
            std::string codeSend;
            qtp::MarketCode marketSend;
            qtp::SecurityCategory scSend;
            qtp::UniversalCode::UCToSymbol(unpackBuffer.GetDataObjPtr()->innerCode, &codeSend, &marketSend, &scSend);
            std::string bacid = unpackBuffer.GetDataObjPtr()->bacid;

            std::vector<std::string> sendVector;
            std::string sendStr;
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("0");  //GET_ORDERS_MODE,0 all
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->acidcard);
            //sendVector.push_back(EncodeMarket(marketSend));   //market
            sendVector.push_back("");//market kdmid has a error this market is char(1),correct is char(2)
            sendVector.push_back(m_mapAccountInfo[bacid][AllTOStr(marketSend)].acard);   //acard
            sendVector.push_back(strcmp(codeSend.c_str(), "000000") == 0 ? "" : codeSend);   //code
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back(sysOrderId);
            sendVector.push_back("");
            sendVector.push_back(AllTOStr(m_mapAccountInfo[bacid][AllTOStr(marketSend)].bacid));
            sendVector.push_back("");

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "505",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "505",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [queryOrder] SendStr:" << sendStr;
            PrintSendData("505", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("QueryOrder fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    std::string cancel_recoder = bodyMap[j]["IS_WITHDRAW"];
                    if (cancel_recoder == "0") {
                        OGS_ORDERSTATUS orderStatus;
                        OGS_DIRECTIVE directive;
                        std::string matchedAmt = bodyMap[j]["MATCHED_AMT"];
                        std::string matchedQty = bodyMap[j]["MATCHED_QTY"];
                        std::string qty = bodyMap[j]["QTY"];
                        std::string legal = bodyMap[j]["VALID_FLAG"];
                        std::string cancelFlag = bodyMap[j]["IS_WITHDRAWN"];
                        std::string canCancelFlag = bodyMap[j]["CAN_WITHDRAW"];
                        std::string trd_id = bodyMap[j]["TRD_ID"];

                        int ndealPrice = 0;
                        double nmatchedAmt = atof(matchedAmt.c_str());
                        int nmatchedQty = atoi(matchedQty.c_str());

                        if (legal == "0" && cancelFlag == "0") {  //illegal order and not canceled
                            orderStatus = ogs_dict::kOtBad;
                        }
                        else {          //legal order
                            if (nmatchedQty > 0) {
                                ndealPrice = nmatchedAmt * 10000 / nmatchedQty;
                                if (qty == matchedQty) {
                                    orderStatus = ogs_dict::kOtMatchedAll;
                                }
                                else if (cancelFlag == "1" && canCancelFlag == "0") {
                                    orderStatus = ogs_dict::kOtMatchedCanceled;
                                }
                                else if (cancelFlag == "1" && canCancelFlag == "1") {
                                    orderStatus = ogs_dict::kOtMatchedCanceling;
                                }
                                else {
                                    orderStatus = ogs_dict::kOtPartMatched;
                                }
                            }
                            else {
                                if (cancelFlag == "1" && canCancelFlag == "0") {
                                    orderStatus = ogs_dict::kOtCanceled;
                                }
                                else if (cancelFlag == "1" && canCancelFlag == "1") {
                                    orderStatus = ogs_dict::kOtCanceling;
                                }
                                else {
                                    orderStatus = ogs_dict::kOtReported;
                                }
                            }
                        }

                        if ((strcmp(trd_id.c_str(), "0B") == 0) || (strcmp(trd_id.c_str(), "1B") == 0) ||
                            (strcmp(trd_id.c_str(), "2B") == 0) || (strcmp(trd_id.c_str(), "UB") == 0) ||
                            (strcmp(trd_id.c_str(), "VB") == 0) || (strcmp(trd_id.c_str(), "WB") == 0) ||
                            (strcmp(trd_id.c_str(), "XB") == 0) || (strcmp(trd_id.c_str(), "YB") == 0))
                            directive = ogs::ogs_dict::DirectiveType::kDtBuy;
                        else
                            directive = ogs::ogs_dict::DirectiveType::kDtSell;

                        std::string code = bodyMap[j]["SECU_CODE"];
                        qtp::MarketCode market = DecodeMarket(bodyMap[j]["MARKET"]);
                        qtp::SecurityCategory sc = qtp::kSC_EQUITY;
                        OGS_INNERCODE innerCode = qtp::UniversalCode::SymbolToUC(code, market, sc);

                        QueryOrderAns queryOrderAns;
                        strcpy(queryOrderAns.bacid, bodyMap[j]["ACCOUNT"].c_str());
                        queryOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                        strcpy(queryOrderAns.sysOrderId, bodyMap[j]["ORDER_ID"].c_str());
                        queryOrderAns.price = (OGS_PRICE) (atof(bodyMap[j]["PRICE"].c_str()) * 10000);
                        queryOrderAns.volume = atoi(bodyMap[j]["QTY"].c_str());
                        queryOrderAns.orderStatus = orderStatus;
                        queryOrderAns.dealVolume = atoi(matchedQty.c_str());
                        queryOrderAns.dealBalance = ((uint64_t)atoll(matchedAmt.c_str())) * 10000;
                        queryOrderAns.dealPrice = ndealPrice;
                        queryOrderAns.innerCode = innerCode;
                        queryOrderAns.withdrawVolume = atoi(bodyMap[j]["WITHDRAWN_QTY"].c_str());
                        queryOrderAns.directive = directive;
                        if (queryOrderAns.orderStatus == ogs_dict::kOtMatchedCanceled ||
                            queryOrderAns.orderStatus == ogs_dict::kOtCanceled) {
                            if (queryOrderAns.dealVolume + queryOrderAns.withdrawVolume < queryOrderAns.volume) {
                                queryOrderAns.withdrawVolume = queryOrderAns.volume - queryOrderAns.dealVolume;
                            }
                        }
                        std::string tmpStr;
                        tmpStr.append(bodyMap[j]["TRD_DATE"].substr(0, 4)).append(
                                bodyMap[j]["TRD_DATE"].substr(5, 2)).append(bodyMap[j]["TRD_DATE"].substr(8, 2));
                        queryOrderAns.tradeDate = atoi(tmpStr.c_str());
                        tmpStr.clear();
                        tmpStr.append(bodyMap[j]["ORDER_DATE"].substr(11, 2)).append(
                                bodyMap[j]["ORDER_DATE"].substr(14, 2)).append(
                                bodyMap[j]["ORDER_DATE"].substr(17, 2));
                        queryOrderAns.orderTime = atoi(tmpStr.c_str());

                        //printf("1.%d:2.%d\n",queryOrderAns.tradeDate,queryOrderAns.orderTime);

                        packBuffer.AddNewObj(&queryOrderAns);
                    }
                }
            }
            else {
                QueryOrderAns queryOrderAns = {0};
                strcpy(queryOrderAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                queryOrderAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                packBuffer.AddNewObj(&queryOrderAns);
            }
            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::queryBargain(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                                 INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<QueryBargainQry> unpackBuffer(&qryBuf);
        PackBuffer<QueryBargainAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            std::vector<std::string> sendVector;
            std::string sendStr;

            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->acidcard);
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->sysOrderId);
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "506",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "506",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [queryBargain] SendStr:" << sendStr;
            PrintSendData("506", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("QueryBargain fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    QueryBargainAns queryBargainAns;
                    strcpy(queryBargainAns.bacid, bodyMap[j]["ACCOUNT"].c_str());
                    queryBargainAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                    strcpy(queryBargainAns.sysOrderId, bodyMap[j]["ORDER_ID"].c_str());

                    std::string code = bodyMap[j]["SECU_CODE"];
                    qtp::MarketCode market = DecodeMarket(bodyMap[j]["MARKET"]);
                    qtp::SecurityCategory sc = qtp::kSC_EQUITY;
                    OGS_INNERCODE innerCode = qtp::UniversalCode::SymbolToUC(code, market, sc);
                    queryBargainAns.innerCode = innerCode;
                    strcpy(queryBargainAns.dealId, bodyMap[j]["MATCHED_SN"].c_str());
                    queryBargainAns.dealVolume =
                            atoi(bodyMap[j]["MATCHED_QTY"].c_str()) < 0 ? 0 : atoi(bodyMap[j]["MATCHED_QTY"].c_str());
                    queryBargainAns.dealBalance = (atoi(bodyMap[j]["MATCHED_AMT"].c_str()) * 10000);
                    queryBargainAns.dealPrice = (OGS_PRICE) (atof(bodyMap[j]["MATCHED_PRICE"].c_str()) * 10000 +
                                                             0.5);

                    packBuffer.AddNewObj(&queryBargainAns);
                }
            }
            else {
                QueryBargainAns queryBargainAns = {0};
                strcpy(queryBargainAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                queryBargainAns.custOrderId = unpackBuffer.GetDataObjPtr()->custOrderId;
                packBuffer.AddNewObj(&queryBargainAns);
            }
            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::queryFundInfo(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                                  INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<QueryFundInfoQry> unpackBuffer(&qryBuf);
        PackBuffer<QueryFundInfoAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            std::vector<std::string> sendVector;
            std::string sendStr;
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->acidcard);
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");
            sendVector.push_back("");

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "502",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "502",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [queryFundInfo] SendStr:" << sendStr;
            PrintSendData("502", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("QueryFund fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    QueryFundInfoAns queryFundInfoAns;
                    strcpy(queryFundInfoAns.acidcard, bodyMap[j]["USER_CODE"].c_str());
                    strcpy(queryFundInfoAns.bacid, bodyMap[j]["ACCOUNT"].c_str());
                    queryFundInfoAns.balance = atol(bodyMap[j]["BALANCE"].c_str());
                    queryFundInfoAns.useableBalance = atol(bodyMap[j]["AVAILABLE"].c_str());
                    queryFundInfoAns.frozenBalance = atol(bodyMap[j]["TRD_FRZ"].c_str());

                    packBuffer.AddNewObj(&queryFundInfoAns);
                }
            }
            else {
                QueryFundInfoAns queryFundInfoAns = {0};
                strcpy(queryFundInfoAns.acidcard, unpackBuffer.GetDataObjPtr()->acidcard);
                strcpy(queryFundInfoAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                packBuffer.AddNewObj(&queryFundInfoAns);
            }

            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::queryPosition(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                                  INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<QueryPositionQry> unpackBuffer(&qryBuf);
        PackBuffer<QueryPositionAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            OGS_INNERCODE innerCode = unpackBuffer.GetDataObjPtr()->innerCode;
            std::string code = "";
            qtp::MarketCode market = qtp::kMC_UNKNOW;
            qtp::SecurityCategory sc = qtp::kSC_UNKNOW;
            if (innerCode != 0) {
                qtp::UniversalCode::UCToSymbol(innerCode, &code, &market, &sc);
            }

            std::vector<std::string> sendVector;
            std::string sendStr;
            std::string marketStr;
            KdmidConverter::market(marketStr, market);
            if (code == "000000") {
                code.clear();
            }

            sendVector.push_back(unpackBuffer.GetDataObjPtr()->acidcard);
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->bacid);
            sendVector.push_back(marketStr.c_str());
            sendVector.push_back("");
            sendVector.push_back(code);
            sendVector.push_back("");

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "504",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "504",
                        sendVector, sendStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [queryPosition] SendStr:" << sendStr;
            PrintSendData("504", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("QueryPosition fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    QueryPositionAns queryPositionAns;
                    strcpy(queryPositionAns.acidcard, bodyMap[j]["USER_CODE"].c_str());
                    strcpy(queryPositionAns.bacid, bodyMap[j]["ACCOUNT"].c_str());

                    std::string code = bodyMap[j]["SECU_CODE"];
                    qtp::MarketCode market = DecodeMarket(bodyMap[j]["MARKET"]);
                    qtp::SecurityCategory sc = qtp::kSC_EQUITY;
                    OGS_INNERCODE innerCode = qtp::UniversalCode::SymbolToUC(code, market, sc);
                    queryPositionAns.innerCode = innerCode;
                    queryPositionAns.currentVolume = atoi(bodyMap[j]["SHARE_BLN"].c_str());
                    queryPositionAns.usableVolume = atoi(bodyMap[j]["SHARE_AVL"].c_str());

                    packBuffer.AddNewObj(&queryPositionAns);
                }
            }
            else {
                QueryPositionAns queryPositionAns = {0};
                strcpy(queryPositionAns.acidcard, unpackBuffer.GetDataObjPtr()->acidcard);
                strcpy(queryPositionAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                packBuffer.AddNewObj(&queryPositionAns);
            }
            unpackBuffer.Next();
        }
        return retCode;
    }

    INTF_RETURNTYPE InterfaceKdmid::heartBeatToBroker() {
        if (m_tcpSocket == nullptr) {
            return kIntfFail;
        }
        std::vector<std::string> send_vec;
        std::string sendstr;
        std::string op_site;
        op_site.append(ogs::ReadConfig::localOption.ClientIp.c_str());
        op_site.append(",");
        op_site.append(ogs::ReadConfig::localOption.ClientMac.c_str());
        MakePackStr(workkey, "KDGATEWAY1.2", "", STATION, "", CHANNEL, "", "1", "0", "", "90", send_vec, sendstr);
        char CrcCode[20];
        CRC_Get((unsigned char *) sendstr.c_str(), strlen(sendstr.c_str()), (unsigned char *) CrcCode);
        //printf("SendStr:%s", sendstr.c_str());
        ///////////////////////////////////////////////////生成有校验码的包
        sendstr.clear();
        MakePackStr(CrcCode, "KDGATEWAY1.2", "", STATION, "", CHANNEL, "", "1", "0", "", "90", send_vec, sendstr);
        VLOG(KDMID_LOGLEVEL) << "[kdmid] [heartBeatToBroker] SendStr:" << sendstr;
        ///////////////////////////////////////////////////发包
        if (Send(m_tcpSocket, sendstr) == SOCKET_ERROR) {
            Close();
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [heartBeatToBroker] heart beat send fail";
            //printf("heart beat send fail.\n");
            return kIntfFail;
        }
        ///////////////////////////////////////////////////收报
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int count = 0;
        if ((count = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
            Close();
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [heartBeatToBroker] heart beat read fail";
            //printf("heart beat read fail.\n");
            return kIntfFail;
        }
        ///////////////////////////////////////////////////解包
        if (atoi(headVector[3].c_str()) != 0) {
            UNCHECKINERROR;
            std::string outStr;
            g2u(headVector[4], outStr);
            VLOG(KDMID_LOGLEVEL) << "[kdmid] [heartBeatToBroker] heart beat read fail " << outStr.c_str();
            //printf("heart beat read fail %s", outStr.c_str());
            return kIntfFail;
        }
        VLOG(KDMID_LOGLEVEL) << "[kdmid] [heartBeatToBroker] heart beat success,SYS_DATE:" << bodyMap[1]["SYS_DATE"].c_str() << ",SYS_STATUS:%s" <<
                             bodyMap[1]["SYS_STATUS"].c_str();
        //printf("heart beat success,SYS_DATE:%s,SYS_STATUS:%s", bodyMap[1]["SYS_DATE"].c_str(),
        //bodyMap[1]["SYS_STATUS"].c_str());
        return kIntfSuccess;
    }

    void InterfaceKdmid::Close() {
        if (m_tcpSocket) {
            m_tcpSocket->Close();
            delete m_tcpSocket;
            m_tcpSocket = nullptr;
        }
        isConnect = false;
    }

    qtp::MarketCode InterfaceKdmid::DecodeMarket(std::string BrokerMarket) {
        if (strcmp(BrokerMarket.c_str(), "00") == 0) {    //sz
            return qtp::kMC_SZE;
        }
        else if (strcmp(BrokerMarket.c_str(), "10") == 0) {   //sh
            return qtp::kMC_SSE;
        }
        else {
            return qtp::kMC_UNKNOW;
        }
    }

    std::string InterfaceKdmid::EncodeMarket(qtp::MarketCode LocalMarket) {
        if (LocalMarket == qtp::kMC_SZE) {
            return "00";
        }
        else if (LocalMarket == qtp::kMC_SSE) {
            return "10";
        }
        else {
            return "";
        }
    }

    std::string InterfaceKdmid::EncodeAction(OGS_DIRECTIVE directive, OGS_EXECUTION execution) {
        if (execution == ogs_dict::kExeLimit) {
            if (directive == ogs_dict::kDtBuy) {
                return "0B";
            }
            else if (directive == ogs_dict::kDtSell) {
                return "0S";
            }
            else if (directive == ogs_dict::kDtLoanBuy) {
                return "0B";
            }
            else if (directive == ogs_dict::kDtMarginSell || directive == ogs_dict::kDtMarketMarginSell) {
                return "0S";
            }
            else {
                return "";
            }
        }
        else {
            return "";
        }
    }

    void InterfaceKdmid::setCallBack(int (*fn)(QueryOrderAns)) {
        func = fn;
    }

    INTF_RETURNTYPE InterfaceKdmid::paybackSecurity(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                                    INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        return kIntfNotSupport;
    }

    INTF_RETURNTYPE InterfaceKdmid::paybackFunds(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                                 INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) {
        UnpackBuffer<PaybackFundsQry> unpackBuffer(&qryBuf);
        PackBuffer<PaybackFundsAns> packBuffer(&ansBuf);
        std::vector<std::string> headVector;
        std::map<int, std::map<std::string, std::string>> bodyMap;
        int dataCount = 0;
        INTF_RETURNTYPE retCode = kIntfSuccess;
        BUF_HANDLE_COUNTTYPE count = unpackBuffer.GetDataCount();
        unpackBuffer.First();
        for (int i = 0; i < count; ++i) {
            std::vector<std::string> sendVector;
            std::string sendStr;

            sendVector.push_back(unpackBuffer.GetDataObjPtr()->bacid);
            sendVector.push_back("0");   //CURRENCY 0 RMB
            sendVector.push_back(AllTOStr(((double) unpackBuffer.GetDataObjPtr()->repayAmt) / 10000));
            sendVector.push_back(unpackBuffer.GetDataObjPtr()->acidcard);

            std::string userCode = unpackBuffer.GetDataObjPtr()->acidcard;
            MAKESTATISON;
            MakePackStr(workkey, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "430",
                        sendVector, sendStr);
            char crcCode[20];
            CRC_Get((unsigned char *) sendStr.c_str(), sendStr.length(), (unsigned char *) crcCode);
            sendStr.clear();
            MakePackStr(crcCode, "KDGATEWAY1.2", userCode.c_str(), STATION, "", CHANNEL, "", "1", "0", "", "430",
                        sendVector, sendStr);
            //VLOG(KDMID_LOGLEVEL) << "[kdmid] [paybackFunds] SendStr:" << sendStr;
            PrintSendData("430", sendStr);
            if (Send(m_tcpSocket, sendStr) == SOCKET_ERROR) {
                Close();
                retCode = kIntfSendFail;
                goto loopEnd;
            }
            /***************receive message**************/

            if ((dataCount = Read(m_tcpSocket, headVector, bodyMap)) < 0) {
                Close();
                retCode = kIntfRecvFail;
                goto loopEnd;
            }
            /****************handle message*************/
            if (atoi(headVector[3].c_str()) != 0) {
                UNCHECKINERROR;
                std::string outStr;
                g2u(headVector[4], outStr);
                errMsg.append("PaybackFunds fail:").append(outStr);
                retCode = kIntfWorkFail;
                goto loopEnd;
            }
            loopEnd:
            if (retCode == kIntfSuccess) {
                for (int j = 1; j <= dataCount; ++j) {
                    PaybackFundsAns paybackFundsAns;
                    strcpy(paybackFundsAns.acidcard, unpackBuffer.GetDataObjPtr()->acidcard);
                    strcpy(paybackFundsAns.bacid, bodyMap[j]["ACCOUNT"].c_str());
                    paybackFundsAns.omsOrderId = unpackBuffer.GetDataObjPtr()->omsOrderId;
                    paybackFundsAns.repayAmtReal = (OGS_REPAYAMTREAL) (atof(bodyMap[j]["REPAY_TRUE"].c_str()) * 10000);

                    packBuffer.AddNewObj(&paybackFundsAns);
                }
            }
            else {
                PaybackFundsAns paybackFundsAns = {0};
                strcpy(paybackFundsAns.acidcard, unpackBuffer.GetDataObjPtr()->acidcard);
                strcpy(paybackFundsAns.bacid, unpackBuffer.GetDataObjPtr()->bacid);
                paybackFundsAns.omsOrderId = unpackBuffer.GetDataObjPtr()->omsOrderId;
                packBuffer.AddNewObj(&paybackFundsAns);
            }
            unpackBuffer.Next();
        }
        return retCode;
    }

}
