//file: TcpSocket.hpp
//desc:
//author: Wen Zhang(wenz.zhang@gmail.com)
//create: 2008-12-31

#ifndef _TCPSOCKET_HPP_
#define _TCPSOCKET_HPP_

#include "Socket.hpp"
class TcpSocket : public Base_Socket {
public:
	TcpSocket(int fd = -1, bool external = false)
		:Base_Socket(fd, external) {}
	~TcpSocket() {}
	/**
	 *@param addr the listening address in host byteorder
	 *@param port the listening port
	 */
	int Listen(UInt32 addr, UInt16 port);

	TcpSocket* Accept();

	int Open();

};

#endif