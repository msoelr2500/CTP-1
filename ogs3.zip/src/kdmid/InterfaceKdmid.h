//
// Created by lwk on 16-5-25.
//

#ifndef OGS_INTERFACEKDMID_H
#define OGS_INTERFACEKDMID_H

#include <string>
#include "ReadConfig.h"
#include "Interface.h"
#include "funcprop.h"
#include "Blowfish.h"
#include "crc.h"
#include "universal_code.h"
#include "ogs_dict.h"
#include "OgsApi.h"

namespace ogs {

    typedef struct UserInfo {
        std::string acard;
        std::string session;
        std::string bacid;
    } *PUserInfo;

    class InterfaceKdmid : public Interface {
    public:
        InterfaceKdmid();

        ~InterfaceKdmid();

        bool getConnectStatus();

        INTF_RETURNTYPE initCommon();

        INTF_RETURNTYPE initSubscribe();

        INTF_RETURNTYPE setSubscribe(INTF_PARAMSTYPE vSubParams);

        INTF_RETURNTYPE connectBroker();

        INTF_RETURNTYPE reConnectBroker();

        INTF_RETURNTYPE login(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                              INTF_ERRMSGTYPE errMsg, INTF_PARAMSTYPE vSubParams, std::map<int, std::string>& args);//quybuf = count + LoginQry * n;ansBuf = count + LoginAns * n
        INTF_RETURNTYPE sendOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE cancelOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryBargain(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryFundInfo(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE queryPosition(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE heartBeatToBroker();

        INTF_RETURNTYPE paybackSecurity(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,	INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        INTF_RETURNTYPE paybackFunds(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args);

        void Close();

        void setCallBack(int (*fn)(QueryOrderAns));

        qtp::MarketCode DecodeMarket(std::string BrokerMarket);

        std::string EncodeMarket(qtp::MarketCode LocalMarket);

        std::string EncodeAction(OGS_DIRECTIVE directive, OGS_EXECUTION execution);

    private:
        bool isConnect;
        TcpSocket *m_tcpSocket;
        char workkey[9];

        static std::map<std::string, std::map<std::string, UserInfo>> m_mapAccountInfo; //<bacid,<market,UserInfo>>
        static std::function<int(ogs::QueryOrderAns)> func;
    };
}

#endif //OGS_INTERFACEKDMID_H
