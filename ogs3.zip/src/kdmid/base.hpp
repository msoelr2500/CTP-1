//file: base.hpp
//desc:
//author: Wen Zhang(wenz.zhang@gmail.com)
//create: 2008-11-22

#ifndef _BASE_HPP_
#define _BASE_HPP_

typedef unsigned char			UInt8;
typedef signed char				Int8;
typedef unsigned short			UInt16;
typedef signed short			Int16;
typedef unsigned int			UInt32;
typedef signed int				Int32;
typedef signed long long		Int64;
typedef unsigned long long		UInt64;
typedef signed long				PointerSizedInt;
typedef unsigned long			PointerSizedUInt;

#endif
