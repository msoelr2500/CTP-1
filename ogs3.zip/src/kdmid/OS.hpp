//file: OS.hpp
//desc:
//author: Wen Zhang(wenz.zhang@gmail.com)
//create: 2008-11-27

#ifndef _OS_HPP_
#define _OS_HPP_

#ifdef WIN32
#include <winsock2.h>
#include <Mmsystem.h>
#pragma comment(lib, "winmm.lib")
#else
#include <sys/time.h>
#endif

#include <time.h>
#include <errno.h>

#include "base.hpp"

#ifdef WIN32
#define ENOTCONN       1002
#define EADDRINUSE     1004
#define EINPROGRESS    1007
#define ENOBUFS        1008
#define EADDRNOTAVAIL  1009
#endif

struct OS {
	static Int64 GetCurrentTimeMS() {
#ifdef WIN32
		return timeGetTime();
#else
		struct timeval tv;
		::gettimeofday(&tv, NULL);
		return tv.tv_sec * 1000 + tv.tv_usec / 1000;
#endif
	}

	static int GetLastError() {
#ifdef WIN32
		int winErr = ::GetLastError();

		switch (winErr) {

		case ERROR_FILE_NOT_FOUND: return ENOENT;
		case ERROR_PATH_NOT_FOUND: return ENOENT;

		case WSAEINTR:             return EINTR;
		case WSAENETRESET:         return EPIPE;
		case WSAENOTCONN:          return ENOTCONN;
		case WSAEWOULDBLOCK:       return EAGAIN;
		case WSAECONNRESET:        return EPIPE;
		case WSAEADDRINUSE:        return EADDRINUSE;
		case WSAEMFILE:            return EMFILE;
		case WSAEINPROGRESS:       return EINPROGRESS;
		case WSAEADDRNOTAVAIL:     return EADDRNOTAVAIL;
		case WSAECONNABORTED:      return EPIPE;
		case 0:                    return 0;

		default:                   return ENOTCONN;
		}

#else
		return errno;
#endif
	}
};

#endif
