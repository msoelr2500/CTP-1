#include "StdAfx.h"
#include "crc.h"
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>

//////////////////////////////////////////////////////////////////////////
// Code ends at Line 231
//////////////////////////////////////////////////////////////////////////

uint32_t CRC_Reflect(uint32_t ref, char ch)
{// Used only by Init_CRC32_Table()

	uint32_t value(0);

	// Swap bit 0 for bit 7 , bit 1 for bit 6, etc.
	for (int i = 1; i < (ch + 1); i++)
	{
		if (ref & 1)
			value |= 1 << (ch - i);
		ref >>= 1;
	}
	return value;
}

void CRC_Get(unsigned char* buffer, int nSize, unsigned char* lpoutbuf)
{
	// Be sure to use unsigned variables,
	// because negative values introduce high bits
	// where zero bits are required.
	char ch[20];

	uint32_t  crc(0xffffffff);
    int len;

    uint32_t crc32_table[256]; // Lookup table arrays
    // This is the official polynomial used by CRC-32 in PKZip, WinZip and Ethernet.
    uint32_t ulPolynomial = 0x04c11db7;

    // 256 values representing ASCII character codes.
    for (int i = 0; i <= 0xFF; i++)
    {
        crc32_table[i] = CRC_Reflect(i, 8) << 24;
        for (int j = 0; j < 8; j++)
            crc32_table[i] = (crc32_table[i] << 1) ^ (crc32_table[i] & (1 << 31) ? ulPolynomial : 0);
        crc32_table[i] = CRC_Reflect(crc32_table[i], 32);
    }

	len = nSize;
	// Save the text in the buffer.
	// Perform the algorithm on each character
	// in the string, using the lookup table values.
	while (len--)
		crc = (crc >> 8) ^ crc32_table[(crc & 0xFF) ^ *buffer++];
	// Exclusive OR the result with the beginning value.
	int icrc;
	icrc = crc ^ 0xffffffff;
	//printf("icrc:%d\n", icrc);
	memset(ch, 0x00, 20);
	//itoa(icrc , ch,16);
	sprintf(ch, "%x", icrc);
	for (int i = 0; i < 8; i++)
	{
		if (ch[i] == 0)
		{
			ch[i] = 0x30;
		}
	}

	strcpy((char *)lpoutbuf, ch);
	//return ch;
}
