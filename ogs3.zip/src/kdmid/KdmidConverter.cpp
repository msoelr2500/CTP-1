///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-09-27
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "KdmidConverter.h"

using std::string;

bool KdmidConverter::order_type(std::string &result, ogs::OGS_DIRECTIVE directive)
{
    switch (directive) {
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
        result.assign("00");
        break;
    case ogs::ogs_dict::kDtLoanBuy:
        result.assign("01");
        break;
    case ogs::ogs_dict::kDtSellPayBack:
        result.assign("02");
        break;
    //! \todo 添加对融资平仓（03）的支持。
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
        result.assign("04");
        break;
    case ogs::ogs_dict::kDtBuyPayback:
        result.assign("05");
        break;
    //! \todo 添加对融券平仓（06）的支持。
    default: return false;
    }
    return true;
}

bool KdmidConverter::market(std::string &result, qtp::MarketCode ogsMarket)
{
    switch (ogsMarket) {
    case qtp::kMC_SSE:
        result.assign("10");
        break;
    case qtp::kMC_SZE:
        result.assign("00");
        break;
    default:
        result.assign("");
        return false;
    }
    return true;
}

bool KdmidConverter::trd_id(std::string &result, ogs::OGS_DIRECTIVE directive)
{
    switch (directive) {
    case ogs::ogs_dict::kDtBuy:
        result.assign("0B");
        break;
    case ogs::ogs_dict::kDtSell:
        result.assign("0S");
        break;
    case ogs::ogs_dict::kDtMarketMarginSell:
        result.assign("RQ");
        break;
    case ogs::ogs_dict::kDtLoanBuy:
        result.assign("RZ");
        break;
    default:
        result.assign("");
        return false;
    }
    return true;
}
