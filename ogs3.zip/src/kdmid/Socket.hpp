//file: Socket.hpp
//desc:
//author: Wen Zhang(wenz.zhang@gmail.com)
//create: 2008-11-22

#ifndef _SOCKET_HPP_
#define _SOCKET_HPP_


#ifdef WIN32
typedef int socklen_t;
#else
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#endif

#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>

#include <string>

#include "base.hpp"
#include "OS.hpp"

class Base_Socket {
public:

	Base_Socket(int fd = -1, bool external = false)
		: mFd(fd), mExternal(external) {
		mLocalAddr.sin_addr.s_addr = 0;
		mLocalAddr.sin_port = 0;
		mDestAddr.sin_addr.s_addr = 0;
		mDestAddr.sin_port = 0;
	}

	virtual ~Base_Socket() {
		Close();
	}

	/**
	 *@param addr the listening address in host byteorder
	 *@param port the listening port
	 */
	virtual int Listen(UInt32 addr, UInt16 port) = 0;

	/**
	 *@param addr the listening address in network byteorder
	 *@param port the listening port
	 *@param nonblocking true:set nonblock
	 */
	int Connect(UInt32 addr, UInt16 port, bool nonblocking = false);

	int Connect(std::string hostname, UInt16 port, bool nonblocking = false);

	int GetFd() { return mFd; }

	bool IsConnected() { return mFd != -1; }

	virtual int Open() = 0;

	void Close() {
		if (mExternal) {
			mFd = -1;
			return;
		}
		if (mFd == -1) return;
#ifdef WIN32
		::closesocket(mFd);
#else
		::close(mFd);
#endif
		mFd = -1;
	}

	struct sockaddr_in GetLocalAddr() {
		return mLocalAddr;
	}

	struct sockaddr_in GetDestAddr() {
		return mDestAddr;
	}

	void SetDestAddr(struct sockaddr_in addr) {
		::memcpy(&mDestAddr, &addr, sizeof(addr));
	}

	void SetDestPort(UInt16 port) {
		mDestAddr.sin_port = htons(port);
	}

	int ReuseAddr() {
		int one = 1;
		if (::setsockopt(mFd, SOL_SOCKET, SO_REUSEADDR, (char*)&one, sizeof(int)) < 0) {
			::perror("ReuseAddr");
			return -OS::GetLastError();
		}
		return 0;
	}

	int NoDelay() {
		int one = 1;
		if (::setsockopt(mFd, IPPROTO_TCP, TCP_NODELAY, (char*)&one, sizeof(int)) < 0) {
			::perror("NoDelay");
			return -OS::GetLastError();
		}
		return 0;
	}

	int KeepAlive() {
		int one = 1;
		if (::setsockopt(mFd, SOL_SOCKET, SO_KEEPALIVE, (char*)&one, sizeof(int)) < 0) {
			::perror("KeepAlive");
			return -OS::GetLastError();
		}
		return 0;
	}

	int NonBlock() {
#ifdef WIN32
		u_long one = 1;
		if (::ioctlsocket(mFd, FIONBIO, &one) < 0) {
#else
		if (::fcntl(mFd, F_SETFL, O_NONBLOCK) < 0) {
#endif
			::perror("NonBlock");
			return -OS::GetLastError();
		}
		return 0;
	}

	int SetSndBufSize(int bufSize) {
		if (::setsockopt(mFd, SOL_SOCKET, SO_SNDBUF, (char *)&bufSize, sizeof(bufSize)) < 0) {
			::perror("SetSendBufSize");
			return -OS::GetLastError();
		}
		return 0;
	}

	int SetRcvBufSize(int bufSize) {
		if (::setsockopt(mFd, SOL_SOCKET, SO_RCVBUF, (char *)&bufSize, sizeof(bufSize)) < 0) {
			::perror("SetRcvBufSize");
			return -OS::GetLastError();
		}
		return 0;
	}

protected:
	int mFd;
	bool mExternal;

	int Connect(bool nonblocking);

	struct sockaddr_in mLocalAddr;
	struct sockaddr_in mDestAddr;
};

#endif