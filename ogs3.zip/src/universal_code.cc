//
// Created by wen on 2016-04-15.
//

#include "universal_code.h"
#include <inttypes.h>

namespace qtp {

    class ChinaStockUniversalCode : public UniversalCode {
    public:
        static uc_t SymbolToUC(const std::string &symbol, MarketCode mc, SecurityCategory sc) {
          uint64_t code = (uint64_t) atoll(symbol.c_str());
          return ((sc & kSC_MASK) << kSC_SHIFT_BITS) | ((mc & kMC_MASK) << kMC_SHIFT_BITS) | (code & kCODE_MASK);
        }

        static int UCToSymbol(uc_t uc, std::string *symbol, MarketCode *mc, SecurityCategory *sc) {
          SecurityCategory sec_cate = SecurityCategory((uc >> kSC_SHIFT_BITS) & kSC_MASK);
          MarketCode market_code = MarketCode((uc >> kMC_SHIFT_BITS) & kMC_MASK);
          uint64_t code = uc & kCODE_MASK;
          //TODO(wen): check the category and market
          if (sc) *sc = sec_cate;
          if (mc) *mc = market_code;

          if (symbol) {
            char buf[kMAX_SYMBOL_SIZE] = {0};
            int len = snprintf(buf, kMAX_SYMBOL_SIZE, "%06" PRIu64 "", code);
            symbol->assign(buf, len);
          }
          return 0;
        }

    private:
        static const size_t kMAX_SYMBOL_SIZE = 16;
    };


    uc_t UniversalCode::SymbolToUC(const std::string &symbol, MarketCode mc, SecurityCategory sc) {
      uc_t uc = INVALID_UC;
      switch (mc) {
        case kMC_SSE:
        case kMC_SZE:
          uc = ChinaStockUniversalCode::SymbolToUC(symbol, mc, sc);
              break;
        case kMC_UNKNOW: //default to china stock
          if (symbol.size() == 0) break;
              if (symbol[0] == '6')
                mc = kMC_SSE;
              else if (symbol[0] == '0' || symbol[0] == '3')
                mc = kMC_SZE;
              uc = ChinaStockUniversalCode::SymbolToUC(symbol, mc, kSC_EQUITY);
              break;
        default:
          break;
      }
      return uc;
    }

    int UniversalCode::UCToSymbol(uc_t uc, std::string *symbol, MarketCode *mc, SecurityCategory *sc) {
      int ret = 0;
      SecurityCategory sec_cate = SecurityCategory((uc >> kSC_SHIFT_BITS) & kSC_MASK);
      MarketCode market_code = MarketCode((uc >> kMC_SHIFT_BITS) & kMC_MASK);

      if (sc) *sc = sec_cate;
      if (mc) *mc = market_code;

      if (symbol) {
        switch (market_code) {
          case kMC_SSE:
          case kMC_SZE:
            ret = ChinaStockUniversalCode::UCToSymbol(uc, symbol, nullptr, nullptr);
                break;
          default:
            break;
        }
      }

      return ret;
    }

} //namespace qtp