//
// Created by lwk on 16-5-9.
//

#ifndef OGS_ORDERSTAGE_H
#define OGS_ORDERSTAGE_H

#include <memory>
#include <unistd.h>

#include "BufferHandle.h"
#include "qtp_stage.h"
#include "qtp_message.h"
#include "qtp_log.h"
#include "qtp_session.h"
#include "Interface.h"
#include "ogs_dict.h"
#include "OgsApi.h"
#include "LoadInterface.h"

namespace ogs
{
    class OrderStage:public qtp::QtpStage
    {
    public:
        OrderStage(std::string brokerType,int nId,bool initSub = false);
        int OnEvent(qtp::QtpMessagePtr message);
        void Run();

        int HandleLogin(qtp::QtpMessagePtr message);
        int HandleSendOrder(qtp::QtpMessagePtr message);
        int HandleCancelOrder(qtp::QtpMessagePtr message);
        int HandleQueryOrder(qtp::QtpMessagePtr message);
        int HandleQueryBargain(qtp::QtpMessagePtr message);
        int HandleQueryFundInfo(qtp::QtpMessagePtr message);
        int HandleQueryPosition(qtp::QtpMessagePtr message);
        int HandleHeartBeat(qtp::QtpMessagePtr message);
        int HandleQueryOrderSe(qtp::QtpMessagePtr message);
        int HandlePaybackSecurity(qtp::QtpMessagePtr message);
        int HandlePaybackFunds(qtp::QtpMessagePtr message);

        // FOR COMPIBILITY
        static int CallBack(QueryOrderAns queryOrderAns);
        static int CallBack(const QueryOrderAns& queryOrderAns, const std::string& description);

    private:
        std::shared_ptr<Interface> interfacePtr;
        int id;
        int mOrderStageId;
        static int mOrderStageCount;
        static std::mutex mOrderStageCountMutex;

        bool m_initSubFlag;
        static bool m_setSubFlag;
    };
}

#endif //OGS_ORDERSTAGE_H
