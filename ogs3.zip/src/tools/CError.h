#ifndef _CERROR_H
#define _CERROR_H

#include "CGlobal.h"
#include <errno.h>
#include <stdarg.h>

static void err_doit(int, int, const char*, va_list);

/*
 * Nonfatal error releated to a system call.
 * Print a message and return.
 */
void err_ret(const char* fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(1, errno, fmt, ap);
    va_end(ap);
}

/*
 * Fatal error releated to a system call.
 * Print a message and terminate.
 */
void err_sys(const char* fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    err_doit(1, errno, fmt, ap);
    va_end(ap);
    exit(1);
}

/*
 * Nonfatal error releated to a system call
 */

#endif /* _CERROR_H */
