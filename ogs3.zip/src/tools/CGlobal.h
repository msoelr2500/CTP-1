#ifndef _CGLOBAL_H
#define _CGLOBAL_H

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/termios.h>

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>         /* for SIG_ERR */

#define MAXLINE 4096

#endif // _CGLOBAL_H
