#ifndef _INTERFACE_H_
#define _INTERFACE_H_

#include <iostream>
#include <string>
#include <memory>
#include <vector>
#include <map>

#include "DataStruct.h"

enum Intf_RetType{
	kIntfNotSupport = -1,
	kIntfSuccess = 0,
	kIntfFail,
	kIntfError,
	kIntfDisconnect,
	kIntfSendFail,
	kIntfSendTimeOut,
	kIntfRecvFail,
	kIntfRecvTimeOut = 7,
	kIntfWorkFail       //business work fail
};

#define INTF_RETURNTYPE Intf_RetType                  //return type of all interface function
#define INTF_QRYBUFTYPE const std::string&   //type of all input parameter
#define INTF_ANSBUFTYPE std::string&         //type of all output parameter
#define INTF_ERRMSGTYPE std::string&
#define INTF_PARAMSTYPE std::vector<std::string>&  //type of params used in setSubscribe

#define INTF_FUNCTIONSET = 0   // = 0 , pure virtual function

namespace ogs {

	class Interface {
	public:
        Interface() { }

        virtual ~Interface() { }

		virtual bool getConnectStatus() INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE initCommon() INTF_FUNCTIONSET;
		//subscribe before login
		virtual INTF_RETURNTYPE initSubscribe() INTF_FUNCTIONSET;
		//subscribe after login
		virtual INTF_RETURNTYPE setSubscribe(INTF_PARAMSTYPE vSubParams) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE connectBroker() INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE reConnectBroker() INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE login(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf, INTF_ERRMSGTYPE errMsg,
                                      INTF_PARAMSTYPE vSubParams, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		//quybuf = count + LoginQry * n;ansBuf = count + LoginAns * n
		virtual INTF_RETURNTYPE sendOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                          INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE cancelOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                            INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE queryOrder(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                           INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE queryBargain(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                             INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE queryFundInfo(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                              INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE queryPosition(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                              INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

        virtual INTF_RETURNTYPE heartBeatToBroker() INTF_FUNCTIONSET;

		virtual void setCallBack(int (*fn)(QueryOrderAns)) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE paybackSecurity(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                              INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

		virtual INTF_RETURNTYPE paybackFunds(INTF_QRYBUFTYPE qryBuf, INTF_ANSBUFTYPE ansBuf,
                                              INTF_ERRMSGTYPE errMsg, std::map<int, std::string>& args) INTF_FUNCTIONSET;

	private:
		bool isConnect;
	};

}
#endif
