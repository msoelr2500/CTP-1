#ifndef _DATASTRUCT_H_
#define _DATASTRUCT_H_

#include "BasicType.h"

namespace ogs {

#define PASSWORDSIZE 23
#define SYSORDERIDSIZE 24
#define MACSIZE 16
#define IPSIZE 16
#define DISKSNSIZE 24
#define BACIDSIZE 32
#define ACIDCARDSIZE 32

    enum MessageType {
        kMtLogin = 8000,
        kMtSendOrder,
        kMtCancelOrder,
        kMtQueryOrder,
        kMtQueryBargain,
        kMtQueryFundInfo,
        kMtQueryPosition,
        kMtHeartBeat,
        kMtLoginAns,
        kMtSendOrderAns,
        kMtCancelOrderAns,
        kMtQueryOrderAns,     //8011 [ogs internal]
        kMtQueryBargainAns,
        kMtQueryFundInfoAns,
        kMtQueryPositionAns,
        kMtHeartBeatAns,
        kMtErrorInfoAns,
        kMtQueryOrderSe,     //queryorder stock edition,queryorder to brokerage
        kMtQueryOrderSeAns,
        kMtPaybackSecurity,
        kMtPaybackSecurityAns,  //8020
        kMtPaybackFunds,
        kMtPaybackFundsAns
    };

/****************************/
    typedef struct LoginQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];      //customer id
        OGS_BACID bacid[BACIDSIZE];         //customer financial id
        OGS_ACTYPE actype;        //account type
        OGS_PASSWORD password[PASSWORDSIZE];  //password
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PLoginQry;

    typedef struct LoginAns {
        OGS_BACID bacid[BACIDSIZE];
        //OGS_ACARD       acard[23];     //stockholder account id
    } *PLoginAns;

/****************************/
    typedef struct SendOrderQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_INNERCODE innerCode;    //stock innercode
        OGS_DIRECTIVE directive;    //business action
        OGS_EXECUTION execution;    //business action trade type
        OGS_PRICE price;        //real price *10000
        OGS_VOLUME volume;
        OGS_CUSTORDERID custOrderId;  //customer order id
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PSendOrderQry;

    typedef struct SendOrderAns {
        OGS_BACID bacid[BACIDSIZE];
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE]; //order id from securities company
    } *PSendOrderAns;

/****************************/
    typedef struct CancelOrderQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_INNERCODE innerCode;
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PCancelOrderQry;

    typedef struct CancelOrderAns {
        OGS_BACID bacid[BACIDSIZE];
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
    } *PCancelOrderAns;

/****************************/
    typedef struct QueryOrderQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_INNERCODE innerCode;
        OGS_DIRECTIVE directive;
        OGS_EXECUTION execution;
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PQueryOrderQry;

    typedef struct QueryOrderAns {
        OGS_BACID bacid[BACIDSIZE];
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
        OGS_PRICE price;
        OGS_VOLUME volume;
        OGS_ORDERSTATUS orderStatus;
        OGS_DEALVOLUME dealVolume;
        OGS_DEALBALANCE dealBalance;
        OGS_DEALPRICE dealPrice;
        OGS_INNERCODE innerCode;
        OGS_WITHDRAWVOLUME withdrawVolume;
        OGS_DIRECTIVE directive;
        OGS_TRADEDATE tradeDate;
        OGS_ORDERTIME orderTime;
    } *PQueryOrderAns;

/****************************/
    typedef struct QueryBargainQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_INNERCODE innerCode;
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PQueryBargainQry;

    typedef struct QueryBargainAns {
        OGS_BACID bacid[BACIDSIZE];
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
        OGS_INNERCODE innerCode;
        OGS_DEALID dealId[24];
        OGS_DEALVOLUME dealVolume;
        OGS_DEALBALANCE dealBalance;
        OGS_DEALPRICE dealPrice;
    } *PQueryBargainAns;

/****************************/
    typedef struct QueryFundInfoQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PQueryFundInfoQry;

    typedef struct QueryFundInfoAns {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_BALANCE balance;
        OGS_USEABLEBALANCE useableBalance;
        OGS_FROZENBALANCE frozenBalance;
    } *PQueryFundInfoAns;

/****************************/
    typedef struct QueryPositionQry {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_INNERCODE innerCode;
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PQueryPositionQry;

    typedef struct QueryPositionAns {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_INNERCODE innerCode;
        OGS_CURRENTVOLUME currentVolume;
        OGS_USABLEVOLUME usableVolume;
    } *PQueryPositionAns;

/****************************/
    typedef struct PaybackSecurityQry{
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_INNERCODE innerCode;
        OGS_REPAYVOLUME repayVolume;
        OGS_OMSORDERID omsOrderId;
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PPaybackSecurityQry;

    typedef struct PaybackSecurityAns{
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_INNERCODE innerCode;
        OGS_OMSORDERID omsOrderId;
        OGS_REPAYVOLUMEREAL repayVolumeReal;
    } *PPaybackSecurityAns;

/****************************/
    typedef struct PaybackFundsQry{
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_REPAYAMT repayAmt;
        OGS_OMSORDERID omsOrderId;
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
    } *PPaybackFundsQry;

    typedef struct PaybackFundsAns{
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_OMSORDERID omsOrderId;
        OGS_REPAYAMTREAL repayAmtReal;
    } *PPaybackFundsAns;

/****************************/
    typedef struct HeartBeatQry{
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
    } *PHeartBeatQry;

    typedef struct HeartBeatAns{
        OGS_SYSSTATUS sysStatus;
        OGS_SYSDATE sysDate;
        OGS_SYSTIME sysTime;
    } *PHeartBeatAns;
/****************************/
    typedef struct OrderInfo {
        OGS_ACIDCARD acidcard[ACIDCARDSIZE];
        OGS_BACID bacid[BACIDSIZE];
        OGS_ACTYPE actype;
        OGS_PASSWORD password[PASSWORDSIZE];
        OGS_IPADDR ipAddr[IPSIZE];
        OGS_MACADDR macAddr[MACSIZE];
        OGS_DISKSN diskSn[DISKSNSIZE];
        OGS_INNERCODE innerCode;
        OGS_DIRECTIVE directive;
        OGS_EXECUTION execution;
        OGS_PRICE price;
        OGS_VOLUME volume;
        OGS_CUSTORDERID custOrderId;
        OGS_SYSORDERID sysOrderId[SYSORDERIDSIZE];
        OGS_ORDERSTATUS orderStatus;
        OGS_DEALVOLUME dealVolume;
        OGS_DEALBALANCE dealBalance;
        OGS_DEALPRICE dealPrice;
        OGS_WITHDRAWVOLUME withdrawVolume;
        OGS_TRADEDATE tradeDate;
        OGS_ORDERTIME orderTime;
        OGS_SESSIONID sessionid;
    } *POrderInfo;

/****************************/
}
#endif
