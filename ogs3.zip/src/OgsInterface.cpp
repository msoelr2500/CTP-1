///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-25
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "OgsInterface.h"

using namespace std;

namespace ogs {

Intf_RetType OgsInterface::setSubscribe(vector<string> &vSubParams) { return kIntfSuccess; }

Intf_RetType OgsInterface::login(const string &qryBuf, string &ansBuf, string &errMsg, vector<string> &vSubParams, map<int, string>& args)
{
    auto func = [&](const ogs::LoginQry &in, list<ogs::LoginAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsLogin(in, out, errMsg, args); };
    return operation<ogs::LoginQry, ogs::LoginAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::sendOrder(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::SendOrderQry &in, list<ogs::SendOrderAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsSendOrder(in, out, errMsg, args); };
    return operation<ogs::SendOrderQry, ogs::SendOrderAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::cancelOrder(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::CancelOrderQry &in, list<ogs::CancelOrderAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsCancelOrder(in, out, errMsg, args); };
    return operation<ogs::CancelOrderQry, ogs::CancelOrderAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::queryOrder(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::QueryOrderQry &in, list<ogs::QueryOrderAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsQueryOrder(in, out, errMsg, args); };
    return operation<ogs::QueryOrderQry, ogs::QueryOrderAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::queryBargain(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::QueryBargainQry &in, list<ogs::QueryBargainAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsQueryBargain(in, out, errMsg, args); };
    return operation<ogs::QueryBargainQry, ogs::QueryBargainAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::queryFundInfo(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::QueryFundInfoQry &in, list<ogs::QueryFundInfoAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsQueryFundInfo(in, out, errMsg, args); };
    return operation<ogs::QueryFundInfoQry, ogs::QueryFundInfoAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::queryPosition(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::QueryPositionQry &in, list<ogs::QueryPositionAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsQueryPosition(in, out, errMsg, args); };
    return operation<ogs::QueryPositionQry, ogs::QueryPositionAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::paybackSecurity(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::PaybackSecurityQry &in, list<ogs::PaybackSecurityAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsPaybackSecurity(in, out, errMsg, args); };
    return operation<ogs::PaybackSecurityQry, ogs::PaybackSecurityAns>(qryBuf, ansBuf, errMsg, args, func);
}

Intf_RetType OgsInterface::paybackFunds(const string &qryBuf, string &ansBuf, string &errMsg, map<int, string>& args)
{
    auto func = [&](const ogs::PaybackFundsQry &in, list<ogs::PaybackFundsAns> &out, string &errMsg, map<int, string>& args) -> Intf_RetType { return ogsPaybackFunds(in, out, errMsg, args); };
    return operation<ogs::PaybackFundsQry, ogs::PaybackFundsAns>(qryBuf, ansBuf, errMsg, args, func);
}

bool OgsInterface::isFundAccountEnabled(const ogs::OGS_BACID *bacid) { return true; }

LoginAns OgsInterface::createErrorAns(const LoginQry &in)
{
    LoginAns out = {0};
    strcpy(out.bacid, in.bacid);
    return out;
}

SendOrderAns OgsInterface::createErrorAns(const SendOrderQry &in)
{
    SendOrderAns out = {0};
    strcpy(out.bacid, in.bacid);
    out.custOrderId = in.custOrderId;
    return out;
}

CancelOrderAns OgsInterface::createErrorAns(const CancelOrderQry &in)
{
    CancelOrderAns out = {0};
    strcpy(out.bacid, in.bacid);
    out.custOrderId = in.custOrderId;
    return out;
}

QueryOrderAns OgsInterface::createErrorAns(const QueryOrderQry &in)
{
    QueryOrderAns out = {0};
    strcpy(out.bacid, in.bacid);
    out.custOrderId = in.custOrderId;
    return out;
}

QueryPositionAns OgsInterface::createErrorAns(const QueryPositionQry &in)
{
    QueryPositionAns out = {0};
    strcpy(out.bacid, in.bacid);
    strcpy(out.acidcard, in.acidcard);
    return out;
}

QueryBargainAns OgsInterface::createErrorAns(const QueryBargainQry &in)
{
    QueryBargainAns out = {0};
    strcpy(out.bacid, in.bacid);
    out.custOrderId = in.custOrderId;
    return out;
}

QueryFundInfoAns OgsInterface::createErrorAns(const QueryFundInfoQry &in)
{
    QueryFundInfoAns out = {0};
    strcpy(out.bacid, in.bacid);
    strcpy(out.acidcard, in.acidcard);
    return out;
}

PaybackSecurityAns OgsInterface::createErrorAns(const PaybackSecurityQry &in)
{
    PaybackSecurityAns out = {0};
    strcpy(out.bacid, in.bacid);
    strcpy(out.acidcard, in.acidcard);
    out.omsOrderId  = in.omsOrderId;
    return out;
}

PaybackFundsAns OgsInterface::createErrorAns(const PaybackFundsQry &in)
{
    PaybackFundsAns out = {0};
    strcpy(out.bacid, in.bacid);
    strcpy(out.acidcard, in.acidcard);
    out.omsOrderId  = in.omsOrderId;
    return out;
}

HeartBeatAns OgsInterface::createErrorAns(const HeartBeatQry &in)
{
    OGS_UNUSED(in);
    HeartBeatAns out = {0};
    return out;
}

}
