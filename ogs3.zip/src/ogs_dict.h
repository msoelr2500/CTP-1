//
// Created by lwk on 16-5-18.
//

#ifndef OGS_DICTIONARY_H
#define OGS_DICTIONARY_H

namespace ogs {
    namespace ogs_dict {
//指令类型
        /*enum DirectiveType {
            kDtBuy = 1,               //买卖
            kDtSell = 2,
            kDtMarketMarginSell = 3,  //融券卖出(市场券)
            kDtMarginSell = 4,        //融券卖出(预约券)
            kDtLoanBuy = 5,           //市场融资买入
            kDtGuaranteeBuy = 6,      //担保品买入
            kDtGuaranteeSell = 7,     //担保品卖出
            kDtBuyPayback = 8,        //买券还券
            kDtSellPayBack = 9,       //卖券还款

            kDtApplyParch = 21,   //申购
            kDTRedemption = 22,   //赎回
        };*/
enum DirectiveType {
            kDtBuy = 1,           //买卖
            kDtSell = 2,
            kDtMarketMarginSell = 3,    //融券卖出(市场券)
            kDtMarginSell = 4,    //融券卖出(预约券)
            kDtLoanBuy = 5, // 市场融资买入
            kDtGuaranteeBuy = 6, // 担保品买入
            kDtGuaranteeSell = 7, // 担保品卖出
            kDtMarketSecPayback = 8, // 现券还券(市场券)
            kDtSecPayback = 9,    //现券还券(预约券)
            kDtBuyPayback = 10,    //买券还券
            kDtCashRepay = 11, // 现金还款
            kDtSellPayBack = 12       //卖券还款
            //kDtApplyParch = 11,   //申购
            //kDTRedemption = 12,   //赎回
        };


//买卖方向
        enum SideType {
            kStBuy = 1,
            kStSell,
        };

//开平标志
        enum OffsetType {
        };

        enum ExecutionType {
            kExeLimit = 0,  //限价
        };

        enum OrderStatusType {
            kOtNotApproved = -1,
            kOtNotReported = 0,
            kOtWaitReporting = 1,
            kOtReported = 2,
            kOtCanceling = 3,
            kOtMatchedCanceling = 4,
            kOtMatchedCanceled = 5,
            kOtCanceled = 6,
            kOtPartMatched = 7,
            kOtMatchedAll = 8,
            kOtBad = 9,
            kOtRiskBlocked = 40,
        };

        enum TradeAccountType {
            kStockNoraml = 1,
            kStockCredit,
            kFutureSpeculate,
            kFutureHedge,
        };
    } //namespace ogs_dict
} //namespace ogs

#endif //OGS_DICTIONARY_H
