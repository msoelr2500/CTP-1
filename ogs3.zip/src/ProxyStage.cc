//
// Created by lwk on 16-6-1.
//

#include "ProxyStage.h"
#include "OgsForwarder.h"
#include "Module.h"

namespace ogs {

    ProxyStage::ProxyStage(Module *modulePtr) {
        m_ModulePtr = modulePtr;
    }

    ProxyStage::~ProxyStage() {

    }

    int ProxyStage::OnEvent(qtp::QtpMessagePtr message) {
        VLOG(200) << "[ProxyStage] got a message.";
        OgsForwarder::SendMessage(m_ModulePtr->getActiveStageId(), message);
        return 0;
    }

}
