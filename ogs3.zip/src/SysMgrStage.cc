//
// Created by lwk on 16-5-13.
//

#include "SysMgrStage.h"
#include "OgsMessage.h"
#include "OgsForwarder.h"

namespace ogs {

    SysMgrStage::SysMgrStage() {

    }

    SysMgrStage::~SysMgrStage() {

    }

    int SysMgrStage::OnEvent(qtp::QtpMessagePtr message) {
        switch (message->MsgType()) {
            case kMtHeartBeat:   //heartbeat from oms
                HandleHeartBeat(message);
                break;
        }
        return 0;
    }

    int SysMgrStage::HandleHeartBeat(qtp::QtpMessagePtr message) {
        OgsMessage ogsMessage(message);
        HeartBeatQry* array;
        if (ogsMessage.isCorrupted() || !ogsMessage.parse(&array)) {
            LOG(error) << "[SysMgrStage] [HandleHeartBeat] " << ogsMessage.error();
            return -1;
        }

        VLOG(200)<<"[SysMgrStage] [HandleHeartBeat]";

        std::string buffer;
        for (uint32_t i = 0; i < ogsMessage.itemCount(); ++i) {
            HeartBeatAns heartBeatAns;
            heartBeatAns.sysStatus = 0;
            heartBeatAns.sysDate = GetDateYMD();
            heartBeatAns.sysTime = GetTimeHMS();
            buffer.append((const char *)&heartBeatAns,sizeof(HeartBeatAns));
        }

        qtp::QtpMessagePtr response = std::make_shared<qtp::QtpMessage>();
        response->BeginEncode(kMtHeartBeatAns, 0);

        uint32_t item_size = sizeof(HeartBeatAns);
        uint32_t item_cnt = ogsMessage.itemCount();
        SetItemSizeAndCnt(response, item_size, item_cnt);

        response->AddTag(kTagBacid, array[0].bacid, strlen(array[0].bacid));
        response->CopyTag(*message, kTagTime);
        response->CopyTag(*message, kTagSession);
        response->SetData(buffer.c_str(), ogsMessage.itemCount() * sizeof(HeartBeatAns), false);
        response->Encode();

        OgsForwarder::SendMessage(kRepStageID,response);
        return 0;
    }
}
