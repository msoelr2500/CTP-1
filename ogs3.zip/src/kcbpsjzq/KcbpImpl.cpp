﻿/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-07-19
///////////////////////////////////////////////////////////////////////////////

#include "KcbpImpl.h"
#include <qtp_log.h>
#include <iostream>
#include "../BufferHandle.h"
#include "../ReadConfig.h"
#include "../OgsApi.h"
#include "KcbpConverter.h"
#include "KcbpLogger.h"
#include "KcbpDataStruct.h"
#include <qtp_log.h>

using namespace std;
using namespace ogs;

KcbpClientManager KcbpImpl::mClients;

KcbpImpl::KcbpImpl()
{
    mConfig.mSiteInfoFormat = ReadConfig::localOption.SiteInfoFormat;
    mConfig.mServerName     = ReadConfig::localOption.Reserve1;
    mConfig.mSendQName      = ReadConfig::localOption.Reserve2;
    mConfig.mReceiveQName   = ReadConfig::localOption.Reserve3;
    mConfig.mUserName       = ReadConfig::localOption.Reserve4;
    mConfig.mPassword       = ReadConfig::localOption.Reserve5;
    mConfig.mServerIp       = ReadConfig::localOption.BrokerAddr;
    mConfig.mServerPort     = atoi(ReadConfig::localOption.BrokerPort.c_str());

    mConfig.mOperWay        = ReadConfig::localOption.EntrustMode;
    mConfig.mOrgId          = ReadConfig::localOption.BranchNo;

    mConnection.setConfig(mConfig);
}

KcbpImpl::~KcbpImpl() {}

bool KcbpImpl::initialize()
{
    return mConnection.initialize();
}

bool KcbpImpl::connect()
{
    return mConnection.connect();
}

void KcbpImpl::disconnect()
{
    mConnection.disconnect();
}

Intf_RetType KcbpImpl::heartBeatToBroker()
{
    return kIntfNotSupport;
}

void KcbpImpl::setCallBack(int (*fn)(QueryOrderAns))
{
    func = fn;
}

bool KcbpImpl::isConnected() const
{
    return mConnection.isConnected();
}

Intf_RetType KcbpImpl::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string> &args)
{
    out.clear();

    char funcCode[] = "410301";

    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)funcCode);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;

    ClientLoginInput input;
    if (strlen(in.bacid) != 0) {
        input.inputtype = "Z";
        input.inputid   = in.bacid;
    } else {
        input.inputtype = "C";
        input.inputid   = in.acidcard;
    }

    // 调用接口。
    std::list<ClientLoginOutput> output;
    Intf_RetType result = mConnection.kcbpClientLogin(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    map<string, KcbpClient> clients;
    for (ClientLoginOutput& item : output) {
        KcbpClient& client = clients[item.custid];
        client.client_id          = item.custid;
        client.mData.custprop     = item.custprop;
        client.mData.custname     = item.custname;
        client.mData.orgid        = item.orgid;
        client.mData.identitysign = item.identitysign;
        client.mData.timeoutflag  = item.timeoutflag;
        client.mData.authlevel    = item.authlevel;
        client.mData.pwderrtimes  = item.pwderrtimes;
        client.mData.custcert     = item.custcert;

        int fIndex = client.indexOf(item.fundid);
        if (fIndex < 0) {
            KcbpFundAccount fundAccount;
            fundAccount.fund_account     = item.fundid;
            fundAccount.mData.bankcode   = item.bankcode;
            fIndex = client.addNewFundAccount(fundAccount);

            // 仅当出现了新的资金账号时才会加入新的LoginAns。
            ogs::LoginAns ans = {0};
            KcbpConverter::from_fundid(ans.bacid, item.fundid);
            out.push_back(ans);
        }

        KcbpFundAccount& fundAccount = client[fIndex];
        Exchange exchange = KcbpConverter::to_exchange_index(item.market);

        if (AccountHelper::isExchangeValid(exchange)) {
            KcbpTradeAccount& account = fundAccount[exchange];
            account.stock_account = item.secuid;
            account.market        = item.market;
            account.name          = item.name;
            account.bankcode      = item.bankcode;
            account.enabled       = true;
        }
    }

    for (map<string, KcbpClient>::const_iterator i = clients.begin(); i != clients.end(); ++i) {
        mClients.addNewClient(i->second);
    }

    mClients.printAccounts();

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    SecuEntrustInput input;
    input.market        = KcbpConverter::to_market(market);
    input.secuid        = tradeAccount.stock_account;
    input.fundid        = KcbpConverter::to_fundid(in.bacid);
    input.stkcode       = KcbpConverter::to_stkcode(code);
    input.bsflag        = KcbpConverter::to_bsflag(in.directive);
    input.price         = KcbpConverter::to_price(in.price);
    input.qty           = KcbpConverter::to_qty(in.volume);
    input.ordergroup    = "0";

    // 调用接口。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)in.acidcard);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;
    fixedInput.custcert  = clientData.custcert;

    std::list<SecuEntrustOutput> output;
    Intf_RetType result = mConnection.kcbpSecuEntrust(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        // 下单出错，则需要打包无效订单返回。
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        out.push_back(ans);
        return result;
    }

    // 处理输出。
    for (const SecuEntrustOutput& item : output) {
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        KcbpConverter::from_ordersno(item.ordersno, ans.sysOrderId);
        out.push_back(ans);
    }

    return result;
}

Intf_RetType KcbpImpl::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));

    // 设置输入。
    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    SecuEntrustWithdrawInput input;
    input.fundid    = KcbpConverter::to_fundid(in.bacid);
    input.ordersno  = KcbpConverter::to_ordersno(in.sysOrderId);

    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)in.acidcard);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;
    fixedInput.custcert  = clientData.custcert;

    std::list<SecuEntrustWithdrawOutput> output;
    Intf_RetType result = mConnection.kcbpSecuEntrustWithdraw(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (const SecuEntrustWithdrawOutput& item : output) {
        ogs::CancelOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        errMsg = StringHelper::convertCodec(item.msgok);
        // no sysOrderId
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));
    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)in.acidcard);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;
    fixedInput.custcert  = clientData.custcert;

    // 初始化输入。
    SecuEntrustQryInput input;
    input.market   = KcbpConverter::to_market(market);
    input.fundid   = KcbpConverter::to_fundid(in.bacid);
    input.secuid   = tradeAccount.stock_account;
    input.stkcode  = KcbpConverter::to_stkcode(code);
    input.ordersno = KcbpConverter::to_ordersno(in.sysOrderId);
    input.qryflag  = "1";
    //input.count    = ;

    // 调用接口。
    std::list<SecuEntrustQryOutput> output;
    Intf_RetType result = mConnection.kcbpSecuEntrustQry(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (const SecuEntrustQryOutput& item : output) {
        QueryOrderAns ans  = {0};
        KcbpConverter::from_fundid(ans.bacid, item.fundid);
        ans.custOrderId    = in.custOrderId;
        ans.tradeDate      = KcbpConverter::from_orderdate(item.orderdate);
        ans.orderTime      = KcbpConverter::from_opertime(item.opertime);
        KcbpConverter::from_ordersno(item.ordersno, ans.sysOrderId);
        ans.directive      = KcbpConverter::from_operation(item.bsflag);
        ans.price          = KcbpConverter::from_orderprice(item.orderprice);
        ans.volume         = KcbpConverter::from_orderqty(item.orderqty);
        ans.dealVolume     = KcbpConverter::from_matchqty(item.matchqty);
        ans.dealBalance    = KcbpConverter::from_matchamt(item.matchamt);
        ans.dealPrice      = ans.dealVolume == 0 ? ans.price : (ans.dealBalance / ans.dealVolume);
        ans.withdrawVolume = KcbpConverter::from_cancelqty(item.cancelqty);
        ans.orderStatus    = KcbpConverter::from_orderstatus(item.orderstatus);
        ans.innerCode      = KcbpConverter::from_stkcode(item.stkcode);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)in.acidcard);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;
    fixedInput.custcert  = clientData.custcert;

    SecuUnitStkQryInput input;
    input.market  = KcbpConverter::to_market(market);
    input.fundid  = KcbpConverter::to_fundid(in.bacid);
    input.secuid  = tradeAccount.stock_account;
    input.stkcode = KcbpConverter::to_stkcode(code);
    input.qryflag = "1";

    // 调用接口。
    std::list<SecuUnitStkQryOutput> output;
    Intf_RetType result = mConnection.kcbpSecuUnitStkQry(fixedInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const SecuUnitStkQryOutput& item : output) {
        ogs::QueryPositionAns ans = {0};
        KcbpConverter::from_custid(ans.acidcard, item.custid);
        KcbpConverter::from_fundid(ans.bacid, item.fundid);
        ans.innerCode = KcbpConverter::from_stkcode(item.stkcode);
        ans.currentVolume = KcbpConverter::from_stkqty(item.stkqty);
        ans.usableVolume = KcbpConverter::from_stkavl(item.stkavl);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));
    // 设置输入。

    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)in.acidcard);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;
    fixedInput.custcert  = clientData.custcert;

    SecuRealDealQryInput input;
    input.fundid   = KcbpConverter::to_fundid(in.bacid);
    input.market   = KcbpConverter::to_market(market);
    input.secuid   = tradeAccount.stock_account;
    input.stkcode  = KcbpConverter::to_stkcode(code);
    input.ordersno = KcbpConverter::to_ordersno(in.sysOrderId);
    input.qryflag  = "1";
    //input.count    = ;

    // 调用接口。
    std::list<SecuRealDealQryOutput> output;
    Intf_RetType result = mConnection.kcbpSecuRealDealQry(fixedInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const SecuRealDealQryOutput& item : output) {
        ogs::QueryBargainAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId   = in.custOrderId;
        ans.dealBalance   = KcbpConverter::from_matchamt(item.matchamt);
        ans.dealPrice     = KcbpConverter::from_matchprice(item.matchprice);
        ans.innerCode     = KcbpConverter::from_stkcode(item.stkcode);
        ans.dealVolume    = KcbpConverter::from_matchqty(item.matchqty);
        KcbpConverter::from_matchcode(item.matchcode, ans.dealId);
        KcbpConverter::from_ordersno(item.ordersno, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));

    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd((unsigned char*)in.password, (unsigned char*)in.acidcard);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;
    fixedInput.netaddr2  = in.macAddr;
    fixedInput.custcert  = clientData.custcert;

    QryFundAssetInput input;
    input.fundid = KcbpConverter::to_fundid(in.bacid);

    // 调用接口。
    std::list<QryFundAssetOutput> output;
    Intf_RetType result = mConnection.kcbpQryFundAsset(fixedInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const QryFundAssetOutput& item : output) {
        ogs::QueryFundInfoAns ans = {0};
        KcbpConverter::from_custid(ans.acidcard, item.custid);
        KcbpConverter::from_fundid(ans.bacid, item.fundid);
        ans.balance        = KcbpConverter::from_fund(item.fundbal);
        ans.useableBalance = KcbpConverter::from_fundavl(item.fundavl);
        ans.frozenBalance  = ans.balance - ans.frozenBalance;
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

Intf_RetType KcbpImpl::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

string KcbpImpl::default_op_station(const char *mac)
{
    return mac;
}

string KcbpImpl::op_station(map<int, string> &args)
{
    // 默认使用配置文件中的站点信息格式。
    if (!mConfig.mSiteInfoFormat.empty()) {
        return ogs::SiteInfo(mConfig.mSiteInfoFormat, args);
    }

    // 配置文件中未制定站点信息格式，则使用默认格式。
    string mac       = args[2];

    return default_op_station(mac.c_str());
}
