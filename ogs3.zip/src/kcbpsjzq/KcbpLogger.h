/****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 ****************************************************************************/

///===========================================================================
/// \module ogs3
/// \author 杨翌超
/// \date 2017-01-05
///===========================================================================

#ifndef KCBPLOGGER_H
#define KCBPLOGGER_H

#include "KcbpGlobal.h"
#include "../OgsLogger.h"
#include "KcbpApiWrapper.h"
#include "KcbpDataStruct.h"
#include "KcbpApiWrapper.h"
#include <iostream>

#define kcbpLogger ogsLogger
#define kcbpDebug ogsDebug << "["<< INTERFACE_NAME << "] "
#define kcbpInfo ogsInfo << "["<< INTERFACE_NAME << "] "
#define kcbpError ogsError << "["<< INTERFACE_NAME << "] "
#define kcbpWarn ogsWarn << "["<< INTERFACE_NAME << "] "
#define kcbpCout ogsDebug << "[" << INTERFACE_NAME << "] "

OgsLogger& operator << (OgsLogger& logger, const KcbpFixedInput& data);

OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data);
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySecuHolderInput& data);
OgsLogger& operator << (OgsLogger& logger, const QrySecuHolderOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryFundAssetInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryFundAssetOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkSumQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkSumQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoByFundIdInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoByFundIdOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealTodaySumQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealTodaySumQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealSumQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealSumQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustSumQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustSumQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoBySecuIdInput& data);
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoBySecuIdOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SetClientTokenStatusInput& data);
OgsLogger& operator << (OgsLogger& logger, const SetClientTokenStatusOutput& data);

#endif
