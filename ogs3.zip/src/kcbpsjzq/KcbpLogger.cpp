/****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 ****************************************************************************/

///===========================================================================
/// \module ogs3
/// \author 杨翌超
/// \date 2017-01-05
///===========================================================================

#include "KcbpLogger.h"

OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[ClientLoginInput]=====================";
    ogsDebug << "|inputtype                    |" << data.inputtype;
    ogsDebug << "|inputid                      |" << data.inputid;
    ogsDebug << "|proc_name                    |" << data.proc_name;
    ogsDebug << "|cert                         |" << data.cert;
    ogsDebug << "|certtype                     |" << data.certtype;
    ogsDebug << "|userrole                     |" << data.userrole;
    ogsDebug << "|randcode                     |" << data.randcode;
    ogsDebug << "|signedrandcode               |" << data.signedrandcode;
    ogsDebug << "|etokenpin                    |" << data.etokenpin;
    ogsDebug << "|dynpwd                       |" << data.dynpwd;
    ogsDebug << "|loginsite                    |" << data.loginsite;
    ogsDebug << "|loginip                      |" << data.loginip;
    ogsDebug << "|mac                          |" << data.mac;
    ogsDebug << "|cpusn                        |" << data.cpusn;
    ogsDebug << "|hddsn                        |" << data.hddsn;
    ogsDebug << "|checkauthflag                |" << data.checkauthflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[ClientLoginOutput]=====================";
    ogsDebug << "|custprop                     |" << data.custprop;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|name                         |" << data.name;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|identitysign                 |" << data.identitysign;
    ogsDebug << "|timeoutflag                  |" << data.timeoutflag;
    ogsDebug << "|authlevel                    |" << data.authlevel;
    ogsDebug << "|pwderrtimes                  |" << data.pwderrtimes;
    ogsDebug << "|singleflag                   |" << data.singleflag;
    ogsDebug << "|checkpwdflag                 |" << data.checkpwdflag;
    ogsDebug << "|custcert                     |" << data.custcert;
    ogsDebug << "|tokenlen                     |" << data.tokenlen;
    ogsDebug << "|lastlogindate                |" << data.lastlogindate;
    ogsDebug << "|lastlogintime                |" << data.lastlogintime;
    ogsDebug << "|lastloginip                  |" << data.lastloginip;
    ogsDebug << "|lastloginmac                 |" << data.lastloginmac;
    ogsDebug << "|inputtype                    |" << data.inputtype;
    ogsDebug << "|inputid                      |" << data.inputid;
    ogsDebug << "|tokenenddate                 |" << data.tokenenddate;
    ogsDebug << "|bindflag                     |" << data.bindflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientInfoOutput]====================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|sex                          |" << data.sex;
    ogsDebug << "|addr                         |" << data.addr;
    ogsDebug << "|postid                       |" << data.postid;
    ogsDebug << "|telno                        |" << data.telno;
    ogsDebug << "|mobileno                     |" << data.mobileno;
    ogsDebug << "|email                        |" << data.email;
    ogsDebug << "|opendate                     |" << data.opendate;
    ogsDebug << "|contact                      |" << data.contact;
    ogsDebug << "|contactfrep                  |" << data.contactfrep;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|idtype                       |" << data.idtype;
    ogsDebug << "|idno                         |" << data.idno;
    ogsDebug << "|idbegindate                  |" << data.idbegindate;
    ogsDebug << "|idenddate                    |" << data.idenddate;
    ogsDebug << "|yearchkdate                  |" << data.yearchkdate;
    ogsDebug << "|closedate                    |" << data.closedate;
    ogsDebug << "|policeorg                    |" << data.policeorg;
    ogsDebug << "|edu                          |" << data.edu;
    ogsDebug << "|occtype                      |" << data.occtype;
    ogsDebug << "|contractverno                |" << data.contractverno;
    ogsDebug << "|extprop                      |" << data.extprop;
    ogsDebug << "|pwderrtimes                  |" << data.pwderrtimes;
    ogsDebug << "|timeout                      |" << data.timeout;
    ogsDebug << "|lockflag                     |" << data.lockflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustWithdrawInput]=================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|bankpwd                      |" << data.bankpwd;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuEntrustWithdrawOutput]=================";
    ogsDebug << "|msgok                        |" << data.msgok;
    ogsDebug << "|cancel_status                |" << data.cancel_status;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QrySecuEntrustWithdrawInput]================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QrySecuEntrustWithdrawOutput]===============";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    ogsDebug << "|orcderid                     |" << data.orcderid;
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|opertime                     |" << data.opertime;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|orderstatus                  |" << data.orderstatus;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuHolderInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QrySecuHolderInput]====================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuHolderOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QrySecuHolderOutput]====================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|name                         |" << data.name;
    ogsDebug << "|secuseq                      |" << data.secuseq;
    ogsDebug << "|regflag                      |" << data.regflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundAssetInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryFundAssetInput]=====================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|remark                       |" << data.remark;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundAssetOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryFundAssetOutput]====================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|fundbal                      |" << data.fundbal;
    ogsDebug << "|fundavl                      |" << data.fundavl;
    ogsDebug << "|marketvalue                  |" << data.marketvalue;
    ogsDebug << "|fund                         |" << data.fund;
    ogsDebug << "|stkvalue                     |" << data.stkvalue;
    ogsDebug << "|fundseq                      |" << data.fundseq;
    ogsDebug << "|fundloan                     |" << data.fundloan;
    ogsDebug << "|fundbuy                      |" << data.fundbuy;
    ogsDebug << "|fundsale                     |" << data.fundsale;
    ogsDebug << "|fundfrz                      |" << data.fundfrz;
    ogsDebug << "|fundlastbal                  |" << data.fundlastbal;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryInput]====================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryOutput]===================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|stkbal                       |" << data.stkbal;
    ogsDebug << "|stkavl                       |" << data.stkavl;
    ogsDebug << "|buycost                      |" << data.buycost;
    ogsDebug << "|costprice                    |" << data.costprice;
    ogsDebug << "|mktval                       |" << data.mktval;
    ogsDebug << "|income                       |" << data.income;
    ogsDebug << "|proincome                    |" << data.proincome;
    ogsDebug << "|mtkcalflag                   |" << data.mtkcalflag;
    ogsDebug << "|stkqty                       |" << data.stkqty;
    ogsDebug << "|lastprice                    |" << data.lastprice;
    ogsDebug << "|stktype                      |" << data.stktype;
    ogsDebug << "|profitcost                   |" << data.profitcost;
    ogsDebug << "|profitprice                  |" << data.profitprice;
    ogsDebug << "|stkbuy                       |" << data.stkbuy;
    ogsDebug << "|stksale                      |" << data.stksale;
    ogsDebug << "|stkdiff                      |" << data.stkdiff;
    ogsDebug << "|stkfrz                       |" << data.stkfrz;
    ogsDebug << "|stktrdfrz                    |" << data.stktrdfrz;
    ogsDebug << "|stktrdunfrz                  |" << data.stktrdunfrz;
    ogsDebug << "|stkbuysale                   |" << data.stkbuysale;
    ogsDebug << "|stkuncomebuy                 |" << data.stkuncomebuy;
    ogsDebug << "|stkuncomesale                |" << data.stkuncomesale;
    ogsDebug << "|costprice_ex                 |" << data.costprice_ex;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuUnitStkSumQryInput]==================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|fundid                       |" << data.fundid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuUnitStkSumQryOutput]==================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|stkbal                       |" << data.stkbal;
    ogsDebug << "|stkavl                       |" << data.stkavl;
    ogsDebug << "|buycost                      |" << data.buycost;
    ogsDebug << "|costprice                    |" << data.costprice;
    ogsDebug << "|mktval                       |" << data.mktval;
    ogsDebug << "|income                       |" << data.income;
    ogsDebug << "|mtkcalflag                   |" << data.mtkcalflag;
    ogsDebug << "|stkqty                       |" << data.stkqty;
    ogsDebug << "|lastprice                    |" << data.lastprice;
    ogsDebug << "|stktype                      |" << data.stktype;
    ogsDebug << "|proincome                    |" << data.proincome;
    ogsDebug << "|profitcost                   |" << data.profitcost;
    ogsDebug << "|profitprice                  |" << data.profitprice;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoByFundIdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientInfoByFundIdInput]================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|fundid                       |" << data.fundid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoByFundIdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientInfoByFundIdOutput]================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryInput]====================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|Ordergroup                   |" << data.Ordergroup;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|extsno                       |" << data.extsno;
    ogsDebug << "|qryoperway                   |" << data.qryoperway;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryOutput]===================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|Ordergroup                   |" << data.Ordergroup;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|reporttime                   |" << data.reporttime;
    ogsDebug << "|opertime                     |" << data.opertime;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|prodcode                     |" << data.prodcode;
    ogsDebug << "|prodname                     |" << data.prodname;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderfrzamt                  |" << data.orderfrzamt;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|cancelqty                    |" << data.cancelqty;
    ogsDebug << "|orderstatus                  |" << data.orderstatus;
    ogsDebug << "|seat                         |" << data.seat;
    ogsDebug << "|cancelflag                   |" << data.cancelflag;
    ogsDebug << "|operdate                     |" << data.operdate;
    ogsDebug << "|bondintr                     |" << data.bondintr;
    ogsDebug << "|operway                      |" << data.operway;
    ogsDebug << "|remark                       |" << data.remark;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuRealDealQryInput]===================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|qryoperway                   |" << data.qryoperway;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuRealDealQryOutput]===================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|trddate                      |" << data.trddate;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|prodcode                     |" << data.prodcode;
    ogsDebug << "|prodname                     |" << data.prodname;
    ogsDebug << "|matchtime                    |" << data.matchtime;
    ogsDebug << "|matchcode                    |" << data.matchcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|matchtype                    |" << data.matchtype;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|bondintr                     |" << data.bondintr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealTodaySumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SecuRealDealTodaySumQryInput]===============";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealTodaySumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuRealDealTodaySumQryOutput]===============";
    ogsDebug << "|operdate                     |" << data.operdate;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|matchtype                    |" << data.matchtype;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|bankid                       |" << data.bankid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuRealDealSumQryInput]==================";
    ogsDebug << "|strdate                      |" << data.strdate;
    ogsDebug << "|enddate                      |" << data.enddate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryoperway                   |" << data.qryoperway;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuRealDealSumQryOutput]=================";
    ogsDebug << "|bizdate                      |" << data.bizdate;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|bankid                       |" << data.bankid;
    ogsDebug << "|fee_jsxf                     |" << data.fee_jsxf;
    ogsDebug << "|fee_sxf                      |" << data.fee_sxf;
    ogsDebug << "|fee_yhs                      |" << data.fee_yhs;
    ogsDebug << "|fee_ghf                      |" << data.fee_ghf;
    ogsDebug << "|fee_qsf                      |" << data.fee_qsf;
    ogsDebug << "|fee_jygf                     |" << data.fee_jygf;
    ogsDebug << "|fee_jsf                      |" << data.fee_jsf;
    ogsDebug << "|fee_zgf                      |" << data.fee_zgf;
    ogsDebug << "|fee_qtf                      |" << data.fee_qtf;
    ogsDebug << "|feefront                     |" << data.feefront;
    ogsDebug << "|fundeffect                   |" << data.fundeffect;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuEntrustSumQryInput]==================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustSumQryOutput]==================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderfrzamt                  |" << data.orderfrzamt;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|cancelqty                    |" << data.cancelqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|qty                          |" << data.qty;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoBySecuIdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientInfoBySecuIdInput]================";
    ogsDebug << "|secuid                       |" << data.secuid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoBySecuIdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientInfoBySecuIdOutput]================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[SecuEntrustInput]=====================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|price                        |" << data.price;
    ogsDebug << "|qty                          |" << data.qty;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|creditid                     |" << data.creditid;
    ogsDebug << "|creditflag                   |" << data.creditflag;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|targetseat                   |" << data.targetseat;
    ogsDebug << "|promiseno                    |" << data.promiseno;
    ogsDebug << "|risksno                      |" << data.risksno;
    ogsDebug << "|autoflag                     |" << data.autoflag;
    ogsDebug << "|enddate                      |" << data.enddate;
    ogsDebug << "|linkman                      |" << data.linkman;
    ogsDebug << "|linkway                      |" << data.linkway;
    ogsDebug << "|linkmarket                   |" << data.linkmarket;
    ogsDebug << "|linksecuid                   |" << data.linksecuid;
    ogsDebug << "|sorttype                     |" << data.sorttype;
    ogsDebug << "|mergematchcode               |" << data.mergematchcode;
    ogsDebug << "|mergematchdate               |" << data.mergematchdate;
    ogsDebug << "|oldorderid                   |" << data.oldorderid;
    ogsDebug << "|prodcode                     |" << data.prodcode;
    ogsDebug << "|pricetype                    |" << data.pricetype;
    ogsDebug << "|blackflag                    |" << data.blackflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEntrustOutput]=====================";
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SetClientTokenStatusInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SetClientTokenStatusInput]=================";
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|inputtype                    |" << data.inputtype;
    ogsDebug << "|inputid                      |" << data.inputid;
    ogsDebug << "|custprop                     |" << data.custprop;
    ogsDebug << "|operway                      |" << data.operway;
    ogsDebug << "|tokenstatus                  |" << data.tokenstatus;
    ogsDebug << "|dynpwd                       |" << data.dynpwd;
    ogsDebug << "|etokenpin                    |" << data.etokenpin;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SetClientTokenStatusOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SetClientTokenStatusOutput]================";
    ogsDebug << "|USER_CODE                    |" << data.USER_CODE;
    ogsDebug << "|USER_ROLE                    |" << data.USER_ROLE;
    ogsDebug << "|STATUS                       |" << data.STATUS;
    return logger;
}

OgsLogger &operator << (OgsLogger &logger, const KcbpFixedInput &data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[KcbpFixedInput]=======================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custorgid                    |" << data.custorgid;
    ogsDebug << "|trdpwd                       |" << data.trdpwd;
    ogsDebug << "|netaddr                      |" << data.netaddr;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|operway                      |" << data.operway;
    ogsDebug << "|ext                          |" << data.ext;
    ogsDebug << "|custcert                     |" << data.custcert;
    ogsDebug << "|netaddr2                     |" << data.netaddr2;
    // ogsDebug << "|ticket                       |" << data.ticket;
    return logger;
}

