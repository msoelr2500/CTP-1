/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-08-09
/////////////////////////////////////////////////////////////////////////////

#ifndef KCBP_GLOBAL_H
#define KCBP_GLOBAL_H

#define TARGET_NAME kcbpsjzq
#define INTERFACE_NAME "kcbpsjzq"
#define INTERFACE_OPTIONAL_NAME "KCBPSJZQ"

#include <memory>
#include <string.h>
#include <qtp_version.h>
#include "../ReadConfig.h"
#include "../Interface.h"
#include "KcbpDataStruct.h"

namespace ogs {

#ifdef __cplusplus
    extern "C"
    {
#endif

    /*! \brief kcbp接口库版本声明。*/
    DECLARE_VERSION(TARGET_NAME, 0, 2, 1)

    /*!
     * \brief 构造本模块的接口。
     * \param brokerType [IN] 券商类型。
     * \param inPtr [OUT] 接口指针。
     */
    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr);

    /*!
     * \brief 从给定的数据块中初始化接口。
     * \param src 数据块。
     * \param size 数据块的大小。
     * \return 如果一切顺利，返回0；出现错误则返回-1。
     */
    int LoadLocalOption(void *src, size_t size);

    void LogLibVersion();

#ifdef __cplusplus
    }
#endif

}

#endif //KCBP_GLOBAL_H
