/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////

#include "KcbpApiWrapper.h"
#include "../StringHelper.h"
#include "KcbpReader.h"
#include "KcbpLogger.h"

#define KCBPCLI_SetConstValue(handle, key, value) KCBPCLI_SetValue(handle, (char*)(key), (char*)(value))
#define KCBPCLI_SQLConstExecute(handle, code) KCBPCLI_SQLExecute(handle, (char*)(code))

using namespace std;
using namespace ogs;

std::mutex KcbpApiWrapper::mInitMutex;
tagKCBPConnectOption KcbpApiWrapper::mKCBPConnection = {0};

KcbpApiWrapper::KcbpApiWrapper()
{

}

KcbpApiWrapper::KcbpApiWrapper(const KcbpConfig &config)
{
    setConfig(config);
}

KcbpApiWrapper::~KcbpApiWrapper()
{

}

bool KcbpApiWrapper::initialize()
{
    std::lock_guard<std::mutex> initLock(mInitMutex);
    static bool initialized = false;

    // 只在第一次调用时执行初始化操作。
    if (!initialized) {
        cout << "初始化..." << endl;

        memset(&mKCBPConnection, 0, sizeof(mKCBPConnection));
        strcpy(mKCBPConnection.szServerName,   config().mServerName.c_str());
        strcpy(mKCBPConnection.szAddress,      config().mServerIp.c_str());
        strcpy(mKCBPConnection.szSendQName,    config().mSendQName.c_str());
        strcpy(mKCBPConnection.szReceiveQName, config().mReceiveQName.c_str());

        mKCBPConnection.nProtocal = 0; //tcp
        mKCBPConnection.nPort     = config().mServerPort;

        kcbpDebug << "初始化成功。";
        cout << "初始化成功。" << endl;
        initialized = true;
    }
    return true;
}

bool KcbpApiWrapper::isConnected() const
{
    return mConnected;
}

bool KcbpApiWrapper::resetConnection(KCBPCLIHANDLE &hHandle)
{
    if (hHandle != NULL)
    {
        KCBPCLI_DisConnectForce(hHandle);
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
    }

    // 调用ConnectServer时，API按照ServerName查找服务端的连接参数，当用户设置了连接
    // 选项时，客户端使用该选项中的参数连接服务端，否则在KCBPCli.ini中查找参数

    // 新建KCBP实例
    int result = 0;
    if ((result = KCBPCLI_Init(&hHandle)) != 0)
    {
        kcbpDebug << "error: KCBPCLI_Init() returns " << result;
        return false;
    }

    // 连接KCBP服务器
    if ((result = KCBPCLI_SetOptions(hHandle, KCBP_OPTION_CONNECT, &mKCBPConnection, sizeof(mKCBPConnection))) != 0)
    {
        kcbpDebug << "error: KCBPCLI_SetOptions() returns " << result;
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
        return false;
    }

    // 超时
    int timeout = 30;
    if ((result = KCBPCLI_SetCliTimeOut(hHandle, timeout)) != 0)
    {
        kcbpDebug << "error: KCBPCLI_SetCliTimeOut() returns " << result;
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
        return false;
    }

#if 0
    std::cout << "szAddress      = " << mKCBPConnection.szAddress << std::endl
              << "nPort          = " << mKCBPConnection.nPort << std::endl
              << "szSendQName    = " << mKCBPConnection.szSendQName << std::endl
              << "szReceiveQName = " << mKCBPConnection.szReceiveQName << std::endl
              << "szServerName   = " << mKCBPConnection.szServerName << std::endl
              << "mUserName      = " << config().mUserName.c_str() << std::endl
              << "mPassword      = " << config().mPassword.c_str() << std::endl;
#endif

    // 连接KCBP服务器
    if (result = KCBPCLI_SQLConnect(hHandle,
                                    mKCBPConnection.szServerName,
                                    (char*)config().mUserName.c_str(),
                                    (char*)config().mPassword.c_str()))
    {
        kcbpDebug << "error: KCBPCLI_SQLConnect() returns " << result;
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
        return false;
    }
    return true;
}

bool KcbpApiWrapper::connect()
{
    mConnected = resetConnection(mHandle);
    if (mConnected) {
        std::cout << "连接成功！" << std::endl;
    } else {
        std::cout << "连接失败！" << std::endl;
    }
    return mConnected;
}

void KcbpApiWrapper::sleepFor(int s)
{
#ifdef WIN32
    Sleep(s * 1000);
#else
    sleep(s);
#endif
}

void KcbpApiWrapper::disconnect()
{
    int result = 0;
    if ((result = KCBPCLI_DisConnect(mHandle)) != 0) {
        kcbpError << "error: KCBPCLI_DisConnect returns " << result;
    }
    mConnected = false;
}

void KcbpApiWrapper::setConfig(const KcbpConfig &config)
{
    mConfig = config;
}

const KcbpConfig &KcbpApiWrapper::config() const
{
    return mConfig;
}

void KcbpApiWrapper::safeAssign(std::string &target, const char *source)
{
    if(!source){
        target.clear();
    }else{
        target.assign(source);
    }
}

bool KcbpApiWrapper::isNetworkError(int errCode)
{
    return (errCode == 2003 || errCode == 2004 || errCode == 2055 || errCode == 2054);
}

void KcbpApiWrapper::fillFixedInput(const char *func_code, const KcbpFixedInput &fixedInput, KCBPCLIHANDLE mHandle)
{
    // 输入固定入参。
    KCBPCLI_SetConstValue(mHandle, "funcid",    func_code);
    KCBPCLI_SetConstValue(mHandle, "custid",    fixedInput.custid.c_str());
    KCBPCLI_SetConstValue(mHandle, "custorgid", fixedInput.custorgid.c_str());
    KCBPCLI_SetConstValue(mHandle, "trdpwd",    fixedInput.trdpwd.c_str());
    KCBPCLI_SetConstValue(mHandle, "netaddr",   fixedInput.netaddr.c_str());
    KCBPCLI_SetConstValue(mHandle, "orgid",     fixedInput.orgid.c_str());
    KCBPCLI_SetConstValue(mHandle, "operway",   fixedInput.operway.c_str());
    KCBPCLI_SetConstValue(mHandle, "ext",       fixedInput.ext.c_str());
    KCBPCLI_SetConstValue(mHandle, "custcert",  fixedInput.ext.c_str());
    KCBPCLI_SetConstValue(mHandle, "netaddr2",  fixedInput.ext.c_str());
    // KCBPCLI_SetConstValue(mHandle, "ticket",    fixedInput.ext.c_str());

    // 设置orgid字段
    KCBPCLI_SetSystemParam(mHandle, KCBP_PARAM_RESERVED, const_cast<char*>(fixedInput.orgid.c_str()));
}

/*!
 * \brief [410301] 用户登录
 */
Intf_RetType KcbpApiWrapper::kcbpClientLogin(const KcbpFixedInput& fixedInput, const ClientLoginInput& input, std::list<ClientLoginOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410301", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "inputtype",      input.inputtype.c_str());
    KCBPCLI_SetConstValue(mHandle, "inputid",        input.inputid.c_str());
    KCBPCLI_SetConstValue(mHandle, "proc_name",      input.proc_name.c_str());
    KCBPCLI_SetConstValue(mHandle, "cert",           input.cert.c_str());
    KCBPCLI_SetConstValue(mHandle, "certtype",       input.certtype.c_str());
    KCBPCLI_SetConstValue(mHandle, "userrole",       input.userrole.c_str());
    KCBPCLI_SetConstValue(mHandle, "randcode",       input.randcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "signedrandcode", input.signedrandcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "etokenpin",      input.etokenpin.c_str());
    KCBPCLI_SetConstValue(mHandle, "dynpwd",         input.dynpwd.c_str());
    KCBPCLI_SetConstValue(mHandle, "loginsite",      input.loginsite.c_str());
    KCBPCLI_SetConstValue(mHandle, "loginip",        input.loginip.c_str());
    KCBPCLI_SetConstValue(mHandle, "mac",            input.mac.c_str());
    KCBPCLI_SetConstValue(mHandle, "cpusn",          input.cpusn.c_str());
    KCBPCLI_SetConstValue(mHandle, "hddsn",          input.hddsn.c_str());
    KCBPCLI_SetConstValue(mHandle, "checkauthflag",  input.checkauthflag.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410301");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            ClientLoginOutput out;
            out.custprop      = reader.get("custprop");
            out.market        = reader.get("market");
            out.secuid        = reader.get("secuid");
            out.name          = reader.get("name");
            out.fundid        = reader.get("fundid");
            out.custid        = reader.get("custid");
            out.custname      = reader.get("custname");
            out.orgid         = reader.get("orgid");
            out.bankcode      = reader.get("bankcode");
            out.identitysign  = reader.get("identitysign");
            out.timeoutflag   = reader.get("timeoutflag");
            out.authlevel     = reader.get("authlevel");
            out.pwderrtimes   = reader.get("pwderrtimes");
            out.singleflag    = reader.get("singleflag");
            out.checkpwdflag  = reader.get("checkpwdflag");
            out.custcert      = reader.get("custcert");
            out.tokenlen      = reader.get("tokenlen");
            out.lastlogindate = reader.get("lastlogindate");
            out.lastlogintime = reader.get("lastlogintime");
            out.lastloginip   = reader.get("lastloginip");
            out.lastloginmac  = reader.get("lastloginmac");
            out.inputtype     = reader.get("inputtype");
            out.inputid       = reader.get("inputid");
            out.tokenenddate  = reader.get("tokenenddate");
            out.bindflag      = reader.get("bindflag");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410321] 客户资料查询
 */
Intf_RetType KcbpApiWrapper::kcbpQryClientInfo(const KcbpFixedInput& fixedInput, std::list<QryClientInfoOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410321", fixedInput, mHandle);

    // 输入其他参数。

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410321");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            QryClientInfoOutput out;
            out.custid        = reader.get("custid");
            out.custname      = reader.get("custname");
            out.orgid         = reader.get("orgid");
            out.sex           = reader.get("sex");
            out.addr          = reader.get("addr");
            out.postid        = reader.get("postid");
            out.telno         = reader.get("telno");
            out.mobileno      = reader.get("mobileno");
            out.email         = reader.get("email");
            out.opendate      = reader.get("opendate");
            out.contact       = reader.get("contact");
            out.contactfrep   = reader.get("contactfrep");
            out.remark        = reader.get("remark");
            out.idtype        = reader.get("idtype");
            out.idno          = reader.get("idno");
            out.idbegindate   = reader.get("idbegindate");
            out.idenddate     = reader.get("idenddate");
            out.yearchkdate   = reader.get("yearchkdate");
            out.closedate     = reader.get("closedate");
            out.policeorg     = reader.get("policeorg");
            out.edu           = reader.get("edu");
            out.occtype       = reader.get("occtype");
            out.contractverno = reader.get("contractverno");
            out.extprop       = reader.get("extprop");
            out.pwderrtimes   = reader.get("pwderrtimes");
            out.timeout       = reader.get("timeout");
            out.lockflag      = reader.get("lockflag");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410413] 委托撤单
 */
Intf_RetType KcbpApiWrapper::kcbpSecuEntrustWithdraw(const KcbpFixedInput& fixedInput, const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410413", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "orderdate", input.orderdate.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",    input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "ordersno",  input.ordersno.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankpwd",   input.bankpwd.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410413");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuEntrustWithdrawOutput out;
            out.msgok         = reader.get("msgok");
            out.cancel_status = reader.get("cancel_status");
            out.ordersno      = reader.get("ordersno");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410415] 委托撤单查询
 */
Intf_RetType KcbpApiWrapper::kcbpQrySecuEntrustWithdraw(const KcbpFixedInput& fixedInput, const QrySecuEntrustWithdrawInput& input, std::list<QrySecuEntrustWithdrawOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410415", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "orderdate", input.orderdate.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",    input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",    input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",   input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "ordersno",  input.ordersno.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryflag",   input.qryflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "count",     input.count.c_str());
    KCBPCLI_SetConstValue(mHandle, "poststr",   input.poststr.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410415");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            QrySecuEntrustWithdrawOutput out;
            out.poststr     = reader.get("poststr");
            out.ordersno    = reader.get("ordersno");
            out.ordergroup  = reader.get("ordergroup");
            out.orcderid    = reader.get("orcderid");
            out.orderdate   = reader.get("orderdate");
            out.opertime    = reader.get("opertime");
            out.fundid      = reader.get("fundid");
            out.market      = reader.get("market");
            out.secuid      = reader.get("secuid");
            out.stkcode     = reader.get("stkcode");
            out.stkname     = reader.get("stkname");
            out.bsflag      = reader.get("bsflag");
            out.orderprice  = reader.get("orderprice");
            out.orderqty    = reader.get("orderqty");
            out.matchqty    = reader.get("matchqty");
            out.orderstatus = reader.get("orderstatus");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410501] 客户查询，查询客户股东代码
 */
Intf_RetType KcbpApiWrapper::kcbpQrySecuHolder(const KcbpFixedInput& fixedInput, const QrySecuHolderInput& input, std::list<QrySecuHolderOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410501", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "fundid",  input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "market",  input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",  input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryflag", input.qryflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "count",   input.count.c_str());
    KCBPCLI_SetConstValue(mHandle, "poststr", input.poststr.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410501");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            QrySecuHolderOutput out;
            out.poststr = reader.get("poststr");
            out.custid  = reader.get("custid");
            out.market  = reader.get("market");
            out.secuid  = reader.get("secuid");
            out.name    = reader.get("name");
            out.secuseq = reader.get("secuseq");
            out.regflag = reader.get("regflag");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410502] 资金查询
 */
Intf_RetType KcbpApiWrapper::kcbpQryFundAsset(const KcbpFixedInput& fixedInput, const QryFundAssetInput& input, std::list<QryFundAssetOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410502", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "fundid",    input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "moneytype", input.moneytype.c_str());
    KCBPCLI_SetConstValue(mHandle, "remark",    input.remark.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410502");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            QryFundAssetOutput out;
            out.custid      = reader.get("custid");
            out.fundid      = reader.get("fundid");
            out.orgid       = reader.get("orgid");
            out.moneytype   = reader.get("moneytype");
            out.fundbal     = reader.get("fundbal");
            out.fundavl     = reader.get("fundavl");
            out.marketvalue = reader.get("marketvalue");
            out.fund        = reader.get("fund");
            out.stkvalue    = reader.get("stkvalue");
            out.fundseq     = reader.get("fundseq");
            out.fundloan    = reader.get("fundloan");
            out.fundbuy     = reader.get("fundbuy");
            out.fundsale    = reader.get("fundsale");
            out.fundfrz     = reader.get("fundfrz");
            out.fundlastbal = reader.get("fundlastbal");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410503] 股份明细查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuUnitStkQry(const KcbpFixedInput& fixedInput, const SecuUnitStkQryInput& input, std::list<SecuUnitStkQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410503", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market",  input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",  input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",  input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode", input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryflag", input.qryflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "count",   input.count.c_str());
    KCBPCLI_SetConstValue(mHandle, "poststr", input.poststr.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410503");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuUnitStkQryOutput out;
            out.custid        = reader.get("custid");
            out.fundid        = reader.get("fundid");
            out.market        = reader.get("market");
            out.secuid        = reader.get("secuid");
            out.stkname       = reader.get("stkname");
            out.stkcode       = reader.get("stkcode");
            out.orgid         = reader.get("orgid");
            out.moneytype     = reader.get("moneytype");
            out.stkbal        = reader.get("stkbal");
            out.stkavl        = reader.get("stkavl");
            out.buycost       = reader.get("buycost");
            out.costprice     = reader.get("costprice");
            out.mktval        = reader.get("mktval");
            out.income        = reader.get("income");
            out.proincome     = reader.get("proincome");
            out.mtkcalflag    = reader.get("mtkcalflag");
            out.stkqty        = reader.get("stkqty");
            out.lastprice     = reader.get("lastprice");
            out.stktype       = reader.get("stktype");
            out.profitcost    = reader.get("profitcost");
            out.profitprice   = reader.get("profitprice");
            out.stkbuy        = reader.get("stkbuy");
            out.stksale       = reader.get("stksale");
            out.stkdiff       = reader.get("stkdiff");
            out.stkfrz        = reader.get("stkfrz");
            out.stktrdfrz     = reader.get("stktrdfrz");
            out.stktrdunfrz   = reader.get("stktrdunfrz");
            out.stkbuysale    = reader.get("stkbuysale");
            out.stkuncomebuy  = reader.get("stkuncomebuy");
            out.stkuncomesale = reader.get("stkuncomesale");
            out.costprice_ex  = reader.get("costprice_ex");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410504] 股份汇总查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuUnitStkSumQry(const KcbpFixedInput& fixedInput, const SecuUnitStkSumQryInput& input, std::list<SecuUnitStkSumQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410504", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market",  input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",  input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode", input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",  input.fundid.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410504");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuUnitStkSumQryOutput out;
            out.custid      = reader.get("custid");
            out.market      = reader.get("market");
            out.stkname     = reader.get("stkname");
            out.stkcode     = reader.get("stkcode");
            out.moneytype   = reader.get("moneytype");
            out.stkbal      = reader.get("stkbal");
            out.stkavl      = reader.get("stkavl");
            out.buycost     = reader.get("buycost");
            out.costprice   = reader.get("costprice");
            out.mktval      = reader.get("mktval");
            out.income      = reader.get("income");
            out.mtkcalflag  = reader.get("mtkcalflag");
            out.stkqty      = reader.get("stkqty");
            out.lastprice   = reader.get("lastprice");
            out.stktype     = reader.get("stktype");
            out.proincome   = reader.get("proincome");
            out.profitcost  = reader.get("profitcost");
            out.profitprice = reader.get("profitprice");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410509] 客户查询，根据股东代码，资金帐户查询客户代码
 */
Intf_RetType KcbpApiWrapper::kcbpQryClientInfoByFundId(const KcbpFixedInput& fixedInput, const QryClientInfoByFundIdInput& input, std::list<QryClientInfoByFundIdOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410509", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market", input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid", input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid", input.fundid.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410509");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            QryClientInfoByFundIdOutput out;
            out.custid   = reader.get("custid");
            out.custname = reader.get("custname");
            out.orgid    = reader.get("orgid");
            out.bankcode = reader.get("bankcode");
            out.fundid   = reader.get("fundid");
            out.market   = reader.get("market");
            out.secuid   = reader.get("secuid");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410510] 当日委托查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuEntrustQry(const KcbpFixedInput& fixedInput, const SecuEntrustQryInput& input, std::list<SecuEntrustQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410510", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market",     input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",     input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",     input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",    input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "ordersno",   input.ordersno.c_str());
    KCBPCLI_SetConstValue(mHandle, "Ordergroup", input.Ordergroup.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankcode",   input.bankcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryflag",    input.qryflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "count",      input.count.c_str());
    KCBPCLI_SetConstValue(mHandle, "poststr",    input.poststr.c_str());
    KCBPCLI_SetConstValue(mHandle, "extsno",     input.extsno.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryoperway", input.qryoperway.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410510");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuEntrustQryOutput out;
            out.poststr     = reader.get("poststr");
            out.orderdate   = reader.get("orderdate");
            out.ordersno    = reader.get("ordersno");
            out.Ordergroup  = reader.get("Ordergroup");
            out.custid      = reader.get("custid");
            out.custname    = reader.get("custname");
            out.fundid      = reader.get("fundid");
            out.moneytype   = reader.get("moneytype");
            out.orgid       = reader.get("orgid");
            out.secuid      = reader.get("secuid");
            out.bsflag      = reader.get("bsflag");
            out.orderid     = reader.get("orderid");
            out.reporttime  = reader.get("reporttime");
            out.opertime    = reader.get("opertime");
            out.market      = reader.get("market");
            out.stkcode     = reader.get("stkcode");
            out.stkname     = reader.get("stkname");
            out.prodcode    = reader.get("prodcode");
            out.prodname    = reader.get("prodname");
            out.orderprice  = reader.get("orderprice");
            out.orderqty    = reader.get("orderqty");
            out.orderfrzamt = reader.get("orderfrzamt");
            out.matchqty    = reader.get("matchqty");
            out.matchamt    = reader.get("matchamt");
            out.cancelqty   = reader.get("cancelqty");
            out.orderstatus = reader.get("orderstatus");
            out.seat        = reader.get("seat");
            out.cancelflag  = reader.get("cancelflag");
            out.operdate    = reader.get("operdate");
            out.bondintr    = reader.get("bondintr");
            out.operway     = reader.get("operway");
            out.remark      = reader.get("remark");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410512] 当日成交查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuRealDealQry(const KcbpFixedInput& fixedInput, const SecuRealDealQryInput& input, std::list<SecuRealDealQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410512", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "fundid",     input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "market",     input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",     input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",    input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "ordersno",   input.ordersno.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankcode",   input.bankcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryflag",    input.qryflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "count",      input.count.c_str());
    KCBPCLI_SetConstValue(mHandle, "poststr",    input.poststr.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryoperway", input.qryoperway.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410512");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuRealDealQryOutput out;
            out.poststr    = reader.get("poststr");
            out.trddate    = reader.get("trddate");
            out.secuid     = reader.get("secuid");
            out.bsflag     = reader.get("bsflag");
            out.ordersno   = reader.get("ordersno");
            out.orderid    = reader.get("orderid");
            out.market     = reader.get("market");
            out.stkcode    = reader.get("stkcode");
            out.stkname    = reader.get("stkname");
            out.prodcode   = reader.get("prodcode");
            out.prodname   = reader.get("prodname");
            out.matchtime  = reader.get("matchtime");
            out.matchcode  = reader.get("matchcode");
            out.matchprice = reader.get("matchprice");
            out.matchqty   = reader.get("matchqty");
            out.matchamt   = reader.get("matchamt");
            out.matchtype  = reader.get("matchtype");
            out.orderqty   = reader.get("orderqty");
            out.orderprice = reader.get("orderprice");
            out.bondintr   = reader.get("bondintr");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410516] 当日成交汇总查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuRealDealTodaySumQry(const KcbpFixedInput& fixedInput, const SecuRealDealTodaySumQryInput& input, std::list<SecuRealDealTodaySumQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410516", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market",   input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",   input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",  input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankcode", input.bankcode.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410516");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuRealDealTodaySumQryOutput out;
            out.operdate   = reader.get("operdate");
            out.custid     = reader.get("custid");
            out.custname   = reader.get("custname");
            out.orgid      = reader.get("orgid");
            out.bsflag     = reader.get("bsflag");
            out.market     = reader.get("market");
            out.stkname    = reader.get("stkname");
            out.stkcode    = reader.get("stkcode");
            out.matchprice = reader.get("matchprice");
            out.matchqty   = reader.get("matchqty");
            out.matchamt   = reader.get("matchamt");
            out.matchtype  = reader.get("matchtype");
            out.bankcode   = reader.get("bankcode");
            out.bankid     = reader.get("bankid");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [411517] 成交汇总查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuRealDealSumQry(const KcbpFixedInput& fixedInput, const SecuRealDealSumQryInput& input, std::list<SecuRealDealSumQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("411517", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "strdate",    input.strdate.c_str());
    KCBPCLI_SetConstValue(mHandle, "enddate",    input.enddate.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",     input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "market",     input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",    input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankcode",   input.bankcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "qryoperway", input.qryoperway.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "411517");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuRealDealSumQryOutput out;
            out.bizdate    = reader.get("bizdate");
            out.custid     = reader.get("custid");
            out.custname   = reader.get("custname");
            out.orgid      = reader.get("orgid");
            out.bsflag     = reader.get("bsflag");
            out.market     = reader.get("market");
            out.stkname    = reader.get("stkname");
            out.stkcode    = reader.get("stkcode");
            out.matchprice = reader.get("matchprice");
            out.matchqty   = reader.get("matchqty");
            out.matchamt   = reader.get("matchamt");
            out.bankcode   = reader.get("bankcode");
            out.bankid     = reader.get("bankid");
            out.fee_jsxf   = reader.get("fee_jsxf");
            out.fee_sxf    = reader.get("fee_sxf");
            out.fee_yhs    = reader.get("fee_yhs");
            out.fee_ghf    = reader.get("fee_ghf");
            out.fee_qsf    = reader.get("fee_qsf");
            out.fee_jygf   = reader.get("fee_jygf");
            out.fee_jsf    = reader.get("fee_jsf");
            out.fee_zgf    = reader.get("fee_zgf");
            out.fee_qtf    = reader.get("fee_qtf");
            out.feefront   = reader.get("feefront");
            out.fundeffect = reader.get("fundeffect");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410522] 当日委托汇总查询
 */
Intf_RetType KcbpApiWrapper::kcbpSecuEntrustSumQry(const KcbpFixedInput& fixedInput, const SecuEntrustSumQryInput& input, std::list<SecuEntrustSumQryOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410522", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market",   input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",   input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",  input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankcode", input.bankcode.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410522");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuEntrustSumQryOutput out;
            out.orderdate   = reader.get("orderdate");
            out.ordergroup  = reader.get("ordergroup");
            out.custid      = reader.get("custid");
            out.custname    = reader.get("custname");
            out.orgid       = reader.get("orgid");
            out.bsflag      = reader.get("bsflag");
            out.market      = reader.get("market");
            out.stkname     = reader.get("stkname");
            out.stkcode     = reader.get("stkcode");
            out.orderprice  = reader.get("orderprice");
            out.orderqty    = reader.get("orderqty");
            out.orderfrzamt = reader.get("orderfrzamt");
            out.matchqty    = reader.get("matchqty");
            out.cancelqty   = reader.get("cancelqty");
            out.matchamt    = reader.get("matchamt");
            out.qty         = reader.get("qty");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410531] 客户查询，根据股东代码，资金帐户查询客户代码
 */
Intf_RetType KcbpApiWrapper::kcbpQryClientInfoBySecuId(const KcbpFixedInput& fixedInput, const QryClientInfoBySecuIdInput& input, std::list<QryClientInfoBySecuIdOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410531", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "secuid", input.secuid.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410531");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            QryClientInfoBySecuIdOutput out;
            out.custid = reader.get("custid");
            out.orgid  = reader.get("orgid");
            out.market = reader.get("market");
            out.secuid = reader.get("secuid");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410411] 委托买卖业务,支持三方交易
 */
Intf_RetType KcbpApiWrapper::kcbpSecuEntrust(const KcbpFixedInput& fixedInput, const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410411", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "market",         input.market.c_str());
    KCBPCLI_SetConstValue(mHandle, "secuid",         input.secuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "fundid",         input.fundid.c_str());
    KCBPCLI_SetConstValue(mHandle, "stkcode",        input.stkcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "bsflag",         input.bsflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "price",          input.price.c_str());
    KCBPCLI_SetConstValue(mHandle, "qty",            input.qty.c_str());
    KCBPCLI_SetConstValue(mHandle, "ordergroup",     input.ordergroup.c_str());
    KCBPCLI_SetConstValue(mHandle, "bankcode",       input.bankcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "creditid",       input.creditid.c_str());
    KCBPCLI_SetConstValue(mHandle, "creditflag",     input.creditflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "remark",         input.remark.c_str());
    KCBPCLI_SetConstValue(mHandle, "targetseat",     input.targetseat.c_str());
    KCBPCLI_SetConstValue(mHandle, "promiseno",      input.promiseno.c_str());
    KCBPCLI_SetConstValue(mHandle, "risksno",        input.risksno.c_str());
    KCBPCLI_SetConstValue(mHandle, "autoflag",       input.autoflag.c_str());
    KCBPCLI_SetConstValue(mHandle, "enddate",        input.enddate.c_str());
    KCBPCLI_SetConstValue(mHandle, "linkman",        input.linkman.c_str());
    KCBPCLI_SetConstValue(mHandle, "linkway",        input.linkway.c_str());
    KCBPCLI_SetConstValue(mHandle, "linkmarket",     input.linkmarket.c_str());
    KCBPCLI_SetConstValue(mHandle, "linksecuid",     input.linksecuid.c_str());
    KCBPCLI_SetConstValue(mHandle, "sorttype",       input.sorttype.c_str());
    KCBPCLI_SetConstValue(mHandle, "mergematchcode", input.mergematchcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "mergematchdate", input.mergematchdate.c_str());
    KCBPCLI_SetConstValue(mHandle, "oldorderid",     input.oldorderid.c_str());
    KCBPCLI_SetConstValue(mHandle, "prodcode",       input.prodcode.c_str());
    KCBPCLI_SetConstValue(mHandle, "pricetype",      input.pricetype.c_str());
    KCBPCLI_SetConstValue(mHandle, "blackflag",      input.blackflag.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410411");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SecuEntrustOutput out;
            out.ordersno   = reader.get("ordersno");
            out.orderid    = reader.get("orderid");
            out.ordergroup = reader.get("ordergroup");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
/*!
 * \brief [410308] 客户动态令牌状态设置
 */
Intf_RetType KcbpApiWrapper::kcbpSetClientTokenStatus(const KcbpFixedInput& fixedInput, const SetClientTokenStatusInput& input, std::list<SetClientTokenStatusOutput>& output, std::string& errMsg)
{
    output.clear();
    kcbpLogger() << fixedInput << input;

    int errCode = KCBPCLI_BeginWrite(mHandle);
    if (errCode != 0) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_BeginWrite() returns %d", errCode);
        return kIntfError;
    }

    KcbpApiWrapper::fillFixedInput("410308", fixedInput, mHandle);

    // 输入其他参数。
    KCBPCLI_SetConstValue(mHandle, "orgid",       input.orgid.c_str());
    KCBPCLI_SetConstValue(mHandle, "inputtype",   input.inputtype.c_str());
    KCBPCLI_SetConstValue(mHandle, "inputid",     input.inputid.c_str());
    KCBPCLI_SetConstValue(mHandle, "custprop",    input.custprop.c_str());
    KCBPCLI_SetConstValue(mHandle, "operway",     input.operway.c_str());
    KCBPCLI_SetConstValue(mHandle, "tokenstatus", input.tokenstatus.c_str());
    KCBPCLI_SetConstValue(mHandle, "dynpwd",      input.dynpwd.c_str());
    KCBPCLI_SetConstValue(mHandle, "etokenpin",   input.etokenpin.c_str());

    // 执行业务操作。
    errCode = KCBPCLI_SQLConstExecute(mHandle, "410308");
    if (isNetworkError(errCode)) {
        StringHelper::string_format(errMsg, "error: KCBPCLI_SQLExecute() returns %d", errCode);
        mConnected = false;
        return kIntfSendFail;
    }

    KcbpReader reader(mHandle);
    if (reader.isCorrupted()) {
        errMsg = reader.error();
        return kIntfWorkFail;
    }

    // 读取数据。
    while (reader.hasMoreData()) {
        while (reader.loadRow()) {
            SetClientTokenStatusOutput out;
            out.USER_CODE = reader.get("USER_CODE");
            out.USER_ROLE = reader.get("USER_ROLE");
            out.STATUS    = reader.get("STATUS");
            kcbpLogger() << out;
            output.push_back(out);
        }
    }

    return kIntfSuccess;
}
