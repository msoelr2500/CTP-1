/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef KCBPCONVERTER_H
#define KCBPCONVERTER_H

#include <string>
#include "../DataStruct.h"
#include "../ogs_dict.h"
#include "../universal_code.h"
#include "KcbpAccount.h"

class KcbpConverter
{
public:
    ///--------------------------------------------------------------------------------------------------------
    /// 通用字段
    ///--------------------------------------------------------------------------------------------------------

    // 资金账号
    static std::string to_fund_account(const char* bacid);
    #define to_fundid to_fund_account

    // 客户号
    static std::string to_client_id(const char* acidcard);
    #define to_custid to_client_id

    static void from_string(char* target, const std::string& source);
    #define from_fundid from_string
    #define from_custid from_string

    // 金额
    static ogs::OGS_BALANCE from_balance(const std::string& balance);
    #define from_matchamt from_balance
    #define from_fund from_balance
    #define from_fundbal from_balance
    #define from_fundavl from_balance

    // 证券数量
    static std::string to_amount(ogs::OGS_VOLUME volume);
    #define to_qty to_amount
    static ogs::OGS_VOLUME from_amount(const std::string& amount);
    #define from_qty from_amount
    #define from_orderqty from_amount
    #define from_matchqty from_amount
    #define from_cancelqty from_amount
    #define from_stkqty from_amount
    #define from_stkavl from_amount

    // 价格
    static std::string to_price(uint32_t ogs_price);
    static int from_price(const std::string& price);
    #define from_orderprice from_price
    #define from_matchprice from_price

    // 证券种类/市场
    static Exchange to_exchange_index(const std::string& exchange_type);
    static qtp::MarketCode from_market(const std::string& exchange_type);
    static std::string to_market(qtp::MarketCode code);

    // 证券代码
    static std::string to_stock_code(const std::string& code);
    #define to_stkcode to_stock_code
    static ogs::OGS_INNERCODE from_stock_code(const std::string& stock_code);
    #define from_stkcode from_stock_code

    // 委托序号
    static void from_entrust_no(const std::string& entrust_no, char* sysOrderId);
    #define from_ordersno from_entrust_no
    static std::string to_entrust_no(const char* sysOrderId);
    #define to_ordersno to_entrust_no

    // 成交序号
    static void from_business_no(const std::string& business_no, char* dealId);
    #define from_matchcode from_business_no

    ///--------------------------------------------------------------------------------------------------------
    /// 接口相关字段
    ///--------------------------------------------------------------------------------------------------------

    // 密码
    static std::string to_trdpwd(unsigned char* password, unsigned char* key);

    // 站点信息
    static std::string op_station(const std::string& wip,
                                  const std::string& clientIp,
                                  const std::string& mac,
                                  const std::string& disksn,
                                  const std::string& cpuid);

    // 委托类型
    static std::string to_entrust_type(ogs::OGS_DIRECTIVE type);
    static std::string to_bsflag(ogs::OGS_DIRECTIVE type);
    static ogs::OGS_DIRECTIVE from_operation(const std::string& bsflag);

    // 时间
    static uint32_t from_opertime(const std::string& time);

    // 日期
    static uint32_t from_orderdate(const std::string& date);

    // 订单状态（委托状态）
    static ogs::ogs_dict::OrderStatusType from_orderstatus(const std::string& entrust_status);
};

#endif // KCBPCONVERTER_H
