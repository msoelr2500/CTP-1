/****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 ****************************************************************************/

///===========================================================================
/// \module ogs3
/// \author 杨翌超
/// \date 2017-01-05
///===========================================================================

#ifndef KCBPDATASTRUCT_H
#define KCBPDATASTRUCT_H

#include <string>
struct ClientLoginInput {
    std::string inputtype;              //!< 登录类型
    std::string inputid;                //!< 登录标识
    std::string proc_name;              //!< 第三方厂商名称
    std::string cert;                   //!< 证书
    std::string certtype;               //!< 证书类型
    std::string userrole;               //!< 用户角色
    std::string randcode;               //!< 随机码
    std::string signedrandcode;         //!< 签名后内容
    std::string etokenpin;              //!< 动态口令pin码
    std::string dynpwd;                 //!< 动态口令
    std::string loginsite;              //!< 委托站点
    std::string loginip;                //!< 登录机器IP
    std::string mac;                    //!< 登录机器MAC地址
    std::string cpusn;                  //!< 登录机器cpu序列号
    std::string hddsn;                  //!< 登录机器硬盘序列号
    std::string checkauthflag;          //!< 安全认证检查标志
};
struct ClientLoginOutput {
    std::string custprop;               //!< 客户性质
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string name;                   //!< 股东姓名
    std::string fundid;                 //!< 缺省资金帐户
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bankcode;               //!< 银行代码
    std::string identitysign;           //!< 数字签名
    std::string timeoutflag;            //!< 延时属性
    std::string authlevel;              //!< 认证方式/级别
    std::string pwderrtimes;            //!< 登陆错误次数
    std::string singleflag;             //!< 客户标志
    std::string checkpwdflag;           //!< 密码有效标志
    std::string custcert;               //!< 客户证书
    std::string tokenlen;               //!< 登录时输入的动态令牌长度
    std::string lastlogindate;          //!< 最近登录日期
    std::string lastlogintime;          //!< 最近登录时间
    std::string lastloginip;            //!< 最近登录IP
    std::string lastloginmac;           //!< 最近登录MAC
    std::string inputtype;              //!< 登陆类型
    std::string inputid;                //!< 登陆标识
    std::string tokenenddate;           //!< 客户动态令牌结束日期
    std::string bindflag;               //!< 硬件绑定信息标识
};
struct QryClientInfoOutput {
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string sex;                    //!< 性别
    std::string addr;                   //!< 地址
    std::string postid;                 //!< 邮编
    std::string telno;                  //!< 电话
    std::string mobileno;               //!< 移动电话
    std::string email;                  //!< EMAIL
    std::string opendate;               //!< 开户日期
    std::string contact;                //!< 联络方式
    std::string contactfrep;            //!< 联络频率
    std::string remark;                 //!< 备注信息
    std::string idtype;                 //!< 证件类型
    std::string idno;                   //!< 证件号码
    std::string idbegindate;            //!< 证件有效开始日期
    std::string idenddate;              //!< 证件有效结束日期
    std::string yearchkdate;            //!< 年检日期
    std::string closedate;              //!< 销户日期
    std::string policeorg;              //!< 发证单位
    std::string edu;                    //!< 学历
    std::string occtype;                //!< 职业
    std::string contractverno;          //!< 开户合同版本号
    std::string extprop;                //!< 扩展属性
    std::string pwderrtimes;            //!< 客户密码校验错误次数
    std::string timeout;                //!< 登陆错误延时
    std::string lockflag;               //!< 密码出错锁定
};
struct SecuEntrustWithdrawInput {
    std::string orderdate;              //!< 委托日期
    std::string fundid;                 //!< 资金帐户
    std::string ordersno;               //!< 委托序号
    std::string bankpwd;                //!< 银行密码
};
struct SecuEntrustWithdrawOutput {
    std::string msgok;                  //!< 成功信息
    std::string cancel_status;          //!< 内部撤单标志
    std::string ordersno;               //!< 撤单委托序号
};
struct QrySecuEntrustWithdrawInput {
    std::string orderdate;              //!< 委托日期
    std::string fundid;                 //!< 资金帐户
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct QrySecuEntrustWithdrawOutput {
    std::string poststr;                //!< 定位串
    std::string ordersno;               //!< 委托序号
    std::string ordergroup;             //!< 委托批号
    std::string orcderid;               //!< 合同序号
    std::string orderdate;              //!< 委托日期
    std::string opertime;               //!< 委托时间
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 客户代码
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string bsflag;                 //!< 买卖类别
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string matchqty;               //!< 成交数量
    std::string orderstatus;            //!< 委托状态
};
struct QrySecuHolderInput {
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct QrySecuHolderOutput {
    std::string poststr;                //!< 定位串
    std::string custid;                 //!< 客户代码
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string name;                   //!< 股东姓名
    std::string secuseq;                //!< 股东序号
    std::string regflag;                //!< 指定交易状态
};
struct QryFundAssetInput {
    std::string fundid;                 //!< 资金账号
    std::string moneytype;              //!< 货币
    std::string remark;                 //!< 备注
};
struct QryFundAssetOutput {
    std::string custid;                 //!< 客户代码
    std::string fundid;                 //!< 资金账户
    std::string orgid;                  //!< 机构编码
    std::string moneytype;              //!< 货币
    std::string fundbal;                //!< 资金余额
    std::string fundavl;                //!< 资金可用金额
    std::string marketvalue;            //!< 资产总值
    std::string fund;                   //!< 资金资产
    std::string stkvalue;               //!< 市值
    std::string fundseq;                //!< 主资金标志
    std::string fundloan;               //!< 融资总金额
    std::string fundbuy;                //!< 买入冻结
    std::string fundsale;               //!< 卖出解冻
    std::string fundfrz;                //!< 冻结总金额
    std::string fundlastbal;            //!< 昨日余额
};
struct SecuUnitStkQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct SecuUnitStkQryOutput {
    std::string custid;                 //!< 客户代码
    std::string fundid;                 //!< 资金账户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string orgid;                  //!< 机构编码
    std::string moneytype;              //!< 货币
    std::string stkbal;                 //!< 股份余额
    std::string stkavl;                 //!< 股份可用
    std::string buycost;                //!< 当前成本
    std::string costprice;              //!< 成本价格
    std::string mktval;                 //!< 市值
    std::string income;                 //!< 盈亏
    std::string proincome;              //!< 参考盈亏
    std::string mtkcalflag;             //!< 市值计算标识
    std::string stkqty;                 //!< 当前拥股数
    std::string lastprice;              //!< 最新价格
    std::string stktype;                //!< 证券类型
    std::string profitcost;             //!< 参考成本
    std::string profitprice;            //!< 参考成本价
    std::string stkbuy;                 //!< 股份买入解冻
    std::string stksale;                //!< 股份卖出冻结
    std::string stkdiff;                //!< 可申赎数量
    std::string stkfrz;                 //!< 股份冻结
    std::string stktrdfrz;              //!< 买入申赎差
    std::string stktrdunfrz;            //!< 申赎数量
    std::string stkbuysale;             //!< 股份实时买卖差额
    std::string stkuncomebuy;           //!< 在途买入
    std::string stkuncomesale;          //!< 在途卖出
    std::string costprice_ex;           //!< 成本价格
};
struct SecuUnitStkSumQryInput {
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string fundid;                 //!< 资金帐户
};
struct SecuUnitStkSumQryOutput {
    std::string custid;                 //!< 客户代码
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string moneytype;              //!< 货币
    std::string stkbal;                 //!< 股份余额
    std::string stkavl;                 //!< 股份可用
    std::string buycost;                //!< 当前成本
    std::string costprice;              //!< 成本价格
    std::string mktval;                 //!< 市值
    std::string income;                 //!< 盈亏
    std::string mtkcalflag;             //!< 市值计算标识
    std::string stkqty;                 //!< 当前拥股数
    std::string lastprice;              //!< 最新价格
    std::string stktype;                //!< 证券类型
    std::string proincome;              //!< 参考盈亏
    std::string profitcost;             //!< 参考成本
    std::string profitprice;            //!< 参考成本价
};
struct QryClientInfoByFundIdInput {
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string fundid;                 //!< 资金帐户
};
struct QryClientInfoByFundIdOutput {
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构代码
    std::string bankcode;               //!< 银行代码
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
};
struct SecuEntrustQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string Ordergroup;             //!< 委托批号
    std::string bankcode;               //!< 外部银行
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
    std::string extsno;                 //!< 外部流水号
    std::string qryoperway;             //!< 委托渠道
};
struct SecuEntrustQryOutput {
    std::string poststr;                //!< 定位串
    std::string orderdate;              //!< 委托日期
    std::string ordersno;               //!< 委托序号
    std::string Ordergroup;             //!< 委托批号
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string fundid;                 //!< 资金账户
    std::string moneytype;              //!< 货币
    std::string orgid;                  //!< 机构编码
    std::string secuid;                 //!< 股东代码
    std::string bsflag;                 //!< 买卖类别
    std::string orderid;                //!< 申报合同序号
    std::string reporttime;             //!< 报盘时间
    std::string opertime;               //!< 委托时间
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string prodcode;               //!< 产品编码
    std::string prodname;               //!< 产品名称
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string orderfrzamt;            //!< 冻结金额
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string cancelqty;              //!< 撤单数量
    std::string orderstatus;            //!< 委托状态
    std::string seat;                   //!< 交易席位
    std::string cancelflag;             //!< 撤单标识
    std::string operdate;               //!< 操作日期
    std::string bondintr;               //!< 债券应计利息
    std::string operway;                //!< 委托渠道
    std::string remark;                 //!< 备注信息
};
struct SecuRealDealQryInput {
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string bankcode;               //!< 外部银行
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
    std::string qryoperway;             //!< 委托渠道
};
struct SecuRealDealQryOutput {
    std::string poststr;                //!< 定位串
    std::string trddate;                //!< 成交日期
    std::string secuid;                 //!< 股东代码
    std::string bsflag;                 //!< 买卖类别
    std::string ordersno;               //!< 委托序号
    std::string orderid;                //!< 申报合同序号
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string prodcode;               //!< 产品编码
    std::string prodname;               //!< 产品名称
    std::string matchtime;              //!< 成交时间
    std::string matchcode;              //!< 成交序号
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string matchtype;              //!< 成交类型
    std::string orderqty;               //!< 委托数量
    std::string orderprice;             //!< 委托价格
    std::string bondintr;               //!< 债券应计利息
};
struct SecuRealDealTodaySumQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
};
struct SecuRealDealTodaySumQryOutput {
    std::string operdate;               //!< 交易日期
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string matchtype;              //!< 成交类型
    std::string bankcode;               //!< 外部银行
    std::string bankid;                 //!< 外部账户
};
struct SecuRealDealSumQryInput {
    std::string strdate;                //!< 起始日期
    std::string enddate;                //!< 终止日期
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
    std::string qryoperway;             //!< 交易渠道
};
struct SecuRealDealSumQryOutput {
    std::string bizdate;                //!< 发生日期
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string bankcode;               //!< 外部银行
    std::string bankid;                 //!< 外部账户
    std::string fee_jsxf;               //!< 净佣金
    std::string fee_sxf;                //!< 佣金
    std::string fee_yhs;                //!< 印花税
    std::string fee_ghf;                //!< 过户费
    std::string fee_qsf;                //!< 清算费
    std::string fee_jygf;               //!< 交易规费
    std::string fee_jsf;                //!< 经手费
    std::string fee_zgf;                //!< 证管费
    std::string fee_qtf;                //!< 其他费
    std::string feefront;               //!< 前台费用
    std::string fundeffect;             //!< 资金发生数
};
struct SecuEntrustSumQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
};
struct SecuEntrustSumQryOutput {
    std::string orderdate;              //!< 委托日期
    std::string ordergroup;             //!< 委托批号
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string orderfrzamt;            //!< 委托金额
    std::string matchqty;               //!< 成交数量
    std::string cancelqty;              //!< 撤单数量
    std::string matchamt;               //!< 成交金额
    std::string qty;                    //!< 可撤数量
};
struct QryClientInfoBySecuIdInput {
    std::string secuid;                 //!< 股东代码
};
struct QryClientInfoBySecuIdOutput {
    std::string custid;                 //!< 客户代码
    std::string orgid;                  //!< 机构代码
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
};
struct SecuEntrustInput {
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string fundid;                 //!< 资金账户
    std::string stkcode;                //!< 证券代码
    std::string bsflag;                 //!< 买卖类别
    std::string price;                  //!< 价格
    std::string qty;                    //!< 数量
    std::string ordergroup;             //!< 委托批号
    std::string bankcode;               //!< 外部银行
    std::string creditid;               //!< 信用产品标识
    std::string creditflag;             //!< 特殊委托类型
    std::string remark;                 //!< 备注信息
    std::string targetseat;             //!< 对方席位
    std::string promiseno;              //!< 约定号
    std::string risksno;                //!< 风险调查流水号
    std::string autoflag;               //!< 自动展期标志
    std::string enddate;                //!< 展期终止日期
    std::string linkman;                //!< 联系人
    std::string linkway;                //!< 联系方式
    std::string linkmarket;             //!< 关联市场
    std::string linksecuid;             //!< 关联股东
    std::string sorttype;               //!< 品种类别
    std::string mergematchcode;         //!< 合并管理的初始交易的成交编号
    std::string mergematchdate;         //!< 合并管理的初始交易的成交日期
    std::string oldorderid;             //!< 原合同序号
    std::string prodcode;               //!< 产品编码
    std::string pricetype;              //!< 报价类型
    std::string blackflag;              //!< 是否允许购买黑名单证券
};
struct SecuEntrustOutput {
    std::string ordersno;               //!< 委托序号
    std::string orderid;                //!< 合同序号
    std::string ordergroup;             //!< 委托批号
};
struct SetClientTokenStatusInput {
    std::string orgid;                  //!< 机构编码
    std::string inputtype;              //!< 帐号类型
    std::string inputid;                //!< 帐号
    std::string custprop;               //!< 用户角色
    std::string operway;                //!< 操作方式
    std::string tokenstatus;            //!< 令牌状态
    std::string dynpwd;                 //!< 动态口令
    std::string etokenpin;              //!< 动态口令pin码
};
struct SetClientTokenStatusOutput {
    std::string USER_CODE;              //!< 用户代码
    std::string USER_ROLE;              //!< 用户角色
    std::string STATUS;                 //!< 令牌状态
};

#endif // KCBPDATASTRUCT_H
