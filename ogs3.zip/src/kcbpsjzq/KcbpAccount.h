/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef KCBPACCOUNT_H
#define KCBPACCOUNT_H

#include "../AccountManager.h"

class KcbpTradeAccount : public TradeAccount
{
public:
    std::string market;
    std::string name;
    std::string bankcode;
};

struct KcbpFundAccountData {
    std::string bankcode;
};

class KcbpFundAccount : public FundAccount<KcbpTradeAccount>
{
public:
    KcbpFundAccountData mData;
};

struct KcbpClientData {
    std::string custprop;
    std::string custname;
    std::string orgid;
    std::string identitysign;
    std::string timeoutflag;
    std::string authlevel;
    std::string pwderrtimes;
    std::string custcert;
};

class KcbpClient : public Client<KcbpFundAccount>
{
public:
    KcbpClientData mData;
};

class KcbpClientManager : public ClientManager<KcbpClient>
{
public:
    KcbpClientData clientData(const std::string client_id) {
        lock_data(this);
        int index = findClientById(client_id);
        if (index < 0) {
            return KcbpClientData();
        }
        return this->at(index).mData;
    }

    KcbpTradeAccount tradeAccount(const std::string& fund_account, Exchange exchange)
    {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0 || !AccountHelper::isExchangeValid(exchange)) {
            return KcbpTradeAccount();
        }
        return this->at(index).at(this->at(index).indexOf(fund_account))[exchange];
    }

    KcbpFundAccountData fundAccountData(const std::string& fund_account)
    {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0) {
            return KcbpFundAccountData();
        }
        return this->at(index).at(this->at(index).indexOf(fund_account)).mData;
    }
};

#endif // KCBPACCOUNT_H
