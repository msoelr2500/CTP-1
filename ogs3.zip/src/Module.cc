//
// Created by lwk on 16-6-1.
//

#include "Module.h"
#include "ProxyStage.h"

namespace ogs {

    bool Module::m_initSubFlag = true;

    Module::Module(std::string brokerType, uint32_t queueId, int threadCnt) : m_ProxyStagePtr(new ProxyStage(this)) {
        //LOG(info) << brokerType << queueId << threadCnt;
        m_ActiveStage = 0;
        //m_ProxyStagePtr = new ProxyStage(this);
        m_ProxyStagePtr->set_queue(qtp::QtpQueueMgr::Instance().CeateQueue(queueId));
        std::shared_ptr<std::thread> proxyStage_thread(new std::thread([&]() { m_ProxyStagePtr->Run(); }));
        m_vThread.push_back(proxyStage_thread);

        for (int i = 1; i <= threadCnt; ++i) {
            m_vOrderStageId.push_back(i + queueId);

            std::shared_ptr<std::thread> orderStage_thread(new std::thread([&, i, brokerType, queueId]() {
                std::shared_ptr<OrderStage> orderStagePtr(new OrderStage(brokerType, i, m_initSubFlag));
                m_initSubFlag = false;
                orderStagePtr->set_queue(qtp::QtpQueueMgr::Instance().CeateQueue(i + queueId));
                orderStagePtr->Run();
                m_vStage.push_back(orderStagePtr);
            }));
            m_vThread.push_back(orderStage_thread);
            VLOG(200) << "[Module] OrderStage " << i << " created.";
        }
    }

    Module::~Module() {

    }

    uint32_t Module::getActiveStageId() {
        if (m_ActiveStage >= m_vOrderStageId.size()) {
            m_ActiveStage = 0;
        }
        LOG(info) << "[Module] current stageID: " << m_vOrderStageId[m_ActiveStage];
        return m_vOrderStageId[m_ActiveStage++];
    }


}
