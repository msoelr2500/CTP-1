//
// Created by lwk on 16-8-8.
//

#ifndef OGS_LOADINTERFACE_H
#define OGS_LOADINTERFACE_H

#include "dlfcn.h"
#include "Interface.h"
#include "qtp_log.h"

namespace ogs{

#ifdef __cplusplus
    extern "C"
    {
#endif

    typedef void (*PFn_InterfaceCreate)(std::string brokerType, std::shared_ptr<Interface> &inPtr);
    typedef int (*PFn_LoadLocalOption)(void* src,size_t size);
    typedef void (*PFn_LogLibVersion)();

    extern PFn_InterfaceCreate Fn_InterfaceCreate;
    extern PFn_LoadLocalOption Fn_LoadLocalOption;
    extern PFn_LogLibVersion Fn_LogLibVersion;

#ifdef __cplusplus
    }
#endif

    int LoadInterafceLib(const char *LibPath);

}

#endif //OGS_LOADINTERFACE_H
