#include "TemplateGlobal.h"
#include "TemplateInterface.h"

namespace ogs {

#ifdef __cplusplus
extern "C"
{
#endif

    DEFINE_VERSION(template)

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr) {
        if ((strcmp(brokerType.c_str(), "TEMPLATE") == 0) || (strcmp(brokerType.c_str(), "template") == 0)) {
            inPtr = std::shared_ptr<Interface>(new TemplateInterface());
        }
    }

    int LoadLocalOption(void* src,size_t size){
        if(size!= sizeof(ogs::ReadConfig::localOption)){
            return -1;
        }
        memcpy(&ogs::ReadConfig::localOption,src,size);
        return 0;
    }

    void LogLibVersion()
    {
        LOG(info) << "TEMPLATE 接口库版本：" << GET_VERSION_STR(template);
    }

#ifdef __cplusplus
}
#endif
}
