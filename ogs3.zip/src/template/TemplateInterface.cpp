/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-02
/////////////////////////////////////////////////////////////////////////////

#include "TemplateInterface.h"


using std::string;
using std::vector;

namespace ogs {

TemplateInterface::TemplateInterface()
{
    LOG(info) << "创建了一个Template接口对象";
}

TemplateInterface::~TemplateInterface()
{

}

bool TemplateInterface::getConnectStatus()
{
    return false;
}

Intf_RetType TemplateInterface::initCommon()
{
    static int counter = 1;

    if(true){
        LOG(info) << "[Template] 初始化[" << counter << "]:成功";
        counter++;
        return kIntfSuccess;
    }
    LOG(info) << "[Template] 初始化失败";
    return kIntfFail;
}

Intf_RetType TemplateInterface::initSubscribe()
{
    LOG(info) << "[Template] 初始化订阅功能";
    return kIntfFail;
}

Intf_RetType TemplateInterface::connectBroker()
{
    if(true){
        LOG(info) << "[Template] 已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType TemplateInterface::reConnectBroker()
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::heartBeatToBroker()
{
    LOG(info) << "[Template] heartBeatToBroker";
    return kIntfSuccess;
}

void TemplateInterface::setCallBack(int (*fn)(QueryOrderAns))
{

}

Intf_RetType TemplateInterface::ogsLogin(const LoginQry &in, std::list<LoginAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsSendOrder(const SendOrderQry &in, std::list<SendOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsCancelOrder(const CancelOrderQry &in, std::list<CancelOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsQueryOrder(const QueryOrderQry &in, std::list<QueryOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsQueryPosition(const QueryPositionQry &in, std::list<QueryPositionAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsQueryBargain(const QueryBargainQry &in, std::list<QueryBargainAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, std::list<QueryFundInfoAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, std::list<PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

Intf_RetType TemplateInterface::ogsPaybackFunds(const PaybackFundsQry &in, std::list<PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfSuccess;
}

}
