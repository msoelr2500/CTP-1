/****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 ****************************************************************************/

///===========================================================================
/// \module ogs3
/// \author 杨翌超
/// \date 2017-01-05
///===========================================================================

#ifndef KCBPDATASTRUCT_H
#define KCBPDATASTRUCT_H

#include <string>

struct ClientLoginInput {
    std::string inputtype;              //!< 登录类型
    std::string inputid;                //!< 登录标识
};
struct ClientLoginOutput {
    std::string custprop;               //!< 客户性质
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string name;                   //!< 股东姓名
    std::string fundid;                 //!< 缺省资金帐户
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bankcode;               //!< 银行代码
    std::string identitysign;           //!< 数字签名
    std::string timeoutflag;            //!< 延时属性
    std::string authlevel;              //!< 认证方式/级别
    std::string pwderrtimes;            //!< 登录错误次数
    std::string agtcustid;              //!< 代理客户
    std::string creditflag;             //!< 资金帐号属性
};
struct QryClientInfoOutput {
    std::string custid;                 //!< 客户代码
    std::string status;                 //!< 客户状态
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string sex;                    //!< 性别
    std::string addr;                   //!< 联系地址
    std::string idaddr;                 //!< 证件地址
    std::string postid;                 //!< 邮编
    std::string telno;                  //!< 电话
    std::string mobileno;               //!< 移动电话
    std::string email;                  //!< EMAIL
    std::string edu;                    //!< 学历
    std::string native;                 //!< 籍贯
    std::string occtype;                //!< 职业
    std::string idnobegindate;          //!< 证件签发日
    std::string idnoenddate;            //!< 证件截止期
    std::string opendate;               //!< 开户日期
    std::string contact;                //!< 联络方式
    std::string contactfrep;            //!< 联络频率
    std::string remark;                 //!< 备注信息
};
struct SecuEntrustWithdrawInput {
    std::string orderdate;              //!< 委托日期
    std::string fundid;                 //!< 资金帐户
    std::string ordersno;               //!< 委托序号
    std::string bankpwd;                //!< 银行密码
};
struct SecuEntrustWithdrawOutput {
    std::string msgok;                  //!< 成功信息
};
struct QrySecuEntrustWithdrawInput {
    std::string orderdate;              //!< 委托日期
    std::string fundid;                 //!< 资金帐户
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct QrySecuEntrustWithdrawOutput {
    std::string poststr;                //!< 定位串
    std::string ordersno;               //!< 委托序号
    std::string ordergroup;             //!< 委托批号
    std::string orcderid;               //!< 合同序号
    std::string orderdate;              //!< 委托日期
    std::string opertime;               //!< 委托时间
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 客户代码
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string bsflag;                 //!< 买卖类别
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string matchqty;               //!< 成交数量
    std::string orderstatus;            //!< 委托状态
    std::string creditdigestid;         //!< 信用交易摘要
};
struct QrySecuHolderInput {
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct QrySecuHolderOutput {
    std::string poststr;                //!< 定位串
    std::string custid;                 //!< 客户代码
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string name;                   //!< 股东姓名
    std::string secuseq;                //!< 股东序号
    std::string creditflag;             //!< 股东账户属性
    std::string opendate;               //!< 开户日期
    std::string regflag;                //!< 指定交易状态
    std::string bondreg;                //!< 回购指定状态
    std::string status;                 //!< 股东状态
};
struct QryFundAssetInput {
    std::string fundid;                 //!< 资金账号
    std::string moneytype;              //!< 货币
};
struct QryFundAssetOutput {
    std::string custid;                 //!< 客户代码
    std::string fundid;                 //!< 资金账户
    std::string orgid;                  //!< 机构编码
    std::string moneytype;              //!< 货币
    std::string fundbal;                //!< 资金余额
    std::string fundavl;                //!< 资金可用金额
    std::string marketvalue;            //!< 资产总值
    std::string fund;                   //!< 资金资产
    std::string stkvalue;               //!< 市值
    std::string fundseq;                //!< 主资金标志
};
struct SecuUnitStkQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct SecuUnitStkQryOutput {
    std::string poststr;                //!< 定位串
    std::string custid;                 //!< 客户代码
    std::string fundid;                 //!< 资金账户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string orgid;                  //!< 机构编码
    std::string moneytype;              //!< 货币
    std::string stkbal;                 //!< 股份余额
    std::string stkavl;                 //!< 股份可用
    std::string buycost;                //!< 当前成本
    std::string costprice;              //!< 成本价格
    std::string mktval;                 //!< 市值
    std::string income;                 //!< 盈亏
    std::string proincome;              //!< 累计盈亏
    std::string mtkcalflag;             //!< 市值计算标识
    std::string stkqty;                 //!< 当前拥股数
    std::string lastprice;              //!< 最新价格
    std::string stktype;                //!< 证券类型
    std::string stkdiff;                //!< 可申赎数量
    std::string stkcantrans;            //!< 股份可转
    std::string stklastbal;             //!< 上日余额
    std::string stkfrz;                 //!< 股份冻结
    std::string stkunfrz;               //!< 股份解冻
    std::string closeprice;             //!< 昨日收盘
    std::string netaddr;                //!< MAC地址
    std::string custtype;               //!< 客户类型
    std::string seat;                   //!< 席位代码
};
struct SecuUnitStkSumQryInput {
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string fundid;                 //!< 资金帐户
};
struct SecuUnitStkSumQryOutput {
    std::string custid;                 //!< 客户代码
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string moneytype;              //!< 货币
    std::string stkbal;                 //!< 股份余额
    std::string stkavl;                 //!< 股份可用
    std::string buycost;                //!< 当前成本
    std::string costprice;              //!< 成本价格
    std::string mktval;                 //!< 市值
    std::string income;                 //!< 盈亏
    std::string mtkcalflag;             //!< 市值计算标识
    std::string stkqty;                 //!< 当前拥股数
    std::string lastprice;              //!< 最新价格
    std::string stktype;                //!< 证券类型
};
struct QryClientInfoByFundIdInput {
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string fundid;                 //!< 资金帐户
};
struct QryClientInfoByFundIdOutput {
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构代码
    std::string bankcode;               //!< 银行代码
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
};
struct SecuEntrustQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string bankcode;               //!< 外部银行
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct SecuEntrustQryOutput {
    std::string poststr;                //!< 定位串
    std::string orderdate;              //!< 委托日期
    std::string ordersno;               //!< 委托序号
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string fundid;                 //!< 资金账户
    std::string moneytype;              //!< 货币
    std::string orgid;                  //!< 机构编码
    std::string secuid;                 //!< 股东代码
    std::string bsflag;                 //!< 买卖类别
    std::string orderid;                //!< 申报合同序号
    std::string reporttime;             //!< 报盘时间
    std::string opertime;               //!< 委托时间
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string orderfrzamt;            //!< 冻结金额
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string cancelqty;              //!< 撤单数量
    std::string orderstatus;            //!< 委托状态
    std::string seat;                   //!< 交易席位
    std::string cancelflag;             //!< 撤单标识
    std::string creditdigestid;         //!< 信用交易摘要
};
struct SecuHistEntrustQryInput {
    std::string strdate;                //!< 起始日期
    std::string enddate;                //!< 终止日期
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string bankcode;               //!< 外部银行
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct SecuHistEntrustQryOutput {
    std::string poststr;                //!< 定位串
    std::string orderdate;              //!< 委托日期
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string fundid;                 //!< 资金账户
    std::string moneytype;              //!< 货币
    std::string orgid;                  //!< 机构编码
    std::string secuid;                 //!< 股东代码
    std::string bsflag;                 //!< 买卖类别
    std::string orderid;                //!< 申报合同序号
    std::string reporttime;             //!< 报盘时间
    std::string opertime;               //!< 委托时间
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string orderfrzamt;            //!< 冻结金额
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string cancelqty;              //!< 撤单数量
    std::string orderstatus;            //!< 委托状态
    std::string seat;                   //!< 交易席位
    std::string creditdigestid;         //!< 信用交易摘要
};
struct SecuRealDealQryInput {
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string ordersno;               //!< 委托序号
    std::string bankcode;               //!< 外部银行
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct SecuRealDealQryOutput {
    std::string poststr;                //!< 定位串
    std::string trddate;                //!< 成交日期
    std::string secuid;                 //!< 股东代码
    std::string bsflag;                 //!< 买卖类别
    std::string ordersno;               //!< 委托序号
    std::string orderid;                //!< 申报合同序号
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string matchtime;              //!< 成交时间
    std::string matchcode;              //!< 成交序号
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string matchtype;              //!< 成交类型
    std::string orderqty;               //!< 委托数量
    std::string orderprice;             //!< 委托价格
    std::string creditdigestid;         //!< 信用交易摘要
};
struct SecuHistRealDealQryInput {
    std::string strdate;                //!< 起始日期
    std::string enddate;                //!< 终止日期
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
    std::string qryflag;                //!< 查询方向
    std::string count;                  //!< 请求行数
    std::string poststr;                //!< 定位串
};
struct SecuHistRealDealQryOutput {
    std::string poststr;                //!< 定位串
    std::string bizdate;                //!< 成交日期
    std::string secuid;                 //!< 股东代码
    std::string bsflag;                 //!< 买卖类别
    std::string orderid;                //!< 申报合同序号
    std::string ordersno;               //!< 委托序号
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券名称
    std::string stkname;                //!< 证券代码
    std::string matchtime;              //!< 成交时间
    std::string matchcode;              //!< 成交序号
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string orderqty;               //!< 委托数量
    std::string orderprice;             //!< 委托价格
    std::string stkbal;                 //!< 股份本次余额
    std::string digestid;               //!< 摘要代码
    std::string digestname;             //!< 摘要代码名称
};
struct SecuHistEntrustSumQryInput {
    std::string strdate;                //!< 起始日期
    std::string enddate;                //!< 终止日期
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
};
struct SecuHistEntrustSumQryOutput {
    std::string orderdate;              //!< 委托日期
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string orderfrzamt;            //!< 委托金额
    std::string matchqty;               //!< 成交数量
    std::string cancelqty;              //!< 撤单数量
    std::string matchamt;               //!< 成交金额
};
struct SecuRealDealTodaySumQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
};
struct SecuRealDealTodaySumQryOutput {
    std::string operdate;               //!< 交易日期
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string matchtype;              //!< 成交类型
    std::string bankcode;               //!< 外部银行
    std::string bankid;                 //!< 外部账户
};
struct SecuRealDealSumQryInput {
    std::string strdate;                //!< 起始日期
    std::string enddate;                //!< 终止日期
    std::string fundid;                 //!< 资金帐户
    std::string market;                 //!< 交易市场
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
};
struct SecuRealDealSumQryOutput {
    std::string bizdate;                //!< 发生日期
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string matchprice;             //!< 成交价格
    std::string matchqty;               //!< 成交数量
    std::string matchamt;               //!< 成交金额
    std::string bankcode;               //!< 外部银行
    std::string bankid;                 //!< 外部账户
};
struct SecuEntrustSumQryInput {
    std::string market;                 //!< 交易市场
    std::string fundid;                 //!< 资金帐户
    std::string stkcode;                //!< 证券代码
    std::string bankcode;               //!< 外部银行
};
struct SecuEntrustSumQryOutput {
    std::string orderdate;              //!< 委托日期
    std::string ordergroup;             //!< 委托批号
    std::string custid;                 //!< 客户代码
    std::string custname;               //!< 客户姓名
    std::string orgid;                  //!< 机构编码
    std::string bsflag;                 //!< 买卖类别
    std::string market;                 //!< 交易市场
    std::string stkname;                //!< 证券名称
    std::string stkcode;                //!< 证券代码
    std::string orderprice;             //!< 委托价格
    std::string orderqty;               //!< 委托数量
    std::string orderfrzamt;            //!< 委托金额
    std::string matchqty;               //!< 成交数量
    std::string cancelqty;              //!< 撤单数量
    std::string matchamt;               //!< 成交金额
    std::string qty;                    //!< 可撤数量
};
struct QryAssetInput {
    std::string fundid;                 //!< 资金账号
    std::string moneytype;              //!< 货币
};
struct QryAssetOutput {
    std::string custid;                 //!< 客户代码
    std::string fundid;                 //!< 资金账户
    std::string orgid;                  //!< 机构编码
    std::string moneytype;              //!< 货币
    std::string fundbal;                //!< 资金余额
    std::string fundavl;                //!< 资金可用金额
    std::string marketvalue;            //!< 资产总值
    std::string fund;                   //!< 资金资产
    std::string stkvalue;               //!< 市值
    std::string fundseq;                //!< 主资金标志
    std::string maxdraw;                //!< 可取金额
    std::string netaddr;                //!< MAC地址
    std::string bankcode;               //!< 银行代码
    std::string bankname;               //!< 银行名称
    std::string fundbjhgavl;            //!< 报价回购可用资金
    std::string creditflag;             //!< 资金帐号属性
};
struct QryClientInfoBySecuIdInput {
    std::string secuid;                 //!< 股东代码
};
struct QryClientInfoBySecuIdOutput {
    std::string custid;                 //!< 客户代码
    std::string orgid;                  //!< 机构代码
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
};
struct QryClientTotalAssetInput {
    std::string fundid;                 //!< 资金帐户
    std::string moneytype;              //!< 货币代码
};
struct QryClientTotalAssetOutput {
    std::string custid;                 //!< 客户代码
    std::string orgid;                  //!< 机构代码
    std::string brhid;                  //!< 分支机构
    std::string fundid;                 //!< 资金帐号
    std::string fundname;               //!< 客户姓名
    std::string moneytype;              //!< 货币代码
    std::string fundassettotal;         //!< 总资产
    std::string fundasset;              //!< 资金
    std::string fundassetstk;           //!< 证券资产
    std::string fundassetof;            //!< 开放式基金资产
    std::string fundassetbond;          //!< 非交易所债券
    std::string fundassetrzgh;          //!< 融资
    std::string fundassetrqgh;          //!< 融券
    std::string fundassetstkzy;         //!< 质押资产
    std::string fundassetbjhg;          //!< 报价回购资产
    std::string custtype;               //!< 客户类型
    std::string status;                 //!< 资金帐户状态
};
struct SecuEntrustInput {
    std::string market;                 //!< 交易市场
    std::string secuid;                 //!< 股东代码
    std::string fundid;                 //!< 资金账户
    std::string stkcode;                //!< 证券代码
    std::string bsflag;                 //!< 买卖类别
    std::string price;                  //!< 价格
    std::string qty;                    //!< 数量
    std::string ordergroup;             //!< 委托批号
    std::string bankcode;               //!< 外部银行
    std::string remark;                 //!< 备注信息
    std::string bankpwd;                //!< 银行密码
    std::string authcode;               //!< 授权码
    std::string featurecode;            //!< 机器特征码
    std::string authinfo;               //!< 认证密码
    std::string productcode;            //!< 产品识别码
    std::string developercode;          //!< 开发商识别码
    std::string versioninfo;            //!< 软件版本信息
};
struct SecuEntrustOutput {
    std::string ordersno;               //!< 委托序号
    std::string orderid;                //!< 合同序号
};

struct RecordLoginInfoInput {
    std::string fundid;                 //!< 资金帐户
    std::string netaddr;                //!< MAC地址
    std::string telno;                  //!< 电话号码
    std::string ipaddr;                 //!< IP地址
    std::string remark;                 //!< 备注
    std::string remark1;                //!< 备注1
    std::string remark2;                //!< 备注2
    std::string remark3;                //!< 备注3
    std::string remark4;                //!< 备注4
    std::string remark5;                //!< 备注5
};
struct RecordLoginInfoOutput {
    std::string msgok;                  //!< 成功信息
};

#endif // KCBPDATASTRUCT_H
