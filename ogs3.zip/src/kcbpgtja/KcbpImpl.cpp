﻿/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-07-19
///////////////////////////////////////////////////////////////////////////////

#include "KcbpImpl.h"
#include <qtp_log.h>
#include <iostream>
#include "../BufferHandle.h"
#include "../ReadConfig.h"
#include "../OgsApi.h"
#include "KcbpConverter.h"
#include "KcbpLogger.h"
#include "KcbpDataStruct.h"
#include <qtp_log.h>

#define KCBP_GTJA_QRY_LINE_COUNT "500"

using namespace std;
using namespace ogs;

KcbpClientManager KcbpImpl::mClients;

KcbpImpl::KcbpImpl()
{
    mConfig.mSiteInfoFormat = ReadConfig::localOption.SiteInfoFormat;
    mConfig.mServerName     = ReadConfig::localOption.Reserve1;
    mConfig.mSendQName      = ReadConfig::localOption.Reserve2;
    mConfig.mReceiveQName   = ReadConfig::localOption.Reserve3;
    mConfig.mUserName       = ReadConfig::localOption.Reserve4;
    mConfig.mPassword       = ReadConfig::localOption.Reserve5;

    mConfig.mAuthcode       = ReadConfig::localOption.Reserve6;
    mConfig.mProductcode    = ReadConfig::localOption.Reserve7;
    mConfig.mDevelopercode  = ReadConfig::localOption.Reserve9;
    mConfig.mVersioninfo    = GET_VERSION_STR(TARGET_NAME);

    mConfig.mServerIp       = ReadConfig::localOption.BrokerAddr;
    mConfig.mServerPort     = atoi(ReadConfig::localOption.BrokerPort.c_str());

    mConfig.mOperWay        = ReadConfig::localOption.EntrustMode;
    mConfig.mOrgId          = ReadConfig::localOption.BranchNo;

    mConnection.setConfig(mConfig);
}

KcbpImpl::~KcbpImpl() {}

bool KcbpImpl::initialize()
{
    return mConnection.initialize();
}

bool KcbpImpl::connect()
{
    return mConnection.connect();
}

void KcbpImpl::disconnect()
{
    mConnection.disconnect();
}

Intf_RetType KcbpImpl::heartBeatToBroker()
{
    return kIntfNotSupport;
}

void KcbpImpl::setCallBack(int (*fn)(QueryOrderAns))
{
    func = fn;
}

bool KcbpImpl::isConnected() const
{
    return mConnection.isConnected();
}

Intf_RetType KcbpImpl::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string> &args)
{
    out.clear();

    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

#if 0
    const char right_passwd[] = "*Sh//+)$";

    int inLength = strlen(in.password);
    int rightLength = strlen(right_passwd);
    kcbpDebug << "input_passwd len = " << inLength;
    std::cout << "input_passwd len = " << inLength << std::endl;
    kcbpDebug << "right_passwd len = " << rightLength;
    std::cout << "right_passwd len = " << rightLength << std::endl;

    if (inLength == rightLength) {
        bool matched = true;
        for (int i = 0; i < rightLength; i++) {
            if (right_passwd[i] != in.password[i]) {
                kcbpDebug << "char at " << i << " (" << in.password[i] << ", " << (int)in.password[i] << ") doesn't match.";
                std::cout << "char at " << i << " (" << in.password[i] << ", " << (int)in.password[i] << ") doesn't match." << std::endl;
                matched = false;
            }
        }
        std::cout << "all chars matched." << std::endl;
        kcbpDebug << "all chars matched.";
    } else {
        kcbpDebug << "input passwd length doesn't match.";
        std::cout << "input passwd length doesn't match." << std::endl;
        if (inLength > rightLength) {
            for (int i = rightLength; i < inLength; i++) {
                kcbpDebug << "unexpected char at " << i << " (" << in.password[i] << ", " << (int)in.password[i] << ").";
                std::cout << "unexpected char at " << i << " (" << in.password[i] << ", " << (int)in.password[i] << ")." << std::endl;
            }
        }
    }

#endif

    // for kcbp_gtja, func 410308 must be called before login.
    RecordLoginInfoInput rInput;
    rInput.fundid        = in.bacid;
    rInput.ipaddr        = in.ipAddr;
    rInput.netaddr       = in.macAddr;
    rInput.remark5       = "0";
    // rInput.telno is ignored.

    std::list<RecordLoginInfoOutput> rOutput;
    Intf_RetType rResult = mConnection.kcbpRecordLoginInfo(fixedInput, rInput, rOutput, errMsg);
    if (rResult != kIntfSuccess) {
        return rResult;
    }

    ClientLoginInput input;
    if (strlen(in.bacid) != 0) {
        input.inputtype = "Z";
        input.inputid   = in.bacid;
    } else {
        input.inputtype = "C";
        input.inputid   = in.acidcard;
    }

    // 调用接口。
    std::list<ClientLoginOutput> output;
    Intf_RetType result = mConnection.kcbpClientLogin(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    map<string, KcbpClient> clients;
    for (ClientLoginOutput& item : output) {
        KcbpClient& client = clients[item.custid];
        client.client_id          = item.custid;
        client.mData.custprop     = item.custprop;
        client.mData.custname     = item.custname;
        client.mData.orgid        = item.orgid;
        client.mData.identitysign = item.identitysign;
        client.mData.timeoutflag  = item.timeoutflag;
        client.mData.authlevel    = item.authlevel;
        client.mData.pwderrtimes  = item.pwderrtimes;
        client.mData.agtcustid    = item.agtcustid;

        int fIndex = client.indexOf(item.fundid);
        if (fIndex < 0) {
            KcbpFundAccount fundAccount;
            fundAccount.fund_account     = item.fundid;
            fundAccount.mData.bankcode   = item.bankcode;
            fundAccount.mData.creditflag = item.creditflag;
            fIndex = client.addNewFundAccount(fundAccount);

            // 仅当出现了新的资金账号时才会加入新的LoginAns。
            ogs::LoginAns ans = {0};
            KcbpConverter::from_fundid(ans.bacid, item.fundid);
            out.push_back(ans);
        }

        KcbpFundAccount& fundAccount = client[fIndex];
        Exchange exchange = KcbpConverter::to_exchange_index(item.market);

        if (AccountHelper::isExchangeValid(exchange)) {
            KcbpTradeAccount& account = fundAccount[exchange];
            account.stock_account = item.secuid;
            account.market        = item.market;
            account.name          = item.name;
            account.bankcode      = item.bankcode;
            account.enabled       = true;
        }
    }

    for (map<string, KcbpClient>::const_iterator i = clients.begin(); i != clients.end(); ++i) {
        mClients.addNewClient(i->second);
    }

    mClients.printAccounts();

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    // KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    std::string ip;
    std::string mask;
    std::string subnetIp;
    ogs::IpAddress(ip, mask, subnetIp);

    // remove '0' at the end of subnetIp.
    for (int i = subnetIp.size() - 1; i >= 0; i--)
    {
        if (subnetIp.at(i) == '0'){
            subnetIp.resize(subnetIp.size() - 1);
        } else {
            break;
        }
    }

    std::string authInfo;
    char prefixIp[50] = {0};
    strcpy(prefixIp, subnetIp.c_str());

    std::string featurecode;
    mConnection.getAccessInfo((char*)in.acidcard, featurecode, authInfo, errMsg, prefixIp);

    SecuEntrustInput input;
    input.market        = KcbpConverter::to_market(market);
    input.secuid        = tradeAccount.stock_account;
    input.fundid        = KcbpConverter::to_fundid(in.bacid);
    input.stkcode       = KcbpConverter::to_stkcode(code);
    input.bsflag        = KcbpConverter::to_bsflag(in.directive);
    input.price         = KcbpConverter::to_price(in.price);
    input.qty           = KcbpConverter::to_qty(in.volume);
    input.ordergroup    = "0";
    input.bankcode      = tradeAccount.bankcode;
    input.authcode      = mConfig.mAuthcode;
    input.featurecode   = featurecode;
    input.authinfo      = authInfo;
    input.productcode   = mConfig.mProductcode;
    input.developercode = mConfig.mDevelopercode;
    input.versioninfo   = mConfig.mVersioninfo;

    // 调用接口。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

    std::list<SecuEntrustOutput> output;
    Intf_RetType result = mConnection.kcbpSecuEntrust(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        // 下单出错，则需要打包无效订单返回。
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        out.push_back(ans);
        return result;
    }

    for (const SecuEntrustOutput& item : output) {
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        KcbpConverter::from_ordersno(item.ordersno, ans.sysOrderId);
        out.push_back(ans);
    }

    // 处理输出。
    return result;
}

Intf_RetType KcbpImpl::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    // KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));

    // 设置输入。
    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    SecuEntrustWithdrawInput input;
    input.orderdate = ogs::GetCurrDay();
    input.fundid    = KcbpConverter::to_fundid(in.bacid);
    input.ordersno  = KcbpConverter::to_ordersno(in.sysOrderId);

    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

    std::list<SecuEntrustWithdrawOutput> output;
    Intf_RetType result = mConnection.kcbpSecuEntrustWithdraw(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    for (const SecuEntrustWithdrawOutput& item : output) {
        ogs::CancelOrderAns ans = {0};
        errMsg = item.msgok;
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        // no sysOrderId
        out.push_back(ans);
    }

    // 处理输出。
    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    // KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));
    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

    // 初始化输入。
    SecuEntrustQryInput input;
    input.market   = KcbpConverter::to_market(market);
    input.fundid   = KcbpConverter::to_fundid(in.bacid);
    input.secuid   = tradeAccount.stock_account;
    input.stkcode  = KcbpConverter::to_stkcode(code);
    input.ordersno = KcbpConverter::to_ordersno(in.sysOrderId);
    input.qryflag  = "1";
    input.count    = KCBP_GTJA_QRY_LINE_COUNT;

    // 调用接口。
    std::list<SecuEntrustQryOutput> output;
    Intf_RetType result = mConnection.kcbpSecuEntrustQry(fixedInput, input, output, errMsg);
    if (result != kIntfSuccess) {
        return result;
    }

    // 处理输出。
    for (const SecuEntrustQryOutput& item : output) {
        QueryOrderAns ans  = {0};
        KcbpConverter::from_fundid(ans.bacid, item.fundid);
        ans.custOrderId    = in.custOrderId;
        ans.tradeDate      = KcbpConverter::from_orderdate(item.orderdate);
        ans.orderTime      = KcbpConverter::from_opertime(item.opertime);
        KcbpConverter::from_ordersno(item.ordersno, ans.sysOrderId);
        ans.directive      = KcbpConverter::from_operation(item.bsflag, item.creditdigestid);
        ans.price          = KcbpConverter::from_orderprice(item.orderprice);
        ans.volume         = KcbpConverter::from_orderqty(item.orderqty);
        ans.dealVolume     = KcbpConverter::from_matchqty(item.matchqty);
        ans.dealBalance    = KcbpConverter::from_matchamt(item.matchamt);
        ans.dealPrice      = ans.dealVolume == 0 ? ans.price : (ans.dealBalance / ans.dealVolume);
        ans.withdrawVolume = KcbpConverter::from_cancelqty(item.cancelqty);
        ans.orderStatus    = KcbpConverter::from_orderstatus(item.orderstatus);
        ans.innerCode      = KcbpConverter::from_stkcode(item.stkcode);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    // KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

    SecuUnitStkQryInput input;
    input.market  = KcbpConverter::to_market(market);
    input.fundid  = KcbpConverter::to_fundid(in.bacid);
    input.secuid  = tradeAccount.stock_account;
    input.stkcode = KcbpConverter::to_stkcode(code);
    input.qryflag = "1";

    // 调用接口。
    std::list<SecuUnitStkQryOutput> output;
    Intf_RetType result = mConnection.kcbpSecuUnitStkQry(fixedInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const SecuUnitStkQryOutput& item : output) {
        ogs::QueryPositionAns ans = {0};
        KcbpConverter::from_custid(ans.acidcard, item.custid);
        KcbpConverter::from_fundid(ans.bacid, item.fundid);
        ans.innerCode = KcbpConverter::from_stkcode(item.stkcode);
        ans.currentVolume = KcbpConverter::from_stkqty(item.stkqty);
        ans.usableVolume = KcbpConverter::from_stkavl(item.stkavl);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &sc);

    // 查找指定账户。
    // KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));
    KcbpTradeAccount tradeAccount = mClients.tradeAccount(KcbpConverter::to_fundid(in.bacid),
                                                          AccountHelper::toExchange(market));
    // 设置输入。

    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

    SecuRealDealQryInput input;
    input.fundid   = KcbpConverter::to_fundid(in.bacid);
    input.market   = KcbpConverter::to_market(market);
    input.secuid   = tradeAccount.stock_account;
    input.stkcode  = KcbpConverter::to_stkcode(code);
    input.ordersno = KcbpConverter::to_ordersno(in.sysOrderId);
    input.qryflag  = "1";
    input.count    = KCBP_GTJA_QRY_LINE_COUNT;

    // 调用接口。
    std::list<SecuRealDealQryOutput> output;
    Intf_RetType result = mConnection.kcbpSecuRealDealQry(fixedInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const SecuRealDealQryOutput& item : output) {
        ogs::QueryBargainAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId   = in.custOrderId;
        ans.dealBalance   = KcbpConverter::from_matchamt(item.matchamt);
        ans.dealPrice     = KcbpConverter::from_matchprice(item.matchprice);
        ans.innerCode     = KcbpConverter::from_stkcode(item.stkcode);
        ans.dealVolume    = KcbpConverter::from_matchqty(item.matchqty);
        KcbpConverter::from_matchcode(item.matchcode, ans.dealId);
        KcbpConverter::from_ordersno(item.ordersno, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    // KcbpClientData clientData = mClients.clientData(KcbpConverter::to_client_id(in.acidcard));

    // 设置输入。
    KcbpFixedInput fixedInput;
    fixedInput.custid    = in.acidcard;
    fixedInput.custorgid = mConnection.config().mOrgId;
    fixedInput.netaddr   = mConnection.config().mSiteInfoFormat.empty() ? default_op_station(in.macAddr) : op_station(args);
    fixedInput.trdpwd    = KcbpConverter::to_trdpwd(in.password);
    fixedInput.orgid     = mConnection.config().mOrgId;
    fixedInput.operway   = mConnection.config().mOperWay;

    QryAssetInput input;
    input.fundid = KcbpConverter::to_fundid(in.bacid);

    // 调用接口。
    std::list<QryAssetOutput> output;
    Intf_RetType result = mConnection.kcbpQryAsset(fixedInput, input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const QryAssetOutput& item : output) {
        ogs::QueryFundInfoAns ans = {0};
        KcbpConverter::from_custid(ans.acidcard, item.custid);
        KcbpConverter::from_fundid(ans.bacid, item.fundid);
        ans.balance        = KcbpConverter::from_fund(item.fundbal);
        ans.useableBalance = KcbpConverter::from_fundavl(item.fundavl);
        ans.frozenBalance  = ans.balance - ans.frozenBalance;
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType KcbpImpl::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

Intf_RetType KcbpImpl::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

string KcbpImpl::default_op_station(const char *mac)
{
    return mac;
}

string KcbpImpl::op_station(map<int, string> &args)
{
    // 默认使用配置文件中的站点信息格式。
    if (!mConfig.mSiteInfoFormat.empty()) {
        return ogs::SiteInfo(mConfig.mSiteInfoFormat, args);
    }

    // 配置文件中未制定站点信息格式，则使用默认格式。
    string mac       = args[2];

    return default_op_station(mac.c_str());
}
