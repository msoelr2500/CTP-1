/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

#include "KcbpInterface.h"
#include "KcbpLogger.h"

using namespace std;

namespace ogs {

KcbpInterface::KcbpInterface()
{
    kcbpInfo << "创建了一个KCBP接口对象";
}

KcbpInterface::~KcbpInterface()
{

}

bool KcbpInterface::getConnectStatus()
{
    return kcbpImpl.isConnected();
}

Intf_RetType KcbpInterface::initCommon()
{
    static int counter = 1;

    if(kcbpImpl.initialize()){
        kcbpInfo << "初始化[" << counter << "]:成功";
        counter++;
        return kIntfSuccess;
    }
    kcbpInfo << "初始化失败";
    return kIntfFail;
}

Intf_RetType KcbpInterface::initSubscribe()
{
    kcbpInfo << "初始化订阅功能";
    return kIntfFail;
}

Intf_RetType KcbpInterface::connectBroker()
{
    if(kcbpImpl.connect()){
        kcbpInfo << "已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType KcbpInterface::reConnectBroker()
{
    if(kcbpImpl.isConnected()){
        kcbpImpl.disconnect();
    }
    return connectBroker();
}

Intf_RetType KcbpInterface::heartBeatToBroker()
{
    kcbpInfo << "heartBeatToBroker";
    return kcbpImpl.heartBeatToBroker();
}

void KcbpInterface::setCallBack(int (*fn)(QueryOrderAns))
{
    kcbpImpl.setCallBack(fn);
}

Intf_RetType KcbpInterface::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsLogin(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsSendOrder(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsCancelOrder(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsQueryOrder(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsQueryPosition(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsQueryBargain(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsQueryFundInfo(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsPaybackSecurity(in, out, errMsg, args);
}

Intf_RetType KcbpInterface::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return kcbpImpl.ogsPaybackFunds(in, out, errMsg, args);
}

}
