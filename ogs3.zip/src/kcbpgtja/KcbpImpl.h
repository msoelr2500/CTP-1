/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-07-19
///////////////////////////////////////////////////////////////////////////////

#ifndef _KCBPIMPL_H_
#define _KCBPIMPL_H_

#include <map>
#include <string>
#include <cassert>
#include <vector>
#include <iconv.h>
#include <list>
#include <vector>
#include <functional>

#include "KcbpApiWrapper.h"
#include "KcbpAccount.h"

#include "../universal_code.h"
#include "../DataStruct.h"
#include "../OrderStage.h"
#include "../ogs_dict.h"

class KcbpImpl{
public:
    KcbpImpl();
    virtual ~KcbpImpl();

    ////////////////////////////////////////////////////////////////////////////
    /// 基础方法
    ////////////////////////////////////////////////////////////////////////////

    bool initialize();

    bool connect();

    void disconnect();

    /*! \brief 心跳 */
    Intf_RetType heartBeatToBroker();

    /*! \brief 设置查单过程的回调函数。*/
    void setCallBack(int (*fn)(ogs::QueryOrderAns));

    ////////////////////////////////////////////////////////////////////////////
    /// 状态
    ////////////////////////////////////////////////////////////////////////////

    bool isConnected() const;

    Intf_RetType ogsLogin(const ogs::LoginQry& in, std::list<ogs::LoginAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsSendOrder(const ogs::SendOrderQry& in, std::list<ogs::SendOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsCancelOrder(const ogs::CancelOrderQry& in, std::list<ogs::CancelOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryOrder(const ogs::QueryOrderQry& in, std::list<ogs::QueryOrderAns>& out, std::string &errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryPosition(const ogs::QueryPositionQry& in, std::list<ogs::QueryPositionAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryBargain(const ogs::QueryBargainQry& in, std::list<ogs::QueryBargainAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryFundInfo(const ogs::QueryFundInfoQry& in, std::list<ogs::QueryFundInfoAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsPaybackSecurity(const ogs::PaybackSecurityQry &in, std::list<ogs::PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsPaybackFunds(const ogs::PaybackFundsQry &in, std::list<ogs::PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args);

protected:
    std::string default_op_station(const char* mac);
    std::string op_station(std::map<int, std::string>& args);

private:
    KcbpApiWrapper mConnection;

    //! 订阅获取到成交回报时的回调函数
    std::function<int(ogs::QueryOrderAns)> func;

    static KcbpClientManager mClients;

    KcbpConfig mConfig;
};

#endif
