/****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 ****************************************************************************/

///===========================================================================
/// \module ogs3
/// \author 杨翌超
/// \date 2017-01-05
///===========================================================================

#include "KcbpLogger.h"

OgsLogger& operator << (OgsLogger& logger, const ClientLoginInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[ClientLoginInput]=====================";
    ogsDebug << "|inputtype                    |" << data.inputtype;
    ogsDebug << "|inputid                      |" << data.inputid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const ClientLoginOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[ClientLoginOutput]=====================";
    ogsDebug << "|custprop                     |" << data.custprop;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|name                         |" << data.name;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|identitysign                 |" << data.identitysign;
    ogsDebug << "|timeoutflag                  |" << data.timeoutflag;
    ogsDebug << "|authlevel                    |" << data.authlevel;
    ogsDebug << "|pwderrtimes                  |" << data.pwderrtimes;
    ogsDebug << "|agtcustid                    |" << data.agtcustid;
    ogsDebug << "|creditflag                   |" << data.creditflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QryClientInfoOutput]====================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|status                       |" << data.status;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|sex                          |" << data.sex;
    ogsDebug << "|addr                         |" << data.addr;
    ogsDebug << "|idaddr                       |" << data.idaddr;
    ogsDebug << "|postid                       |" << data.postid;
    ogsDebug << "|telno                        |" << data.telno;
    ogsDebug << "|mobileno                     |" << data.mobileno;
    ogsDebug << "|email                        |" << data.email;
    ogsDebug << "|edu                          |" << data.edu;
    ogsDebug << "|native                       |" << data.native;
    ogsDebug << "|occtype                      |" << data.occtype;
    ogsDebug << "|idnobegindate                |" << data.idnobegindate;
    ogsDebug << "|idnoenddate                  |" << data.idnoenddate;
    ogsDebug << "|opendate                     |" << data.opendate;
    ogsDebug << "|contact                      |" << data.contact;
    ogsDebug << "|contactfrep                  |" << data.contactfrep;
    ogsDebug << "|remark                       |" << data.remark;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustWithdrawInput]=================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|bankpwd                      |" << data.bankpwd;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuEntrustWithdrawOutput]=================";
    ogsDebug << "|msgok                        |" << data.msgok;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QrySecuEntrustWithdrawInput]================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QrySecuEntrustWithdrawOutput]===============";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    ogsDebug << "|orcderid                     |" << data.orcderid;
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|opertime                     |" << data.opertime;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|orderstatus                  |" << data.orderstatus;
    ogsDebug << "|creditdigestid               |" << data.creditdigestid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuHolderInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QrySecuHolderInput]====================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QrySecuHolderOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QrySecuHolderOutput]====================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|name                         |" << data.name;
    ogsDebug << "|secuseq                      |" << data.secuseq;
    ogsDebug << "|creditflag                   |" << data.creditflag;
    ogsDebug << "|opendate                     |" << data.opendate;
    ogsDebug << "|regflag                      |" << data.regflag;
    ogsDebug << "|bondreg                      |" << data.bondreg;
    ogsDebug << "|status                       |" << data.status;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundAssetInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryFundAssetInput]=====================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryFundAssetOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[QryFundAssetOutput]====================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|fundbal                      |" << data.fundbal;
    ogsDebug << "|fundavl                      |" << data.fundavl;
    ogsDebug << "|marketvalue                  |" << data.marketvalue;
    ogsDebug << "|fund                         |" << data.fund;
    ogsDebug << "|stkvalue                     |" << data.stkvalue;
    ogsDebug << "|fundseq                      |" << data.fundseq;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryInput]====================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryOutput]===================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|stkbal                       |" << data.stkbal;
    ogsDebug << "|stkavl                       |" << data.stkavl;
    ogsDebug << "|buycost                      |" << data.buycost;
    ogsDebug << "|costprice                    |" << data.costprice;
    ogsDebug << "|mktval                       |" << data.mktval;
    ogsDebug << "|income                       |" << data.income;
    ogsDebug << "|proincome                    |" << data.proincome;
    ogsDebug << "|mtkcalflag                   |" << data.mtkcalflag;
    ogsDebug << "|stkqty                       |" << data.stkqty;
    ogsDebug << "|lastprice                    |" << data.lastprice;
    ogsDebug << "|stktype                      |" << data.stktype;
    ogsDebug << "|stkdiff                      |" << data.stkdiff;
    ogsDebug << "|stkcantrans                  |" << data.stkcantrans;
    ogsDebug << "|stklastbal                   |" << data.stklastbal;
    ogsDebug << "|stkfrz                       |" << data.stkfrz;
    ogsDebug << "|stkunfrz                     |" << data.stkunfrz;
    ogsDebug << "|closeprice                   |" << data.closeprice;
    ogsDebug << "|netaddr                      |" << data.netaddr;
    ogsDebug << "|custtype                     |" << data.custtype;
    ogsDebug << "|seat                         |" << data.seat;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuUnitStkSumQryInput]==================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|fundid                       |" << data.fundid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuUnitStkSumQryOutput]==================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|stkbal                       |" << data.stkbal;
    ogsDebug << "|stkavl                       |" << data.stkavl;
    ogsDebug << "|buycost                      |" << data.buycost;
    ogsDebug << "|costprice                    |" << data.costprice;
    ogsDebug << "|mktval                       |" << data.mktval;
    ogsDebug << "|income                       |" << data.income;
    ogsDebug << "|mtkcalflag                   |" << data.mtkcalflag;
    ogsDebug << "|stkqty                       |" << data.stkqty;
    ogsDebug << "|lastprice                    |" << data.lastprice;
    ogsDebug << "|stktype                      |" << data.stktype;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoByFundIdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientInfoByFundIdInput]================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|fundid                       |" << data.fundid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoByFundIdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientInfoByFundIdOutput]================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryInput]====================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryOutput]===================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|reporttime                   |" << data.reporttime;
    ogsDebug << "|opertime                     |" << data.opertime;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderfrzamt                  |" << data.orderfrzamt;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|cancelqty                    |" << data.cancelqty;
    ogsDebug << "|orderstatus                  |" << data.orderstatus;
    ogsDebug << "|seat                         |" << data.seat;
    ogsDebug << "|cancelflag                   |" << data.cancelflag;
    ogsDebug << "|creditdigestid               |" << data.creditdigestid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuHistEntrustQryInput]==================";
    ogsDebug << "|strdate                      |" << data.strdate;
    ogsDebug << "|enddate                      |" << data.enddate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuHistEntrustQryOutput]=================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|reporttime                   |" << data.reporttime;
    ogsDebug << "|opertime                     |" << data.opertime;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderfrzamt                  |" << data.orderfrzamt;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|cancelqty                    |" << data.cancelqty;
    ogsDebug << "|orderstatus                  |" << data.orderstatus;
    ogsDebug << "|seat                         |" << data.seat;
    ogsDebug << "|creditdigestid               |" << data.creditdigestid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuRealDealQryInput]===================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuRealDealQryOutput]===================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|trddate                      |" << data.trddate;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|matchtime                    |" << data.matchtime;
    ogsDebug << "|matchcode                    |" << data.matchcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|matchtype                    |" << data.matchtype;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|creditdigestid               |" << data.creditdigestid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuHistRealDealQryInput]=================";
    ogsDebug << "|strdate                      |" << data.strdate;
    ogsDebug << "|enddate                      |" << data.enddate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|qryflag                      |" << data.qryflag;
    ogsDebug << "|count                        |" << data.count;
    ogsDebug << "|poststr                      |" << data.poststr;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuHistRealDealQryOutput]=================";
    ogsDebug << "|poststr                      |" << data.poststr;
    ogsDebug << "|bizdate                      |" << data.bizdate;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|orderid                      |" << data.orderid;
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|matchtime                    |" << data.matchtime;
    ogsDebug << "|matchcode                    |" << data.matchcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|stkbal                       |" << data.stkbal;
    ogsDebug << "|digestid                     |" << data.digestid;
    ogsDebug << "|digestname                   |" << data.digestname;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuHistEntrustSumQryInput]================";
    ogsDebug << "|strdate                      |" << data.strdate;
    ogsDebug << "|enddate                      |" << data.enddate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SecuHistEntrustSumQryOutput]================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderfrzamt                  |" << data.orderfrzamt;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|cancelqty                    |" << data.cancelqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealTodaySumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[SecuRealDealTodaySumQryInput]===============";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealTodaySumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuRealDealTodaySumQryOutput]===============";
    ogsDebug << "|operdate                     |" << data.operdate;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|matchtype                    |" << data.matchtype;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|bankid                       |" << data.bankid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuRealDealSumQryInput]==================";
    ogsDebug << "|strdate                      |" << data.strdate;
    ogsDebug << "|enddate                      |" << data.enddate;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuRealDealSumQryOutput]=================";
    ogsDebug << "|bizdate                      |" << data.bizdate;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|matchprice                   |" << data.matchprice;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|bankid                       |" << data.bankid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustSumQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuEntrustSumQryInput]==================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustSumQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustSumQryOutput]==================";
    ogsDebug << "|orderdate                    |" << data.orderdate;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custname                     |" << data.custname;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|stkname                      |" << data.stkname;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|orderprice                   |" << data.orderprice;
    ogsDebug << "|orderqty                     |" << data.orderqty;
    ogsDebug << "|orderfrzamt                  |" << data.orderfrzamt;
    ogsDebug << "|matchqty                     |" << data.matchqty;
    ogsDebug << "|cancelqty                    |" << data.cancelqty;
    ogsDebug << "|matchamt                     |" << data.matchamt;
    ogsDebug << "|qty                          |" << data.qty;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryAssetInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "======================[QryAssetInput]=======================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryAssetOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "======================[QryAssetOutput]======================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|fundbal                      |" << data.fundbal;
    ogsDebug << "|fundavl                      |" << data.fundavl;
    ogsDebug << "|marketvalue                  |" << data.marketvalue;
    ogsDebug << "|fund                         |" << data.fund;
    ogsDebug << "|stkvalue                     |" << data.stkvalue;
    ogsDebug << "|fundseq                      |" << data.fundseq;
    ogsDebug << "|maxdraw                      |" << data.maxdraw;
    ogsDebug << "|netaddr                      |" << data.netaddr;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|bankname                     |" << data.bankname;
    ogsDebug << "|fundbjhgavl                  |" << data.fundbjhgavl;
    ogsDebug << "|creditflag                   |" << data.creditflag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoBySecuIdInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientInfoBySecuIdInput]================";
    ogsDebug << "|secuid                       |" << data.secuid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientInfoBySecuIdOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[QryClientInfoBySecuIdOutput]================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientTotalAssetInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[QryClientTotalAssetInput]=================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const QryClientTotalAssetOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[QryClientTotalAssetOutput]=================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|brhid                        |" << data.brhid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|fundname                     |" << data.fundname;
    ogsDebug << "|moneytype                    |" << data.moneytype;
    ogsDebug << "|fundassettotal               |" << data.fundassettotal;
    ogsDebug << "|fundasset                    |" << data.fundasset;
    ogsDebug << "|fundassetstk                 |" << data.fundassetstk;
    ogsDebug << "|fundassetof                  |" << data.fundassetof;
    ogsDebug << "|fundassetbond                |" << data.fundassetbond;
    ogsDebug << "|fundassetrzgh                |" << data.fundassetrzgh;
    ogsDebug << "|fundassetrqgh                |" << data.fundassetrqgh;
    ogsDebug << "|fundassetstkzy               |" << data.fundassetstkzy;
    ogsDebug << "|fundassetbjhg                |" << data.fundassetbjhg;
    ogsDebug << "|custtype                     |" << data.custtype;
    ogsDebug << "|status                       |" << data.status;
    return logger;
}

OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QrySecuEntrustInput]====================";
    ogsDebug << "|market                       |" << data.market;
    ogsDebug << "|secuid                       |" << data.secuid;
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|stkcode                      |" << data.stkcode;
    ogsDebug << "|bsflag                       |" << data.bsflag;
    ogsDebug << "|price                        |" << data.price;
    ogsDebug << "|qty                          |" << data.qty;
    ogsDebug << "|ordergroup                   |" << data.ordergroup;
    ogsDebug << "|bankcode                     |" << data.bankcode;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|bankpwd                      |" << data.bankpwd;
    ogsDebug << "|authcode                     |" << data.authcode;
    ogsDebug << "|featurecode                  |" << data.featurecode;
    ogsDebug << "|authinfo                     |" << data.authinfo;
    ogsDebug << "|productcode                  |" << data.productcode;
    ogsDebug << "|developercode                |" << data.developercode;
    ogsDebug << "|versioninfo                  |" << data.versioninfo;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[QrySecuEntrustOutput]===================";
    ogsDebug << "|ordersno                     |" << data.ordersno;
    ogsDebug << "|orderid                      |" << data.orderid;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const RecordLoginInfoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[RecordLoginInfoInput]===================";
    ogsDebug << "|fundid                       |" << data.fundid;
    ogsDebug << "|netaddr                      |" << data.netaddr;
    ogsDebug << "|telno                        |" << data.telno;
    ogsDebug << "|ipaddr                       |" << data.ipaddr;
    ogsDebug << "|remark                       |" << data.remark;
    ogsDebug << "|remark1                      |" << data.remark1;
    ogsDebug << "|remark2                      |" << data.remark2;
    ogsDebug << "|remark3                      |" << data.remark3;
    ogsDebug << "|remark4                      |" << data.remark4;
    ogsDebug << "|remark5                      |" << data.remark5;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const RecordLoginInfoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[RecordLoginInfoOutput]===================";
    ogsDebug << "|msgok                        |" << data.msgok;
    return logger;
}

OgsLogger &operator << (OgsLogger &logger, const KcbpFixedInput &data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[KcbpFixedInput]=======================";
    ogsDebug << "|custid                       |" << data.custid;
    ogsDebug << "|custorgid                    |" << data.custorgid;
    ogsDebug << "|trdpwd                       |" << data.trdpwd;
    ogsDebug << "|netaddr                      |" << data.netaddr;
    ogsDebug << "|orgid                        |" << data.orgid;
    ogsDebug << "|operway                      |" << data.operway;
    ogsDebug << "|ext                          |" << data.ext;
    return logger;
}

