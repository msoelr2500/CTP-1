/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "KcbpReader.h"
#include <cstring>
#include "../StringHelper.h"

const size_t KcbpReader::DEFAULT_BUFFER_SIZE = 512;

KcbpReader::KcbpReader(KCBPCLIHANDLE handle, size_t bufferSize)
{
    mHandle = handle;
    mBufferSize = bufferSize;
    mBuffer = new char[mBufferSize];
    mCorrupted = !verify();
}

KcbpReader::~KcbpReader()
{
    KCBPCLI_SQLCloseCursor(mHandle);
    delete [] mBuffer;
}

bool KcbpReader::isCorrupted() const
{
    return mCorrupted;
}

std::string KcbpReader::error() const
{
    return mError;
}

bool KcbpReader::hasMoreData()
{
    return KCBPCLI_SQLMoreResults(mHandle) == 0;
}

bool KcbpReader::loadRow()
{
    return KCBPCLI_RsFetchRow(mHandle) == 0;
}

std::string KcbpReader::get(const char *key)
{
    KCBPCLI_RsGetColByName(mHandle, const_cast<char*>(key), mBuffer);
    return mBuffer;
}

bool KcbpReader::verify()
{
    int errCode = 0;
    KCBPCLI_GetErrorCode(mHandle, &errCode);

    if (errCode != 0) {
        KCBPCLI_GetErrorMsg(mHandle, mBuffer);
        StringHelper::string_format(mError, "error: KCBPCLI_SQLExecute() returns %d: %s", errCode, mBuffer);
        return false;
    }

    errCode = KCBPCLI_RsOpen(mHandle);
    if( errCode != 0 && errCode != 100 ) {
        StringHelper::string_format(mError, "error: KCBPCLI_RsOpen() returns %d", errCode);
        return false;
    }

    int nColNums = 0;
    KCBPCLI_SQLNumResultCols(mHandle, &nColNums);
    KCBPCLI_SQLFetch(mHandle);

    // 检查业务处理是否出现错误。
    if (KCBPCLI_RsGetColByName(mHandle, const_cast<char*>("CODE"), mBuffer)) { return false; }
    if (strcmp(mBuffer, "0") != 0) {
        std::string error_code = mBuffer;
        KCBPCLI_RsGetColByName(mHandle, const_cast<char*>("MSG"), mBuffer);
        StringHelper::string_format(mError, "error(%s): %s", error_code.c_str(), StringHelper::convertCodec(mBuffer).c_str());
        return false;
    }
    return true;
}
