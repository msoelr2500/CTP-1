/****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 ****************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef KCBPAPIWRAPPER_H
#define KCBPAPIWRAPPER_H

#define KCBP_CONNECT_TIMEOUT_MS 1000

#include <string>
#include <list>
#include <mutex>
#include <unistd.h>
#include <kcbp/KCBPCli.h>
#include <kcbp/kdencodecli.h>
#include "KcbpDataStruct.h"
#include <kcbp_gtja/GetAuthInfo.h>

#include "../Interface.h" // for Intf_RetType

struct KcbpFixedInput
{
    // 外围功能编号funcid由接口函数确定。
    std::string custid;         //!< 登陆后送，登录客户代码
    std::string custorgid;      //!< 登录后送，客户所属机构
    std::string trdpwd;         //!< 交易密码
    std::string netaddr;        //!< 操作站点 网卡地址或电话号码
    std::string orgid;          //!< 操作地机构代码
    std::string operway;        //!< 操作方式
    std::string ext = "0";      //!< 目前必须为数值0，做版本号用
    std::string authcode;       //!< 授权码 系统接入登记时分配
    std::string featurecode;    //!< 机器特征码 调用gtjaaccessinfo.dll获得的sFeatureCode
    std::string authinfo;       //!< 认证密码 调用gtjaaccessinfo.dll获得的sAuthInfo
    std::string productcode;    //!< 产品识别码 系统接入登记时分配
    std::string developercode;  //!< 开发商识别码 系统接入登记时分配
    std::string versioninfo;    //!< 软件版本信息 目前不做校验，可以根据实际软件版本信息送入参
};

struct KcbpConfig
{
    std::string mSiteInfoFormat;
    // ------- for connect --------- //
    std::string mServerIp;
    int         mServerPort;
    std::string mUserName;
    std::string mPassword;
    std::string mServerName;
    std::string mSendQName;
    std::string mReceiveQName;
    // ------ for operation -------- //
    std::string mOperWay;  //!< 操作方式
    std::string mOrgId;    //!< 操作地机构代码
    // ------ for entrust ---------- //
    std::string mAuthcode; //!< 授权码 系统接入登记时分配
    std::string mProductcode; //!< 产品识别码
    std::string mDevelopercode; //!< 开发商识别码 系统接入登记时分配
    std::string mVersioninfo; //!< 软件版本信息 目前不做校验，可以根据实际软件版本信息送入参
};

class KcbpApiWrapper
{
public:
    explicit KcbpApiWrapper();
    explicit KcbpApiWrapper(const KcbpConfig& config);
    virtual ~KcbpApiWrapper();

    ////////////////////////////////////////////////////////////////////////////
    /// 初始化，配置选项和网络连接
    ////////////////////////////////////////////////////////////////////////////

    bool connect();

    static void sleepFor(int s);

    /*! \brief 初始化或重初始化lpconfig，在主线程读完配置文件后执行一次，不能在其他线程使用 */
    bool initialize();

    bool isConnected() const;
    bool resetConnection(KCBPCLIHANDLE& hHandle);

    void disconnect();
    void setConfig(const KcbpConfig& config);
    const KcbpConfig& config() const;

    static void safeAssign(std::string& target, const char* source);

    static bool isNetworkError(int errCode);

    static int getAccessInfo(const std::string& custId , std::string& sFeatureCode, std::string& sAuthInfo, std::string &ErrMsg, char* sPrefixIp, char cType = 0);

    ///--------------------------------------------------------------------------------------------------------
    /// KCBP API // 业务范围：公用
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType kcbpClientLogin(const KcbpFixedInput& fixedInput, const ClientLoginInput& input, std::list<ClientLoginOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQryClientInfo(const KcbpFixedInput& fixedInput, std::list<QryClientInfoOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuEntrustWithdraw(const KcbpFixedInput& fixedInput, const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQrySecuEntrustWithdraw(const KcbpFixedInput& fixedInput, const QrySecuEntrustWithdrawInput& input, std::list<QrySecuEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQrySecuHolder(const KcbpFixedInput& fixedInput, const QrySecuHolderInput& input, std::list<QrySecuHolderOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQryFundAsset(const KcbpFixedInput& fixedInput, const QryFundAssetInput& input, std::list<QryFundAssetOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuUnitStkQry(const KcbpFixedInput& fixedInput, const SecuUnitStkQryInput& input, std::list<SecuUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuUnitStkSumQry(const KcbpFixedInput& fixedInput, const SecuUnitStkSumQryInput& input, std::list<SecuUnitStkSumQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQryClientInfoByFundId(const KcbpFixedInput& fixedInput, const QryClientInfoByFundIdInput& input, std::list<QryClientInfoByFundIdOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuEntrustQry(const KcbpFixedInput& fixedInput, const SecuEntrustQryInput& input, std::list<SecuEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuHistEntrustQry(const KcbpFixedInput& fixedInput, const SecuHistEntrustQryInput& input, std::list<SecuHistEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuRealDealQry(const KcbpFixedInput& fixedInput, const SecuRealDealQryInput& input, std::list<SecuRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuHistRealDealQry(const KcbpFixedInput& fixedInput, const SecuHistRealDealQryInput& input, std::list<SecuHistRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuHistEntrustSumQry(const KcbpFixedInput& fixedInput, const SecuHistEntrustSumQryInput& input, std::list<SecuHistEntrustSumQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuRealDealTodaySumQry(const KcbpFixedInput& fixedInput, const SecuRealDealTodaySumQryInput& input, std::list<SecuRealDealTodaySumQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuRealDealSumQry(const KcbpFixedInput& fixedInput, const SecuRealDealSumQryInput& input, std::list<SecuRealDealSumQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuEntrustSumQry(const KcbpFixedInput& fixedInput, const SecuEntrustSumQryInput& input, std::list<SecuEntrustSumQryOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQryAsset(const KcbpFixedInput& fixedInput, const QryAssetInput& input, std::list<QryAssetOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQryClientInfoBySecuId(const KcbpFixedInput& fixedInput, const QryClientInfoBySecuIdInput& input, std::list<QryClientInfoBySecuIdOutput>& output, std::string& errMsg);
    Intf_RetType kcbpQryClientTotalAsset(const KcbpFixedInput& fixedInput, const QryClientTotalAssetInput& input, std::list<QryClientTotalAssetOutput>& output, std::string& errMsg);
    Intf_RetType kcbpSecuEntrust(const KcbpFixedInput& fixedInput, const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg);
    Intf_RetType kcbpRecordLoginInfo(const KcbpFixedInput& fixedInput, const RecordLoginInfoInput& input, std::list<RecordLoginInfoOutput>& output, std::string& errMsg);

protected:
    static void fillFixedInput(const char* func_code, const KcbpFixedInput& fixedInput, KCBPCLIHANDLE mHandle);

private:
    bool mConnected = false;
    KcbpConfig mConfig;

    static tagKCBPConnectOption mKCBPConnection;

    KCBPCLIHANDLE mHandle = NULL;
    static std::mutex mInitMutex;
};

#endif // KCBPAPIWRAPPER_H
