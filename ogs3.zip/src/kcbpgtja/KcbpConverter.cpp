/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "KcbpConverter.h"
#include "KcbpLogger.h"
#include <string.h>

using std::string;

using ogs::ogs_dict::ExecutionType;
using ogs::ogs_dict::OrderStatusType;
using qtp::MarketCode;
using ogs::ogs_dict::DirectiveType;

ogs::OGS_BALANCE KcbpConverter::from_balance(const std::string &balance)
{
    return std::atof(balance.c_str()) * 10000;
}

std::string KcbpConverter::to_amount(ogs::OGS_VOLUME volume)
{
    return std::to_string(volume);
}

std::string KcbpConverter::to_client_id(const char *acidcard)
{
    return acidcard;
}

string KcbpConverter::op_station(const string &wip, const std::string& clientIp, const string &mac, const string &disksn, const string &cpuid)
{
    string result;
    StringHelper::string_format(result, "TYJR-LHHJ- IIP.%s LIP.%s MAC.%s HD.%s CPU.%s",
                                         wip.c_str(), clientIp.c_str(), mac.c_str(), disksn.c_str(), cpuid.c_str());
    return result;
}

std::string KcbpConverter::to_fund_account(const char* bacid)
{
    return bacid;
}

std::string KcbpConverter::to_trdpwd(const char *password)
{
    return password;
}

std::string KcbpConverter::to_entrust_no(const char *sysOrderId)
{
    return string(sysOrderId);
}

std::string KcbpConverter::to_entrust_type(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
        return string("0");
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
        return string("7");
    case ogs::ogs_dict::kDtLoanBuy:
        return string("6");
    default: return string();
    }
}

std::string KcbpConverter::to_market(qtp::MarketCode code)
{
    switch(code){
    case qtp::kMC_SSE: return string("1");
    case qtp::kMC_SZE: return string("2");
    case qtp::kMC_UNKNOW:
    case qtp::kMC_CFFE:
        return string();
    }
    return string();
}

std::string KcbpConverter::to_stock_code(const std::string &code)
{
    if (code == "000000") {
        return string("");
    }
    return code;
}

std::string KcbpConverter::to_bsflag(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtLoanBuy:
    case ogs::ogs_dict::kDtGuaranteeBuy:
    case ogs::ogs_dict::kDtBuy:
        return string("0B");
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtGuaranteeSell:
        return string("0S");
    default: return string();
    }
}

std::string KcbpConverter::to_creditdigestid(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtGuaranteeBuy:
        return string("a");
    case ogs::ogs_dict::kDtLoanBuy:
        return string("b");
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtGuaranteeSell:
        return string("c");
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
        return string("d");
    case ogs::ogs_dict::kDtMarketSecPayback:
    case ogs::ogs_dict::kDtSecPayback:
        return string("f");
    case ogs::ogs_dict::kDtBuyPayback:
        return string("e");
    case ogs::ogs_dict::kDtSellPayBack:
        return string("u");
    default: return string();
    }
}

ogs::OGS_DIRECTIVE KcbpConverter::from_operation(const std::string &bsflag, const std::string &creditdigestid)
{
    if (bsflag == "0B" && creditdigestid == "a") {
        return ogs::ogs_dict::kDtBuy;
    } else if (bsflag == "0S" && creditdigestid == "c") {
        return ogs::ogs_dict::kDtSell;
    } else if (bsflag == "0B" && creditdigestid == "b") {
        return ogs::ogs_dict::kDtLoanBuy;
    } else if (bsflag == "0S" && creditdigestid == "d") {
        return ogs::ogs_dict::kDtMarginSell;
    } else if (creditdigestid == "f") {
        return ogs::ogs_dict::kDtSecPayback;
    } else if (creditdigestid == "e") {
        return ogs::ogs_dict::kDtBuyPayback;
    } else if (creditdigestid == "u") {
        return ogs::ogs_dict::kDtSellPayBack;
    }
    return static_cast<ogs::OGS_DIRECTIVE>(-1);
}

Exchange KcbpConverter::to_exchange_index(const std::string &exchange_type)
{
    if (exchange_type == "1") {
        return Exchange::SSE;
    } else if (exchange_type == "2") {
        return Exchange::SZE;
    } else if (exchange_type == "D") {
        return Exchange::SH_B;
    } else if (exchange_type == "5") {
        return Exchange::SH_HK;
    } else if (exchange_type == "H") {
        return Exchange::SZ_B;
    }
    return Exchange::ExchangeCount;
}

std::string KcbpConverter::to_price(uint32_t ogs_price)
{
    string result;
    StringHelper::string_format(result, "%.3f", ogs_price / 10000.0);
    return result;
}

int KcbpConverter::from_price(const std::string &price)
{
    return (int)(std::stod(price) * 10000);
}

ogs::OGS_VOLUME KcbpConverter::from_amount(const std::string &amount)
{
    return std::stoll(amount);
}

/*! kcbp返回时间格式为："Hmmss??" */
uint32_t KcbpConverter::from_opertime(const std::string &time)
{
    int hour, minute, second;
    if (time.size() == 7) {
        hour = std::stoi(time.substr(0, 1));
        minute = std::stoi(time.substr(1, 2));
        second = std::stoi(time.substr(3, 2));
    } else if (time.size() == 8) {
        hour = std::stoi(time.substr(0, 2));
        minute = std::stoi(time.substr(2, 2));
        second = std::stoi(time.substr(4, 2));
    } else {
        kcbpError << "error: opertime(" << time << ") can't be parsed.";
    }

    return hour * 10000 + minute * 100 + second;
}

/*! kcbp返回日期格式为："yyyyMMdd" */
uint32_t KcbpConverter::from_orderdate(const std::string &date)
{
    int year = std::stoi(date.substr(0, 4));
    int month = std::stoi(date.substr(4, 2));
    int day = std::stoi(date.substr(6, 2));

    return year * 10000 + month * 100 + day;
}

qtp::MarketCode KcbpConverter::from_market(const std::string &exchange_type)
{
    if (exchange_type == "1") {
        return qtp::kMC_SSE;
    } else if (exchange_type == "2"){
        return qtp::kMC_SZE;
    } else {
        return qtp::kMC_UNKNOW;
    }
}

ogs::ogs_dict::OrderStatusType KcbpConverter::from_orderstatus(const std::string &entrust_status)
{
    if(entrust_status == "0"){
        return ogs::ogs_dict::kOtNotReported;
    }else if(entrust_status == "1"){
        return ogs::ogs_dict::kOtWaitReporting;
    }else if(entrust_status == "2"){
        return ogs::ogs_dict::kOtReported;
    }else if(entrust_status == "3"){
        return ogs::ogs_dict::kOtCanceling;
    }else if(entrust_status == "4"){
        return ogs::ogs_dict::kOtMatchedCanceling;
    }else if(entrust_status == "5"){
        return ogs::ogs_dict::kOtMatchedCanceled;
    }else if(entrust_status == "6"){
        return ogs::ogs_dict::kOtCanceled;
    }else if(entrust_status == "7"){
        return ogs::ogs_dict::kOtPartMatched;
    }else if(entrust_status == "8"){
        return ogs::ogs_dict::kOtMatchedAll;
    }else if(entrust_status == "9"){
        return ogs::ogs_dict::kOtBad;
    }else{
        return ogs::ogs_dict::kOtNotApproved;
    }
}

ogs::OGS_INNERCODE KcbpConverter::from_stock_code(const std::string &stock_code)
{
    return qtp::UniversalCode::SymbolToUC(stock_code);
}

void KcbpConverter::from_entrust_no(const std::string &entrust_no, char *sysOrderId)
{
    memcpy(sysOrderId, entrust_no.c_str(), entrust_no.size());
}

void KcbpConverter::from_business_no(const std::string &business_no, char *dealId)
{
    memcpy(dealId, business_no.c_str(), business_no.size());
}

void KcbpConverter::from_string(char *target, const std::string &source)
{
    strcpy(target, source.c_str());
}
