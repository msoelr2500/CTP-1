/*****************************************************************************
 *
 * Copyright (C) 2016 SmartAlpha - All Rights Reserved
 *
 * You may not use, distribute and modify this code for any
 * purpose unless you receive an official authorization from
 * SmartAlpha.
 *
 * You should have received a copy of the license with
 * this file. If not, please write to: admin@smartalpha.cn,
 * or visit: http://smartalpha.cn
 *
 *****************************************************************************/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef KCBPREADER_H
#define KCBPREADER_H

#include <kcbp/KCBPCli.h>
#include <string>

class KcbpReader
{
public:
    KcbpReader(KCBPCLIHANDLE handle, size_t bufferSize = DEFAULT_BUFFER_SIZE);
    virtual ~KcbpReader();

    bool isCorrupted() const;
    std::string error() const;

    bool hasMoreData();
    bool loadRow();
    std::string get(const char* key);

    static const size_t DEFAULT_BUFFER_SIZE;

protected:
    bool verify();

private:
    char* mBuffer;
    size_t mBufferSize;
    bool mCorrupted = false;
    std::string mError;
    KCBPCLIHANDLE mHandle;
};

#endif // KCBPREADER_H
