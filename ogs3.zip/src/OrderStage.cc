//
// Created by lwk on 16-5-9.
//

#include "OrderStage.h"
#include "OgsLogger.h"
//#include "InterfaceCteate.h"
#include "OgsMessage.h"
#include "OgsForwarder.h"

using std::string;

#define MAKEBUFFER(T)\
std::string qryBuffer,ansBuffer,option;\
uint32_t item_size = 0;\
uint32_t item_cnt = 0;\
uint16_t option_len = 0;\
if (GetItemSizeAndCnt(message, &item_size, &item_cnt) != 0) {\
LOG(error)<<"get size&cnt error,item_size:"<<item_size<<" item_cnt:"<<item_cnt;return -1;}\
if (item_size != sizeof(T)) {LOG(error)<<"error of item_size:"<<item_size;return -1;}\
if (item_size * item_cnt != message->GetDataLen()) {\
LOG(error)<<"error of DataLen,item_size:"<<item_size<<" item_cnt:"<<item_cnt;return -1;}\
BUF_HANDLE_COUNTTYPE cnt=item_cnt;\
char chTmp[1024];\
void * tmpBuf=nullptr;\
memcpy(chTmp,&cnt, sizeof(BUF_HANDLE_COUNTTYPE));\
qryBuffer.assign(chTmp,sizeof(BUF_HANDLE_COUNTTYPE));\
qryBuffer.append((const char *)message->GetData(),message->DataLen());\
std::map<int, std::string> args;\
if(message->GetOption((uint16_t)1010, (const void **)&tmpBuf, &option_len) == 0)\
{option=(char *)tmpBuf; option.resize(option_len);\
ogsDebug << "oms SiteInfo = " << option;\
ogs::ParseOmsSiteInfo(option, args);}\
else LOG(error)<<"GetOption OmsSiteInfo error";\
int tryCnt = 5;\
while (!interfacePtr->getConnectStatus()&&(tryCnt-->0)) {\
LOG(warn) << "try to reConnectBroker";\
interfacePtr->reConnectBroker();sleep(1);}\
if (tryCnt<=0){LOG(warn) << "reConnectBroker fail"; return -1;}\
std::string errMsg;\
Intf_RetType ret;

#define REPBUFFER(T,msg_type)\
if (ret != kIntfSuccess) {\
LOG(error) << "[OrderStage] interface called fail, msgType: " << OgsLogger::msgType(msg_type) << ", errorcode: " << ret;}\
qtp::session_id_t client_session=0;\
message->GetTagAsInteger(kTagSession,&client_session);\
UnpackBuffer<T> unpackBuffer(&ansBuffer);\
unpackBuffer.First();\
auto response = std::make_shared<qtp::QtpMessage>();\
response->BeginEncode(msg_type,0);\
item_size=sizeof(T);\
item_cnt=unpackBuffer.GetDataCount();\
SetItemSizeAndCnt(response,item_size,item_cnt);\
errMsg.append(".");\
uint32_t errorCode = ret;\
SetErrorCodeAndMsg(response, errorCode, errMsg.c_str(), errMsg.length());\
response->AddTag(kTagSession,&client_session, sizeof(qtp::session_id_t));\
OGS_BACID *bacid=unpackBuffer.GetDataObjPtr()->bacid;\
response->AddTag(kTagBacid,bacid,strlen(bacid));\
OGS_SYSTIME recvTime;\
message->GetTagAsInteger(kTagTime,&recvTime);\
response->AddTag(kTagTime,&recvTime,sizeof(OGS_SYSTIME));\
response->SetData(ansBuffer.c_str()+ sizeof(BUF_HANDLE_COUNTTYPE),unpackBuffer.GetDataCount()*sizeof(T),false);\
response->Encode();

namespace ogs {
    bool OrderStage::m_setSubFlag = true;

    int OrderStage::mOrderStageCount = 0;
    std::mutex OrderStage::mOrderStageCountMutex;

    OrderStage::OrderStage(std::string brokerType, int nId, bool initSub) : QtpStage() {
        std::lock_guard<std::mutex> local_lock(mOrderStageCountMutex);
        mOrderStageId = mOrderStageCount;
        mOrderStageCount++;

        ogsInfo << "[OrderStage] OrderStage " << mOrderStageId << " is created.";

        id = nId;
        Fn_InterfaceCreate(brokerType, interfacePtr);
        if(interfacePtr== nullptr) {
            LOG(info) << "[OrderStage] get nullptr interface(" << brokerType << "), shutdown ogs-server!";
            std::cerr << "\033[31m[OrderStage] get nullptr interface(" << brokerType << "), shutdown ogs-server!\033[0m" << std::endl;
            exit(0);
        }
        interfacePtr->initCommon();
        interfacePtr->setCallBack(&CallBack);
        //interfacePtr->connectBroker();
        m_initSubFlag = initSub;
        if (initSub) {
            interfacePtr->initSubscribe();
        }
    }

    int OrderStage::OnEvent(qtp::QtpMessagePtr message) {
        ogsInfo << "[OrderStage" << mOrderStageId << "] [OnEvent] MsgType: " << OgsLogger::msgType(message->MsgType());
        switch (message->MsgType()) {
            case kMtLogin:
                HandleLogin(message);
                break;
            case kMtSendOrder:
                HandleSendOrder(message);
                break;
            case kMtCancelOrder:
                HandleCancelOrder(message);
                break;
            case kMtQueryOrder:
                HandleQueryOrder(message);
                break;
            case kMtQueryBargain:
                HandleQueryBargain(message);
                break;
            case kMtQueryFundInfo:
                HandleQueryFundInfo(message);
                break;
            case kMtQueryPosition:
                HandleQueryPosition(message);
                break;
                //case kMtHeartBeat:
            case kMtHeartBeatTimer:
                HandleHeartBeat(message);
                break;
            case kMtQueryOrderSe:
                HandleQueryOrderSe(message);
                break;
            case kMtPaybackSecurity:
                HandlePaybackSecurity(message);
                break;
            case kMtPaybackFunds:
                HandlePaybackFunds(message);
                break;
        }
        ogsInfo << "[OrderStage" << mOrderStageId << "] [OnEvent] message has been processed.";
        return 0;
    }

    void OrderStage::Run() {
        while (1) {
            if (interfacePtr->connectBroker() == kIntfSuccess) {
                LOG(info) << "[OrderStage] Connect Broker success";
                break;
            }
            else {
                LOG(warn) << "[OrderStage] Connect Broker fail";
                sleep(1);
            }
        }
        qtp::QtpStage::Run();
    }

    int OrderStage::HandleLogin(qtp::QtpMessagePtr message) {
        OgsMessage ogsMessage(message);
        if (ogsMessage.isCorrupted()) {
            LOG(error) << "[OrderStage] [HandleLogin] " << ogsMessage.error();
            return -1;
        }

        string qryBuffer = ogsMessage.toQryBuffer();
        string ansBuffer;

        int tryCnt = 5;
        while (!interfacePtr->getConnectStatus() && (tryCnt-- > 0)) {
            LOG(warn) << "[OrderStage] [HandleLogin] try to reConnectBroker";
            interfacePtr->reConnectBroker();
            sleep(1);
        }
        if (tryCnt <= 0) {
            LOG(warn) << "[OrderStage] [HandleLogin] reConnectBroker fail";
            return -1;
        }
        std::string errMsg;
        Intf_RetType ret;

        std::vector<std::string> vParams;
        std::map<int, std::string> args;
        ret = interfacePtr->login(qryBuffer, ansBuffer, errMsg, vParams, args);

        if (ret != kIntfSuccess) {
            LOG(error) << "[OrderStage] [HandleLogin] interface called fail,errorcode: " << ret;
        }
        if (m_setSubFlag) {
            interfacePtr->setSubscribe(vParams);
            m_setSubFlag = false;
        }

        UnpackBuffer<LoginAns> unpackBuffer(&ansBuffer);
        qtp::QtpMessagePtr response = std::make_shared<qtp::QtpMessage>();
        response->BeginEncode(kMtLoginAns, kOgsServiceId);

        uint32_t item_size = sizeof(LoginAns);
        uint32_t item_cnt = unpackBuffer.GetDataCount();
        uint32_t error_code = (uint32_t)ret;

        SetItemSizeAndCnt(response, item_size, item_cnt);
        SetErrorCodeAndMsg(response, error_code, errMsg.c_str(), errMsg.length());

        unpackBuffer.First();
        OGS_BACID *bacid = unpackBuffer.GetDataObjPtr()->bacid;

        response->AddTag(kTagBacid, bacid, strlen(bacid));
        response->CopyTag(*message, kTagTime);
        response->CopyTag(*message, kTagSession);
        response->SetData(ansBuffer.c_str() + sizeof(BUF_HANDLE_COUNTTYPE), unpackBuffer.GetDataCount() * sizeof(LoginAns), false);
        response->Encode(qtp::QtpMessage::kEnNormal);

        OgsForwarder::SendMessage(kRepStageID, response);
        OgsForwarder::SendMessage(kOrderMgrStageID, response);

        return ret;
    }

    int OrderStage::HandleSendOrder(qtp::QtpMessagePtr message) {
        MAKEBUFFER(SendOrderQry);
        SendOrderQry* array = (SendOrderQry*)message->GetData();
        for (size_t i = 0; i < item_cnt; i++) {
            orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleSendOrder] start...";
        }

        ret = interfacePtr->sendOrder(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(SendOrderAns, kMtSendOrderAns);

        for (size_t i = 0; i < item_cnt; i++) {
            orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleSendOrder] finished(" << ret << "): " << errMsg;
        }

        OgsForwarder::SendMessage(kRepStageID, response);
        OgsForwarder::SendMessage(kOrderMgrStageID, response);
        return ret;
    }

    int OrderStage::HandleCancelOrder(qtp::QtpMessagePtr message) {
        MAKEBUFFER(CancelOrderQry);
        CancelOrderQry* array = (CancelOrderQry*)message->GetData();
        for (size_t i = 0; i < item_cnt; i++) {
            orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleCancelOrder] start...";
        }

        ret = interfacePtr->cancelOrder(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(CancelOrderAns, kMtCancelOrderAns);
        for (size_t i = 0; i < item_cnt; i++) {
            orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleCancelOrder] finished(" << ret << "): " << errMsg;
        }

        OgsForwarder::SendMessage(kRepStageID, response);
        return ret;
    }

    int OrderStage::HandleQueryOrder(qtp::QtpMessagePtr message) {
        MAKEBUFFER(QueryOrderQry);
        OGS_TAGSYSORDERIDISEMPTY tag_SysOrderIdIsEmpty;
        message->GetTagAsInteger(kTagSysOrderIdIsEmpty, &tag_SysOrderIdIsEmpty);

        QueryOrderQry* array = (QueryOrderQry*)message->GetData();
        for (size_t i = 0; i < item_cnt; i++) {
            if (tag_SysOrderIdIsEmpty == 1) {
                orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleQueryOrder] [fuzzy] start...";
            } else {
                orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleQueryOrder] [accurate] start...";
            }
        }

        ret = interfacePtr->queryOrder(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(QueryOrderAns, kMtQueryOrderAns);
        for (size_t i = 0; i < item_cnt; i++) {
            if (tag_SysOrderIdIsEmpty == 1) {
                orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleQueryOrder] [fuzzy] finished(" << OgsLogger::errorCode(ret) << "): " << errMsg;
            } else {
                orderLog(array[i].custOrderId) << "[OrderStage" << mOrderStageId << "] [HandleQueryOrder] [accurate] finished(" << OgsLogger::errorCode(ret) << "): " << errMsg;
            }
        }

        response->AddTag(kTagSysOrderIdIsEmpty,&tag_SysOrderIdIsEmpty,sizeof(OGS_TAGSYSORDERIDISEMPTY));
        OgsForwarder::SendMessage(kOrderMgrStageID, response);
        return ret;
    }

    int OrderStage::HandleQueryBargain(qtp::QtpMessagePtr message) {
        MAKEBUFFER(QueryBargainQry);
        ret = interfacePtr->queryBargain(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(QueryBargainAns, kMtQueryBargainAns);
        OgsForwarder::SendMessage(kRepStageID, response);
        return ret;
    }

    int OrderStage::HandleQueryFundInfo(qtp::QtpMessagePtr message) {
        MAKEBUFFER(QueryFundInfoQry);
        ret = interfacePtr->queryFundInfo(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(QueryFundInfoAns, kMtQueryFundInfoAns);
        OgsForwarder::SendMessage(kRepStageID, response);
        return ret;
    }

    int OrderStage::HandleQueryPosition(qtp::QtpMessagePtr message) {
        MAKEBUFFER(QueryPositionQry);
        ret = interfacePtr->queryPosition(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(QueryPositionAns, kMtQueryPositionAns);
        OgsForwarder::SendMessage(kRepStageID, response);
        return ret;
    }

    int OrderStage::HandleHeartBeat(qtp::QtpMessagePtr message) {
        int tryCnt = 5;
        while (!interfacePtr->getConnectStatus() && (tryCnt-- > 0)) {
            LOG(warn) << "[OrderStage] [HandleHeartBeat] try to reConnectBroker";
            interfacePtr->reConnectBroker();
            sleep(1);
        }
        if (tryCnt <= 0) {
            LOG(warn) << "[OrderStage] [HandleHeartBeat] reConnectBroker fail";
            return -1;
        }
        return interfacePtr->heartBeatToBroker();
    }

    int OrderStage::HandleQueryOrderSe(qtp::QtpMessagePtr message)
    {
        MAKEBUFFER(QueryOrderQry);
        ret = interfacePtr->queryOrder(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(QueryOrderAns, kMtQueryOrderSeAns);
        OgsForwarder::SendMessage(kRepStageID, response);
        return ret;
    }

    int OrderStage::CallBack(const QueryOrderAns& queryOrderAns, const std::string& description) {
        VLOG(200) << "[OrderStage] [CallBack] callback on orderId:" << queryOrderAns.custOrderId;
        auto response = std::make_shared<qtp::QtpMessage>();
        response->BeginEncode(kMtQueryOrderAns, 0);
        uint32_t item_size = sizeof(QueryOrderAns);
        uint32_t item_cnt = 1;
        SetItemSizeAndCnt(response, item_size, item_cnt);

        //! 对于订阅推送的查单回报，其错误信息即为说明信息。
        std::string errMsg = description.empty() ? std::string("订单推送成功") : description;
        uint32_t error_code = kIntfSuccess;
        SetErrorCodeAndMsg(response, error_code, errMsg.c_str(), errMsg.length());

        qtp::session_id_t client_session = 0;
        response->AddTag(kTagSession, &client_session, sizeof(qtp::session_id_t));
        OGS_BACID bacid[BACIDSIZE];
        strcpy(bacid, queryOrderAns.bacid);
        response->AddTag(kTagBacid, bacid, strlen(bacid));
        OGS_SYSTIME recvTime = GetTimeHMS();
        response->AddTag(kTagTime, &recvTime, sizeof(OGS_SYSTIME));
        OGS_TAGISCALLBACK isCallback = 1;
        response->AddTag(kTagIsCallback, &isCallback, sizeof(OGS_TAGISCALLBACK));

        response->SetData(&queryOrderAns, item_size, false);
        response->Encode();

        OgsForwarder::SendMessage(kOrderMgrStageID, response);
        return 0;
    }

    int OrderStage::HandlePaybackSecurity(qtp::QtpMessagePtr message) {
        return 0;
    }

    int OrderStage::HandlePaybackFunds(qtp::QtpMessagePtr message) {
        MAKEBUFFER(PaybackFundsQry);
        ret = interfacePtr->paybackFunds(qryBuffer, ansBuffer, errMsg, args);
        REPBUFFER(PaybackFundsAns, kMtPaybackFundsAns);
        OgsForwarder::SendMessage(kRepStageID, response);
        return ret;
    }

    int OrderStage::CallBack(QueryOrderAns queryOrderAns)
    {
        return CallBack(queryOrderAns, std::string());
    }


}
