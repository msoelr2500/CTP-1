#ifndef OGSLOGGER_H
#define OGSLOGGER_H

#include "OgsGlobal.h"
#include "DataStruct.h"
#include "qtp_log.h"
#include "singleton.h"
#include <mutex>

enum LogLevel {
    LEVEL_OFF = 0,
    LEVEL_FATAL = 50,
    LEVEL_ERROR = 100,
    LEVEL_WARN = 150,
    LEVEL_INFO = 200,
    LEVEL_DEBUG = 400,
    LEVEL_TRACE = 600,
    LEVEL_ALL = 100000
};

#define ogsFatal VLOG(LEVEL_FATAL)
#define ogsError VLOG(LEVEL_ERROR)
#define ogsWarn VLOG(LEVEL_WARN)
#define ogsInfo VLOG(LEVEL_INFO)
#define ogsDebug VLOG(LEVEL_DEBUG)
#define ogsTrace VLOG(LEVEL_TRACE)
#define orderLog(id) ogsInfo << "[" << id << "] "

#define ogsLogger OgsLogger::Instance
#define LOCK_OGSLOGGER(ogslogger) std::lock_guard<std::mutex> ogsLock((ogslogger).mutex())

class OgsMessage;

class OgsLogger : public qtp::Singleton<OgsLogger>
{
public:
    std::mutex& mutex();

    OgsLogger& operator << (ogs::LoginQry& qry);
    OgsLogger& operator << (ogs::LoginAns& ans);
    OgsLogger& operator << (ogs::SendOrderQry& qry);
    OgsLogger& operator << (ogs::SendOrderAns& ans);
    OgsLogger& operator << (ogs::CancelOrderQry& qry);
    OgsLogger& operator << (ogs::CancelOrderAns& ans);
    OgsLogger& operator << (ogs::QueryOrderQry& qry);
    OgsLogger& operator << (ogs::QueryOrderAns& ans);
    OgsLogger& operator << (ogs::QueryBargainQry& qry);
    OgsLogger& operator << (ogs::QueryBargainAns& ans);
    OgsLogger& operator << (ogs::QueryFundInfoQry& qry);
    OgsLogger& operator << (ogs::QueryFundInfoAns& ans);
    OgsLogger& operator << (ogs::QueryPositionQry& qry);
    OgsLogger& operator << (ogs::QueryPositionAns& ans);
    OgsLogger& operator << (ogs::PaybackSecurityQry& qry);
    OgsLogger& operator << (ogs::PaybackSecurityAns& ans);
    OgsLogger& operator << (ogs::PaybackFundsQry& qry);
    OgsLogger& operator << (ogs::PaybackFundsAns& ans);
    OgsLogger& operator << (ogs::HeartBeatQry& qry);
    OgsLogger& operator << (ogs::HeartBeatAns& ans);

    void lockLessLog(ogs::LoginQry& qry) const;
    void lockLessLog(ogs::LoginAns& ans) const;
    void lockLessLog(ogs::SendOrderQry& qry) const;
    void lockLessLog(ogs::SendOrderAns& ans) const;
    void lockLessLog(ogs::CancelOrderQry& qry) const;
    void lockLessLog(ogs::CancelOrderAns& ans) const;
    void lockLessLog(ogs::QueryOrderQry& qry) const;
    void lockLessLog(ogs::QueryOrderAns& ans) const;
    void lockLessLog(ogs::QueryBargainQry& qry) const;
    void lockLessLog(ogs::QueryBargainAns& ans) const;
    void lockLessLog(ogs::QueryFundInfoQry& qry) const;
    void lockLessLog(ogs::QueryFundInfoAns& ans) const;
    void lockLessLog(ogs::QueryPositionQry& qry) const;
    void lockLessLog(ogs::QueryPositionAns& ans) const;
    void lockLessLog(ogs::PaybackSecurityQry& qry) const;
    void lockLessLog(ogs::PaybackSecurityAns& ans) const;
    void lockLessLog(ogs::PaybackFundsQry& qry) const;
    void lockLessLog(ogs::PaybackFundsAns& ans) const;
    void lockLessLog(ogs::HeartBeatQry& qry) const;
    void lockLessLog(ogs::HeartBeatAns& ans) const;

    OgsLogger& operator << (OgsMessage& msg);

    static std::string msgType(uint32_t type);
    static std::string errorCode(uint32_t code);

protected:
    void logPassword(const char* password) const;

private:
    std::mutex mMutex;
};

#endif // OGSLOGGER_H
