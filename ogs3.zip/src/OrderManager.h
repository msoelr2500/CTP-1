////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-17
////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef ORDERMANAGER_H
#define ORDERMANAGER_H

#include <map>
#include <rocksdb/db.h>
#include <qtp_session.h>

#include "DataStruct.h"
#include "Interface.h"

/*!
 * \brief 订单状态，该订单状态主要用于ogs订单管理而不是用来描述订单在交易所的状态。
 */
enum OrderState
{
    WAITING_ENTRUST_ANS,
    WAITING_ENTRUST_QRY_ANS,
    FINISHED
};

class OrderItem
{
public:
    OrderItem()
    {
        orderInfo = {0};
        queryCount = 10;
    }

    OrderItem(const ogs::OrderInfo& info, int queryCount)
    {
        orderInfo = info;
        this->queryCount = queryCount;
    }

    bool isSuccessfullyEntrusted() {
        return strlen(orderInfo.sysOrderId) > 0;
    }

    ogs::OrderInfo orderInfo;                 //!< 订单信息。
    OrderState mOrderState;                   //!< 订单状态。

    bool mWaitingSendOrderAns = false;        //!< 该订单是否收到了下单回报
    int  mWaitingSendOrderAnsPeriod = 0;      //!< 等待下单回报的周期数 （以kOrderMgrTimerId定时器周期为单位）

    bool mWaitingQueryOrderAns = false;       //!< 该订单是否正在等待查单回报
    int  mWaitingQueryOrderAnsPeriod = 0;     //!< 等待查单回报的周期数 （以kOrderMgrTimerId定时器周期为单位）

    std::string mEntrustError;                //!< 委托错误。
    std::string mStatusInfo;                  //!< 最新状态信息。
    std::string mNotifyPrompt;                //!< 推送提示。
    int queryCount = 10;                      //!< 剩余查单次数。

    OrderItem& operator=(const OrderItem& item)
    {
        orderInfo                   = item.orderInfo;
        queryCount                  = item.queryCount;

        mWaitingSendOrderAns        = item.mWaitingSendOrderAns;
        mWaitingSendOrderAnsPeriod  = item.mWaitingSendOrderAnsPeriod;

        mWaitingQueryOrderAns       = item.mWaitingQueryOrderAns;
        mWaitingQueryOrderAnsPeriod = item.mWaitingQueryOrderAnsPeriod;

        mEntrustError               = item.mEntrustError;
        mStatusInfo                 = item.mStatusInfo;
        mNotifyPrompt               = item.mNotifyPrompt;
    }

    ogs::QueryOrderAns toQueryOrderAns() const
    {
        ogs::QueryOrderAns ans = {0};
        strcpy(ans.bacid, orderInfo.bacid);
        ans.custOrderId    = orderInfo.custOrderId;
        ans.price          = orderInfo.price;
        ans.volume         = orderInfo.volume;
        ans.orderStatus    = orderInfo.orderStatus;
        ans.dealVolume     = orderInfo.dealVolume;
        ans.dealBalance    = orderInfo.dealBalance;
        ans.dealPrice      = orderInfo.dealPrice;
        ans.innerCode      = orderInfo.innerCode;
        ans.withdrawVolume = orderInfo.withdrawVolume;
        ans.directive      = orderInfo.directive;
        ans.tradeDate      = orderInfo.tradeDate;
        ans.orderTime      = orderInfo.orderTime;
        memcpy(ans.sysOrderId, orderInfo.sysOrderId, SYSORDERIDSIZE);
        return ans;
    }

    ogs::QueryOrderQry toQueryOrderQry() const
    {
        ogs::QueryOrderQry qry = {0};
        strcpy(qry.acidcard, orderInfo.acidcard);
        strcpy(qry.bacid, orderInfo.bacid);
        qry.actype      = orderInfo.actype;
        qry.innerCode   = orderInfo.innerCode;
        qry.directive   = orderInfo.directive;
        qry.execution   = orderInfo.execution;
        qry.custOrderId = orderInfo.custOrderId;
        memcpy(qry.ipAddr,     orderInfo.ipAddr,     IPSIZE);
        memcpy(qry.macAddr,    orderInfo.macAddr,    MACSIZE);
        memcpy(qry.diskSn,     orderInfo.diskSn,     DISKSNSIZE);
        memcpy(qry.password,   orderInfo.password,   PASSWORDSIZE);
        memcpy(qry.sysOrderId, orderInfo.sysOrderId, SYSORDERIDSIZE);
        return qry;
    }
};

class OrderManager
{
public:
    OrderManager();
    explicit OrderManager(const std::string& dbPath);
    virtual ~OrderManager();

    bool setDatabase(const std::string& dbPath);
    bool isDatabaseOpen() const;
    std::string databasePath() const;
    const rocksdb::Status& databaseStatus() const;

    bool hasOrder(const char* sysOrderId) const;
    bool matchOrder(ogs::QueryOrderAns* array, int size);

    // add method.
    bool addOrder(const OrderItem& item);
    bool addOrder(const ogs::SendOrderQry& sendOrderQry, qtp::session_id_t session_id);

    // update method.
    bool updateOrder(const OrderItem& item, bool forceNotify = false);
    bool updateOrder(const ogs::SendOrderAns& sendOrderAns,
                     Intf_RetType errorCode = kIntfSuccess,
                     const std::string& entrustError = std::string(""));

    bool updateOrder(const ogs::QueryOrderAns& queryOrderAns,
                     const std::string& description = std::string(),
                     bool isCallback = false);

    void settleOrder();

    // get method.
    bool getOrder(ogs::OrderInfo& info) const;
    bool getUnfinishedOrder(OrderItem& item) const;
    std::map<ogs::OGS_CUSTORDERID, OrderItem> unfinishedOrders() const;
    int orderCount() const;
    int unfinishedOrderCount() const;

    void clearOrder();

    static bool isOrderNeedUpdate(uint32_t oldStatus, ogs::OGS_DEALVOLUME oldDealVol,
                                  uint32_t newStatus, ogs::OGS_DEALVOLUME newDealVol);

    // query order
    static void notifyOrderStatusChange(const OrderItem& order);

protected:
    bool saveToDB(const ogs::OrderInfo& orderInfo);
    bool loadFromDB();
    // need custorderid to get the specified order.
    bool loadFromDB(ogs::OrderInfo& orderInfo);

    bool addToMap(const OrderItem& item);
    void updateMap(const OrderItem& item);

private:
    void initDBOptions();

private:
    std::map<ogs::OGS_CUSTORDERID, ogs::OrderInfo> mOrderMap;
    std::map<ogs::OGS_CUSTORDERID, OrderItem> mUnfinishedOrderMap;

    std::map<std::string, ogs::OGS_CUSTORDERID> mSysOrderIdMap;

    rocksdb::DB* mDB = nullptr;
    rocksdb::Options mDBOptions;
    rocksdb::Status mDBStatus;
    std::string mDatabasePath;
};

#endif
