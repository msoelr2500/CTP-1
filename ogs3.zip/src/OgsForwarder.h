///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef OGSFORWARDER_H
#define OGSFORWARDER_H

#include <qtp_message.h>
#include <qtp_queue.h>
#include <qtp_session.h>

class OgsForwarder
{
public:
    static int SendMessage(uint32_t stage_id, qtp::QtpMessagePtr msg);
    static int ReplyClient(qtp::session_id_t session_id, qtp::QtpMessagePtr message);
};

#endif
