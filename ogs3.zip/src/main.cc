#include <iostream>
#include "Factory.h"
#include "OgsVersion.h"
#include "OgsApi.h"
#include <memory>

using namespace std;
using namespace ogs;

int main(int argc,char** argv)
{
    std::string version_str = GET_VERSION_STR(ogs);
    LOG(info) << "ogs version:" << version_str;

    ogs::Factory factory;
    factory.init(argc, argv);

    factory.runRecvThr();
    factory.runRepThr();
    factory.orderMgrModule();
    factory.sysMgrModule();
    factory.taskOrderStageModule();
    factory.reqOrderStageModule();
    factory.start();
    factory.join();
    while (true) {
        char c = getchar();
        if (c == 'f') {
            cout.flush();
        }
        if (c == 'y') {
            return 0;
        }
    }
    return 0;
}
