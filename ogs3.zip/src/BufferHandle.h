#ifndef _BUFFER_HANDLE_H_
#define _BUFFER_HANDLE_H_

#include <string.h>

#define BUF_HANDLE_COUNTTYPE int

namespace ogs {

	template<typename T>
	class UnpackBuffer {
	public:
		UnpackBuffer();

		UnpackBuffer(const std::string *buffer);

		~UnpackBuffer();

		void SetBuffer(const std::string *buffer);

		bool CheckQryBufSize();

		BUF_HANDLE_COUNTTYPE GetDataCount();

		bool Next();

		bool HasMore();

		void First();

		T *GetDataObjPtr();

	private:
		BUF_HANDLE_COUNTTYPE dataCount;     //T data count in buffer
		BUF_HANDLE_COUNTTYPE currentCount;
		const std::string *buf;

		T dataObj;
	};

	template<typename T>
	UnpackBuffer<T>::UnpackBuffer() {
		currentCount = 0;
		dataCount = 0;
		memset(&dataObj, 0, sizeof(T));
	}

	template<typename T>
	UnpackBuffer<T>::UnpackBuffer(const std::string *buffer) {
		currentCount = 0;
		dataCount = 0;
		memset(&dataObj, 0, sizeof(T));
		buf = buffer;
		if (buf->size() >= sizeof(BUF_HANDLE_COUNTTYPE)) {
			memcpy(&dataCount, buf->c_str(), sizeof(BUF_HANDLE_COUNTTYPE));
		}
	}

	template<typename T>
	UnpackBuffer<T>::~UnpackBuffer() {
	}

	template<typename T>
	void UnpackBuffer<T>::SetBuffer(const std::string *buffer) {
		buf = buffer;
		if (buf->size() >= sizeof(BUF_HANDLE_COUNTTYPE)) {
			memcpy(&dataCount, buf->c_str(), sizeof(BUF_HANDLE_COUNTTYPE));
		}
	}

	template<typename T>
	bool UnpackBuffer<T>::CheckQryBufSize() {
		return buf->size() == (sizeof(BUF_HANDLE_COUNTTYPE) + dataCount * sizeof(T)) ? true : false;
	}

	template<typename T>
	BUF_HANDLE_COUNTTYPE UnpackBuffer<T>::GetDataCount() {
		return dataCount;
	}

	template<typename T>
	bool UnpackBuffer<T>::Next() {
		if (currentCount >= dataCount) {
			return false;
		}
		else {
			currentCount++;
			memcpy(&dataObj, buf->c_str() + sizeof(BUF_HANDLE_COUNTTYPE) + sizeof(T) * currentCount, sizeof(T));
			return true;
		}
	}

	template<typename T>
	bool UnpackBuffer<T>::HasMore() {
		if (currentCount >= dataCount) {
			return false;
		}
		else {
			return true;
		}
	}

	template<typename T>
	void UnpackBuffer<T>::First() {
		if (dataCount >= 1) {
			memcpy(&dataObj, buf->c_str() + sizeof(BUF_HANDLE_COUNTTYPE), sizeof(T));
		}
	}

	template<typename T>
	T *UnpackBuffer<T>::GetDataObjPtr() {
		return &dataObj;
	}

	/************************************************************************/


	template<typename T>
	class PackBuffer {
	public:
		PackBuffer();

		PackBuffer(std::string *buffer);

		~PackBuffer();

		void SetBuffer(std::string *buffer);

		T *GetObjPtrIndexOf(BUF_HANDLE_COUNTTYPE index);   //get the pointer of index T data object,start of 0;
		void AddNewObj(const T *obj);      //add a new object to buffer

	private:
		BUF_HANDLE_COUNTTYPE dataCount;    //T data count in buffer
		std::string *buf;
	};

	template<typename T>
	PackBuffer<T>::PackBuffer() {
		dataCount = 0;
	}

	template<typename T>
	PackBuffer<T>::PackBuffer(std::string *buffer) {
		buf = buffer;
		dataCount = 0;
	}

	template<typename T>
	PackBuffer<T>::~PackBuffer() {
	}

	template<typename T>
	void PackBuffer<T>::SetBuffer(std::string *buffer) {
		buf = buffer;
	}

	template<typename T>
	T *PackBuffer<T>::GetObjPtrIndexOf(BUF_HANDLE_COUNTTYPE index) {
		if (index > dataCount) {
			return nullptr;
		}
		else {
			return (T *) (buf->c_str() + sizeof(BUF_HANDLE_COUNTTYPE) + index * sizeof(T));
		}
	}

	template<typename T>
	void PackBuffer<T>::AddNewObj(const T *obj) {
		char tmpCh[32], tmpChObj[256];
		std::string tmpStr;
		dataCount++;
		memcpy(tmpCh, &dataCount, sizeof(BUF_HANDLE_COUNTTYPE));

		if (dataCount > 1) {
			tmpStr.assign(buf->c_str() + sizeof(BUF_HANDLE_COUNTTYPE), buf->size() - sizeof(BUF_HANDLE_COUNTTYPE));
		}

		buf->assign(tmpCh, sizeof(BUF_HANDLE_COUNTTYPE));
		buf->append(tmpStr.c_str(), sizeof(T) * (dataCount - 1));
		memcpy(tmpChObj, obj, sizeof(T));
		buf->append(tmpChObj, sizeof(T));
	}

}
#endif