//
// Created by lwk on 16-5-9.
//

#ifndef OGS_OGSSERVER_H
#define OGS_OGSSERVER_H

#include <map>

#include "qtp_server.h"
#include "qtp_message.h"
#include "qtp_queue.h"
#include "qtp_timeout.h"
#include "qtp_session.h"
#include "Factory.h"
#include "ogs_dict.h"
#include "Lock_Vector.h"
#include "OgsApi.h"
#include "DataStruct.h"

#define MAXSENDCNT 232792560 //the lowest common multiple of 1 to 22, means support max stage count is 22,

namespace ogs {

    class Factory;

    class OgsServer : public qtp::QtpServer {
    public:
        OgsServer(Factory *faPtr);

        void OnRead(struct bufferevent *bev);

        void OnAccept(struct bufferevent *bev, evutil_socket_t fd, struct sockaddr *sa, int socklen);

        void OnClose(struct bufferevent *bev) override;

        void OnEvent(struct bufferevent *bev, short events);

        void OnTimeout(qtp::QtpTimeout *timeout);

    private:

        Factory* factoryPtr;
        LockVector<qtp::session_id_t> m_vSessionID;
    };
}

#endif //OGS_OGSSERVER_H
