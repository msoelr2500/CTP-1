//
// Created by lwk on 16-5-17.
//

#ifndef OGS_READCONFIG_H
#define OGS_READCONFIG_H

#include <iostream>
#include <string.h>

#include "ReadIniConfig.h"

#define SECTION "ogs"

namespace ogs{
    typedef struct {
        std::string LocalAddr;       //local address to listen
        uint16_t LocalPort;          //local port to listen
        uint32_t TradeStart;         //trade time start,control handle sendorderqry etc. request
        uint32_t TradeEnd;           //trade time end
        uint32_t RequestEnd;         //request order status end time
        uint32_t TaskThreadCnt;      //connect to broker thread count of handle task
        uint32_t ReqThreadCnt;       //connect to broker thread count of handle queryorder request
        uint32_t RequestGap;         //request unend order to broker,update order status,in millisecond
        uint32_t HeartBeatGap;       //heart beat to broker,in milldsecond
        uint32_t HoldSessionGap;     //hold client(ps.oms) session along time, out of this gap application will clear this client's session,in second
        uint32_t unAckedOrderQryCnt; //!< 未被券商确认的委托单被归为废单前的查单次数。
        std::string ClientIp;
        std::string ClientMac;
        std::string ClientDiskSn;
        std::string SiteInfoFormat;  //!< 站点信息（站点留痕）的格式。
        std::string BrokerAddr;
        std::string BrokerPort;
        std::string LicensePath;     //file path of license that broker needs
        std::string BranchNo;
        std::string EntrustMode;
        std::string Currency;
        std::string PwdType;
        std::string BrokerType;      //broker type, control create interface class, e.g AI KDMID O32 KDKCBP DDVIP KCBP20
        std::string LibPath;         //dynamic load library path
        std::string LogDir;
        uint32_t LogLevel;
        uint32_t LogVerbose;
        std::string Reserve1;
        std::string Reserve2;
        std::string Reserve3;
        std::string Reserve4;
        std::string Reserve5;
        std::string Reserve6;
        std::string Reserve7;
        uint32_t Reserve8;
        std::string Reserve9;
    }LocalOption;

    class ReadConfig
    {
    public:
        static LocalOption localOption;
        ReadConfig();
        bool Reading(int argc,char* argv[]);
        void CreateDefaultConfig(char *filename);
    private:
        std::string m_FilePath;
    };
}

#endif //OGS_READCONFIG_H
