//
// Created by lwk on 16-5-10.
//

#ifndef OGS_ORDERMGRSTAGE_H
#define OGS_ORDERMGRSTAGE_H

#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <algorithm>
#include <vector>

#include "qtp_message.h"
#include "qtp_session.h"
#include "qtp_stage.h"
#include "DataStruct.h"
#include "OgsApi.h"
#include "Factory.h"
#include "ogs_dict.h"
#include "OgsMessage.h"
#include "OrderManager.h"

#include "rocksdb/db.h"
#include "rocksdb/slice.h"
#include "rocksdb/options.h"

class OrderInfoRef {
public:
    OrderInfoRef()
    {
        orderInfo = {0};
        queryCount = 10;
    }

    OrderInfoRef(const ogs::OrderInfo& info, int queryCount)
    {
        orderInfo = info;
        this->queryCount = queryCount;
    }

    bool isSuccessfullyEntrusted() {
        return strlen(orderInfo.sysOrderId) > 0;
    }

    ogs::OrderInfo orderInfo;   //!< 订单信息。
    std::string mEntrustError;  //!< 委托错误。
    std::string mStatusInfo;    //!< 最新状态信息。
    int queryCount = 10;        //!< 剩余查单次数。

    OrderInfoRef& operator=(const OrderInfoRef& ref)
    {
        orderInfo = ref.orderInfo;
        queryCount = ref.queryCount;
        return (*this);
    }
} ;

namespace ogs {

class Factory;

class OrderMgrStage:public qtp::QtpStage
{
public:
    OrderMgrStage(Factory* faPtr);
    ~OrderMgrStage();
    int OnEvent(qtp::QtpMessagePtr message);

    bool SelectOrder(QueryOrderQry* queryOrderQry, qtp::session_id_t session, QueryOrderAns& queryOrderAns);

    static void initOrderBySendOrderQry(OrderInfo &order, const SendOrderQry& qry, qtp::session_id_t session);

protected:
    void onSendOrder(OgsMessage& message);
    void onSendOrderAns(OgsMessage& message);
    void onQueryOrder(OgsMessage& message);
    void onQueryOrderAns(OgsMessage& message);
    void onLoginAns(OgsMessage& message);
    void onOrderMgrTimer(OgsMessage& message);

private:
    Factory* m_factoryPtr;
    std::map<OGS_CUSTORDERID ,OrderInfo> m_orderMap;
    std::map<OGS_CUSTORDERID ,OrderInfoRef> m_unendOrderMap;
    std::map<std::string,OGS_CUSTORDERID> m_SysOrderIdMap;

    std::vector<std::string> m_bacidVector;

    rocksdb::DB* db;
    rocksdb::Options options;

    OrderManager orderManager;
};

}

#endif //OGS_ORDERMGRSTAGE_H
