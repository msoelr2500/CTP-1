//
// Created by lwk on 16-5-10.
//

#include "OrderMgrStage.h"
#include "ReadConfig.h"
#include "OgsLogger.h"
#include "OgsMessage.h"
#include "OgsForwarder.h"
#include "StringHelper.h"

#define DBPATH "./db_ogs"

using namespace ogs::ogs_dict;
using std::string;
using std::map;

namespace ogs {

OrderMgrStage::OrderMgrStage(Factory *faPtr) {
    m_factoryPtr = faPtr;

    std::string dbPath;
    StringHelper::string_format(dbPath, "%s%d", DBPATH, GetDateYMD());

    if (!orderManager.setDatabase(dbPath)) {
        std::cerr << "\033[31m[OrderMgrStage] rocksdb initialize failed, ogs-server terminated.\033[0m" << std::endl;
        ogsFatal << "[OrderMgrStage] rocksdb initialize failed(status: " << orderManager.databaseStatus().ToString()
                 << "), ogs-server terminated.";
        exit(0);
    }
}

OrderMgrStage::~OrderMgrStage()
{

}

int OrderMgrStage::OnEvent(qtp::QtpMessagePtr message) {
    VLOG(200) << "[OrderMgrStage] [OnEvent] MsgType: " << OgsLogger::msgType(message->MsgType());
    OgsMessage ogsMessage(message);
    switch (message->MsgType()) {
        // unsolved problem:if sendorderans comes before sendorderqry,how to handle it.
        case kMtSendOrder: {  //add new order in map and db
            onSendOrder(ogsMessage);
            break;
        }
        case kMtSendOrderAns: {    //update sysorderid in map and db
            onSendOrderAns(ogsMessage);
            break;
        }
        case kMtQueryOrder: {     //get order from map,send back a queryorderans to client
            onQueryOrder(ogsMessage);
            break;
        }
        case kMtQueryOrderAns: {
            onQueryOrderAns(ogsMessage);
            break;
        }
        case kMtOrderMgrTimer: {
            onOrderMgrTimer(ogsMessage);
            break;
        }
        case kMtLoginAns: {
            onLoginAns(ogsMessage);
            break;
        }
    }
    return 0;
}

bool OrderMgrStage::SelectOrder(QueryOrderQry *queryOrderQry, qtp::session_id_t session, QueryOrderAns &queryOrderAns) {
    OrderInfo orderInfo = {0};
    orderInfo.custOrderId = queryOrderQry->custOrderId;
    memcpy(orderInfo.sysOrderId, queryOrderQry->sysOrderId, SYSORDERIDSIZE);

    bool result = orderManager.getOrder(orderInfo);
    if (result) {
        if (orderInfo.sessionid != session) {
            orderInfo.sessionid = session;
            orderManager.updateOrder(OrderItem(orderInfo, ReadConfig::localOption.unAckedOrderQryCnt));
        }

        strcpy(queryOrderAns.bacid, orderInfo.bacid);
        queryOrderAns.custOrderId    = orderInfo.custOrderId;
        strcpy(queryOrderAns.sysOrderId, orderInfo.sysOrderId);
        queryOrderAns.price          = orderInfo.price;
        queryOrderAns.volume         = orderInfo.volume;
        queryOrderAns.orderStatus    = orderInfo.orderStatus;
        queryOrderAns.dealVolume     = orderInfo.dealVolume;
        queryOrderAns.dealBalance    = orderInfo.dealBalance;
        queryOrderAns.dealPrice      = orderInfo.dealPrice;
        queryOrderAns.innerCode      = orderInfo.innerCode;
        queryOrderAns.withdrawVolume = orderInfo.withdrawVolume;
        queryOrderAns.directive      = orderInfo.directive;
        queryOrderAns.tradeDate      = orderInfo.tradeDate;
        queryOrderAns.orderTime      = orderInfo.orderTime;
    }

    return result;
}

void OrderMgrStage::initOrderBySendOrderQry(OrderInfo &order, const SendOrderQry &qry, qtp::session_id_t session)
{
    strcpy(order.acidcard, qry.acidcard);
    order.actype         = qry.actype;
    strcpy(order.bacid, qry.bacid);
    strcpy(order.password, qry.password);
    strcpy(order.ipAddr,   qry.ipAddr);
    strcpy(order.macAddr,  qry.macAddr);
    strcpy(order.diskSn,   qry.diskSn);
    memset(order.sysOrderId, 0, SYSORDERIDSIZE);
    order.innerCode      = qry.innerCode;
    order.directive      = qry.directive;
    order.execution      = qry.execution;
    order.price          = qry.price;
    order.volume         = qry.volume;
    order.custOrderId    = qry.custOrderId;
    order.orderStatus    = kOtNotReported;
    order.dealVolume     = 0;
    order.dealBalance    = 0;
    order.dealPrice      = 0;
    order.withdrawVolume = 0;
    order.tradeDate      = GetDateYMD();
    order.orderTime      = GetTimeHMS();
    order.sessionid      = session;
}

void OrderMgrStage::onSendOrder(OgsMessage &message)
{
    SendOrderQry* array;

    if (!message.parse(&array)) {
        LOG(error) << "[OrderMgrStage] [onSendOrder] " << message.error();
        return;
    }

    qtp::session_id_t session_id;
    if (!message.session(session_id)) {
        LOG(error) << "[OrderMgrStage] [onSendOrder] failed to get session_id.";
    }

    for (uint32_t i = 0; i < message.itemCount(); ++i) {
        orderManager.addOrder(array[i], session_id);
    }
}

void OrderMgrStage::onSendOrderAns(OgsMessage &message)
{
    uint32_t error_code = -1;
    std::string errMsg;

    if (!message.errorCode(error_code) || !message.errorMsg(errMsg)) {
        LOG(error) << "[OrderMgrStage] [onSendOrderAns] failed to get error_code and error_msg";
        return;
    }

    SendOrderAns* array;
    if (!message.parse(&array)) {
        LOG(error) << "[OrderMgrStage] [onSendOrderAns] " << message.error();
        return;
    }

    for (uint32_t i = 0; i < message.itemCount(); ++i) {
        orderManager.updateOrder(array[i], (Intf_RetType)error_code, errMsg);
    }
}

void OrderMgrStage::onQueryOrder(OgsMessage &message)
{
    QueryOrderQry* array;
    if (!message.parse(&array)) {
        LOG(error) << "[OrderMgrStage] [onQueryOrder] " << message.error();
        return;
    }

    for (uint32_t i = 0; i < message.itemCount(); ++i) {
        QueryOrderQry *queryOrderQry = &array[i];
        QueryOrderAns queryOrderAns = {0};
        uint32_t error_code = kIntfSuccess;
        std::string error_msg;
        qtp::session_id_t session_id;
        if (!message.session(session_id)) {
            LOG(error) << "[OrderMgrStage] [onQueryOrder] failed to get session_id.";
        }

        if (!SelectOrder(queryOrderQry, session_id, queryOrderAns)) {
            StringHelper::string_format(error_msg, "QueryOrder Failed: no such order whose custOrderId = %d", queryOrderQry->custOrderId);
            LOG(error) << "[OrderMgrStage] [onQueryOrder] " << error_msg;
            error_code = kIntfWorkFail;
        }

        qtp::QtpMessagePtr response = std::make_shared<qtp::QtpMessage>();
        response->BeginEncode(kMtQueryOrderAns, 0);
        response->AddTag(kTagSession, &session_id, sizeof(qtp::session_id_t));
        response->AddTag(kTagBacid, queryOrderQry->bacid, strlen(queryOrderQry->bacid));
        response->CopyTag(*message.qtpMessage(), kTagTime);

        uint32_t item_size = sizeof(QueryOrderAns);
        uint32_t item_cnt = 1;
        SetItemSizeAndCnt(response, item_size, item_cnt);
        SetErrorCodeAndMsg(response, error_code, error_msg.c_str(), error_msg.length());

        response->SetData(&queryOrderAns, sizeof(QueryOrderAns), false);
        response->Encode();
        OgsForwarder::SendMessage(kRepStageID, response);
    }
}

void OrderMgrStage::onQueryOrderAns(OgsMessage &message)
{
    uint32_t error_code = -1;
    std::string errMsg;

    if (!message.errorCode(error_code) || !message.errorMsg(errMsg)) {
        LOG(error) << "[OrderMgrStage] [onQueryOrderAns] failed to get error_code and error_msg";
        return;
    }

    QueryOrderAns* array;
    if (!message.parse(&array)) {
        LOG(error) << "[OrderMgrStage] [onQueryOrderAns] " << message.error();
        return;
    }

    OGS_TAGISCALLBACK tag_IsCallback = 0;
    message.getTagAsInteger(kTagIsCallback, &tag_IsCallback);
    OGS_TAGSYSORDERIDISEMPTY tag_SysOrderIdIsEmpty;
    message.getTagAsInteger(kTagSysOrderIdIsEmpty, &tag_SysOrderIdIsEmpty);

    bool isFuzzyMatch = (tag_SysOrderIdIsEmpty == 1);
    bool isCallback   = (tag_IsCallback == 1);

    if (error_code != kIntfSuccess) {
        LOG(error) << "[OrderMgrStage] [onQueryOrderAns] error of error_code:" << error_code;
        // 如果忽略这个回报，订单将不能再发出新的查单请求。
        orderManager.updateOrder(*array, isCallback ? "订单状态推送时出现了错误。" : "查单时出现了错误。", isCallback);
        return;
    }

    if (!isFuzzyMatch || isCallback) {   // queryOrderQry with sysorderid
        VLOG(300) << "[OrderMgrStage] [onQueryOrderAns] unfinished order (with sysorderid) QueryOrderAns.";
        if (message.itemCount() == 1) {
            ogsLogger() << array[0];
            //! 对于订阅推送的查单回报，其错误信息即为说明信息。\sa OrderStage::CallBack
            orderManager.updateOrder(array[0], (tag_IsCallback == 1) ? errMsg : std::string(), isCallback);
        } else {
            orderLog(array->custOrderId) << "[OrderMgrStage] [onQueryOrderAns] error item size: " << message.itemCount();
            OrderItem item;
            item.orderInfo.custOrderId = array[0].custOrderId;
            if (orderManager.getUnfinishedOrder(item)) {
                item.mWaitingQueryOrderAns = false;
            }
            orderManager.updateOrder(item, false);
        }
    } else {
        // 如果忽略这个回报，订单将不能再发出新的查单请求。
        // queryOrderQry without sysorderid, queryorderans may has more than one record,
        VLOG(300) << "[OrderMgrStage] [onQueryOrderAns] unacked order (without sysorderid) QueryOrderAns.";
        orderManager.matchOrder(array, message.itemCount());
    }
}

void OrderMgrStage::onLoginAns(OgsMessage &message)
{
    uint32_t error_code = -1;
    std::string errMsg;

    if (!message.errorCode(error_code) || !message.errorMsg(errMsg)) {
        LOG(error) << "[OrderMgrStage] [onLoginAns] failed to get error_code and error_msg";
        return;
    }
    if (error_code != kIntfSuccess) {
        LOG(error) << "[OrderMgrStage] [onLoginAns] error of error_code:" << error_code;
        return;
    }

    LoginAns* array;
    if (!message.parse(&array)) {
        LOG(error) << "[OrderMgrStage] [onLoginAns] " << message.error();
    }

    for (uint32_t i = 0; i < message.itemCount(); ++i) {
        std::string bacidStr = std::string(array[i].bacid);
        std::vector<std::string>::iterator it = std::find(m_bacidVector.begin(), m_bacidVector.end(), bacidStr);
        if (it == m_bacidVector.end()) {
            VLOG(200) << "[OrderMgrStage] [OnEvent] [onLoginAns] add bacid(" << array[i].bacid << ") to bacid list.";
            m_bacidVector.push_back(bacidStr);
        }
    }
}

void OrderMgrStage::onOrderMgrTimer(OgsMessage &message)
{
    int timeNow = GetTimeHMS();
    //! \todo 加入多线程同步访问策略。
    if (timeNow * 1000 <= ReadConfig::localOption.RequestGap * 2) {
        VLOG(200) << "[OrderMgrStage] [OnEvent] [kMtOrderMgrTimer] it's a new day, create a new db file.";

        orderManager.clearOrder();
        std::string dbPath;
        StringHelper::string_format(dbPath, "%s%d", DBPATH, GetDateYMD());
        orderManager.setDatabase(dbPath);
    }

    //query the unfinishde order, update their order status
    //! \todo 加入多线程同步访问策略。
    if (timeNow <= ReadConfig::localOption.RequestEnd) {
        map<OGS_CUSTORDERID, OrderItem> unfinishedOrders = orderManager.unfinishedOrders();
        VLOG(200) << "[OrderMgrStage] [onOrderMgrTimer] start to query unfinished orders (size = " << unfinishedOrders.size() << ").";

        for (map<OGS_CUSTORDERID, OrderItem>::iterator iterator = unfinishedOrders.begin(); iterator != unfinishedOrders.end(); ++iterator) {
            OGS_TAGSYSORDERIDISEMPTY tag_SysOrderIdIsEmpty = 0;
            OrderItem& item = iterator->second;
            if (strlen(item.orderInfo.sysOrderId) <= 0) {
                tag_SysOrderIdIsEmpty = 1;
            }

            if (item.queryCount <= 0) {
                // 已经达到最大查询次数，不再查询该订单。从未完成订单中移除该订单，并将主订单表中
                // 对应订单的状态更新为废单。
                item.orderInfo.orderStatus = kOtBad;
                orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] [onOrderMgrTimer] unacked-order has reached its re-query count limits, set its status to kOtBad.";
                StringHelper::string_format(item.mNotifyPrompt, "废单原因：%s", item.mEntrustError.c_str());
                orderManager.updateOrder(item, true);
            } else {
                // 向券商查询该订单。
                VLOG(200) << "[OrderMgrStage] [onOrderMgrTimer] QueryOrder loop: unfinished order " << iterator->first;

                bool needQuery = false;
                bool needNotify = false;

                if (item.mWaitingSendOrderAns) {
                    item.mWaitingSendOrderAnsPeriod++;
                    if (item.mWaitingSendOrderAnsPeriod == 10) {
                        // 如果委托回报没有收到就开始查单，订单仍有可能过早变成废单。
#if 0
                        item.mStatusInfo = "订单委托所花的时间已经超出了预期，开始尝试查单...";
                        needQuery = true;
#else
                        item.mStatusInfo = "订单委托所花的时间已经超出了预期，请继续耐心等待...";
                        item.mNotifyPrompt = item.mStatusInfo;
                        orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] [onOrderMgrTimer] waiting send order ans take longer than expected.";
                        needNotify = true;
#endif
                    }
                    orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] [onOrderMgrTimer] waiting send order ans...";
                } else if (item.mWaitingQueryOrderAns) {
                    item.mWaitingQueryOrderAnsPeriod++;
                    if (item.mWaitingQueryOrderAnsPeriod == 10) {
                        // 如果没有收到查单回报就开始发送新的查单请求，那么新的查单请求的回报也很有可能无法无法及时收到。
#if 0
                        item.mStatusInfo = "订单查询所花的时间已经超出了预期，尝试重新查单...";
                        needQuery = true;
#else
                        item.mStatusInfo = "订单查询所花的时间已经超出了预期，请继续耐心等待...";
                        item.mNotifyPrompt = item.mStatusInfo;
                        orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] [onOrderMgrTimer] waiting query order ans take longer than expected.";
                        needNotify = true;
#endif
                    }
                    orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] [onOrderMgrTimer] waiting query order ans...";
                } else {
                    needQuery = true;
                }

                if (needQuery) {
                    if (strlen(item.orderInfo.sysOrderId) <= 0) {
                        tag_SysOrderIdIsEmpty = 1;
                        // 每一个未委托成功的订单有指定数目查单机会，如果超过查询次数仍未查到，将其视为废单。
                        item.queryCount--;
                        orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] [onOrderMgrTimer] unacked-order's remaining re-query count is "<< item.queryCount;
                    }

                    std::vector<std::string>::iterator it = std::find(m_bacidVector.begin(), m_bacidVector.end(), std::string(item.orderInfo.bacid));
                    if (it == m_bacidVector.end()) {
                        needQuery = false;
                        orderLog(item.orderInfo.custOrderId) << "[OrderMgrStage] can't query order: bacid " << item.orderInfo.bacid << " don't login yet.";
                        continue;
                    }

                    QueryOrderQry queryOrderQry = item.toQueryOrderQry();
                    ogsLogger() << queryOrderQry;

                    qtp::session_id_t session_id = item.orderInfo.sessionid;
                    auto response = std::make_shared<qtp::QtpMessage>();
                    response->BeginEncode(kMtQueryOrder, kOgsServiceId);
                    uint32_t item_size = sizeof(QueryOrderQry);
                    uint32_t item_cnt = 1;
                    SetItemSizeAndCnt(response, item_size, item_cnt);
                    OGS_BACID bacid[BACIDSIZE];
                    strcpy(bacid, queryOrderQry.bacid);
                    response->AddTag(kTagBacid, bacid, strlen(bacid));
                    response->AddTag(kTagSession, &session_id, sizeof(qtp::session_id_t));
                    OGS_SYSTIME time = GetTimeHMS();
                    response->AddTag(kTagTime, &time, sizeof(OGS_SYSTIME));
                    response->AddTag(kTagSysOrderIdIsEmpty, &tag_SysOrderIdIsEmpty, sizeof(OGS_TAGSYSORDERIDISEMPTY));
                    response->SetData(&queryOrderQry, sizeof(QueryOrderQry), false);
                    response->Encode();

                    orderLog(item.orderInfo.custOrderId) << " [OrderMgrStage] [kMtOrderMgrTimer] send query order request to OrderStage.";
                    OgsForwarder::SendMessage(kReqOrderStageProxyID, response);

                    item.mWaitingQueryOrderAns = true;
                }

                orderManager.updateOrder(item, needNotify);
            }
        }
    }
    else {
        VLOG(200) << "[OrderMgrStage] [OnEvent] [kMtOrderMgrTimer] timeNow <= RequestEnd, so put an end to all unfinished orders (size = "
                  << m_unendOrderMap.size() << ").";
        orderManager.settleOrder();
    }
}

}
