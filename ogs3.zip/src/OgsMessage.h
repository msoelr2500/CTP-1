////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-21
////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef OGSMESSAGE_H
#define OGSMESSAGE_H

#include <qtp_message.h>
#include <qtp_session.h>
#include "StringHelper.h"

class OgsMessage {
public:
    explicit OgsMessage(qtp::QtpMessagePtr message);
    OgsMessage();

    bool verify();

    bool isCorrupted() const;

    std::string error() const;

    uint32_t itemCount() const;
    uint32_t itemSize() const;
    uint32_t totalSize() const;

    uint32_t type() const;

    bool session(qtp::session_id_t& output) const;
    bool errorCode(uint32_t& output) const;
    bool errorMsg(std::string& msg) const;

    /*! 如果正确解析，返回true；返回false时可以调用error()查看错误信息。 */
    template <typename ItemType>
    bool parse(ItemType** array, uint32_t* size = nullptr)
    {
        if (isCorrupted()) return false;

        if (mItemSize != sizeof(ItemType)) {
            mError = "[OgsMessage] parse error: item size from msg != sizeof(item type).";
            return false;
        }

        *array = (ItemType*)mMessage->GetData();
        if (size) *size = mItemSize;

        return true;
    }

    template <typename TagType>
    int getTagAsInteger(qtp::QtpMessage::option_id_t id, TagType* tag) const {
        return mMessage->GetTagAsInteger(id, tag);
    }

    const void* rawData() const;

    std::string toQryBuffer() const;

    static qtp::QtpMessagePtr buildTimeoutMsg(uint16_t msgtype, uint8_t service = 0);

    qtp::QtpMessagePtr qtpMessage();

private:
    qtp::QtpMessagePtr mMessage;

    std::string mError;

    uint32_t mItemSize;
    uint32_t mItemCount;
    bool mCorrupted = false;
};

#endif // OGSMESSAGE_H
