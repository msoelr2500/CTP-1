
#ifndef KAMSINTERFACE_H
#define KAMSINTERFACE_H

#include <string>
#include <map>
#include "../ogs_dict.h"
#include "../OgsApi.h"
#include "../ReadConfig.h"
#include "../OgsInterface.h"
#include "qtp_log.h"
#include "universal_code.h"
#include "DataMap.h"
#include "kdencodecli.h"
#include "KCBPCli.h"

namespace ogs {
#define IMPOR_INFOLEVEL 8

class KamsInterface : public OgsInterface
{
public:
    KamsInterface();

    virtual ~KamsInterface();

    virtual bool getConnectStatus() override;

    virtual Intf_RetType initCommon() override;

    virtual Intf_RetType initSubscribe() override;

    virtual Intf_RetType connectBroker() override;

    virtual Intf_RetType reConnectBroker() override;

    virtual Intf_RetType heartBeatToBroker() override;

    virtual void setCallBack(int (*fn)(QueryOrderAns)) override;

    ///--------------------------------------------------------------------------------------------------------
    /// 业务操作接口
    ///--------------------------------------------------------------------------------------------------------

    virtual Intf_RetType ogsLogin(const LoginQry& in, std::list<LoginAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsSendOrder(const SendOrderQry& in, std::list<SendOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsCancelOrder(const CancelOrderQry& in, std::list<CancelOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsQueryOrder(const QueryOrderQry& in, std::list<QueryOrderAns>& out, std::string &errMsg, std::map<int, std::string> &args) override;
    virtual Intf_RetType ogsQueryPosition(const QueryPositionQry& in, std::list<QueryPositionAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsQueryBargain(const QueryBargainQry& in, std::list<QueryBargainAns>& out, std::string& errMsg, std::map<int, std::string> &args) override;
    virtual Intf_RetType ogsQueryFundInfo(const QueryFundInfoQry& in, std::list<QueryFundInfoAns>& out, std::string& errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsPaybackSecurity(const PaybackSecurityQry &in, std::list<PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args) override;
    virtual Intf_RetType ogsPaybackFunds(const PaybackFundsQry &in, std::list<PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args) override;

    typedef struct _FundacctInfo
    {
        std::string fundacct;   // 资金账号
        std::string market;     // 交易市场
        std::string secuid;     // 股东代码
        std::string status;     // 股东状态
        std::string projectid;  // 资产单元编号
        std::string fundid;     // 产品编号
        std::string combid;     // 组合编号
    }FundacctInfo;

    typedef struct _SiteInfo
    {
        string cpu;     // CPU序列号
        string ide;     // 硬盘序列号
        string ip;      // IP地址
        string mac;     // MAC地址
    }MySiteInfo;

    static tagKCBPConnectOption stKCBPConnection;
private:
    Intf_RetType QueryFundacctInfo(std::map<int, std::string>& args);
    Intf_RetType QueryProjectid(std::map<int, std::string>& args);
    Intf_RetType QueryFundidCombid(std::map<int, std::string>& args);
    Intf_RetType SQLExecute(KCBPCLIHANDLE hHandle, std::string &errMsg, char *szProgramName);
    Intf_RetType BeginWrite(KCBPCLIHANDLE hHandle, std::string &errMsg);
    std::vector<std::map<std::string, std::string>> GetExecuteResult(KCBPCLIHANDLE hHandle);

    std::string GetColNames(KCBPCLIHANDLE hHandle);

    void SetFixedParms(KCBPCLIHANDLE  hHandle, std::string strUserid, std::string strPasswd, std::string funcid, std::string sessionid, std::map<int, std::string>& args);
    void SetFloatingParms(KCBPCLIHANDLE  hHandle, std::map<std::string, std::string> value);

    FundacctInfo GetFundacctInfo(std::string bacid, std::string mid);

    static vector<FundacctInfo> fundacctInfos;  /**< 资金账号信息 */
    static std::string sessionid;   /**< 会话编号。登录时送空，登录业务返回此编号，以后的业务操作必须送入此编号 */
    static std::string userid;      /**< 用户编号 */
    static std::string userpwd;     /**< 用户密码 */
    static MySiteInfo siteInfo;     /**< 留痕信息备份 */
    static bool UpdateSiteInfo(std::map<int, std::string>& args);
private:
    KCBPCLIHANDLE hHandle;
    bool isconnect;

};

}

#endif // KAMSINTERFACE_H
