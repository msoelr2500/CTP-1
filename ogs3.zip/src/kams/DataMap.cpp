#include "DataMap.h"

namespace ogs {

// 静态变量初始化
map<qtp::MarketCode, string> DataMap::marketMap = DataMap::initMarketMap();
map<ogs_dict::DirectiveType, string> DataMap::directiveMap = DataMap::initDirectiveMap();
map<ogs_dict::ExecutionType, string> DataMap::executionMap = DataMap::initExecutionMap();
map<ogs_dict::OrderStatusType, string> DataMap::orderStatusMap = DataMap::initOrderStatusMap();

DataMap::DataMap()
{

}
}
