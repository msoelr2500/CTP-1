#ifndef DATA_MAP_H
#define DATA_MAP_H
#include <map>
#include <string>
#include <iostream>
#include "../ogs_dict.h"
#include "universal_code.h"

using namespace std;
namespace ogs {

class DataMap
{
public:
    DataMap();

    /****************************** 交易市场互相转换 ******************************/
    static map<qtp::MarketCode, string> marketMap;
    static map<qtp::MarketCode, string> initMarketMap()
    {
        map<qtp::MarketCode, string> map;
        map[qtp::kMC_SSE] = "1";
        map[qtp::kMC_SZE] = "0";
        return map;
    }
    static string getMarketVaule(qtp::MarketCode key)
    {
        for (auto &kv : marketMap)
        {
            if (kv.first == key){ return kv.second; }
        }
        return "";
    }
    static qtp::MarketCode getMarketKey(string value)
    {
        for (auto &kv : marketMap)
        {
            if (kv.second == value){ return kv.first; }
        }
        return qtp::kMC_UNKNOW;
    }

    /****************************** 买卖指令互相转换 ******************************/
    static map<ogs_dict::DirectiveType, string> directiveMap;
    static map<ogs_dict::DirectiveType, string> initDirectiveMap()
    {
        map<ogs_dict::DirectiveType, string> map;
        map[ogs_dict::kDtBuy] = "0B";
        map[ogs_dict::kDtSell] = "0S";
        return map;
    }
    static string getDirectiveVaule(ogs_dict::DirectiveType key)
    {
        for (auto &kv : directiveMap)
        {
            if (kv.first == key){ return kv.second; }
        }
        return "";
    }
    static ogs_dict::DirectiveType getDirectiveKey(string value)
    {
        for (auto &kv : directiveMap)
        {
            if (kv.second == value){ return kv.first; }
        }
        return (ogs_dict::DirectiveType)0;
    }

    /****************************** 执行类型互相转换 ******************************/
    static map<ogs_dict::ExecutionType, string> executionMap;
    static map<ogs_dict::ExecutionType, string> initExecutionMap()
    {
        map<ogs_dict::ExecutionType, string> map;
        map[ogs_dict::kExeLimit] = "0";
        return map;
    }
    static string getExecutionVaule(ogs_dict::ExecutionType key)
    {
        for (auto &kv : executionMap)
        {
            if (kv.first == key){ return kv.second; }
        }
        return "";
    }
    static ogs_dict::ExecutionType getExecutionKey(string value)
    {
        for (auto &kv : executionMap)
        {
            if (kv.second == value){ return kv.first; }
        }
        return (ogs_dict::ExecutionType)-1;
    }

    /****************************** 订单状态互相转换 ******************************/
    static map<ogs_dict::OrderStatusType, string> orderStatusMap;
    static map<ogs_dict::OrderStatusType, string> initOrderStatusMap()
    {
        map<ogs_dict::OrderStatusType, string> map;
        map[ogs_dict::kOtNotApproved] = "0";
        map[ogs_dict::kOtNotReported] = "A";
        map[ogs_dict::kOtWaitReporting] = "B";
        map[ogs_dict::kOtReported] = "2";
        map[ogs_dict::kOtCanceling] = "3";
        map[ogs_dict::kOtMatchedCanceling] = "4";
        map[ogs_dict::kOtMatchedCanceled] = "5";
        map[ogs_dict::kOtCanceled] = "6";
        map[ogs_dict::kOtPartMatched] = "7";
        map[ogs_dict::kOtMatchedAll] = "8";
        map[ogs_dict::kOtBad] = "9";
        map[ogs_dict::kOtRiskBlocked] = "";
        return map;
    }
    static string getOrderStatusVaule(ogs_dict::OrderStatusType key)
    {
        for (auto &kv : orderStatusMap)
        {
            if (kv.first == key){ return kv.second; }
        }
        return "";
    }
    static ogs_dict::OrderStatusType getOrderStatusKey(string value)
    {
        for (auto &kv : orderStatusMap)
        {
            if (kv.second == value){ return kv.first; }
        }
        return ogs_dict::OrderStatusType(-2);
    }

};

}


#endif // DATA_MAP_H
