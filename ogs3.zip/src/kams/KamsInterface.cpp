

#include "KamsInterface.h"
#include "../ogs_dict.h"
#include "../OgsApi.h"
#include "../StringHelper.h"

using std::string;
using std::vector;

namespace ogs {
tagKCBPConnectOption KamsInterface::stKCBPConnection;
// 静态变量初始化
vector<KamsInterface::FundacctInfo> KamsInterface::fundacctInfos;
KamsInterface::MySiteInfo KamsInterface::siteInfo;
std::string KamsInterface::sessionid;
std::string KamsInterface::userid;
std::string KamsInterface::userpwd;

KamsInterface::KamsInterface()
{
    LOG(info) << "创建了一个Kams接口对象";
    hHandle = NULL;

    KamsInterface::siteInfo.cpu = "";
    KamsInterface::siteInfo.ide = ReadConfig::localOption.ClientDiskSn;
    KamsInterface::siteInfo.ip = ReadConfig::localOption.ClientIp;
    KamsInterface::siteInfo.mac = ReadConfig::localOption.ClientMac;
}

KamsInterface::~KamsInterface()
{

}

bool KamsInterface::getConnectStatus()
{
    return isconnect;
}

Intf_RetType KamsInterface::initCommon()
{
    int nlen = sizeof(stKCBPConnection);
    memset(&stKCBPConnection, 0, sizeof(nlen));
    strcpy(stKCBPConnection.szServerName, ReadConfig::localOption.Reserve1.c_str());//用户自定义的KCBP服务器名称
    stKCBPConnection.nProtocal = 0;//tcp
    strcpy(stKCBPConnection.szAddress, ReadConfig::localOption.BrokerAddr.c_str());
    stKCBPConnection.nPort = atoi(ReadConfig::localOption.BrokerPort.c_str());
    strcpy(stKCBPConnection.szSendQName, ReadConfig::localOption.Reserve2.c_str());
    strcpy(stKCBPConnection.szReceiveQName, ReadConfig::localOption.Reserve3.c_str());
    return kIntfSuccess;
}

Intf_RetType KamsInterface::initSubscribe()
{
    LOG(info) << "[Kams] 初始化订阅功能";
    return kIntfFail;
}

Intf_RetType KamsInterface::connectBroker()
{
    VLOG(200) << "begin connectBroker()......";
    if (hHandle != NULL)
    {
        KCBPCLI_DisConnectForce(hHandle);
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
    }
    //调用ConnectServer时，API按照ServerName查找服务端的连接参数，当用户设置了连接
    //选项时，客户端使用该选项中的参数连接服务端，否则在KCBPCli.ini中查找参数
    /*新建KCBP实例*/
    int nlen = sizeof(stKCBPConnection);
    if (KCBPCLI_Init(&hHandle) != 0)
    {
        VLOG(200) << "KCBPCLI_Init error";
        return kIntfFail;
    }

    /*连接KCBP服务器*/
    if (KCBPCLI_SetOptions(hHandle, KCBP_OPTION_CONNECT, &stKCBPConnection, nlen))
    {
        VLOG(200) << "KCBPCLI_SetConnectOption error";
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
        return kIntfFail;
    }

    /*超时*/
    int outtime = 30;
    if (KCBPCLI_SetOptions(hHandle, KCBP_OPTION_TIMEOUT, &outtime, sizeof(int)))
    {
        VLOG(200) << "KCBPCLI_SetCliTimeOut Error";
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
        return kIntfFail;
    }

    int nTrace = atoi(ReadConfig::localOption.Reserve6.c_str());
    KCBPCLI_SetOption(hHandle, KCBP_OPTION_TRACE, (void *)&nTrace);

    VLOG(200) << " szAddress = " << stKCBPConnection.szAddress
              << " nPort = " << stKCBPConnection.nPort
              << " szSendQName = " << stKCBPConnection.szSendQName
              << " szReceiveQName = " << stKCBPConnection.szReceiveQName
              << " szServerName = " << stKCBPConnection.szServerName
              << " Reserve4 = " << ReadConfig::localOption.Reserve4
              << " Reserve5 = " << ReadConfig::localOption.Reserve5;

    int ret = KCBPCLI_SQLConnect(hHandle,
                                 stKCBPConnection.szServerName,
                                 (char*)ReadConfig::localOption.Reserve4.c_str(),
                                 (char*)ReadConfig::localOption.Reserve5.c_str());
    if (ret != 0)
    {
        VLOG(200) << "Connect Failure  Errcode= " << ret;
        KCBPCLI_Exit(hHandle);
        hHandle = NULL;
        return kIntfFail;
    }
    VLOG(200) << "Connect success! ";
    isconnect = true;

    if(isconnect){
        LOG(info) << "[Kams] 已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType KamsInterface::reConnectBroker()
{
    return connectBroker();
}

Intf_RetType KamsInterface::heartBeatToBroker()
{
    LOG(info) << "[Kams] heartBeatToBroker";
    return kIntfSuccess;
}

void KamsInterface::setCallBack(int (*fn)(QueryOrderAns))
{

}

Intf_RetType KamsInterface::ogsLogin(const LoginQry &in, std::list<LoginAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;

    KamsInterface::sessionid = "";
    KamsInterface::userid = "";
    KamsInterface::userpwd = "";

    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    string bacid = to_string(in.bacid);
    string acidcard = to_string(in.acidcard);
    string password = in.password;

    KamsInterface::userid = acidcard;
    KamsInterface::userpwd = password;

    KamsInterface::UpdateSiteInfo(args);

    // 送单入参
    std::map<std::string, std::string> value;
    value["usercode"] = KamsInterface::userid;
    value["hostname"] = ReadConfig::localOption.ClientIp;

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899100", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);

    eRet = SQLExecute(hHandle, errMsg, "899100");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            KamsInterface::sessionid = r["SESSIONID"];
        }

        QueryFundacctInfo(args);
        QueryProjectid(args);
        QueryFundidCombid(args);

        for(FundacctInfo fundacctInfo: KamsInterface::fundacctInfos)
        {

            if(fundacctInfo.fundacct == bacid)
            {
                VLOG(200) << "fundacct:" << fundacctInfo.fundacct
                          << " ,market:" << fundacctInfo.market
                          << " ,secuid:" << fundacctInfo.secuid
                          << " ,projectid:" << fundacctInfo.projectid
                          << " ,fundid:" << fundacctInfo.fundid
                          << " ,combid:" << fundacctInfo.combid;

                LoginAns la;
                la.bacid = in.bacid;
                out.push_back(la);
            }
        }
    }

    return eRet;
}

Intf_RetType KamsInterface::ogsSendOrder(const SendOrderQry &in, std::list<SendOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    if(in.directive == ogs_dict::kDtBuy || in.directive == ogs_dict::kDtSell)
    {
        if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
        {
            return eRet;
        }

        qtp::MarketCode market = qtp::kMC_UNKNOW;
        qtp::SecurityCategory category = qtp::kSC_UNKNOW;
        std::string code;
        qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);

        string price = std::to_string((double)in.price / 10000);
        string volume = std::to_string(in.volume);
        string bacid = std::to_string(in.bacid);

        FundacctInfo fi = GetFundacctInfo(bacid, DataMap::getMarketVaule(market));
        if(fi.fundacct == "")
        {
            eRet = kIntfFail;
            errMsg = "Not found fundacctInfo";
            return kIntfError;
        }

        KamsInterface::UpdateSiteInfo(args);

        // 送单入参
        std::map<std::string, std::string> value;
        value["fundid"] = fi.fundid;
        value["combid"] = fi.combid;
        value["projectid"] = fi.projectid;
        value["schemeid"] = "0";
        value["secuid"] = fi.secuid;
        value["instrsno"] = "0";
        value["instrsno_modi"] = "0";
        value["dispatchid"] = "0";
        value["market"] = DataMap::getMarketVaule(market);
        value["stkcode"] = code;
        value["seat"] = "";
        value["hedgeflag"] = "0";
        value["bsflag"] = DataMap::getDirectiveVaule((ogs_dict::DirectiveType)in.directive);
        value["orderprice"] = price;
        value["orderqty"] = volume;
        value["ordersource"] = "0";
        value["pricetype"] = DataMap::getExecutionVaule((ogs_dict::ExecutionType)in.execution);
        value["investtype"] = "1";
        value["fairflag"] = "0";
        value["overinstrprocess"] = "0";
        value["appendentrust"] = "0";
        value["confirmserialno"] = "";

        SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899321", KamsInterface::sessionid, args);
        SetFloatingParms(hHandle, value);

        eRet = SQLExecute(hHandle, errMsg, "899321");
        if(kIntfSuccess == eRet)
        {
            std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

            for(std::map<std::string, std::string> r : result)
            {
                SendOrderAns soa;

                strcpy(soa.sysOrderId, r["ordersno"].c_str());
                soa.bacid = in.bacid;
                soa.custOrderId = in.custOrderId;

                VLOG(200) << "===SendOrderAns==="
                          << "sysOrderId = " << soa.sysOrderId
                          << "custOrderId = " << soa.custOrderId
                          << "bacid = " << soa.bacid
                          << "===SendOrderAns===";

                out.push_back(soa);
            }
        }
    }
    else
    {
        errMsg = "Dissurport order type";
        eRet = kIntfError;
    }

    return eRet;
}

Intf_RetType KamsInterface::ogsCancelOrder(const CancelOrderQry &in, std::list<CancelOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;

    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    KamsInterface::UpdateSiteInfo(args);

    std::map<std::string, std::string> value;
    value["ordersno"] = in.sysOrderId;
    value["orderdate"] = GetCurrDay();

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899322", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);

    eRet = SQLExecute(hHandle, errMsg, "899322");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        CancelOrderAns coa;
        coa.bacid = in.bacid;
        coa.custOrderId = in.custOrderId;
        strcpy(coa.sysOrderId, in.sysOrderId);
        out.push_back(coa);
    }

    return eRet;
}

Intf_RetType KamsInterface::ogsQueryOrder(const QueryOrderQry &in, std::list<QueryOrderAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }
    // 获取参数
    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);

    string stkid = (code == "") ? ("") : (code + (market== qtp::kMC_SZE ? "SZ" : "SS"));

    FundacctInfo fi = GetFundacctInfo(std::to_string(in.bacid), DataMap::getMarketVaule(market));
    if(fi.fundacct == "")
    {
        eRet = kIntfFail;
        errMsg = "Not found fundacctInfo";
        return eRet;
    }

    KamsInterface::UpdateSiteInfo(args);

    // 设置参数
    std::map<std::string, std::string> value;
    value["stktype"] = "";
    value["fundid"] = fi.fundid;
    value["market"] = DataMap::getMarketVaule(market);
    value["projectid"] = fi.projectid;
    value["stkid"] = stkid;
    value["combid"] = fi.combid;
    value["bsflag"] = DataMap::getDirectiveVaule((ogs_dict::DirectiveType)in.directive);
    value["secuid"] = fi.secuid;
    value["cancelflag"] = "";
    value["orderstatus"] = "";
    value["rptseat"] = "";
    value["instrsno"] = "";
    value["ordersource"] = "";
    value["hedgeflag"] = "";
    value["orderoperid"] = "";
    value["ordersno"] = in.sysOrderId;
    value["direction"] = "";
    value["investtype"] = "";
    value["directoperid"] = "";
    value["orderid"] = "";
    value["displayowner"] = "";
    value["nodisplaybsflag"] = "";
    value["fundacct"] = fi.fundacct;
    value["fundgroup"] = "";

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899565", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);

    eRet = SQLExecute(hHandle, errMsg, "899565");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            QueryOrderAns qoa;
            qoa.bacid = in.bacid;
            qoa.custOrderId = in.custOrderId;
            strcpy(qoa.sysOrderId, r["ordersno"].c_str());
            qoa.price = (int)(std::atof(r["orderprice"].c_str()) * 10000);
            qoa.volume = std::atoi(r["orderqty"].c_str());
            qoa.orderStatus = DataMap::getOrderStatusKey(r["orderstatus"]);
            qoa.dealVolume = std::atoi(r["matchqty"].c_str());
            qoa.dealBalance = std::atof(r["matchamt"].c_str());
            qoa.dealPrice = std::atof(r["matchprice"].c_str());
            qoa.innerCode = in.innerCode;
            qoa.directive = in.directive;
            qoa.withdrawVolume = std::atoi(r["cancelqty"].c_str());
            qoa.tradeDate = std::atoi(r["orderdate"].c_str());
            qoa.orderTime = std::atoi(r["opertime"].c_str());

            VLOG(200) << "===QueryOrderAns==="
                      << "sysOrderId = " << qoa.sysOrderId
                      << "custOrderId = " << qoa.custOrderId
                      << "orderStatus = " << (int)qoa.orderStatus
                      << "volume = " << qoa.volume
                      << "price = " << qoa.price
                      << "dealVolume = " << qoa.dealVolume
                      << "===QueryOrderAns===";

            out.push_back(qoa);
        }
    }

    return eRet;
}

// 查持仓
Intf_RetType KamsInterface::ogsQueryPosition(const QueryPositionQry &in, std::list<QueryPositionAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    // 获取参数
    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);

    string stkid = (code == "") ? ("") : (code + (market== qtp::kMC_SZE ? "SZ" : "SS"));

    FundacctInfo fi = GetFundacctInfo(std::to_string(in.bacid), DataMap::getMarketVaule(market));
    if(fi.fundacct == "")
    {
        eRet = kIntfFail;
        errMsg = "Not found fundacctInfo";
        return eRet;
    }

    KamsInterface::UpdateSiteInfo(args);

    // 设置参数
    std::map<std::string, std::string> value;
    value["fundid"] = fi.fundid;
    value["projectid"] = fi.projectid;
    value["combid"] = fi.combid;
    value["secuid"] = fi.secuid;
    value["stkid"] = stkid;
    value["market"] = DataMap::getMarketVaule(market).c_str();
    value["fundtype"] = "";
    value["stktype"] = "";
    value["ft_hedgeflag"] = "0";
    value["investtype"] = "1";
    value["seat"] = "";

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899503", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);

    eRet = SQLExecute(hHandle, errMsg, "899503");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            QueryPositionAns qpa;
            qpa.acidcard = in.acidcard;
            qpa.bacid = in.bacid;
            qpa.innerCode = in.innerCode;
            qpa.currentVolume = std::atoi(r["buyqty"].c_str());
            qpa.usableVolume = std::atoi(r["lastqty"].c_str());

            VLOG(200) << "===SendOrderAns==="
                      << "code = " << code
                      << "currentVolume = " << qpa.currentVolume
                      << "usableVolume = " << qpa.usableVolume
                      << "===SendOrderAns===";

            out.push_back(qpa);
        }
    }

    VLOG(200) << errMsg;

    return eRet;
}

// 查成交
Intf_RetType KamsInterface::ogsQueryBargain(const QueryBargainQry &in, std::list<QueryBargainAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    // 获取参数
    qtp::MarketCode market = qtp::kMC_UNKNOW;
    qtp::SecurityCategory category = qtp::kSC_UNKNOW;
    std::string code;
    qtp::UniversalCode::UCToSymbol(in.innerCode, &code, &market, &category);

    string stkid = (code == "") ? ("") : (code + (market== qtp::kMC_SZE ? "SZ" : "SS"));

    FundacctInfo fi = GetFundacctInfo(std::to_string(in.bacid), DataMap::getMarketVaule(market));
    if(fi.fundacct == "")
    {
        eRet = kIntfFail;
        errMsg = "Not found fundacctInfo";
        return eRet;
    }

    KamsInterface::UpdateSiteInfo(args);

    // 设置参数
    std::map<std::string, std::string> value;
    value["fundid"] = fi.fundid;
    value["market"] = DataMap::getMarketVaule(market);
    value["combid"] = fi.combid;
    value["stktype"] = "";
    value["stkid"] = stkid;
    value["secuid"] = fi.secuid;
    value["bsflag"] = "";
    value["matchtype"] = "";
    value["fundgroup"] = "";
    value["nodisplaybsflag"] = "";
    value["hedgeflag"] = "";
    value["direction"] = "";
    value["investtype"] = "";
    value["mainseat"] = "";
    value["instrsno"] = "";
    value["ordersno"] = in.sysOrderId;
    value["orderid"] = "";
    value["fundacct"] = fi.fundacct;

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899567", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);


    eRet = SQLExecute(hHandle, errMsg, "899567");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            QueryBargainAns qba;
            qba.bacid = in.bacid;
            qba.custOrderId = in.custOrderId;
            strcpy(qba.sysOrderId, r["ordersno"].c_str());
            qba.innerCode = in.innerCode;
            strcpy(qba.dealId, r["matchsno"].c_str());
            qba.dealVolume = std::atoi(r["matchqty"].c_str());
            qba.dealBalance = (OGS_DEALBALANCE)(std::atof(r["matchamt"].c_str()) * 10000);
            qba.dealPrice = (OGS_DEALPRICE)(std::atof(r["matchprice"].c_str()) * 10000);

            VLOG(200) << "===QueryBargainAns==="
                      << "code = " << code
                      << "sysOrderId = " << qba.sysOrderId
                      << "dealVolume = " << qba.dealVolume
                      << "dealBalance = " << qba.dealBalance
                      << "dealPrice = " << qba.dealPrice
                      << "===QueryBargainAns===";

            out.push_back(qba);
        }
    }

    return eRet;
}

// 查资金
Intf_RetType KamsInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, std::list<QueryFundInfoAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    // 获取参数
    qtp::MarketCode market = qtp::kMC_SZE;  // 随便弄个市场，将账号信息查出来
    std::string currDay = GetCurrDay();

    FundacctInfo fi = GetFundacctInfo(std::to_string(in.bacid), DataMap::getMarketVaule(market));
    if(fi.fundacct == "")
    {
        eRet = kIntfFail;
        errMsg = "Not found fundacctInfo";
        return eRet;
    }

    KamsInterface::UpdateSiteInfo(args);

    // 设置参数
    std::map<std::string, std::string> value;
    value["beginbusidate"] = currDay;
    value["endbusidate"] = currDay;
    value["fundid"] = fi.fundid;
    value["projectid"] = fi.projectid;

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899501", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);


    eRet = SQLExecute(hHandle, errMsg, "899501");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            QueryFundInfoAns qfia;
            qfia.acidcard = in.acidcard;
            qfia.bacid = in.bacid;
            qfia.balance = (OGS_BALANCE)(std::atof(r["totalasset"].c_str()) * 10000);
            qfia.useableBalance = (OGS_BALANCE)(std::atof(r["td_cashbalance"].c_str()) * 10000);
            qfia.frozenBalance = 0;

            VLOG(200)<<"===QueryFundInfoAns==="
                    << "acidcard = " << qfia.acidcard
                    << "bacid = " << qfia.bacid
                    << "balance = " << qfia.balance
                    << "useableBalance = " << qfia.useableBalance
                    << "===QueryFundInfoAns===";

            out.push_back(qfia);
        }
    }

    return eRet;
}

Intf_RetType KamsInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, std::list<PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfNotSupport;
}

Intf_RetType KamsInterface::ogsPaybackFunds(const PaybackFundsQry &in, std::list<PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args)
{
    return kIntfNotSupport;
}

Intf_RetType KamsInterface::QueryProjectid(std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    std::string errMsg;

    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    std::map<std::string, std::string> value;
    value["fundacct"] = "";
    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899543", KamsInterface::sessionid, args);
    SetFloatingParms(hHandle, value);

    eRet = SQLExecute(hHandle, errMsg, "899543");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            for(auto &&fundacctInfo: KamsInterface::fundacctInfos)
            {
                if(fundacctInfo.fundacct == r["FUNDACCT"])
                {
                    fundacctInfo.projectid = r["PROJECTID"];
                }
            }
        }
    }

    return eRet;
}

Intf_RetType KamsInterface::QueryFundidCombid(std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    std::string errMsg;

    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899541", KamsInterface::sessionid, args);

    eRet = SQLExecute(hHandle, errMsg, "899541");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            for(auto &&fundacctInfo: KamsInterface::fundacctInfos)
            {
                if(fundacctInfo.projectid == r["PROJECTID"])
                {
                    fundacctInfo.combid = r["COMBID"];
                    fundacctInfo.fundid = r["FUNDID"];
                }
            }
        }
    }

    return eRet;
}

Intf_RetType KamsInterface::QueryFundacctInfo(std::map<int, std::string>& args)
{
    Intf_RetType eRet = kIntfError;
    std::string errMsg;

    if((eRet = BeginWrite(hHandle, errMsg)) != kIntfSuccess)
    {
        return eRet;
    }

    SetFixedParms(hHandle, KamsInterface::userid, KamsInterface::userpwd, "899542", KamsInterface::sessionid, args);

    eRet = SQLExecute(hHandle, errMsg, "899542");
    if(kIntfSuccess == eRet)
    {
        std::vector<std::map<std::string, std::string>> result = GetExecuteResult(hHandle);

        for(std::map<std::string, std::string> r : result)
        {
            // 只用上海跟深圳的市场账号
            if(r["market"]  == "0" || r["market"]  == "1")
            {
                FundacctInfo fundacctInfo;

                fundacctInfo.market = r["market"];
                fundacctInfo.secuid = r["secuid"];
                fundacctInfo.status = r["status"];
                fundacctInfo.fundacct = r["fundacct"];

                KamsInterface::fundacctInfos.push_back(fundacctInfo);
            }
        }
    }

    return eRet;
}

KamsInterface::FundacctInfo KamsInterface::GetFundacctInfo(std::string bacid, std::string mid)
{
    FundacctInfo fi;

    for(auto &fundacctInfo: KamsInterface::fundacctInfos)
    {
        if(fundacctInfo.fundacct == bacid)
        {
            bool find = mid == "";  // 如果市场是空的，那就随便返回一个深圳或者上海的回去
            if(mid  != "")
            {
                if( fundacctInfo.market == mid)
                {
                    find = true;
                }
            }

            if(find)
            {
                fi.fundacct = fundacctInfo.fundacct;
                fi.market = fundacctInfo.market;
                fi.secuid = mid == "" ? "" : fundacctInfo.secuid;   // 市场是空的，那就默认股东账号为空（股东账号分深圳，上海等市场）
                fi.status = fundacctInfo.status;
                fi.projectid = fundacctInfo.projectid;
                fi.fundid = fundacctInfo.fundid;
                fi.combid = fundacctInfo.combid;
                break;
            }
        }
    }
    return fi;
}

void KamsInterface::SetFixedParms(KCBPCLIHANDLE  hHandle, std::string strUserid, std::string strPasswd, std::string funcid, std::string sessionid, std::map<int, std::string>& args)
{
    char strEncryptPasswd[256];
    KDEncode(KDCOMPLEX_ENCODE,
             (unsigned char *)strPasswd.c_str(), (int)strPasswd.size(),
             (unsigned char *)strEncryptPasswd, 256,
             (void *)strUserid.c_str(), (int)strUserid.size());

    // 如果传过来的参数没有，那就使用之前缓存的信息。
    string stationaddr = "";
    stationaddr += (args[4] != "") ? ("CPU[" + args[4] + "]") : ("CPU[" + KamsInterface::siteInfo.cpu+ "]");
    stationaddr += (args[3] != "") ? ("IDE[" + args[3] + "]") : ("IDE[" + KamsInterface::siteInfo.ide + "]");
    stationaddr += (args[1] != "") ? ("IP[" + args[1] + "]") : ("IP[" + KamsInterface::siteInfo.ip + "]");
    stationaddr += (args[2] != "") ? ("MAC[" + args[2] + "]") : ("MAC[" + KamsInterface::siteInfo.mac + "]");

//    VLOG(200) << "stationaddr = "  << stationaddr;

    KCBPCLI_SetValue(hHandle, "g_sysid", "0");
    KCBPCLI_SetValue(hHandle, "g_menuid", "0");
    KCBPCLI_SetValue(hHandle, "g_funcid", (char *)funcid.c_str());
    KCBPCLI_SetValue(hHandle, "g_userid", (char *)strUserid.c_str());
    KCBPCLI_SetValue(hHandle, "g_userpwd", strEncryptPasswd);
    KCBPCLI_SetValue(hHandle, "g_userway", "0");
    KCBPCLI_SetValue(hHandle, "g_stationaddr", (char *)stationaddr.c_str());
    KCBPCLI_SetValue(hHandle, "g_chkuserid", "0");
    KCBPCLI_SetValue(hHandle, "g_checksno", "0");
    KCBPCLI_SetValue(hHandle, "g_sessionid", (char *)sessionid.c_str());
    KCBPCLI_SetValue(hHandle, "g_confirmaction", "0");
    KCBPCLI_SetValue(hHandle, "g_confirmlevel", "0");
}

// 主要是为了查看设置的参数
void KamsInterface::SetFloatingParms(KCBPCLIHANDLE  hHandle, std::map<std::string, std::string>value)
{
    VLOG(200) << "===↓↓↓SetFloatingParms↓↓↓===";
    for(auto &v: value)
    {
        VLOG(200) << v.first << " = " << v.second;
        KCBPCLI_SetValue(hHandle, (char *)v.first.c_str(), (char *)v.second.c_str());
    }
    VLOG(200) << "===↑↑↑SetFloatingParms↑↑↑===";
}

bool KamsInterface::UpdateSiteInfo(std::map<int, std::string>& args)
{
    if(args[1] != ""){ KamsInterface::siteInfo.ip = args[1]; }
    if(args[2] != ""){ KamsInterface::siteInfo.mac = args[2]; }
    if(args[3] != ""){ KamsInterface::siteInfo.ide = args[3]; }
    if(args[4] != ""){ KamsInterface::siteInfo.cpu = args[4]; }

    return true;
}

Intf_RetType KamsInterface::BeginWrite(KCBPCLIHANDLE hHandle, std::string &errMsg)
{
    Intf_RetType initfRet = kIntfSuccess;

    int ret = KCBPCLI_BeginWrite(hHandle);
    if (ret != 0)
    {
        errMsg = "KCBPCLI_BeginWrite Err, ret = " + std::to_string(ret);
        initfRet = kIntfError;
    }

    return initfRet;
}

Intf_RetType KamsInterface::SQLExecute(KCBPCLIHANDLE hHandle, std::string &errMsg, char *szProgramName)
{
    int ret = KCBPCLI_SQLExecute(hHandle, szProgramName);

    if (ret != 0)
    {
        if (ret == 2003 || ret == 2004 || ret == 2055 || ret == 2054)
        {
            isconnect = false;
        }
        char szTmp[1024] = { 0 };
        KCBPCLI_GetErrorMsg(hHandle, szTmp);
        string err = szTmp;
        errMsg = "接收超时" + err + " ret = " + std::to_string(ret);
        KCBPCLI_SQLCloseCursor(hHandle);
        return kIntfError;
    }

    int nColNums = 0;
    ret = KCBPCLI_SQLNumResultCols(hHandle, &nColNums);//解包
    if (ret != 0)
    {
        errMsg = "unknown resultset colnums, ret = " + std::to_string(ret);
        KCBPCLI_SQLCloseCursor(hHandle);
        return kIntfError;
    }

    KCBPCLI_SQLFetch(hHandle);
    char szTmpbuf[1024] = { 0 };
    if (KCBPCLI_RsGetColByName(hHandle, "CODE", szTmpbuf))
    {
        errMsg = "Get CODE Fail";
        KCBPCLI_SQLCloseCursor(hHandle);
        return kIntfError;
    }

    if (strcmp(szTmpbuf, "0") != 0)
    {
        KCBPCLI_RsGetColByName(hHandle, "MSG", szTmpbuf);
        errMsg = StringHelper::convertCodec(szTmpbuf);
        KCBPCLI_SQLCloseCursor(hHandle);
        return kIntfError;
    }

    return kIntfSuccess;

}

std::vector<std::map<std::string, std::string>> KamsInterface::GetExecuteResult(KCBPCLIHANDLE hHandle)
{
    std::vector<std::map<std::string, std::string>> result;

    while (KCBPCLI_SQLMoreResults(hHandle) == 0)
    {
        std::string colNames = GetColNames(hHandle);
        std::vector<std::string> keyNames = Split(colNames, ",");

        //        VLOG(200) << colNames;

        while (!KCBPCLI_RsFetchRow(hHandle))
        {
            std::map<std::string, std::string> ret;
            for(std::string keyName: keyNames)
            {
                char vlu[128] = { 0 };
                KCBPCLI_RsGetColByName(hHandle, (char *)keyName.c_str(), vlu);
                ret[keyName] = std::string(vlu);
            }
            result.push_back(ret);
        }
    }
    KCBPCLI_SQLCloseCursor(hHandle);

    return result;
}

std::string KamsInterface::GetColNames(KCBPCLIHANDLE hHandle)
{
    int nCol = 0;
    char names[2048] = { 0 };

    KCBPCLI_SQLNumResultCols(hHandle, &nCol);
    KCBPCLI_RsGetColNames(hHandle, names, 2047);

    std::string s(names);
    Trim(s);

    return s;
}

}
