#include "KamsGlobal.h"
#include "KamsInterface.h"

namespace ogs {

#ifdef __cplusplus
extern "C"
{
#endif

    DEFINE_VERSION(kams)

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr) {
        if ((strcmp(brokerType.c_str(), "KAMS") == 0) || (strcmp(brokerType.c_str(), "kams") == 0)) {
            inPtr = std::shared_ptr<Interface>(new KamsInterface());
        }
    }

    int LoadLocalOption(void* src,size_t size){
        if(size!= sizeof(ogs::ReadConfig::localOption)){
            return -1;
        }
        memcpy(&ogs::ReadConfig::localOption,src,size);
        return 0;
    }

    void LogLibVersion()
    {
        LOG(info) << "KAMS 接口库版本：" << GET_VERSION_STR(kams);
    }

#ifdef __cplusplus
}
#endif
}

