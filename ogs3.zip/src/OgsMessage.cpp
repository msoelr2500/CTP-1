////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-21
////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "OgsMessage.h"
#include "BufferHandle.h"
#include "StringHelper.h"
#include "OgsApi.h"
#include "DataStruct.h"

using std::string;

OgsMessage::OgsMessage(qtp::QtpMessagePtr message)
{
    mMessage = message;
    mCorrupted = !verify();
}

OgsMessage::OgsMessage()
{
    mCorrupted = true;
    mError = "[OgsMessage] empty message.";
}

bool OgsMessage::verify()
{
    if (ogs::GetItemSizeAndCnt(mMessage, &mItemSize, &mItemCount) != 0) {
        mError = "[OgsMessage] message corrupted: failed to parse item size and count.";
        return false;
    }

    if (mItemSize * mItemCount != mMessage->GetDataLen()) {
        StringHelper::string_format(mError, "[OgsMessage] message corrupted: itemSize(%d) * itemCount(%d) != dataLen(%d).",
                                    mItemSize, mItemCount, mMessage->GetDataLen());
        return false;
    }

    mError = "[OgsMessage] message is parsed successfully.";
    return true;
}

bool OgsMessage::isCorrupted() const
{
    return mCorrupted;
}

std::string OgsMessage::error() const {
    return mError;
}

uint32_t OgsMessage::itemCount() const
{
    return mItemCount;
}

uint32_t OgsMessage::itemSize() const
{
    return mItemSize;
}

uint32_t OgsMessage::totalSize() const
{
    return mMessage->GetDataLen();
}

uint32_t OgsMessage::type() const
{
    return mMessage->MsgType();
}

bool OgsMessage::session(qtp::session_id_t& output) const
{
    return mMessage->GetTagAsInteger(ogs::kTagSession, &output) == 0;
}

bool OgsMessage::errorCode(uint32_t &output) const
{
    return mMessage->GetOptionAsInteger(ogs::kMoErrorCode, &output) == 0;
}

bool OgsMessage::errorMsg(std::string& msg) const
{
    void* msgPtr = nullptr;
    uint16_t msgLength;
    bool result = mMessage->GetOption(ogs::kMoErrorMsg, (const void **)&msgPtr, &msgLength) == 0;
    if (result && msgPtr)
        msg = string((const char*)msgPtr, msgLength);
    return result;
}

const void *OgsMessage::rawData() const
{
    return mMessage->GetData();
}

std::string OgsMessage::toQryBuffer() const
{
    string result;
    BUF_HANDLE_COUNTTYPE count = itemCount();
    result.resize(sizeof(BUF_HANDLE_COUNTTYPE) + totalSize());
    memcpy((char*)result.c_str(), &count, sizeof(BUF_HANDLE_COUNTTYPE));
    memcpy((char*)result.c_str() + sizeof(BUF_HANDLE_COUNTTYPE), rawData(), totalSize());
    return result;
}

qtp::QtpMessagePtr OgsMessage::buildTimeoutMsg(uint16_t msgtype, uint8_t service)
{
    qtp::QtpMessagePtr message = std::make_shared<qtp::QtpMessage>();
    message->BeginEncode(msgtype, service);
    message->Encode();
    return message;
}

qtp::QtpMessagePtr OgsMessage::qtpMessage()
{
    return mMessage;
}
