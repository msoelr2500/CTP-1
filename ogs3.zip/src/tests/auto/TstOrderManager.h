///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TSTORDERMANAGER_H
#define TSTORDERMANAGER_H

#include <gtest/gtest.h>
#include "OrderManager.h"
#include "ogs_dict.h"

class TstOrderManager : public testing::Test, public OrderManager
{
public:
    TstOrderManager();
    virtual void SetUp() override;
    virtual void TearDown() override;
    virtual ~TstOrderManager();
};

TEST_F(TstOrderManager, SetDatabaseTest)
{
    ASSERT_TRUE(setDatabase("./test_db"));
    ASSERT_TRUE(isDatabaseOpen());
    ASSERT_TRUE(databaseStatus().ok());

    ASSERT_TRUE(setDatabase("./test_db"));
    ASSERT_TRUE(isDatabaseOpen());
    ASSERT_TRUE(databaseStatus().ok());
}

TEST_F(TstOrderManager, SendOrderTest)
{
    ogs::SendOrderQry qry = {0};
    qry.acidcard = 12345;
    qry.bacid = 54321;
    qry.custOrderId = 5123431531;
    qry.actype = 1;
    qry.directive = ogs::ogs_dict::kDtBuy;
    qry.execution = ogs::ogs_dict::kExeLimit;
    qry.innerCode = 111111111;
    qry.price = 100000;
    qry.volume = 900;
    memcpy(qry.password, "123321dd", 8);
    memcpy(qry.diskSn, "qrydisksn", 9);
    memcpy(qry.ipAddr, "1.222.233.54", 12);
    memcpy(qry.macAddr, "1234567890AB", 12);

    ASSERT_TRUE(addOrder(qry, 1001));

    OrderItem item;
    item.orderInfo.custOrderId = qry.custOrderId;
    ASSERT_TRUE(getUnfinishedOrder(item));

    ASSERT_EQ(item.orderInfo.custOrderId, qry.custOrderId);
    ASSERT_EQ(item.orderInfo.bacid, qry.bacid);
    ASSERT_EQ(item.orderInfo.custOrderId, qry.custOrderId);
    ASSERT_EQ(item.orderInfo.actype, qry.actype);
    ASSERT_EQ(item.orderInfo.directive, qry.directive);
    ASSERT_EQ(item.orderInfo.execution, qry.execution);
    ASSERT_EQ(item.orderInfo.innerCode, qry.innerCode);
    ASSERT_EQ(item.orderInfo.price, qry.price);
    ASSERT_EQ(item.orderInfo.volume, qry.volume);
    ASSERT_EQ(item.orderInfo.sessionid, 1001);
    ASSERT_STREQ(item.orderInfo.password, qry.password);
    ASSERT_STREQ(item.orderInfo.diskSn, qry.diskSn);
    ASSERT_STREQ(item.orderInfo.ipAddr, qry.ipAddr);
    ASSERT_STREQ(item.orderInfo.macAddr, qry.macAddr);
    ASSERT_STREQ(item.orderInfo.sysOrderId, "");
}

#endif // TSTORDERMANAGER_H
