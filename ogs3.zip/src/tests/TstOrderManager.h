///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TSTORDERMANAGER_H
#define TSTORDERMANAGER_H

#include <gtest/gtest.h>
#include "../OrderManager.h"
#include "../ogs_dict.h"

class TstOrderManager : public testing::Test, public OrderManager
{
public:
    TstOrderManager();
    virtual void SetUp() override;
    virtual void TearDown() override;
    virtual ~TstOrderManager();
};

TEST_F(TstOrderManager, Test001_SetDatabase)
{
    ASSERT_TRUE(setDatabase("./test_db"));
    ASSERT_TRUE(isDatabaseOpen());
    ASSERT_TRUE(databaseStatus().ok());

    ASSERT_TRUE(setDatabase("./test_db"));
    ASSERT_TRUE(isDatabaseOpen());
    ASSERT_TRUE(databaseStatus().ok());
}

TEST_F(TstOrderManager, Test002_SendOrderTest)
{
    // add a order record by send order qry
    ogs::SendOrderQry qry = {0};
    strcpy(qry.acidcard, "12345");
    strcpy(qry.bacid, "54321");
    qry.custOrderId = 5123431531;
    qry.actype = 1;
    qry.directive = ogs::ogs_dict::kDtBuy;
    qry.execution = ogs::ogs_dict::kExeLimit;
    qry.innerCode = 111111111;
    qry.price = 100000;
    qry.volume = 900;
    memcpy(qry.password, "123321dd", 8);
    memcpy(qry.diskSn, "qrydisksn", 9);
    memcpy(qry.ipAddr, "1.222.233.54", 12);
    memcpy(qry.macAddr, "1234567890AB", 12);

    ASSERT_TRUE(addOrder(qry, 1001));

    OrderItem item;
    item.orderInfo.custOrderId = qry.custOrderId;
    ASSERT_TRUE(getUnfinishedOrder(item));

    ASSERT_EQ(item.orderInfo.custOrderId, qry.custOrderId);
    ASSERT_STREQ(item.orderInfo.bacid, qry.bacid);
    ASSERT_EQ(item.orderInfo.custOrderId, qry.custOrderId);
    ASSERT_EQ(item.orderInfo.actype, qry.actype);
    ASSERT_EQ(item.orderInfo.directive, qry.directive);
    ASSERT_EQ(item.orderInfo.execution, qry.execution);
    ASSERT_EQ(item.orderInfo.innerCode, qry.innerCode);
    ASSERT_EQ(item.orderInfo.price, qry.price);
    ASSERT_EQ(item.orderInfo.volume, qry.volume);
    ASSERT_EQ(item.orderInfo.sessionid, 1001);
    ASSERT_STREQ(item.orderInfo.password, qry.password);
    ASSERT_STREQ(item.orderInfo.diskSn, qry.diskSn);
    ASSERT_STREQ(item.orderInfo.ipAddr, qry.ipAddr);
    ASSERT_STREQ(item.orderInfo.macAddr, qry.macAddr);
    ASSERT_STREQ(item.orderInfo.sysOrderId, "");

    // update by SendOrderAns
    ogs::SendOrderAns sendOrderAns = {0};
    strcpy(sendOrderAns.bacid, qry.bacid);
    sendOrderAns.custOrderId = qry.custOrderId;
    memcpy(sendOrderAns.sysOrderId, "[sysorderid]", 12);

    std::string entrust_error = "[entrust_error]";
    ASSERT_TRUE(updateOrder(sendOrderAns, kIntfSuccess, entrust_error));

    memcpy(item.orderInfo.sysOrderId, sendOrderAns.sysOrderId, SYSORDERIDSIZE);
    ASSERT_TRUE(getOrder(item.orderInfo));
    ASSERT_STREQ(item.orderInfo.sysOrderId, sendOrderAns.sysOrderId);

    // update by QueryOrderAns

    ogs::QueryOrderAns queryOrderAns = {0};
    strcpy(queryOrderAns.bacid, qry.bacid);
    queryOrderAns.custOrderId = qry.custOrderId;
    queryOrderAns.directive = qry.directive;
    queryOrderAns.innerCode = qry.innerCode;
    queryOrderAns.price = qry.price;
    queryOrderAns.volume = qry.volume;
    memcpy(queryOrderAns.sysOrderId, sendOrderAns.sysOrderId, SYSORDERIDSIZE);
    queryOrderAns.orderStatus = ogs::ogs_dict::kOtPartMatched;
    queryOrderAns.dealVolume = 51;
    queryOrderAns.dealPrice = 140000;
    queryOrderAns.dealBalance = queryOrderAns.dealVolume * queryOrderAns.dealPrice;

    ASSERT_TRUE(updateOrder(queryOrderAns));

    ASSERT_TRUE(getOrder(item.orderInfo));
    ASSERT_EQ(item.orderInfo.dealBalance, queryOrderAns.dealBalance);
    ASSERT_EQ(item.orderInfo.dealPrice,   queryOrderAns.dealPrice);
    ASSERT_EQ(item.orderInfo.dealVolume,  queryOrderAns.dealVolume);
    ASSERT_EQ(item.orderInfo.orderStatus, queryOrderAns.orderStatus);
}

TEST_F(TstOrderManager, Test003_DbIoTest)
{
    ogs::OrderInfo info;
    strcpy(info.acidcard, "1010101010");
    info.actype = 1;
    strcpy(info.bacid, "11");
    info.custOrderId = 9999;
    info.dealPrice = 546100;
    memcpy(info.diskSn, "[disksn]", 8);
    memcpy(info.sysOrderId, "[sysorderid]", 12);

    ASSERT_TRUE(saveToDB(info));

    ogs::OrderInfo info2;
    info2.custOrderId = info.custOrderId;

    ASSERT_TRUE(loadFromDB(info2));
    ASSERT_STREQ(info.acidcard,    info2.acidcard);
    ASSERT_EQ(info.actype,      info2.actype);
    ASSERT_STREQ(info.bacid,       info2.bacid);
    ASSERT_EQ(info.custOrderId, info2.custOrderId);
    ASSERT_EQ(info.dealPrice,   info2.dealPrice);
    ASSERT_TRUE(strcmp(info.diskSn,     info2.diskSn) == 0);
    ASSERT_TRUE(strcmp(info.sysOrderId, info2.sysOrderId) == 0);
}

#endif // TSTORDERMANAGER_H
