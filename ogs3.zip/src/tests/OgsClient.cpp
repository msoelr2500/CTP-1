///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "OgsClient.h"

#ifndef _WIN32
#include <netinet/in.h>
# ifdef _XOPEN_SOURCE_EXTENDED
#  include <arpa/inet.h>
# endif
#include <sys/socket.h>
#endif

#include <string.h>
#include "qtp_manager.h"
#include "qtp_server.h"
#include "qtp_message.h"
#include "qtp_client.h"
#include "qtp_session.h"
#include "qtp_log.h"

#include "../OgsLogger.h"
#include "../DataStruct.h"
#include "../OgsApi.h"
#include "../OgsForwarder.h"

#define BUF_MAX 2048

using namespace qtp;
using namespace std;

OgsClient::OgsClient() : qtp::QtpClient(true)
{
}

OgsClient::~OgsClient()
{
}

bool OgsClient::connectHost(const std::string &server, int port)
{
    struct sockaddr_in sock_addr;

    ::memset(&sock_addr, 0, sizeof(sock_addr));
    if (::inet_aton(server.c_str(), &sock_addr.sin_addr) == 0) {
        return false;
    }

    sock_addr.sin_family = AF_INET;
    sock_addr.sin_port = htons(port);
    Connect((sockaddr*)&sock_addr, sizeof(sock_addr));
    return true;
}

int OgsClient::msgCount() const
{
    std::lock_guard<mutex> dataLock(mDataMutex);
    return mMsgList.size();
}

bool OgsClient::takeNextMsg(OgsMessage &message)
{
    std::lock_guard<mutex> dataLock(mDataMutex);
    if (mMsgList.size() != 0) {
        message = *mMsgList.begin();
        mMsgList.erase(mMsgList.begin());
        return true;
    }
    return false;
}

void OgsClient::OnMessage(QtpMessagePtr message, bufferevent *bev)
{
    (void)bev;
    recvMessage(message->MsgType(),message);
}

void OgsClient::OnConnected()
{
#define SESSIONCLIENTID 100
    // LOG(info) << "OgsClient::OnConnected";
    QtpSessionMgr::Instance().AddSession(SESSIONCLIENTID, client_);
    mIsConnected = true;

    // MessageQueue::instance()->notifyConnectedState(MessageQueue::STATE_CONNECTED);
}

void OgsClient::sendMessage(int msg_type,void* msg_content,int size)
{
    if( !IsConnected() ) return;

    uint32_t itemsize,itemcnt =1;
    itemsize = size;

    auto message = std::make_shared<QtpMessage>();
    message->BeginEncode(msg_type, ogs::kOgsServiceId);

    ogs:: SetItemSizeAndCnt(message,itemsize,itemcnt);

    message->SetData(msg_content,itemsize, false);
    message->Encode(QtpMessage::kEnNormal); //只encode选项区
    SendMessage(message);
}

void OgsClient::recvMessage(int msg_type, qtp::QtpMessagePtr message)
{
    std::lock_guard<mutex> dataLock(mDataMutex);
    // std::cout << "[OgsClient] got a message." << std::endl;
#if defined(LOG_MESSAGE_TYPE)
    std::cout << "message type: " << OgsLogger::msgType(msg_type) << std::endl;
#endif
    mMsgList.push_back(OgsMessage(message));
    // notify client of the message.
}

void OgsClient::OnDisconnected()
{
    // LOG(info) << "OgsClient::disConnected";
    mIsConnected = false;
}
