///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MESSAGETHREAD_H
#define MESSAGETHREAD_H

#include <thread>
#include <qtp_manager.h>
#include "OgsClient.h"

class MessageThread
{
public:
    MessageThread();
    virtual ~MessageThread();

    static MessageThread& instance();

    bool connect(const std::string& ip, int port);
    bool isConnected() const;
    int close();

    void sendMessage(int msg_type,void* send_content,int size);

    int msgCount() const;
    bool takeNextMsg(OgsMessage& message);

    void run();

    void exec();

    void shutdown();

private:
    bool mIsConnected = false;
    OgsClient* mClient;
    qtp::QtpManager* mQtpManager;
    std::thread mThread;
    static MessageThread* mInstance;
};

#endif // MESSAGETHREAD_H
