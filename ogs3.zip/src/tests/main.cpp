///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include <gtest/gtest.h>
#include <iostream>
#include "MessageThread.h"
#include "../ReadConfig.h"
#include "../DataStruct.h"
#include "unistd.h"

int main(int argc, char* argv[])
{
    // std::cout.sync_with_stdio(true);
    testing::InitGoogleTest(&argc, argv);

    return RUN_ALL_TESTS();
}
