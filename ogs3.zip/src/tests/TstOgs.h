///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TSTOGS_H
#define TSTOGS_H

#include <gtest/gtest.h>
#include "../ReadConfig.h"
#include "MessageThread.h"
#include "../DataStruct.h"
#include "../ogs_dict.h"
#include "universal_code.h"
#include "AutoGlobal.h"

#define KCBPGTJA_TEST

#if defined(DDVIP_TEST)
#define TEST_BACID "20000001196"
#define TEST_ACIDCARD "20000001196"
#define TEST_PASSWORD "123987"
#elif defined(KCBPGTJA_TEST)
#define TEST_BACID "26550"
#define TEST_ACIDCARD "1019917"
#define TEST_PASSWORD "*Sh//+)$"
#elif defined(KCBPSJZQ_TEST)
#define TEST_BACID "19010085"
#define TEST_ACIDCARD "19010085"
#define TEST_PASSWORD "123123"
#elif defined(KDVIP_TEST)
#define TEST_BACID "923100001647"
#define TEST_ACIDCARD "102803587"
#define TEST_PASSWORD "123321"
#elif defined(UFX_TEST)
#define TEST_BACID "8100000100"
#define TEST_ACIDCARD "2790778"
#define TEST_PASSWORD "606869"
#elif defined(KDMID_TEST)
#define TEST_BACID "809086000006"
#define TEST_ACIDCARD "100678222"
#define TEST_PASSWORD "123456"
#elif defined(PBOX_TEST)
#define TEST_BACID "10020097"
#define TEST_ACIDCARD "10020097"
#define TEST_PASSWORD "111111"
#elif defined(PBUFX_TEST)
#define TEST_BACID "81106500051"
#define TEST_ACIDCARD "81106500051"
#define TEST_PASSWORD "1"
#endif

class TstOgs : public testing::Test
{
public:
    TstOgs();
    virtual void SetUp() override;
    virtual void TearDown() override;
    virtual ~TstOgs();

    std::string sysorderid;
};

TEST_F(TstOgs, Test001_Config)
{
    ogs::ReadConfig readConfig;
    readConfig.Reading(0, NULL);
    ASSERT_FALSE(readConfig.localOption.LocalAddr.empty());
}

TEST_F(TstOgs, Test002_Connect)
{
    MessageThread::instance().connect(ogs::ReadConfig::localOption.LocalAddr,
                                      ogs::ReadConfig::localOption.LocalPort);
    MessageThread::instance().run();

    while (true) {
        if (MessageThread::instance().isConnected()) break;
    }
    ASSERT_TRUE(MessageThread::instance().isConnected());
}

TEST_F(TstOgs, Test003_Login)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::LoginQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;

        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());

        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        MessageThread::instance().sendMessage(ogs::MessageType::kMtLogin, &qry,sizeof(ogs::LoginQry));

        while (true) {
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            ogs::LoginAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() > 0);

            /**
            for (int i = 0; i < message.itemCount(); ++i) {
                std::cout << "bacid: " << ans[i].bacid << std::endl;
            }
            **/
            break;
        }

        break;
    };

    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test004_QueryFundInfo)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::QueryFundInfoQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());

        MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryFundInfo, &qry,sizeof(ogs::QueryFundInfoQry));

        while (true) {
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            ogs::QueryFundInfoAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() == 1);

            break;
        }

        break;
    };

    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test005_QueryOrderSe)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::QueryOrderQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        qry.execution = ogs::ogs_dict::kExeLimit;
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000000", qtp::kMC_CFFE, qtp::kSC_EQUITY);

        MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryOrderSe, &qry,sizeof(ogs::QueryOrderQry));

        while (true) {
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            ogs::QueryOrderAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() >= 0);

            break;
        }

        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test006_QueryPosition)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::QueryPositionQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000000", qtp::kMC_CFFE, qtp::kSC_EQUITY);

        MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryPosition, &qry, sizeof(ogs::QueryPositionQry));

        while (true) {
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            ogs::QueryPositionAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() >= 0);

            break;
        }

        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test007_QueryBargain)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::QueryBargainQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000000", qtp::kMC_CFFE, qtp::kSC_EQUITY);

        MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryBargain, &qry, sizeof(ogs::QueryBargainQry));

        while (true) {
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            ogs::QueryBargainAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() >= 0);

            break;
        }

        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test008_SendOrder)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::SendOrderQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        qry.directive = ogs::ogs_dict::kDtBuy;
        qry.custOrderId = 10000;
        qry.execution = ogs::ogs_dict::kExeLimit;
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000001", qtp::kMC_SZE, qtp::kSC_EQUITY);
        qry.price = 91900;
        qry.volume = 100;

        MessageThread::instance().sendMessage(ogs::MessageType::kMtSendOrder, &qry,sizeof(ogs::SendOrderQry));

        while (true) {
            ASSERT_TRUE(MessageThread::instance().isConnected());
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            if (message.type() != ogs::kMtSendOrderAns) continue;

            ogs::SendOrderAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() == 1);
            ASSERT_TRUE(strlen(ans->sysOrderId) > 0);
            TestHelper::sysorderid = ans->sysOrderId;

            break;
        }
        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test009_OrderStatusPush)
{
    while (true) {
        // This is necessary!
        ASSERT_TRUE(MessageThread::instance().isConnected());
        if (MessageThread::instance().msgCount() == 0) {
            continue;
        }

        OgsMessage pushedMessage;
        ASSERT_TRUE(MessageThread::instance().takeNextMsg(pushedMessage));
        ASSERT_FALSE(pushedMessage.isCorrupted());

        if (pushedMessage.type() != ogs::kMtQueryOrderAns) continue;

        ogs::QueryOrderAns* qryAns;
        ASSERT_TRUE(pushedMessage.parse(&qryAns));
        ASSERT_TRUE(pushedMessage.itemCount() > 0);
        if (strcmp(qryAns->sysOrderId, TestHelper::sysorderid.c_str()) == 0) {
            break;
        }
    }
}

TEST_F(TstOgs, Test010_QuerySendedOrder)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::QueryOrderQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.sysOrderId, TestHelper::sysorderid.c_str(), TestHelper::sysorderid.length());
        qry.execution = ogs::ogs_dict::kExeLimit;
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000001", qtp::kMC_SZE, qtp::kSC_EQUITY);

        MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryOrderSe, &qry,sizeof(ogs::QueryOrderQry));

        while (true) {
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());
            uint32_t errorCode;
            ASSERT_TRUE(message.errorCode(errorCode));
            ASSERT_TRUE(errorCode == 0);

            ogs::QueryOrderAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() == 1);
            ASSERT_TRUE(strcmp(ans->sysOrderId, TestHelper::sysorderid.c_str()) == 0);

            break;
        }

        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test011_QueryLastBargain)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::QueryBargainQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.sysOrderId, TestHelper::sysorderid.c_str(), TestHelper::sysorderid.length());
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000001", qtp::kMC_SZE, qtp::kSC_EQUITY);

        MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryBargain, &qry, sizeof(ogs::QueryBargainQry));

        while (true) {
            ASSERT_TRUE(MessageThread::instance().isConnected());
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());
            uint32_t errorCode;
            ASSERT_TRUE(message.errorCode(errorCode));
            ASSERT_TRUE(errorCode == 0);

            ogs::QueryBargainAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() >= 0);

            break;
        }

        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test012_CancelOrder)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::CancelOrderQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        qry.custOrderId = 10000;
        qry.innerCode = qtp::UniversalCode::SymbolToUC("000001", qtp::kMC_SZE, qtp::kSC_EQUITY);

        memcpy(qry.sysOrderId, TestHelper::sysorderid.c_str(), TestHelper::sysorderid.length());

        MessageThread::instance().sendMessage(ogs::MessageType::kMtCancelOrder, &qry,sizeof(ogs::CancelOrderQry));

        while (true) {
            ASSERT_TRUE(MessageThread::instance().isConnected());
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            if (message.type() != ogs::kMtCancelOrderAns) continue;

            uint32_t errorCode;
            ASSERT_TRUE(message.errorCode(errorCode));
            ASSERT_TRUE(errorCode == 0);
            if (errorCode == 0) {
                ogs::CancelOrderAns* ans;
                ASSERT_TRUE(message.parse(&ans));
                ASSERT_TRUE(message.itemCount() == 1);
                ASSERT_TRUE(strlen(ans->sysOrderId) > 0);
            } else {
                ogs::QueryOrderQry qry = {0};
                strcpy(qry.acidcard, TEST_ACIDCARD);
                strcpy(qry.bacid, TEST_BACID);
                qry.actype = 1;
                memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
                memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
                memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
                memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
                memcpy(qry.sysOrderId, TestHelper::sysorderid.c_str(), TestHelper::sysorderid.length());
                qry.execution = ogs::ogs_dict::kExeLimit;
                qry.innerCode = qtp::UniversalCode::SymbolToUC("000001", qtp::kMC_SZE, qtp::kSC_EQUITY);

                MessageThread::instance().sendMessage(ogs::MessageType::kMtQueryOrderSe, &qry,sizeof(ogs::QueryOrderQry));

                while (true) {
                    if (MessageThread::instance().msgCount() == 0) continue;

                    OgsMessage message;
                    ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
                    ASSERT_FALSE(message.isCorrupted());
                    uint32_t errorCode;
                    ASSERT_TRUE(message.errorCode(errorCode));
                    ASSERT_TRUE(errorCode == 0);

                    ogs::QueryOrderAns* ans;
                    ASSERT_TRUE(message.parse(&ans));
                    ASSERT_TRUE(message.itemCount() == 1);
                    ASSERT_TRUE(strcmp(ans->sysOrderId, TestHelper::sysorderid.c_str()) == 0);

                    break;
                }
            }

            break;
        }
        break;
    };

    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test013_SendInvalidOrder)
{
    while(true){
        ASSERT_TRUE(MessageThread::instance().isConnected());

        ogs::SendOrderQry qry = {0};
        strcpy(qry.acidcard, TEST_ACIDCARD);
        strcpy(qry.bacid, TEST_BACID);
        qry.actype = 1;
        memcpy(qry.ipAddr, ogs::ReadConfig::localOption.ClientIp.c_str(), ogs::ReadConfig::localOption.ClientIp.length());
        memcpy(qry.diskSn, ogs::ReadConfig::localOption.ClientDiskSn.c_str(), ogs::ReadConfig::localOption.ClientDiskSn.length());
        memcpy(qry.macAddr, ogs::ReadConfig::localOption.ClientMac.c_str(), ogs::ReadConfig::localOption.ClientMac.length());
        memcpy(qry.password, TEST_PASSWORD, strlen(TEST_PASSWORD));
        qry.directive = ogs::ogs_dict::kDtBuy;
        qry.custOrderId = 10002;
        qry.execution = ogs::ogs_dict::kExeLimit;
        qry.innerCode = 0;
        qry.price = 91900;
        qry.volume = 100;

        MessageThread::instance().sendMessage(ogs::MessageType::kMtSendOrder, &qry,sizeof(ogs::SendOrderQry));

        while (true) {
            ASSERT_TRUE(MessageThread::instance().isConnected());
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            if (message.type() != ogs::kMtSendOrderAns) continue;

            ogs::SendOrderAns* ans;
            ASSERT_TRUE(message.parse(&ans));
            ASSERT_TRUE(message.itemCount() == 1);
            ASSERT_TRUE(strlen(ans->sysOrderId) == 0);
            TestHelper::sysorderid = ans->sysOrderId;

            break;
        }

        while (true) {
            ASSERT_TRUE(MessageThread::instance().isConnected());
            if (MessageThread::instance().msgCount() == 0) continue;

            OgsMessage message;
            ASSERT_TRUE(MessageThread::instance().takeNextMsg(message));
            ASSERT_FALSE(message.isCorrupted());

            if (message.type() != ogs::kMtQueryOrderAns) continue;

            ogs::QueryOrderAns* ans;
            ASSERT_TRUE(message.parse(&ans));

            if (message.itemCount() != 1) continue;
            if (ans->custOrderId != qry.custOrderId) continue;

            // ASSERT_TRUE(ans->orderStatus == ogs::ogs_dict::kOtBad);

            break;
        }

        break;
    };
    ASSERT_TRUE(true);
}

TEST_F(TstOgs, Test013_Close)
{
    MessageThread::instance().close();
    while (true) {
        if (!MessageThread::instance().isConnected()) break;
    }
    ASSERT_FALSE(MessageThread::instance().isConnected());
}

#endif // TSTOGS_H
