///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "TstOrderManager.h"
#include <stdio.h>

TstOrderManager::TstOrderManager()
{

}

void TstOrderManager::SetUp()
{
    setDatabase("./test_db");
}

void TstOrderManager::TearDown()
{
    system("rm -rf ./test_db");
}

TstOrderManager::~TstOrderManager()
{

}
