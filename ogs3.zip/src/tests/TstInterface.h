///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-14
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef TSTINTERFACE_H
#define TSTINTERFACE_H

#include <gtest/gtest.h>

/*
class TstInterface : public testing::Test
{
public:
    TstInterface();
    virtual void SetUp() override;
    virtual void TearDown() override;
    virtual ~TstInterface();
};

TEST_F(TstInterface, TestInterface)
{
    ASSERT_TRUE(true);
}
*/

#endif
