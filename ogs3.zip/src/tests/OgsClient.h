///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef OGSCLIENT_H
#define OGSCLIENT_H

#include <qtp_client.h>
#include <qtp_message.h>
#include <list>
#include <mutex>
#include "../OgsMessage.h"

class OgsClient : public qtp::QtpClient
{
public:
    OgsClient();
    ~OgsClient();

    bool connectHost(const std::string& server,int port);

    int msgCount() const;
    bool takeNextMsg(OgsMessage& message);

    virtual void OnConnected();
    virtual void OnDisconnected();

    virtual void OnMessage(qtp::QtpMessagePtr message, bufferevent* bev);

    void sendMessage(int msg_type,void* msg_content,int size);
    void recvMessage(int msg_type,qtp::QtpMessagePtr message);

private:
    bool mIsConnected = false;

    mutable std::mutex mDataMutex;
    std::list<OgsMessage> mMsgList;
};

#endif
