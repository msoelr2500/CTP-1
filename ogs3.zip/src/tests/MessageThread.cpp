///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-12
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "MessageThread.h"
#include "../StringHelper.h"
#include <iostream>

MessageThread* MessageThread::mInstance = nullptr;

MessageThread::MessageThread()
{
    mQtpManager = new qtp::QtpManager();
    mQtpManager->Init();
    mClient = new OgsClient();
    mQtpManager->AddMember(mClient);
    mThread = std::thread(&MessageThread::exec, this);
}

MessageThread::~MessageThread() {}

MessageThread &MessageThread::instance()
{
    if (!mInstance) mInstance = new MessageThread();
    return *mInstance;
}

bool MessageThread::connect(const std::string &ip, int port)
{
    // std::string message;
    // StringHelper::string_format(message, "connecting to %s:%d...", ip.c_str(), port);
    // std::cout << message << std::endl;
    return mClient->connectHost(ip, port);
}

bool MessageThread::isConnected() const
{
    return mClient->IsConnected();
}

int MessageThread::close()
{
    return mClient->Close();
}

void MessageThread::sendMessage(int msg_type, void *send_content, int size)
{
    // std::cout << "Send a message to server." << std::endl;
    mClient->sendMessage(msg_type, send_content, size);
}

int MessageThread::msgCount() const
{
    return mClient->msgCount();
}

bool MessageThread::takeNextMsg(OgsMessage &message)
{
    return mClient->takeNextMsg(message);
}

void MessageThread::run()
{
    mThread.detach();
}

void MessageThread::exec()
{
    mQtpManager->Start();
}

void MessageThread::shutdown()
{
    mQtpManager->Stop();
}
