/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-12-30
/////////////////////////////////////////////////////////////////////////////

#ifndef OGSGLOBAL_H
#define OGSGLOBAL_H

#include <qtp_version.h>

#define OGS_VERSION_MAJOR 3
#define OGS_VERSION_MINOR 3
#define OGS_VERSION_PATCH 0
#define OGS_VERSION_STR "3.3.0"

namespace ogs {
    DECLARE_VERSION(ogs, 3, 3, 0)
}

#define OGS_VERSION OGS_VERSION_CHECK(OGS_VERSION_MAJOR, OGS_VERSION_MINOR, OGS_VERSION_PATCH)

#define OGS_VERSION_CHECK(major, minor, patch) (major * 100 + minor) * 10000 + patch

#include "BasicType.h"

#define OGS_DISABLE_COPY(Class) \
    Class(const Class &) = delete;\
    Class &operator=(const Class &) = delete;

#define OGS_UNUSED(x) (void)x;

#endif // OGSGLOBAL_H
