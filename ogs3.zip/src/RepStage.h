//
// Created by lwk on 16-5-9.
//

#ifndef OGS_REPSTAGE_H
#define OGS_REPSTAGE_H

#include <map>

#include "qtp_session.h"
#include "qtp_log.h"
#include "qtp_stage.h"
#include "qtp_message.h"
#include "ogs_dict.h"
#include "OgsApi.h"
#include "DataStruct.h"
#include "ReadConfig.h"

namespace ogs {
typedef struct ClientInfo {
    qtp::session_id_t session_id;
    OGS_SYSTIME lastTime;
} *PClientInfo;

class Factory;

/*!
 * \brief OGS向其客户端的回复线程。客户端向OgsServer线程发送输入，从RepStage线程接收输出。
 */
class RepStage : public qtp::QtpStage {
public:
    RepStage(Factory *faPtr);
    ~RepStage();

    int OnEvent(qtp::QtpMessagePtr message);

private:
    std::map<std::string, ClientInfo> m_mapSessionID;
    Factory* m_factoryPtr;
    OGS_SYSDATE m_sysDate;
};
}

#endif //OGS_REPSTAGE_H
