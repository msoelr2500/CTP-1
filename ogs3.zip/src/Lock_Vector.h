#ifndef LOCK_VECTOR_H
#define LOCK_VECTOR_H

#include <vector>
#include <mutex>
#include <condition_variable>
#include <memory>

template <typename T>
class LockVector {
private:
	/***********/
	mutable std::mutex mut;
	std::vector<T> data_vector;
	std::condition_variable data_cond;
public:
	LockVector() {
	}

	void push_back(const T& new_value) {
		std::lock_guard<std::mutex> lk(mut);
		data_vector.push_back(new_value);
		data_cond.notify_one();
	}

	T WaitAndPop() {
		std::unique_lock<std::mutex> lk(mut);
		data_cond.wait(lk, [this] { return !data_vector.empty(); });
		T res = data_vector.front();
		data_vector.erase(0);
		return res;
	}

	T TryPop() {
		std::lock_guard<std::mutex> lk(mut);
		if (data_vector.empty())
			return nullptr;
		T res = data_vector.front();
		data_vector.erase(0);
		return res;
	}

	bool IsEmpty() const {
		std::lock_guard<std::mutex> lk(mut);
		return data_vector.empty();
	}
	/***********/
	T operator[](size_t i){
		std::lock_guard<std::mutex> lk(mut);
		return data_vector[i];
	}

	size_t size(){
		std::lock_guard<std::mutex> lk(mut);
		return data_vector.size();
	}

	void erase(size_t pos){
		std::lock_guard<std::mutex> lk(mut);
		if(pos<data_vector.size())
			data_vector.erase(data_vector.begin()+pos);
	}

	T back()
	{
		std::lock_guard<std::mutex> lk(mut);
		return data_vector.back();
	}


};




#endif