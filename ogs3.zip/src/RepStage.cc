//
// Created by lwk on 16-5-9.
//

#include "RepStage.h"
#include "OgsForwarder.h"
#include "ReadConfig.h"
#include "Factory.h"
#include "OgsLogger.h"
#include "qtp_message.h"

namespace ogs {

RepStage::RepStage(Factory *faPtr) {
    m_factoryPtr = faPtr;
    m_sysDate = GetDateYMD();
}

RepStage::~RepStage() {

}

int RepStage::OnEvent(qtp::QtpMessagePtr message) {
    VLOG(200) << "[RepStage] OnEvent";

    uint32_t error_code = 0;
    void *msgPtr = nullptr;
    char error_msg[256];
    uint16_t msgLength;
    if (GetErrorCodeAndMsg(message, &error_code, &msgPtr, &msgLength) != -1) {
        memcpy(error_msg, msgPtr, msgLength);
        error_msg[msgLength] = 0;
        LOG(info) << "[RepStage] error_code:" << error_code << ",error_msg:" << error_msg;
    }

    qtp::session_id_t client_session = 0;
    OGS_SYSTIME recvTime;

    int maxBacidLen = BACIDSIZE;
    void * bacid = nullptr;
    message->GetTag(kTagBacid, (const void **)&bacid, (qtp::QtpMessage::option_size_t *)&maxBacidLen);

    std::string bacidStr;
    if (bacid) bacidStr = std::string((char *)bacid);

    message->GetTagAsInteger(kTagTime, &recvTime);

    switch (message->MsgType()) {
        case kMtLoginAns:
        case kMtSendOrderAns:
        case kMtCancelOrderAns:
        case kMtQueryBargainAns:
        case kMtQueryFundInfoAns:
        case kMtQueryPositionAns:
        case kMtHeartBeatAns:
        case kMtQueryOrderSeAns:
        case kMtPaybackSecurityAns:
        case kMtPaybackFundsAns:
            if (m_mapSessionID.find(bacidStr) != m_mapSessionID.end()) {
                if (recvTime > m_mapSessionID[bacidStr].lastTime) {
                    m_mapSessionID[bacidStr].lastTime = recvTime;
                    message->GetTagAsInteger(kTagSession, &client_session);
                    if (client_session != m_mapSessionID[bacidStr].session_id) {
                        m_mapSessionID[bacidStr].session_id = client_session;
                    }
                }
                else {
                    client_session = m_mapSessionID[bacidStr].session_id;
                }
            }
            else {
                message->GetTagAsInteger(kTagSession, &client_session);
                if (bacidStr != "") {
                    ClientInfo clientInfo{client_session, recvTime};
                    m_mapSessionID[bacidStr] = clientInfo;
                }
            }
            break;
        case kMtQueryOrderAns:
            if (m_mapSessionID.find(bacidStr) != m_mapSessionID.end()) {
                client_session = m_mapSessionID[bacidStr].session_id;
            }
            else {
                LOG(error) << "[RepStage] bacid is disconnect: " << bacid;
                return 0;
            }
            break;
        case kMtHoldSessionTimer: {
            OGS_SYSDATE nowDate = GetDateYMD();
            if (nowDate != m_sysDate) {
                std::map<std::string, ClientInfo>::iterator iterator;
                OGS_SYSTIME nowTime = GetTimeHMS();
                for (iterator = m_mapSessionID.begin(); iterator != m_mapSessionID.end(); iterator++) {
                    iterator->second.lastTime = nowTime;
                }
                m_sysDate = nowDate;
            }
            return 0;
        }
        case kMtRemoveSession: {
            qtp::session_id_t session_id;
            memcpy(&session_id, message->GetData(), sizeof(qtp::session_id_t));
            std::map<std::string, ClientInfo>::iterator iterator;
            for (iterator = m_mapSessionID.begin(); iterator != m_mapSessionID.end(); iterator++) {
                if (iterator->second.session_id == session_id) {
                    m_mapSessionID.erase(iterator);
                    break;
                }
            }
            return 0;
        }
        default:
            LOG(warn) << "[RepStage] [OnEvent] unknow MsgType.";
            message->GetTagAsInteger(kTagSession, &client_session);
            break;
    }

    LOG(info) << "[RepStage] reply client session: " << client_session << ", type:" << OgsLogger::msgType(message->MsgType());
    int result =  OgsForwarder::ReplyClient(client_session, message);
    return 0;
}

}
