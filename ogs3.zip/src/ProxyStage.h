//
// Created by lwk on 16-6-1.
//

#ifndef OGS_PROXYSTAGE_H
#define OGS_PROXYSTAGE_H

#include "qtp_stage.h"

namespace ogs {

    class Module;

    class ProxyStage : public qtp::QtpStage {
    public:
        ProxyStage(Module *modulePtr);

        ~ProxyStage();

        int OnEvent(qtp::QtpMessagePtr message);

    private:
        Module *m_ModulePtr;
    };
}

#endif //OGS_PROXYSTAGE_H
