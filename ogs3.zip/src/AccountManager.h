#ifndef ACCOUNTMANAGER_H
#define ACCOUNTMANAGER_H

#include <string>
#include <vector>
#include <mutex>
#include "universal_code.h"
#include "StringHelper.h"
#include <iostream>

/*!
 * \brief 交易账户。一般情况下，每个客户在一种金融市场中只有一个交易账户。
 */
class TradeAccount {
public:
    bool enabled = false;
    std::string stock_account;
};

/*!
 * \brief 交易市场类型。
 */
enum Exchange{
    SSE = 0,        //!< 上海A股
    SZE,            //!< 深圳A股
    CFFE,           //!< 中国金融期货交易所
    SH_HK,          //!< 沪港通
    SH_B,           //!< 上海B股
    SZ_B,           //!< 深圳B股
    TZ_A,           //!< 特转A，特转账户指的是三板市场开立的账户，特转A为RMB账户
    TZ_B,           //!< 特转B，特转账户指的是三板市场开立的账户，特转B为外币账户
    ExchangeCount   //!< 交易市场总数
};

/*!
 * \brief 资金账户。一个用户可能拥有多个资金账户。
 */
template <typename TradeAccountType>
class FundAccount : public std::vector<TradeAccountType>{
public:
    FundAccount() { (*this).resize(ExchangeCount); }

    virtual void invalidate() {
        for(int i = 0; i < ExchangeCount; i++){
            (*this)[i].enabled = false;
        }
    }

    int indexOf(const std::string& tradeAccount) const {
        for (size_t i = 0; i < this->size(); i++) {
            if ((*this)[i].stock_account == tradeAccount)
                return i;
        }
        return -1;
    }

    bool hasTradeAccount(const std::string& tradeAccount) const {
        return indexOf(tradeAccount) >= 0;
    }

    std::string fund_account;
};

/*!
 * \brief 用户数据。
 */
template <typename FundAccountType>
class Client : public std::vector<FundAccountType> {
public:
    std::string client_id;

    int addNewFundAccount(const FundAccountType& account) {
        int fundAccountIndex = indexOf(account.fund_account);
        if (fundAccountIndex < 0) {
            // 出现了新的资金账号。
            this->push_back(account);
            return this->size() - 1;
        }

        (*this)[fundAccountIndex] = account;
        return fundAccountIndex;
    }

    bool hasFundAccount(const std::string& fund_account) const {
        return indexOf(fund_account) >= 0;
    }

    bool hasTradeAccount(const std::string& tradeAccount) const {
        for (size_t i = 0; i < this->size(); i++) {
            if (this->at(i).hasTradeAccount(tradeAccount))
                return true;
        }
        return false;
    }

    void removeFundAccount(const std::string& fundAccount) {
        int index = indexOf(fundAccount);
        if (index >= 0) {
            erase(this->begin() + index);
        }
    }

    int indexOf(const std::string& fund_account) const {
        for (size_t i = 0; i < this->size(); i++) {
            if (this->at(i).fund_account == fund_account) {
                return i;
            }
        }
        return -1;
    }

    int fundAccountIndexByTradeAccount(const std::string& trade_account) const {
        for (size_t i = 0; i < this->size(); i++) {
            if (this->at(i).indexOf(trade_account) >= 0) {
                return i;
            }
        }
        return -1;
    }

    virtual void invalidate() {
        client_id.clear();
        this->clear();
    }

    void printAccounts()
    {
        std::cout << "+[client_id]: " << client_id << std::endl;
        for (size_t fIndex = 0; fIndex < this->size(); fIndex++) {
            std::cout << "----+[fund_account]: " << this->at(fIndex).fund_account << std::endl;
            for (size_t tIndex = 0; tIndex < this->at(fIndex).size(); tIndex++) {
                if (this->at(fIndex).at(tIndex).enabled) {
                    std::cout << "---------+[trade_account]: " << this->at(fIndex).at(tIndex).stock_account << std::endl;
                }
            }
        }
    }
};

class AccountHelper
{
public:
    static Exchange toExchange(qtp::MarketCode market){
        switch (market) {
        case qtp::MarketCode::kMC_SSE: return Exchange::SSE;
        case qtp::MarketCode::kMC_SZE: return Exchange::SZE;
        case qtp::MarketCode::kMC_CFFE: return Exchange::CFFE;
        default:
            return Exchange::ExchangeCount;
        }
    }

    static inline bool isExchangeValid(Exchange exchange) {
        return (exchange != Exchange::ExchangeCount);
    }
};

template <typename ClientType>
class ClientManager : public std::vector<ClientType>
{
public:
    explicit ClientManager() {}
    virtual ~ClientManager() {}

    #define lock_data(ClientManagerPtr) std::lock_guard<std::mutex> ogsLock((ClientManagerPtr)->mutex())

    std::string stockAccount(const std::string& fund_account, qtp::MarketCode market) const
    {
        lock_data(this);
        Exchange exchange = AccountHelper::toExchange(market);
        if (!AccountHelper::isExchangeValid(exchange)) {
            return std::string("");
        }

        int clientId = this->findClientByFundAccount(fund_account);
        if (clientId >= 0) {
            return this->at(clientId).
                         at(this->at(clientId).indexOf(fund_account)).
                         at(exchange).stock_account;
        }
        return std::string("");
    }

    void addNewClient(const ClientType& client)
    {
        lock_data(this);
        int index = findClientById(client.client_id);
        if (index < 0) {
            this->push_back(client);
        } else {
            // 删除查询之前存在的客户账号信息。
            invalidateClient(index);
            (*this)[index] = client;
        }
    }

    void removeClient(const std::string& clientId)
    {
        lock_data(this);
        int index = findClientById(clientId);
        if (index >= 0) {
            this->erase(this->begin() + index);
        }
    }
    void removeClient(int index)
    {
        lock_data(this);
        if (index >= 0 && index < this->size()) {
            this->erase(this->begin() + index);
        }
    }

    bool hasClients(const std::string& clientId) const
    {
        lock_data(this);
        return findClientById(clientId) >= 0;
    }
    bool hasFundAccount(const std::string& fundAccount) const
    {
        lock_data(this);
        return findClientByFundAccount(fundAccount) >= 0;
    }
    bool hasTradeAccount(const std::string& tradeAccount) const
    {
        lock_data(this);
        return findClientByTradeAccount(tradeAccount) >= 0;
    }

    void invalidateClientByFundAccount(const std::string& fund_account) {
        lock_data(this);
        int index = this->findClientByFundAccount(fund_account);
        if (index >= 0)
            this->at(index).invalidate();
    }

    void printAccounts()
    {
        lock_data(this);
        for (size_t i = 0; i < this->size(); i++) {
            this->at(i).printAccounts();
        }
    }

protected:
    int findClientById(const std::string& clientId) const
    {
        for (size_t i = 0; i < this->size(); i++) {
            if (this->at(i).client_id == clientId) {
                return i;
            }
        }
        return -1;
    }

    int findClientByFundAccount(const std::string& fundAccount) const
    {
        for (size_t i = 0; i < this->size(); i++) {
            if (this->at(i).hasFundAccount(fundAccount)) {
                return i;
            }
        }
        return -1;
    }

    int findClientByTradeAccount(const std::string& tradeAccount) const
    {
        for (size_t i = 0; i < this->size(); i++) {
            if (this->at(i).hasTradeAccount(tradeAccount)) {
                return i;
            }
        }
        return -1;
    }

    std::mutex& mutex() const { return mDataMutex; }

    void invalidateClient(const std::string& clientId)
    {
        int index = findClientById(clientId);
        if (index >= 0) {
            invalidateClient(index);
        }
    }

    void invalidateClient(int index)
    {
        if (index >=0 && index < this->size()) {
            (*this)[index].invalidate();
        }
    }

private:
    mutable std::mutex mDataMutex;
};

#endif // ACCOUNTMANAGER_H
