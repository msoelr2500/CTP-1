#ifndef OGS_FACTORY_H
#define OGS_FACTORY_H

#include <thread>
#include <memory>
#include <arpa/inet.h>

#include "Lock_Vector.h"
#include "qtp_manager.h"
#include "qtp_queue.h"
#include "qtp_log.h"
#include "qtp_version.h"
#include "OgsServer.h"
#include "RepStage.h"
#include "OrderMgrStage.h"
#include "SysMgrStage.h"
#include "OrderStage.h"
#include "OgsApi.h"
#include "ReadConfig.h"
#include "Module.h"
#include "LoadInterface.h"
#include "OgsVersion.h"

namespace ogs {

	class OgsServer;
	class OrderStage;
	class OrderMgrStage;

	class Factory {
	public:
		Factory();

		~Factory();

		void init(int argc, char *argv[]);

		void runRecvThr();

		void runRepThr();

		void orderMgrModule();

		void sysMgrModule();

		void start();

		void join();

		void taskOrderStageModule();

		void reqOrderStageModule();

		OgsServer* GetOgsServerPtr();

	private:
		qtp::QtpManager m_manager;
		OgsServer* m_ogsServerPtr;
		RepStage* m_repStagePtr;
		OrderMgrStage* m_orderMgrStagePtr;
		SysMgrStage* m_sysMgrStagePtr;
		LockVector<uint32_t> m_vorderStageID;
		LockVector<std::shared_ptr<std::thread>> m_vThread;

		LockVector<std::shared_ptr<Module>> m_vModule;
	};
}
#endif