//
// Created by lwk on 16-5-9.
//

#include "OgsServer.h"
#include "ReadConfig.h"
#include "OgsMessage.h"
#include "OgsForwarder.h"
#include "OgsInterface.h"
#include "OgsLogger.h"
#include "ogs_dict.h"
#include "qtp_log.h"

namespace ogs {

    OgsServer::OgsServer(Factory *faPtr) : QtpServer() {
        factoryPtr = faPtr;
    }

    void OgsServer::OnRead(struct bufferevent *bev) {
        struct evbuffer *input = bufferevent_get_input(bev);
        while (1) {
            size_t len = evbuffer_get_length(input);
            if (len < qtp::QtpMessage::kMsgHeadSize) break;
            qtp::QtpMessage::MsgHead *pmh = (qtp::QtpMessage::MsgHead *) evbuffer_pullup(input,
                                                                                         qtp::QtpMessage::kMsgHeadSize);
            if (pmh->version != qtp::QtpMessage::kCurrentVersion) {//TODO(wen): check the version
                bufferevent_free(bev);
                return;
            }

            if (len < qtp::QtpMessage::kMsgHeadSize + pmh->optslen + pmh->datalen) break;
            qtp::QtpMessagePtr message = std::make_shared<qtp::QtpMessage>();
            size_t buflen = pmh->optslen + pmh->datalen;
            char *buf = message->AllocBuffer(buflen);
            qtp::QtpMessage::MsgHead head;
            evbuffer_remove(input, &head, sizeof(head));
            evbuffer_remove(input, buf, pmh->optslen + pmh->datalen);

            message->Decode(head);
            bufferevent_unlock(bev);
            qtp::session_id_t session_id = qtp::QtpSessionMgr::Instance().GetSessionID(bev);
            bufferevent_lock(bev);

            LOG(info) << "[OgsServer] [OnRead] Got a Message: " << OgsLogger::msgType(head.msgtype) << ",OpsLen:" << head.optslen << ",DataLen:" <<
            head.datalen << " client session:" << session_id; // TRACE LOG

            OGS_SYSTIME recvTime = GetTimeHMS();

            message->AddTag(kTagTime, &recvTime, sizeof(OGS_SYSTIME));
            message->AddTag(kTagSession, &session_id, sizeof(qtp::session_id_t));

#if defined(OGS_LOG_RECEIVED_MESSAGE)
            OgsMessage ogsMsg(message);
            ogsLogger() << ogsMsg;
#endif

            switch (head.msgtype) {
                case kMtSendOrder:
                    if (GetTimeHMS() <= ReadConfig::localOption.TradeStart || GetTimeHMS() >= ReadConfig::localOption.TradeEnd) {
                        LOG(error) << "[OgsServer] [OnRead] it's not trade time, CAN'T send order. now is " << GetTimeHMS(); // ERROR LOG

                        OgsMessage ogsMessage(message);
                        SendOrderQry* array;
                        if (!ogsMessage.parse(&array)) {
                            LOG(error) << "[OgsServer] [OnRead] [kMtSendOrder] " << ogsMessage.error();
                            return;
                        }
                        if (ogsMessage.itemCount() == 0) {
                            LOG(error) << "[OgsServer] [OnRead] [kMtSendOrder] error: ogsMessage.itemCount() == 0";
                            return;
                        }

                        OGS_SYSTIME time = GetTimeHMS();
                        for (uint32_t i = 0; i < ogsMessage.itemCount(); ++i) {
                            qtp::QtpMessagePtr response = std::make_shared<qtp::QtpMessage>();

                            response->BeginEncode(kMtSendOrderAns, kOgsServiceId);

                            response->AddTag(kTagSession, &session_id,     sizeof(qtp::session_id_t));
                            response->AddTag(kTagBacid,   array[i].bacid, strlen(array[i].bacid));
                            response->AddTag(kTagTime,    &time,           sizeof(OGS_SYSTIME));

                            uint32_t item_size_ans = sizeof(SendOrderAns);
                            uint32_t item_cnt_ans  = ogsMessage.itemCount();
                            SetItemSizeAndCnt(response, item_size_ans, item_cnt_ans);

                            std::string error_msg;
                            StringHelper::string_format(error_msg, "[ogs] 当前时间（%d）不在交易时段（%d~%d），下单指令被拒绝。", time,
                                                        ReadConfig::localOption.TradeStart, ReadConfig::localOption.TradeEnd);
                            uint32_t error_code = kIntfFail;
                            SetErrorCodeAndMsg(response, error_code, error_msg.c_str(), error_msg.length());

                            SendOrderAns ans = OgsInterface::createErrorAns(array[i]);

                            response->SetData(&ans, sizeof(SendOrderAns), false);
                            response->Encode();
                            OgsForwarder::SendMessage(kRepStageID, response);
                        }

                        for (uint32_t i = 0; i < ogsMessage.itemCount(); ++i) {
                            OrderItem item;
                            OrderMgrStage::initOrderBySendOrderQry(item.orderInfo, array[i], session_id);
                            item.orderInfo.orderStatus = ogs_dict::kOtBad;
                            StringHelper::string_format(item.mNotifyPrompt, "[ogs] 该订单指令在交易时段（%d~%d）之外发出，被拒绝并归为废单。",
                                                        ReadConfig::localOption.TradeStart, ReadConfig::localOption.TradeEnd);
                            OrderManager::notifyOrderStatusChange(item);
                        }
                        continue;
                    }
                    VLOG(200) << "[OgsServer] [OnRead] send kMtSendOrder message to TaskOrderStage."; // TRACE LOG
                    OgsForwarder::SendMessage(kOrderMgrStageID, message);
                case kMtLogin:
                case kMtCancelOrder:
                case kMtQueryBargain:
                case kMtQueryFundInfo:
                case kMtQueryPosition:
                case kMtQueryOrderSe:
                case kMtPaybackSecurity:
                case kMtPaybackFunds:{
                    VLOG(200) << "[OgsServer] [OnRead] send message to TaskOrderStage."; // TRACE LOG
                    OgsForwarder::SendMessage(kTaskOrderStageProxyID, message);
                    break;
                }
                case kMtQueryOrder:
                    VLOG(200) << "[OgsServer] [OnRead] send kMtQueryOrder message to OrderMgrStage,handle oms QueryOrder."; // TRACE LOG
                    OgsForwarder::SendMessage(kOrderMgrStageID, message);
                    break;
                case kMtHeartBeat:
                    VLOG(200) << "[OgsServer] [OnRead] send kMtHeartBeat message to SysMgrStage,handle oms HeartBeat."; // TRACE LOG
                    OgsForwarder::SendMessage(kSysMgrStageID, message); //handle oms heartbeat request
                    break;
            }
            //usleep(1);
        } //while (1)
    }

    void OgsServer::OnAccept(struct bufferevent *bev, evutil_socket_t fd, struct sockaddr *sa, int socklen) {
        qtp::session_id_t session_id_ = qtp::QtpSessionMgr::Instance().AddSession(bev);
        LOG(info) << "[OgsServer] [OnAccept] new client session:" << session_id_; // TRACE LOG
        m_vSessionID.push_back(session_id_);
    }

    void OgsServer::OnClose(struct bufferevent *bev) {
        //bufferevent_unlock(bev);    no need in qtp_framework_V0.0.11
        qtp::session_id_t session_id_ = qtp::QtpSessionMgr::Instance().GetSessionID(bev);
        LOG(info) << "[OgsServer] [OnClose] close a session:" << session_id_; // TRACE LOG
        VLOG(200) << "client(" << session_id_ << ") is disconnected.";
        qtp::QtpSessionMgr::Instance().RemoveSession(bev);
        for (size_t i = 0; i < m_vSessionID.size(); i++) {
            if (m_vSessionID[i] == session_id_) {
                m_vSessionID.erase(i);
                //Close(bev);
                break;
            }
        }
        auto response = std::make_shared<qtp::QtpMessage>();
        response->BeginEncode(kMtRemoveSession, kOgsServiceId);
        response->SetData(&session_id_, sizeof(qtp::session_id_t), false);
        response->Encode();
        OgsForwarder::SendMessage(kRepStageID, response);
    }

    void OgsServer::OnEvent(struct bufferevent *bev, short events) {
        qtp::QtpServer::OnEvent(bev, events);
    }

    void OgsServer::OnTimeout(qtp::QtpTimeout *timeout) {
        if (timeout->id() == kOrderMgrTimerId) {
            VLOG(200) << "[OgsServer] [OnTimeout] OrderMgrTimer timeout! notify OrderMgrStage."; // TRACE LOG
            OgsForwarder::SendMessage(kOrderMgrStageID, OgsMessage::buildTimeoutMsg(kMtOrderMgrTimer, 0));
        }
        else if (timeout->id() == kHeartBeatTimerId) {
            VLOG(200) << "[OgsServer] [OnTimeout] HeartBeatTimer timeout! notify TaskOrderStage and ReqOrderStage."; // TRACE LOG
            auto message = OgsMessage::buildTimeoutMsg(kMtHeartBeatTimer, kOgsServiceId);
            OgsForwarder::SendMessage(kTaskOrderStageProxyID, message);
            OgsForwarder::SendMessage(kReqOrderStageProxyID, message);
        }
        else if (timeout->id() == kHoldSessionTimerId) {
            VLOG(200) << "[OgsServer] [OnTimeout] HoldSessionTimer timeout! notify RepStage."; // TRACE LOG
            OgsForwarder::SendMessage(kRepStageID, OgsMessage::buildTimeoutMsg(kMtHoldSessionTimer, kOgsServiceId));
        }
        else {
            LOG(error) << "[OgsServer] [OnTimeout] unknow timer timeout, ignore."; // TRACE LOG
        }
    }
}
