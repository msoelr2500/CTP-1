///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-10-25
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef OGSINTERFACE_H
#define OGSINTERFACE_H

#include <list>
#include <string>
#include <functional>

#include "OgsGlobal.h"
#include "Interface.h"
#include "BufferHandle.h"

namespace ogs {

class OgsInterface : public Interface
{
public:

    ///--------------------------------------------------------------------------------------------------------
    /// 未更改的接口
    ///--------------------------------------------------------------------------------------------------------

    virtual bool getConnectStatus() = 0;

    virtual Intf_RetType initCommon() = 0;

    virtual Intf_RetType initSubscribe() = 0;

    virtual Intf_RetType connectBroker() = 0;

    virtual Intf_RetType reConnectBroker() = 0;

    virtual Intf_RetType heartBeatToBroker() = 0;

    // DO NOT USE THIS FUNCTION !!! USE OrderStage::CallBack INSTEAD.
    virtual void setCallBack(int (*fn)(QueryOrderAns)) = 0;

    ///--------------------------------------------------------------------------------------------------------
    /// 原有的基本接口
    ///--------------------------------------------------------------------------------------------------------

    virtual Intf_RetType setSubscribe(std::vector<std::string>& vSubParams) override final;

    virtual Intf_RetType login(const std::string& qryBuf, std::string& ansBuf, std::string& errMsg, std::vector<std::string> &vSubParams, std::map<int, std::string>& args) override final;
    virtual Intf_RetType sendOrder(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType cancelOrder(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType queryOrder(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType queryBargain(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType queryFundInfo(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType queryPosition(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType paybackSecurity(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;
    virtual Intf_RetType paybackFunds(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args) override final;

    ///--------------------------------------------------------------------------------------------------------
    /// 新业务操作接口
    ///--------------------------------------------------------------------------------------------------------

    virtual Intf_RetType ogsLogin(const LoginQry& in, std::list<LoginAns>& out, std::string& errMsgs, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsSendOrder(const SendOrderQry& in, std::list<SendOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsCancelOrder(const CancelOrderQry& in, std::list<CancelOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsQueryOrder(const QueryOrderQry& in, std::list<QueryOrderAns>& out, std::string &errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsQueryPosition(const QueryPositionQry& in, std::list<QueryPositionAns>& out, std::string& errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsQueryBargain(const QueryBargainQry& in, std::list<QueryBargainAns>& out, std::string& errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsQueryFundInfo(const QueryFundInfoQry& in, std::list<QueryFundInfoAns>& out, std::string& errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsPaybackSecurity(const PaybackSecurityQry &in, std::list<PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args) = 0;
    virtual Intf_RetType ogsPaybackFunds(const PaybackFundsQry &in, std::list<PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args) = 0;

    virtual bool isFundAccountEnabled(const OGS_BACID *bacid);

    static LoginAns createErrorAns(const LoginQry& in);
    static SendOrderAns createErrorAns(const SendOrderQry& in);
    static CancelOrderAns createErrorAns(const CancelOrderQry& in);
    static QueryOrderAns createErrorAns(const QueryOrderQry& in);
    static QueryPositionAns createErrorAns(const QueryPositionQry& in);
    static QueryBargainAns createErrorAns(const QueryBargainQry& in);
    static QueryFundInfoAns createErrorAns(const QueryFundInfoQry& in);
    static PaybackSecurityAns createErrorAns(const PaybackSecurityQry& in);
    static PaybackFundsAns createErrorAns(const PaybackFundsQry& in);
    static HeartBeatAns createErrorAns(const HeartBeatQry& in);

private:

    ///--------------------------------------------------------------------------------------------------------
    /// 基本操作模式
    ///--------------------------------------------------------------------------------------------------------

    template <typename TypeIn, typename TypeOut>
    Intf_RetType operation(const std::string &qryBuf, std::string &ansBuf, std::string &errMsg, std::map<int, std::string>& args,
                           const std::function<Intf_RetType (const TypeIn&, std::list<TypeOut>&, std::string&, std::map<int, std::string>&)> func)
    {
        UnpackBuffer<TypeIn> queryBuffer(&qryBuf);
        queryBuffer.First();
        PackBuffer<TypeOut> answerBuffer(&ansBuf);

        // 对多个登陆请求依次处理
        int queryDataCount = queryBuffer.GetDataCount();
        std::vector<Intf_RetType> results;
        std::vector<std::string> errMsgs;
        results.resize(queryDataCount);
        errMsgs.resize(queryDataCount);

        for (int i = 0; i < queryDataCount; ++i) {
            // 检查合法性。
            if (!isFundAccountEnabled(queryBuffer.GetDataObjPtr()->bacid)) {
                errMsgs[i] = "指定的资金账户不可用。";
                results[i] = kIntfWorkFail;
                continue;
            }

            // 调用接口。
            std::list<TypeOut> out;
            results[i] = func(*queryBuffer.GetDataObjPtr(), out, errMsgs[i], args);
            if (results[i] != kIntfSuccess) {
                std::cerr << errMsgs[i] << std::endl;
                // 如果出错并且没有返回，填充默认数据。
                if (out.size() == 0) {
                    out.push_back(createErrorAns(*queryBuffer.GetDataObjPtr()));
                }
            }

            // 装入返回数据。
            for (const TypeOut& item : out) {
                answerBuffer.AddNewObj(&item);
            }

            queryBuffer.Next();
        }

        if (queryDataCount == 0) {
            errMsg.assign("未输入任何请求数据。");
            return kIntfWorkFail;
        }
        errMsg = errMsgs[errMsgs.size() - 1];
        return results[results.size() - 1];
    }
};

} // namespace ogs

#endif // OGSINTERFACE_H
