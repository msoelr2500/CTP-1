//
// Created by lwk on 16-5-13.
//

#ifndef OGS_OGSAPI_H
#define OGS_OGSAPI_H

#include <time.h>
#include <sstream>
#include "DataStruct.h"
#include "qtp_message.h"
#include "universal_code.h"
#include "Interface.h"

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>
#include <linux/hdreg.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>

namespace ogs {

    static const uint16_t kOgsServiceId = 122;

    static const uint32_t kRepStageID = 8880;
    static const uint32_t kOrderMgrStageID = kRepStageID + 1;
    static const uint32_t kSysMgrStageID = kRepStageID + 2;

    static const int kOrderMgrTimerId = 8000;
    static const int kHeartBeatTimerId = kOrderMgrTimerId + 1;
    static const int kHoldSessionTimerId = kOrderMgrTimerId + 2;

    static const uint32_t kMtOrderMgrTimer = 8100;   //message type
    static const uint32_t kMtHeartBeatTimer = kMtOrderMgrTimer + 1;
    static const uint32_t kMtHoldSessionTimer = kMtOrderMgrTimer + 2;
    static const uint32_t kMtRemoveSession = kMtOrderMgrTimer + 3;

    static const uint32_t kReqOrderStageProxyID = 8200;
    static const uint32_t kTaskOrderStageProxyID = kReqOrderStageProxyID + 200; //reqorderstage maximum count is 200

    enum OgsTagId {
        kTagSession = 1,
        kTagBacid = 2,
        kTagTime = 3,
        kTagSysOrderIdIsEmpty = 4,
        kTagIsCallback = 5,
    };

    enum OgsMsgOption {
        kMoItemSize = 1000,
        kMoItemCnt = 1001,
        kMoErrorCode = 1002,
        kMoErrorMsg = 1003
    };

    inline static int SetItemSizeAndCnt(qtp::QtpMessagePtr message, const uint32_t &item_size, const uint32_t &item_cnt) {
        message->AddOption(kMoItemSize, &item_size, sizeof(item_size));
        message->AddOption(kMoItemCnt, &item_cnt, sizeof(item_cnt));
        return 0;
    }

    inline static int GetItemSizeAndCnt(qtp::QtpMessagePtr message, uint32_t *item_size, uint32_t *item_cnt) {
        if (item_size && message->GetOptionAsInteger(kMoItemSize, item_size) != 0) return -1;
        if (item_cnt && message->GetOptionAsInteger(kMoItemCnt, item_cnt) != 0) return -1;
        return 0;
    }

    inline static int SetErrorCodeAndMsg(qtp::QtpMessagePtr message, const uint32_t &error_code, const char* error_msg, uint32_t msgLength) {
        // 默认成功信息为“.”
        static std::string defSuccess = ".";
        static std::string defFailed = "业务操作失败";

        message->AddOption(kMoErrorCode, &error_code, sizeof(error_code));
        if (msgLength == 0 || !error_msg) {
            if (error_code == kIntfSuccess) {
                message->AddOption(kMoErrorMsg, defSuccess.c_str(), defSuccess.length());
            } else {
                message->AddOption(kMoErrorMsg, defFailed.c_str(), defFailed.length());
            }
        } else {
            message->AddOption(kMoErrorMsg, error_msg, msgLength);
        }
        return 0;
    }

    inline static int GetErrorCodeAndMsg(qtp::QtpMessagePtr message, uint32_t *error_code, void **msgBuffer,
                                     qtp::QtpMessage::option_size_t* msgLength) {
        if (error_code && message->GetOptionAsInteger(kMoErrorCode, error_code) != 0) return -1;
        if (msgBuffer && msgLength && message->GetOption(kMoErrorMsg, (const void **)msgBuffer, msgLength) != 0) return -1;
        return 0;
    }


    inline static int GetDateYMD() {
        time_t t = time(NULL);
        struct tm *current_time = localtime(&t);
        return (current_time->tm_year + 1900) * 10000 + (current_time->tm_mon + 1) * 100 + current_time->tm_mday;
    }

    inline static int GetTimeHMS() {
        time_t t = time(NULL);
        struct tm *current_time = localtime(&t);
        return current_time->tm_hour * 10000 + current_time->tm_min * 100 + current_time->tm_sec;
    }

    // 去掉字符串所有空格
    inline static void Trim(std::string &s)
    {
        int index = 0;
        if( !s.empty())
        {
            while((index = s.find(' ',index)) != std::string::npos)
            {
                s.erase(index,1);
            }
        }
    }

    // 分割字符串，列如讲"2,5,7" 返回2 5 7
    inline static std::vector<std::string> Split(const std::string& s, const std::string& delim)
    {
        std::vector<std::string> elems;
        size_t pos = 0;
        size_t len = s.length();
        size_t delim_len = delim.length();
        if (delim_len == 0) return elems;
        while (pos < len)
        {
            int find_pos = s.find(delim, pos);
            if (find_pos < 0)
            {
                elems.push_back(s.substr(pos, len - pos));
                break;
            }
            elems.push_back(s.substr(pos, find_pos - pos));
            pos = find_pos + delim_len;
        }
        return elems;
    }

    // 获取当前日期，返回如19891230这样的
    std::string GetCurrDay();

    int TimeDiff(uint32_t begin, uint32_t end);

    template<typename T>
    inline static std::string AllTOStr(T src) {
        std::stringstream ss;
        ss << src;
        std::string dest;
        ss >> dest;
        return (dest == "0" ? "" : dest);
    }

    bool isOrderFinished(ogs::OGS_ORDERSTATUS orderStatus);

    /*!
     * \brief 获取本机磁盘序列号。
     * \param output 用于获取查到的磁盘序列号。
     * \return 如果查询成功，返回true；出现错误则返回false。
     */
    bool HardDriveSerialNo(std::string& output);

    /*!
     * \brief 获取硬件地址（MAC）。
     * \param output 用于获取查到的硬件地址。
     * \return 如果查询成功，返回true；出现错误则返回false。
     */
    bool HardwareAddress(std::string& output);

    bool IpAddress(std::string& ip, std::string& netmask, std::string& subnetIp);

    std::string SiteInfo(const std::string& format, std::map<int, std::string>& args);

    void ParseOmsSiteInfo(const std::string& option, std::map<int, std::string>& args);

    ogs::OGS_ORDERSTATUS determinOrderStatus(ogs::OGS_VOLUME volume,
                                             ogs::OGS_DEALVOLUME dealVolume,
                                             ogs::OGS_WITHDRAWVOLUME withdrawVolume);

    void parseInnerCode(OGS_INNERCODE innerCode,
                        std::string& code,
                        qtp::MarketCode& market,
                        qtp::SecurityCategory& sc);

}

#endif //OGS_OGSAPI_H
