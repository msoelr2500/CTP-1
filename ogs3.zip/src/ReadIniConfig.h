//
// Created by lwk on 16-5-17.
//

#ifndef OGS_READINICONFIG_H
#define OGS_READINICONFIG_H

namespace ogs {

//read ini file
    int read_ini_config_string(const char *section, const char *key, char *value, int size, const char *default_value,
                               const char *file);

//read ini file
    int read_ini_config_int(const char *section, const char *key, int default_value, const char *file);

//write ini file
    int write_ini_config_string(const char *section, const char *key, const char *value, const char *file);

    int write_ini_config_int(const char *section, const char *key, int iValue, const char *file);

}
#endif //OGS_READINICONFIG_H
