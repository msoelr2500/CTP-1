///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-04
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "OgsApi.h"
#include "ogs_dict.h"
#include "StringHelper.h"
#include <iostream>
#include <cstdarg>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

namespace ogs {

bool isOrderFinished(OGS_ORDERSTATUS orderStatus) {
    return (orderStatus == ogs_dict::kOtMatchedCanceled)  ||
           (orderStatus == ogs_dict::kOtCanceled)         ||
           (orderStatus == ogs_dict::kOtMatchedAll)       ||
           (orderStatus == ogs_dict::kOtBad);
}

bool HardDriveSerialNo(std::string &output)
{
    int fd;
    struct hd_driveid hid;
    fd = open("/dev/sda", O_RDONLY);

    if (fd < 0) return false;
    if (ioctl(fd, HDIO_GET_IDENTITY, &hid) < 0) return false;

    close(fd);
    output = (char*)hid.serial_no;
    return true;
}

bool HardwareAddress(std::string &output)
{
    struct ifreq ifReq;
    strcpy(ifReq.ifr_name, "eth0");

    int fd;
    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) return false;
    if (ioctl(fd, SIOCGIFHWADDR, &ifReq) < 0) {
        close(fd);
        return false;
    }

    StringHelper::string_format(output, "%X%X%X%X%X%X", (unsigned char) ifReq.ifr_hwaddr.sa_data[0],
            (unsigned char) ifReq.ifr_hwaddr.sa_data[1],
            (unsigned char) ifReq.ifr_hwaddr.sa_data[2],
            (unsigned char) ifReq.ifr_hwaddr.sa_data[3],
            (unsigned char) ifReq.ifr_hwaddr.sa_data[4],
            (unsigned char) ifReq.ifr_hwaddr.sa_data[5]);

    close(fd);
    return true;
}

bool IpAddress(std::string &ip, std::string &netmask, std::string& subnetIp)
{
    int fd;
    char ipaddr[50];

    struct ifreq          ifr_ip;
    struct in_addr        in_ip;
    struct in_addr        in_mask;
    struct in_addr        in_subnet;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) return false;

    memset(&ifr_ip, 0, sizeof(ifr_ip));
    strncpy(ifr_ip.ifr_name, "eth0", sizeof(ifr_ip.ifr_name) - 1);

    if(ioctl( fd, SIOCGIFADDR, &ifr_ip) < 0) return false;

    in_ip = ((struct sockaddr_in *)&ifr_ip.ifr_addr)->sin_addr;
    strcpy(ipaddr, inet_ntoa(in_ip));
    ip = ipaddr;

    if(ioctl( fd, SIOCGIFNETMASK, &ifr_ip) < 0) return false;

    in_mask = ((struct sockaddr_in *)&ifr_ip.ifr_netmask)->sin_addr;
    strcpy(ipaddr, inet_ntoa(in_mask));
    netmask = ipaddr;

    in_subnet.s_addr = in_mask.s_addr & in_ip.s_addr;
    strcpy(ipaddr, inet_ntoa(in_subnet));
    subnetIp = ipaddr;

    close(fd);

    return true;
}

int TimeDiff(uint32_t begin, uint32_t end) {
    return (end   / 10000 * 3600 + (end   % 10000) / 100 * 60 + end   % 100) -
            (begin / 10000 * 3600 + (begin % 10000) / 100 * 60 + begin % 100);
}

std::string GetCurrDay()
{
    time_t timep;
    struct tm *p;
    time(&timep); /*获得time_t结构的时间，UTC时间*/
    p = localtime(&timep); /*转换为struct tm结构的当地时间*/
    char day[9] = { 0 };
    if (p->tm_mon < 9)
    {
        if (p->tm_mday < 10)
        {
            sprintf(day, "%4d0%1d0%1d", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday);
        }
        else
        {
            sprintf(day, "%4d0%1d%2d", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday);
        }
    }
    else
    {
        if (p->tm_mday < 10)
        {
            sprintf(day, "%4d%2d0%1d", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday);
        }
        else
        {
            sprintf(day, "%4d%2d%2d", 1900 + p->tm_year, 1 + p->tm_mon, p->tm_mday);
        }
    }
    return day;
}


OGS_ORDERSTATUS determinOrderStatus(OGS_VOLUME volume, OGS_DEALVOLUME dealVolume, OGS_WITHDRAWVOLUME withdrawVolume)
{
    if (withdrawVolume == 0) {
        if (dealVolume == 0) {
            return ogs_dict::kOtReported;
        } else {
            if (dealVolume < volume) {
                return ogs_dict::kOtPartMatched;
            } else {
                return ogs_dict::kOtMatchedAll;
            }
        }
    } else {
        if (dealVolume == 0) {
            if (withdrawVolume < volume) {
                return ogs_dict::kOtCanceling;
            } else {
                return ogs_dict::kOtCanceled;
            }
        } else {
            if (dealVolume < volume - withdrawVolume) {
                return ogs_dict::kOtMatchedCanceling;
            } else {
                return ogs_dict::kOtMatchedCanceled;
            }
        }
    }

    return ogs_dict::kOtBad;
}

std::string SiteInfo(const std::string &format, std::map<int, std::string> &args)
{
    std::string client_ip = args[1];
    std::string mac       = args[2];
    std::string disksn    = args[3];
    std::string cpuid     = args[4];
    std::string wip       = args[5];

    int totalSize = 0;
    for (int i = 0; i < format.size(); ++i) {
        if ((format[i] != '%') || (i == format.size() - 1)) {
            ++totalSize;
            continue;
        } else {
            switch (format[i+1]) {
            case '1': totalSize += client_ip.size(); ++i; break;
            case '2': totalSize += mac.size();       ++i; break;
            case '3': totalSize += disksn.size();    ++i; break;
            case '4': totalSize += cpuid.size();     ++i; break;
            case '5': totalSize += wip.size();       ++i; break;
            case '%': totalSize += 1;                ++i; break;
            default:  totalSize += 1; break;
            }
        }
    }

    std::string result(totalSize, '\0');

    int target_index = 0;
    for (int i = 0; i < format.size(); ++i) {
        if ((format[i] != '%') || (i == format.size() - 1)) {
            result[target_index++] = format[i];
        } else {
            switch (format[i+1]) {
            case '1':
                memcpy((void*)(result.c_str() + target_index), client_ip.c_str(), client_ip.length());
                target_index += client_ip.length();
                i++;
                break;
            case '2':
                memcpy((void*)(result.c_str() + target_index), mac.c_str(), mac.length());
                target_index += mac.length();
                i++;
                break;
            case '3':
                memcpy((void*)(result.c_str() + target_index), disksn.c_str(), disksn.length());
                target_index += disksn.length();
                i++;
                break;
            case '4':
                memcpy((void*)(result.c_str() + target_index), cpuid.c_str(), cpuid.length());
                target_index += cpuid.length();
                i++;
                break;
            case '5':
                memcpy((void*)(result.c_str() + target_index), wip.c_str(), wip.length());
                target_index += wip.length();
                i++;
                break;
            case '%': result[target_index++] = '%'; i++; break;
            default:  result[target_index++] = format[i]; break;
            }
        }
    }
    return result;
}

void ParseOmsSiteInfo(const std::string &option, std::map<int, std::string> &args)
{
    args.clear();

    std::vector<std::string> matched;
    StringHelper::maxSplit(option, "#", matched);

    if (matched.size() > 0) args.insert(std::make_pair(1, matched[0])); // ip
    if (matched.size() > 1) args.insert(std::make_pair(2, matched[1])); // mac
    if (matched.size() > 2) args.insert(std::make_pair(3, matched[2])); // disksn
    if (matched.size() > 3) args.insert(std::make_pair(4, matched[3])); // cpuid
    if (matched.size() > 4) args.insert(std::make_pair(5, matched[4])); // wip
}

void parseInnerCode(OGS_INNERCODE innerCode, std::string &code, qtp::MarketCode &market, qtp::SecurityCategory &sc)
{
    qtp::UniversalCode::UCToSymbol(innerCode, &code, &market, &sc);
    if (code == "000000") code.clear();
}

}
