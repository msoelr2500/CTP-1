////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-17
////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "OrderManager.h"
#include "StringHelper.h"
#include "OgsApi.h"
#include "OgsLogger.h"
#include "ReadConfig.h"
#include "ogs_dict.h"
#include "OgsForwarder.h"

using namespace ogs;
using namespace ogs::ogs_dict;
using std::map;
using std::pair;
using std::string;

OrderManager::OrderManager()
{
    initDBOptions();
}

OrderManager::OrderManager(const std::string &dbPath)
{
    initDBOptions();
    setDatabase(dbPath);
}

OrderManager::~OrderManager()
{
    if (mDB) delete mDB;
}

bool OrderManager::setDatabase(const std::string &dbPath)
{
    if (mDB) delete mDB;

    mDBStatus = rocksdb::DB::Open(mDBOptions, dbPath, &mDB);
    if (!mDBStatus.ok()) {
        ogsError << "[OrderManager] [setDatabase] failed to open db(" << dbPath << "): " << mDBStatus.ToString();
        mDB = nullptr;
        mDatabasePath.clear();
    } else {
        mDatabasePath = dbPath;
        // 从数据库读取原有订单记录。
        return loadFromDB();
    }

    return mDBStatus.ok();
}

std::string OrderManager::databasePath() const
{
    return mDatabasePath;
}

const rocksdb::Status &OrderManager::databaseStatus() const
{
    return mDBStatus;
}

bool OrderManager::hasOrder(const char *sysOrderId) const
{
    for (map<OGS_CUSTORDERID, OrderInfo>::const_iterator i = mOrderMap.begin(); i != mOrderMap.end(); i++) {
        if (strcmp(sysOrderId, i->second.sysOrderId) == 0) {
            return true;
        }
    }
    return false;
}

bool OrderManager::matchOrder(ogs::QueryOrderAns* array, int size)
{
    if (size <= 0) return false;

    map<OGS_CUSTORDERID, OrderItem>::iterator i = mUnfinishedOrderMap.find(array[0].custOrderId);
    if (i == mUnfinishedOrderMap.end()) {
        return false;
    }
    const OrderInfo& orderInfo = i->second.orderInfo;

    int matchedIndex = -1;
    int minTimeDiffAbs = INT_MAX;

    for (int i = 0; i < size; ++i) {
        VLOG(300) << "[OrderManager] [matchOrder] matching sysOrderId:" << array[i].sysOrderId;
        if (hasOrder(array[i].sysOrderId)) continue;

        if (strcmp(orderInfo.bacid, array[i].bacid) != 0) {
            VLOG(300) << orderInfo.bacid << " bacid " << array[i].bacid;
            continue;
        }
        if (orderInfo.innerCode != array[i].innerCode) {
            VLOG(300) << orderInfo.innerCode << " innerCode " << array[i].innerCode;
            continue;
        }
        if (// orderInfo buy && queryOrderAns sell
            ((orderInfo.directive == kStBuy || orderInfo.directive == kDtLoanBuy ||
              orderInfo.directive == kDtGuaranteeBuy || orderInfo.directive == kDtBuyPayback) &&
             (array[i].directive == kDtSell || array[i].directive == kDtMarginSell ||
              array[i].directive == kDtGuaranteeSell || array[i].directive == kDtSellPayBack)) ||
            // queryOrderAns buy && orderInfo sell
            ((array[i].directive == kStBuy || array[i].directive == kDtLoanBuy ||
              array[i].directive == kDtGuaranteeBuy || array[i].directive == kDtBuyPayback) &&
             (orderInfo.directive == kDtSell || orderInfo.directive == kDtMarginSell ||
              orderInfo.directive == kDtGuaranteeSell || orderInfo.directive == kDtSellPayBack)))
        {
            VLOG(300) << orderInfo.directive << " directive " << array[i].directive;
            continue;
        }
        if (orderInfo.volume != array[i].volume) {
            VLOG(300) << orderInfo.volume << " volume " << array[i].volume;
            continue;
        }
        if (orderInfo.price != array[i].price) {
            VLOG(300) << orderInfo.price << " price " << array[i].price;
            continue;
        }
        if (orderInfo.tradeDate != array[i].tradeDate) {
            VLOG(300) << orderInfo.tradeDate << " tradeDate " << array[i].tradeDate;
            continue;
        }

        // Now chose the closest order as the matched.
        int currTimeDiff = std::abs(TimeDiff(orderInfo.orderTime, array[i].orderTime));
        if (minTimeDiffAbs > currTimeDiff) {
            minTimeDiffAbs = currTimeDiff;
            matchedIndex = i;
        }
    }

    // a order has been matched.
    if (matchedIndex >= 0) {
        orderLog(array[matchedIndex].custOrderId) << "[OrderManager] [matchOrder] matched one order: sysOrderId = " << array[matchedIndex].sysOrderId;
        updateOrder(array[matchedIndex], "订单匹配成功。");
        return true;
    } else {
        i->second.mWaitingQueryOrderAns = false;
    }

    return false;
}

bool OrderManager::addOrder(const OrderItem &item)
{
    addToMap(item);

    if (!saveToDB(item.orderInfo)) {
        return false;
    }

    return true;
}

bool OrderManager::addOrder(const SendOrderQry &sendOrderQry, qtp::session_id_t session_id)
{
    OrderItem item;
    item.mWaitingSendOrderAns = true;
    OrderInfo& info = item.orderInfo;
    strcpy(info.acidcard, sendOrderQry.acidcard);
    info.actype         = sendOrderQry.actype;
    strcpy(info.bacid, sendOrderQry.bacid);
    strcpy(info.password, sendOrderQry.password);
    strcpy(info.ipAddr,   sendOrderQry.ipAddr);
    strcpy(info.macAddr,  sendOrderQry.macAddr);
    strcpy(info.diskSn,   sendOrderQry.diskSn);
    info.innerCode      = sendOrderQry.innerCode;
    info.directive      = sendOrderQry.directive;
    info.execution      = sendOrderQry.execution;
    info.price          = sendOrderQry.price;
    info.volume         = sendOrderQry.volume;
    info.custOrderId    = sendOrderQry.custOrderId;
    info.orderStatus    = kOtNotReported;
    info.dealVolume     = 0;
    info.dealBalance    = 0;
    info.dealPrice      = 0;
    info.withdrawVolume = 0;
    info.tradeDate      = GetDateYMD();
    info.orderTime      = GetTimeHMS();
    info.sessionid      = session_id;

    if (addOrder(item)) {
        orderLog(info.custOrderId) << "[OrderManager] [addOrder] add new order by SendOrderQry success.";
        return true;
    } else {
        orderLog(info.custOrderId) << "[OrderManager] [addOrder] add new order by SendOrderQry failed.";
        return false;
    }
}

bool OrderManager::updateOrder(const OrderItem &item, bool forceNotify)
{
    bool result = true;

    std::map<OGS_CUSTORDERID, OrderInfo>::const_iterator i = mOrderMap.find(item.orderInfo.custOrderId);
    if (i == mOrderMap.end()) {
        ogsDebug << "[OrderManager] [updateOrder] can't find the specified orderitem";
        return false;
    }

    const OrderInfo& currOrderInfo = i->second;

    ogsDebug << "[OrderManager] [updateOrder] oldStatus = " << currOrderInfo.orderStatus
             << ", newStatus = " << item.orderInfo.orderStatus
             << ", oldDealVol = " << currOrderInfo.dealVolume
             << ", newDealVol = " << item.orderInfo.dealVolume;

    bool needUpdate = isOrderNeedUpdate(currOrderInfo.orderStatus,  currOrderInfo.dealVolume,
                                        item.orderInfo.orderStatus, item.orderInfo.dealVolume);

    // 更新订单表。
    updateMap(item);

    if (needUpdate || forceNotify) {
        // 更新数据库。
        if (!saveToDB(item.orderInfo)) {
            result = false;
        }
        // 推送更新。
        notifyOrderStatusChange(item);
    }

    return result;
}

bool OrderManager::updateOrder(const SendOrderAns &sendOrderAns, Intf_RetType errorCode, const std::string &entrustError)
{
    // 获取当前版本的OrderItem。
    OrderItem item;
    item.orderInfo.custOrderId = sendOrderAns.custOrderId;

    if (!getUnfinishedOrder(item)) {
        orderLog(item.orderInfo.custOrderId) << "[OrderManager] [updateOrder] error: can't find the order specified by SendOrderAns.";
        return false;
    }

    // 更新当前版本的OrderItem。
    item.mWaitingSendOrderAns = false;
    item.mEntrustError = entrustError;
    if (item.mEntrustError.size() < 2) {
        item.mEntrustError = OgsLogger::errorCode(errorCode);
    }

    memcpy(item.orderInfo.sysOrderId, sendOrderAns.sysOrderId, SYSORDERIDSIZE);

    // 如果订单出现某些无法通过查单解决的错误，立即更新为废单。
    if (errorCode == kIntfWorkFail || errorCode == kIntfSendFail || errorCode == kIntfNotSupport) {
        item.orderInfo.orderStatus = kOtBad;
        item.mNotifyPrompt = string("废单原因：") + item.mEntrustError;
    } else if (errorCode == kIntfSuccess) {
        item.mNotifyPrompt = string("委托成功。");
    } else {
        item.mNotifyPrompt = string("委托时出现了错误：") + item.mEntrustError;
    }

    // 保存更新。
    if (updateOrder(item, true)) {
        orderLog(item.orderInfo.custOrderId) << "[OrderManager] [updateOrder] update order by SendOrderAns success.";
        return true;
    } else {
        orderLog(item.orderInfo.custOrderId) << "[OrderManager] [updateOrder] update order by SendOrderAns failed.";
        return false;
    }
}

/*!
 * 以查单回报形式推送的订单更新。产生的订单完结属于正常完结。
 */
bool OrderManager::updateOrder(const QueryOrderAns &queryOrderAns, const std::string& description, bool isCallback)
{
    // 获取当前版本的OrderItem。
    OrderItem item;
    // 一般的查单回报中有custOrderId和sysOrderId，接口推送的查单主动推送的回报只有sysOrderId
    item.orderInfo.custOrderId = queryOrderAns.custOrderId;
    memcpy(item.orderInfo.sysOrderId, queryOrderAns.sysOrderId, SYSORDERIDSIZE);

    if (!getUnfinishedOrder(item)) {
        ogsDebug << "[OrderManager] [updateOrder] can't find the specified order";
        return false;
    }

    bool forceNotify = false;
    if (strlen(item.orderInfo.sysOrderId) == 0) {
        memcpy(item.orderInfo.sysOrderId, queryOrderAns.sysOrderId, SYSORDERIDSIZE);
        ogsDebug << "[OrderManager] [updateOrder] unacked order get a update";
        forceNotify = true;
    }

    // 更新当前版本的OrderItem。
    if (!isCallback) {
        item.mWaitingQueryOrderAns = false;     // 接口推送的查单回报不影响ogs主动发起的查单流程
    }
    item.orderInfo.orderStatus    = queryOrderAns.orderStatus;
    item.orderInfo.dealVolume     = queryOrderAns.dealVolume;
    item.orderInfo.dealBalance    = queryOrderAns.dealBalance;
    item.orderInfo.dealPrice      = queryOrderAns.dealPrice;
    item.orderInfo.withdrawVolume = queryOrderAns.withdrawVolume;
    if (isOrderFinished(item.orderInfo.orderStatus)) {
        if (description.empty()) {
            item.mNotifyPrompt = "[ogs] 订单已完结。";
        } else {
            StringHelper::string_format(item.mNotifyPrompt, "[ogs] 订单已完结: %s", description.c_str());
        }
        forceNotify = true;
    } else {
        if (description.empty()) {
            item.mNotifyPrompt = "[ogs] 订单已更新。";
        } else {
            StringHelper::string_format(item.mNotifyPrompt, "[ogs] 订单已更新: %s", description.c_str());
        }
    }

    // 保存更新。
    return updateOrder(item, forceNotify);
}

void OrderManager::settleOrder()
{
    std::map<uint64_t, OrderItem> copyMap = mUnfinishedOrderMap;
    for (map<OGS_CUSTORDERID, OrderItem>::iterator itUnendMap = copyMap.begin(); itUnendMap != copyMap.end(); ++itUnendMap) {
        OrderItem& item = itUnendMap->second;

        if (itUnendMap->second.orderInfo.orderStatus == kOtNotReported ||
            itUnendMap->second.orderInfo.orderStatus == kOtWaitReporting ||
            itUnendMap->second.orderInfo.orderStatus == kOtReported ||
            itUnendMap->second.orderInfo.orderStatus == kOtCanceling ||
            itUnendMap->second.orderInfo.orderStatus == kOtCanceled) {

            orderLog(item.orderInfo.custOrderId)
                      << "[OrderMgrStage] [settleOrder] the status of unfinished order (custOrderId = "
                      << item.orderInfo.custOrderId
                      << ") was "
                      << item.orderInfo.orderStatus
                      << ", now it's set to kOtCanceled (finished)."; // TRACE LOG

            item.orderInfo.orderStatus = kOtCanceled;
            item.orderInfo.dealVolume = 0;
            item.orderInfo.dealBalance = 0;
            item.orderInfo.dealPrice = 0;
            item.orderInfo.withdrawVolume = item.orderInfo.volume;
        }
        else if (itUnendMap->second.orderInfo.orderStatus == kOtMatchedCanceling ||
                 itUnendMap->second.orderInfo.orderStatus == kOtMatchedCanceled ||
                 itUnendMap->second.orderInfo.orderStatus == kOtPartMatched) {
            orderLog(item.orderInfo.custOrderId)
                      << "[OrderMgrStage] [settleOrder] the status of unfinished order (custOrderId = "
                      << item.orderInfo.custOrderId
                      << ") was "
                      << item.orderInfo.orderStatus
                      << ", now it's set to kOtPartMatched (finished)."; // TRACE LOG

            item.orderInfo.orderStatus = kOtPartMatched;
            item.orderInfo.withdrawVolume = item.orderInfo.volume - item.orderInfo.dealVolume;
        }
        else if (itUnendMap->second.orderInfo.orderStatus == kOtMatchedAll ||
                 itUnendMap->second.orderInfo.orderStatus == kOtBad) {
            orderLog(item.orderInfo.custOrderId)
                      << "[OrderMgrStage] [settleOrder] find a finished order (custOrderId = "
                      << itUnendMap->second.orderInfo.custOrderId
                      << ") in unfinished order map, that's strange."; // TRACE LOG
        }

        item.mNotifyPrompt = "[ogs] 已到清算时间，未完成订单被清算为已完成状态。";
        updateOrder(item, true);
        orderLog(itUnendMap->second.orderInfo.custOrderId) << "[OrderMgrStage] [settleOrder] order is now finished.";
    }
}

bool OrderManager::getOrder(OrderInfo &info) const
{
    std::map<OGS_CUSTORDERID ,OrderInfo>::const_iterator i = mOrderMap.end();
    if (info.custOrderId == 0) {
        // 如果custOrderId无效，则使用sysOrderId来查询。
        for (std::map<OGS_CUSTORDERID ,OrderInfo>::const_iterator it = mOrderMap.begin(); it != mOrderMap.end(); it++) {
            if (strcmp(it->second.sysOrderId, info.sysOrderId) != 0) {
                continue;
            } else {
                i = it;
                break;
            }
        }
    } else {
        // 默认使用custOrderId来查询。
        i = mOrderMap.find(info.custOrderId);
    }

    if (i == mOrderMap.end()) return false;

    info = i->second;
    return true;
}

bool OrderManager::getUnfinishedOrder(OrderItem &item) const
{
    std::map<OGS_CUSTORDERID ,OrderItem>::const_iterator i = mUnfinishedOrderMap.end();
    if (item.orderInfo.custOrderId == 0) {
        // 如果custOrderId无效，则使用sysOrderId来查询。
        for (std::map<OGS_CUSTORDERID, OrderItem>::const_iterator it = mUnfinishedOrderMap.begin(); it != mUnfinishedOrderMap.end(); it++) {
            if (strcmp(it->second.orderInfo.sysOrderId, item.orderInfo.sysOrderId) != 0) {
                continue;
            } else {
                i = it;
                break;
            }
        }
    } else {
        // 默认使用custOrderId来查询。
        i = mUnfinishedOrderMap.find(item.orderInfo.custOrderId);
    }

    if (i == mUnfinishedOrderMap.end()) return false;

    item = i->second;
    return true;
}

std::map<OGS_CUSTORDERID, OrderItem> OrderManager::unfinishedOrders() const
{
    return mUnfinishedOrderMap;
}

void OrderManager::clearOrder()
{
    mOrderMap.clear();
    mUnfinishedOrderMap.clear();
}

bool OrderManager::isOrderNeedUpdate(uint32_t oldStatus, OGS_DEALVOLUME oldDealVol, uint32_t newStatus, OGS_DEALVOLUME newDealVol)
{
    bool needUpdate = false;
    switch (newStatus) {
        case kOtNotReported:
            if (oldStatus < kOtCanceling && oldStatus != kOtNotReported) {
                needUpdate = true;
            }
            break;
        case kOtWaitReporting:
            if (oldStatus < kOtCanceling && oldStatus != kOtWaitReporting) {
                needUpdate = true;
            }
            break;
        case kOtReported:
            if (oldStatus < kOtCanceling && oldStatus != kOtReported) {
                needUpdate = true;
            }
            break;
        case kOtCanceling:
            if (oldStatus < kOtCanceling || oldStatus == kOtPartMatched) {
                needUpdate = true;
            }
            break;
        case kOtMatchedCanceling:
            if (oldStatus < kOtCanceling || oldStatus == kOtPartMatched) {
                needUpdate = true;
            }
            break;
        case kOtMatchedCanceled:
            if (oldStatus < kOtMatchedCanceled || oldStatus == kOtPartMatched) {
                needUpdate = true;
            }
            break;
        case kOtCanceled:
            if (oldStatus < kOtMatchedCanceled || oldStatus == kOtPartMatched) {
                needUpdate = true;
            }
            break;
        case kOtPartMatched:
            if (oldStatus < kOtMatchedCanceling || oldStatus == kOtPartMatched) {
                if (newDealVol > oldDealVol)
                    needUpdate = true;
            }
            break;
        case kOtMatchedAll:
            if (oldStatus == kOtPartMatched || oldStatus <= kOtMatchedCanceling) {
                needUpdate = true;
            }
            break;
        case kOtBad:
            if (oldStatus <= kOtMatchedAll) {
                needUpdate = true;
            }
            break;
    }
    return needUpdate;
}

void OrderManager::notifyOrderStatusChange(const OrderItem &order)
{
    orderLog(order.orderInfo.custOrderId) << "[OrderManager] [notifyOrderStatusChange] notify " << order.orderInfo.sessionid;
    qtp::QtpMessagePtr response = std::make_shared<qtp::QtpMessage>();
    response->BeginEncode(kMtQueryOrderAns, 0);

    response->AddTag(kTagSession, &order.orderInfo.sessionid, sizeof(qtp::session_id_t));
    response->AddTag(kTagBacid, order.orderInfo.bacid, strlen(order.orderInfo.bacid));
    int time = GetTimeHMS();
    response->AddTag(kTagTime, &time, sizeof(OGS_SYSTIME));

    // 如果直接传入常量，则会出现错误。
    uint32_t itemCount = sizeof(QueryOrderAns);
    uint32_t itemSize = 1;
    SetItemSizeAndCnt(response, itemCount, itemSize);
    uint32_t error_code = kIntfSuccess;
    SetErrorCodeAndMsg(response, error_code, order.mNotifyPrompt.c_str(), order.mNotifyPrompt.length());

    // 将状态变化以QueryOrderAns通知给OMS。
    QueryOrderAns ans = order.toQueryOrderAns();
    response->SetData(&ans, sizeof(QueryOrderAns), false);
    response->Encode();

    OgsForwarder::SendMessage(kRepStageID, response);
}

bool OrderManager::saveToDB(const OrderInfo &orderInfo)
{
    if (!isDatabaseOpen()) {
        ogsError << "[OrderManager] [saveToDB] error: db isn't open.";
        return false;
    }

    std::string key = std::to_string(orderInfo.custOrderId);
    std::string value;
    value.assign((const char*)&orderInfo, sizeof(OrderInfo));

    mDBStatus = mDB->Put(rocksdb::WriteOptions(), key, value);
    if (mDBStatus.ok()) {
        ogsDebug << "[OrderManager] [saveToDB] save order(" << orderInfo.custOrderId << ") to db.";
        return true;
    } else {
        ogsError << "[OrderManager] [saveToDB] save order(" << orderInfo.custOrderId << ") failed: " << mDBStatus.ToString();
    }
    return false;
}

bool OrderManager::loadFromDB()
{
    if (!isDatabaseOpen()) return false;

    rocksdb::Iterator *it = mDB->NewIterator(rocksdb::ReadOptions());
    for (it->SeekToFirst(); it->Valid(); it->Next()) {
        OrderInfo orderInfo = {0};
        memcpy(&orderInfo, it->value().ToString().c_str(), sizeof(OrderInfo));
        ogsInfo << "[OrderManager] load order from db:" << orderInfo.custOrderId;

        mOrderMap.insert(std::pair<OGS_CUSTORDERID, OrderInfo>(orderInfo.custOrderId, orderInfo));
        if (!isOrderFinished(orderInfo.orderStatus)) {
            //undone all condition judge
            OrderItem item(orderInfo, ReadConfig::localOption.unAckedOrderQryCnt);
            mUnfinishedOrderMap.insert(std::pair<OGS_CUSTORDERID, OrderItem>(orderInfo.custOrderId, item));
        }
    }
    ogsInfo << "[OrderManager] mOrderMap size: " << mOrderMap.size() << " mUnfinishedOrderMap size: " << mUnfinishedOrderMap.size();
    delete it;

    return true;
}

bool OrderManager::loadFromDB(OrderInfo &orderInfo)
{
    std::string key = std::to_string(orderInfo.custOrderId);
    std::string value;
    mDBStatus = mDB->Get(rocksdb::ReadOptions(), key, &value);
    if (!mDBStatus.ok()) {
        return false;
    }
    memcpy(&orderInfo, value.c_str(), sizeof(OrderInfo));
    return true;
}

bool OrderManager::addToMap(const OrderItem& item)
{
    map<OGS_CUSTORDERID, OrderInfo>::iterator i = mOrderMap.find(item.orderInfo.custOrderId);
    if (i != mOrderMap.end()) {
        ogsWarn << "[OrderManager] [addOrder] order(" << item.orderInfo.custOrderId << ") is already existed, now overwrite the record.";
        mOrderMap.erase(i);
    }

    mOrderMap.insert(pair<OGS_CUSTORDERID, OrderInfo>(item.orderInfo.custOrderId, item.orderInfo));
    mUnfinishedOrderMap.insert(pair<OGS_CUSTORDERID, OrderItem>(item.orderInfo.custOrderId, item));
    return true;
}

void OrderManager::updateMap(const OrderItem &item)
{
    mOrderMap[item.orderInfo.custOrderId] = item.orderInfo;
    map<OGS_CUSTORDERID, OrderItem>::iterator i = mUnfinishedOrderMap.find(item.orderInfo.custOrderId);

    if (ogs::isOrderFinished(item.orderInfo.orderStatus)) {
        if (i != mUnfinishedOrderMap.end()) {
            mUnfinishedOrderMap.erase(i);
        }
        orderLog(item.orderInfo.custOrderId) << "[OrderManager] [updateMap]: order is now finished.";
    } else {
        if (i != mUnfinishedOrderMap.end()) {
            i->second = item;
        } else {
            mUnfinishedOrderMap.insert(pair<OGS_CUSTORDERID, OrderItem>(item.orderInfo.custOrderId, item));
        }
    }
}

void OrderManager::initDBOptions()
{
    // Optimize RocksDB. This is the easiest way to get RocksDB to perform well
    mDBOptions.IncreaseParallelism();
    mDBOptions.OptimizeLevelStyleCompaction();
    // create the DB if it's not already present
    mDBOptions.create_if_missing = true;
}

bool OrderManager::isDatabaseOpen() const
{
    return (mDB != nullptr);
}

int OrderManager::orderCount() const
{
    return mOrderMap.size();
}

int OrderManager::unfinishedOrderCount() const
{
    return mUnfinishedOrderMap.size();
}
