/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#ifndef PBUFXCONVERTER_H
#define PBUFXCONVERTER_H

#include <string>
#include "../DataStruct.h"
#include "../ogs_dict.h"
#include "../universal_code.h"
#include "PbUfxAccount.h"
#include <string.h>

class PbUfxConverter
{
public:
    static std::string op_station(const std::string& wip,
                                  const std::string& clientIp,
                                  const std::string& mac,
                                  const std::string& disksn,
                                  const std::string& cpuid);

    static void to_mac_address(std::string& mac_address, const char* macAddr);
    static void to_ip_address(std::string& ip_address, const char* ipAddr);
    static void to_hd_volserial(std::string& hd_volserial, const char* diskSn);

    static std::string PCHAR_TO_STRING(const char* target) { return target; }
    #define to_client_id PCHAR_TO_STRING     // acidcard
    #define to_fund_account PCHAR_TO_STRING // bacid
    #define to_account_content to_fund_account

    static std::string STRING_TO_PCHAR(char* target, const std::string& source) { strcpy(target, source.c_str()); }
    #define from_client_id STRING_TO_PCHAR // to acidcard
    #define from_capital_account STRING_TO_PCHAR // to bacid;

    static std::string to_stock_account(PbUfxFundAccount& account, qtp::MarketCode market);

    static std::string to_input_content(ogs::OGS_ACTYPE actype);

    static std::string to_password(const char* password);

    static std::string to_entrust_no(const char* sysOrderId);

    static std::string to_amount(ogs::OGS_VOLUME volume);
    #define to_current_amount to_amount
    #define to_entrust_amount to_amount

    static std::string to_entrust_type(ogs::OGS_DIRECTIVE type);
    static std::string to_exchange_type(qtp::MarketCode code);
    static std::string to_stock_code(const std::string& code);
    static std::string to_price_type(ogs::OGS_EXECUTION execution);
    static std::string to_entrust_direction(ogs::OGS_DIRECTIVE type);
    static std::string to_entrust_prop(ogs::OGS_DIRECTIVE type);
    static std::string to_asset_prop(ogs::OGS_DIRECTIVE type);
    static std::string to_asset_prop(ogs::OGS_ACTYPE type);
    static Exchange to_exchange_index(const std::string& market_no);
    static std::string to_price(uint32_t ogs_price);
    #define to_entrust_price to_price

    static int from_price(const std::string& price);

    #define from_entrust_price from_price
    #define from_deal_price from_price

    static ogs::OGS_VOLUME from_amount(const std::string& amount);
    #define from_current_amount from_amount
    #define from_enable_amount from_amount
    #define from_entrust_amount from_amount
    #define from_deal_amount from_amount
    #define from_withdraw_amount from_amount

    static uint32_t from_time(const std::string& time);
    #define from_entrust_time from_time

    static uint32_t from_date(const std::string& date);
    #define from_entrust_date from_date

    static ogs::OGS_BALANCE from_balance(const std::string& balance);
    #define from_deal_balance from_balance
    #define from_current_balance from_balance
    #define from_frozen_balance from_balance
    #define from_enable_balance from_balance

    static qtp::MarketCode from_exchange_type(const std::string& exchange_type);
    static ogs::ogs_dict::OrderStatusType from_entrust_state(const std::string& entrust_state);

    static ogs::OGS_INNERCODE from_stock_code(const std::string& stock_code);
    static void from_entrust_no(const std::string& entrust_no, char* sysOrderId);
    static void from_deal_no(const std::string& deal_no, char* dealId);
};

#endif // PBUFXCONVERTER_H
