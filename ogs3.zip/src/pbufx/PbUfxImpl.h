/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#ifndef _PBUFXIMPL_H_
#define _PBUFXIMPL_H_

#include <ufx/t2sdk_interface.h>
#include <map>
#include <string>
#include <cassert>
#include <vector>
#include <iconv.h>
#include <list>
#include <vector>
#include <functional>

#include "PbUfxApiWrapper.h"
#include "PbUfxAccount.h"

#include "../universal_code.h"
#include "../DataStruct.h"
#include "../OrderStage.h"
#include "../ogs_dict.h"

class PbUfxImpl{
public:
    PbUfxImpl();
    virtual ~PbUfxImpl();

    ////////////////////////////////////////////////////////////////////////////
    /// 基础方法
    ////////////////////////////////////////////////////////////////////////////

    bool initialize();

    bool connect();

    void disconnect();

    /*! \brief 心跳 */
    Intf_RetType heartBeatToBroker();

    /*! \brief 设置查单过程的回调函数。*/
    void setCallBack(int (*fn)(ogs::QueryOrderAns));

    ////////////////////////////////////////////////////////////////////////////
    /// 状态
    ////////////////////////////////////////////////////////////////////////////

    bool isConnected() const;

    Intf_RetType ogsLogin(const ogs::LoginQry& in, std::list<ogs::LoginAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsSendOrder(const ogs::SendOrderQry& in, std::list<ogs::SendOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsCancelOrder(const ogs::CancelOrderQry& in, std::list<ogs::CancelOrderAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryOrder(const ogs::QueryOrderQry& in, std::list<ogs::QueryOrderAns>& out, std::string &errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryPosition(const ogs::QueryPositionQry& in, std::list<ogs::QueryPositionAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsQueryBargain(const ogs::QueryBargainQry& in, std::list<ogs::QueryBargainAns>& out, std::string& errMsg, std::map<int, std::string> &args);
    Intf_RetType ogsQueryFundInfo(const ogs::QueryFundInfoQry& in, std::list<ogs::QueryFundInfoAns>& out, std::string& errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsPaybackSecurity(const ogs::PaybackSecurityQry &in, std::list<ogs::PaybackSecurityAns> &out, std::string &errMsg, std::map<int, std::string>& args);
    Intf_RetType ogsPaybackFunds(const ogs::PaybackFundsQry &in, std::list<ogs::PaybackFundsAns> &out, std::string &errMsg, std::map<int, std::string>& args);

protected:
    std::string op_station(std::map<int, std::string>& args);

private:
    PbUfxApiWrapper mConnection;

    //! ufx配置文件接口
    static CConfigInterface* lpConfig;

    //! 订阅获取到成交回报时的回调函数
    std::function<int(ogs::QueryOrderAns)> func;

    static PbUfxClientManager mClients;
};

#endif // _PBUFXIMPL_H_
