/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxLogger.h"

OgsLogger& operator << (OgsLogger& logger, const MessageHeartbeatInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[MessageHeartbeatInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmUserLoginInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[AmUserLoginInput]=====================";
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|password                     |" << data.password;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    ogsDebug << "|authorization_id             |" << data.authorization_id;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmUserLoginOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmUserLoginOutput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|version_no                   |" << data.version_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmUserLogoutInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmUserLogoutInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmUserChgPassInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmUserChgPassInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|old_password                 |" << data.old_password;
    ogsDebug << "|new_password                 |" << data.new_password;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmFundQueryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[AmFundQueryInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmFundQueryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmFundQueryOutput]=====================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|account_name                 |" << data.account_name;
    ogsDebug << "|account_type                 |" << data.account_type;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmAssetQueryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmAssetQueryInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|capital_account              |" << data.capital_account;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmAssetQueryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmAssetQueryOutput]====================";
    ogsDebug << "|capital_account              |" << data.capital_account;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|asset_name                   |" << data.asset_name;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmCombiQueryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmCombiQueryInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmCombiQueryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmCombiQueryOutput]====================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|combi_name                   |" << data.combi_name;
    ogsDebug << "|market_no_list               |" << data.market_no_list;
    ogsDebug << "|futu_invest_type             |" << data.futu_invest_type;
    ogsDebug << "|entrust_direction_list       |" << data.entrust_direction_list;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmHolderQueryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmHolderQueryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmHolderQueryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmHolderQueryOutput]====================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmFundAssetQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmFundAssetQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|currency_code                |" << data.currency_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmFundAssetQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmFundAssetQryOutput]===================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|currency_code                |" << data.currency_code;
    ogsDebug << "|total_asset                  |" << data.total_asset;
    ogsDebug << "|nav                          |" << data.nav;
    ogsDebug << "|yesterday_nav                |" << data.yesterday_nav;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|begin_balance                |" << data.begin_balance;
    ogsDebug << "|futu_deposit_balance         |" << data.futu_deposit_balance;
    ogsDebug << "|occupy_deposit_balance       |" << data.occupy_deposit_balance;
    ogsDebug << "|futu_asset                   |" << data.futu_asset;
    ogsDebug << "|stock_asset                  |" << data.stock_asset;
    ogsDebug << "|bond_asset                   |" << data.bond_asset;
    ogsDebug << "|fund_asset                   |" << data.fund_asset;
    ogsDebug << "|repo_asset                   |" << data.repo_asset;
    ogsDebug << "|other_asset                  |" << data.other_asset;
    ogsDebug << "|fund_share                   |" << data.fund_share;
    ogsDebug << "|fund_net_asset               |" << data.fund_net_asset;
    ogsDebug << "|payable_balance              |" << data.payable_balance;
    ogsDebug << "|receivable_balance           |" << data.receivable_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmUnitAssetQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmUnitAssetQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|currency_code                |" << data.currency_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmUnitAssetQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmUnitAssetQryOutput]===================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|currency_code                |" << data.currency_code;
    ogsDebug << "|current_balance              |" << data.current_balance;
    ogsDebug << "|begin_balance                |" << data.begin_balance;
    ogsDebug << "|futu_deposit_balance         |" << data.futu_deposit_balance;
    ogsDebug << "|futu_asset                   |" << data.futu_asset;
    ogsDebug << "|stock_asset                  |" << data.stock_asset;
    ogsDebug << "|bond_asset                   |" << data.bond_asset;
    ogsDebug << "|fund_asset                   |" << data.fund_asset;
    ogsDebug << "|repo_asset                   |" << data.repo_asset;
    ogsDebug << "|option_asset                 |" << data.option_asset;
    ogsDebug << "|other_asset                  |" << data.other_asset;
    ogsDebug << "|payable_balance              |" << data.payable_balance;
    ogsDebug << "|receivable_balance           |" << data.receivable_balance;
    ogsDebug << "|futu_today_profit            |" << data.futu_today_profit;
    ogsDebug << "|futu_float_profit            |" << data.futu_float_profit;
    ogsDebug << "|futu_close_profit            |" << data.futu_close_profit;
    ogsDebug << "|futu_fee                     |" << data.futu_fee;
    ogsDebug << "|spot_accumulate_profit       |" << data.spot_accumulate_profit;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmCurrentsQueryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmCurrentsQueryInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmCurrentsQueryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[AmCurrentsQueryOutput]===================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|currency_code                |" << data.currency_code;
    ogsDebug << "|busin_no                     |" << data.busin_no;
    ogsDebug << "|busin_caption                |" << data.busin_caption;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|trade_fee                    |" << data.trade_fee;
    ogsDebug << "|stamp_tax                    |" << data.stamp_tax;
    ogsDebug << "|transfer_fee                 |" << data.transfer_fee;
    ogsDebug << "|commission                   |" << data.commission;
    ogsDebug << "|handling_fee                 |" << data.handling_fee;
    ogsDebug << "|admin_fee                    |" << data.admin_fee;
    ogsDebug << "|clearing_fee                 |" << data.clearing_fee;
    ogsDebug << "|delivery_fee                 |" << data.delivery_fee;
    ogsDebug << "|risk_fund                    |" << data.risk_fund;
    ogsDebug << "|other_fee                    |" << data.other_fee;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|settle_speed                 |" << data.settle_speed;
    ogsDebug << "|capital_direction            |" << data.capital_direction;
    ogsDebug << "|stock_direction              |" << data.stock_direction;
    ogsDebug << "|close_type                   |" << data.close_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmHistCurrentsQueryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[AmHistCurrentsQueryInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmHistCurrentsQueryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[AmHistCurrentsQueryOutput]=================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|serial_no                    |" << data.serial_no;
    ogsDebug << "|currency_code                |" << data.currency_code;
    ogsDebug << "|busin_no                     |" << data.busin_no;
    ogsDebug << "|busin_caption                |" << data.busin_caption;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|business_price               |" << data.business_price;
    ogsDebug << "|business_amount              |" << data.business_amount;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|trade_fee                    |" << data.trade_fee;
    ogsDebug << "|stamp_tax                    |" << data.stamp_tax;
    ogsDebug << "|transfer_fee                 |" << data.transfer_fee;
    ogsDebug << "|commission                   |" << data.commission;
    ogsDebug << "|handling_fee                 |" << data.handling_fee;
    ogsDebug << "|admin_fee                    |" << data.admin_fee;
    ogsDebug << "|clearing_fee                 |" << data.clearing_fee;
    ogsDebug << "|delivery_fee                 |" << data.delivery_fee;
    ogsDebug << "|risk_fund                    |" << data.risk_fund;
    ogsDebug << "|other_fee                    |" << data.other_fee;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|settle_speed                 |" << data.settle_speed;
    ogsDebug << "|capital_direction            |" << data.capital_direction;
    ogsDebug << "|stock_direction              |" << data.stock_direction;
    ogsDebug << "|close_type                   |" << data.close_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmDepositRatioQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[AmDepositRatioQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmDepositRatioQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[AmDepositRatioQryOutput]==================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|deposit_ratio                |" << data.deposit_ratio;
    ogsDebug << "|long_deposit_ratio           |" << data.long_deposit_ratio;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmCapitalAdjustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[AmCapitalAdjustInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|adjust_mode                  |" << data.adjust_mode;
    ogsDebug << "|business_balance             |" << data.business_balance;
    ogsDebug << "|enable_date                  |" << data.enable_date;
    ogsDebug << "|remark                       |" << data.remark;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmCapitalAdjustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[AmCapitalAdjustOutput]===================";
    ogsDebug << "|adjust_result                |" << data.adjust_result;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====================[SecuEntrustInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[SecuEntrustOutput]=====================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuShareTransferEntInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|buy_price                    |" << data.buy_price;
    ogsDebug << "|buy_amount                   |" << data.buy_amount;
    ogsDebug << "|sell_price                   |" << data.sell_price;
    ogsDebug << "|sell_amount                  |" << data.sell_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuShareTransferEntOutput]================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===========[SecuShareTransferWithdrawCombiInput]============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===========[SecuShareTransferWithdrawCombiOutput]===========";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawByEntrustNoInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "========[SecuShareTransferWithdrawByEntrustNoInput]=========";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawByEntrustNoOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "========[SecuShareTransferWithdrawByEntrustNoOutput]========";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuEntrustCombiInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|covered_flag                 |" << data.covered_flag;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|limit_entrust_ratio          |" << data.limit_entrust_ratio;
    ogsDebug << "|ftr_limit_entrust_ratio      |" << data.ftr_limit_entrust_ratio;
    ogsDebug << "|opt_limit_entrust_ratio      |" << data.opt_limit_entrust_ratio;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuEntrustCombiOutput]==================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|request_order                |" << data.request_order;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuEntrustWithdrawCombiInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuEntrustWithdrawCombiOutput]==============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuEntrustWithdrawInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuEntrustWithdrawOutput]=================";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuShareTransferWithdrawInput]==============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[SecuShareTransferWithdrawOutput]==============";
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuUnitStkQryOutput]===================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|begin_cost                   |" << data.begin_cost;
    ogsDebug << "|current_cost                 |" << data.current_cost;
    ogsDebug << "|pre_buy_amount               |" << data.pre_buy_amount;
    ogsDebug << "|pre_sell_amount              |" << data.pre_sell_amount;
    ogsDebug << "|pre_buy_balance              |" << data.pre_buy_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|today_buy_amount             |" << data.today_buy_amount;
    ogsDebug << "|today_sell_amount            |" << data.today_sell_amount;
    ogsDebug << "|today_buy_balance            |" << data.today_buy_balance;
    ogsDebug << "|today_sell_balance           |" << data.today_sell_balance;
    ogsDebug << "|today_buy_fee                |" << data.today_buy_fee;
    ogsDebug << "|today_sell_fee               |" << data.today_sell_fee;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuEntrustQryOutput]===================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|pre_buy_frozen_balance       |" << data.pre_buy_frozen_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|exchange_report_no           |" << data.exchange_report_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuHistEntrustQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuHistEntrustQryOutput]=================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|pre_buy_frozen_balance       |" << data.pre_buy_frozen_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuShareTransferEntrQryInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuShareTransferEntrQryOutput]==============";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|buy_price                    |" << data.buy_price;
    ogsDebug << "|buy_amount                   |" << data.buy_amount;
    ogsDebug << "|sell_price                   |" << data.sell_price;
    ogsDebug << "|sell_amount                  |" << data.sell_amount;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|buy_deal_amount              |" << data.buy_deal_amount;
    ogsDebug << "|buy_deal_balance             |" << data.buy_deal_balance;
    ogsDebug << "|sell_deal_amount             |" << data.sell_deal_amount;
    ogsDebug << "|sell_deal_balance            |" << data.sell_deal_balance;
    ogsDebug << "|buy_cancel_amount            |" << data.buy_cancel_amount;
    ogsDebug << "|sell_cancel_amount           |" << data.sell_cancel_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[SecuRealDealQryInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuRealDealQryOutput]===================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|instance_no                  |" << data.instance_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[SecuHistRealDealQryInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_serial_list          |" << data.entrust_serial_list;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuHistRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[SecuHistRealDealQryOutput]=================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuComboFundQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuComboFundQryInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuComboFundQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[SecuComboFundQryOutput]==================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|enable_balance_t0            |" << data.enable_balance_t0;
    ogsDebug << "|enable_balance_t1            |" << data.enable_balance_t1;
    ogsDebug << "|current_balance              |" << data.current_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuShareTransferEntrustInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|rival_holdid                 |" << data.rival_holdid;
    ogsDebug << "|rival_seat                   |" << data.rival_seat;
    ogsDebug << "|engaged_no                   |" << data.engaged_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[SecuShareTransferEntrustOutput]==============";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==========[SecuShareTransferEntrustWithdrawInput]===========";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==========[SecuShareTransferEntrustWithdrawOutput]==========";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "========[SecuShareTransferEntrustWithdrawCombiInput]========";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=======[SecuShareTransferEntrustWithdrawCombiOutput]========";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmEtfDealingInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmEtfDealingInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmEtfDealingOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmEtfDealingOutput]====================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmEtfEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmEtfEntrustInput]=====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_balance              |" << data.entrust_balance;
    ogsDebug << "|purchase_way                 |" << data.purchase_way;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const AmEtfEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[AmEtfEntrustOutput]====================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FundEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FundEntrustQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FundEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FundEntrustQryOutput]===================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_balance              |" << data.entrust_balance;
    ogsDebug << "|purchase_way                 |" << data.purchase_way;
    ogsDebug << "|pre_buy_frozen_balance       |" << data.pre_buy_frozen_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|exchange_report_no           |" << data.exchange_report_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfDealingQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[EtfDealingQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfDealingQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[EtfDealingQryOutput]====================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|detail_entrust_no            |" << data.detail_entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FundRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FundRealDealQryInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FundRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[FundRealDealQryOutput]===================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfDealingRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[EtfDealingRealDealQryInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfDealingRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[EtfDealingRealDealQryOutput]================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfStockListQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[EtfStockListQryInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|etf_code                     |" << data.etf_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfStockListQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[EtfStockListQryOutput]===================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_amount                 |" << data.stock_amount;
    ogsDebug << "|replace_flag                 |" << data.replace_flag;
    ogsDebug << "|replace_ratio                |" << data.replace_ratio;
    ogsDebug << "|replace_balance              |" << data.replace_balance;
    ogsDebug << "|redeem_replace_balance       |" << data.redeem_replace_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfBaseInfoQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[EtfBaseInfoQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|etf_type                     |" << data.etf_type;
    ogsDebug << "|etf_code                     |" << data.etf_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const EtfBaseInfoQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[EtfBaseInfoQryOutput]===================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|etf_code                     |" << data.etf_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_num                    |" << data.stock_num;
    ogsDebug << "|creation_redeem_type         |" << data.creation_redeem_type;
    ogsDebug << "|etf_market_type              |" << data.etf_market_type;
    ogsDebug << "|rival_market                 |" << data.rival_market;
    ogsDebug << "|etf_type                     |" << data.etf_type;
    ogsDebug << "|max_cash_ratio               |" << data.max_cash_ratio;
    ogsDebug << "|report_unit                  |" << data.report_unit;
    ogsDebug << "|yesterday_cash               |" << data.yesterday_cash;
    ogsDebug << "|yesterday_nav                |" << data.yesterday_nav;
    ogsDebug << "|estimate_cash                |" << data.estimate_cash;
    ogsDebug << "|underlying_index             |" << data.underlying_index;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesInfoQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FuturesInfoQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesInfoQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FuturesInfoQryOutput]===================";
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_name                   |" << data.stock_name;
    ogsDebug << "|future_kind_name             |" << data.future_kind_name;
    ogsDebug << "|settlement_month             |" << data.settlement_month;
    ogsDebug << "|target_market_no             |" << data.target_market_no;
    ogsDebug << "|target_stock_code            |" << data.target_stock_code;
    ogsDebug << "|multiple                     |" << data.multiple;
    ogsDebug << "|last_trade_date              |" << data.last_trade_date;
    ogsDebug << "|last_trade_time              |" << data.last_trade_time;
    ogsDebug << "|settlement_date              |" << data.settlement_date;
    ogsDebug << "|settlement_price             |" << data.settlement_price;
    ogsDebug << "|pre_settlement_price         |" << data.pre_settlement_price;
    ogsDebug << "|market_position              |" << data.market_position;
    ogsDebug << "|pre_market_position          |" << data.pre_market_position;
    ogsDebug << "|market_price_permit          |" << data.market_price_permit;
    ogsDebug << "|uplimited_price              |" << data.uplimited_price;
    ogsDebug << "|downlimited_price            |" << data.downlimited_price;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FuturesEntrustInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|close_direction              |" << data.close_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|limit_deal_amount            |" << data.limit_deal_amount;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[FuturesEntrustOutput]===================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[FuturesPortfolioSingleEntrustInput]============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|limit_deal_amount            |" << data.limit_deal_amount;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|portfolio_type               |" << data.portfolio_type;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===========[FuturesPortfolioSingleEntrustOutput]============";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[FuturesEntrustWithdrawCombiInput]=============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[FuturesEntrustWithdrawCombiOutput]=============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[FuturesEntrustWithdrawInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[FuturesEntrustWithdrawOutput]===============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====[FuturesPortfolioSingleEntrustWithdrawCombiInput]======";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=====[FuturesPortfolioSingleEntrustWithdrawCombiOutput]=====";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "========[FuturesPortfolioSingleEntrustWithdrawInput]========";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=======[FuturesPortfolioSingleEntrustWithdrawOutput]========";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesUftUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[FuturesUftUnitStkQryInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|position_flag                |" << data.position_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesUftUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[FuturesUftUnitStkQryOutput]================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|today_amount                 |" << data.today_amount;
    ogsDebug << "|lastday_amount               |" << data.lastday_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|today_enable_amount          |" << data.today_enable_amount;
    ogsDebug << "|lastday_enable_amount        |" << data.lastday_enable_amount;
    ogsDebug << "|begin_cost                   |" << data.begin_cost;
    ogsDebug << "|current_cost                 |" << data.current_cost;
    ogsDebug << "|current_cost_price           |" << data.current_cost_price;
    ogsDebug << "|pre_buy_amount               |" << data.pre_buy_amount;
    ogsDebug << "|pre_sell_amount              |" << data.pre_sell_amount;
    ogsDebug << "|pre_buy_balance              |" << data.pre_buy_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|today_buy_amount             |" << data.today_buy_amount;
    ogsDebug << "|today_sell_amount            |" << data.today_sell_amount;
    ogsDebug << "|today_buy_balance            |" << data.today_buy_balance;
    ogsDebug << "|today_sell_balance           |" << data.today_sell_balance;
    ogsDebug << "|today_buy_fee                |" << data.today_buy_fee;
    ogsDebug << "|today_sell_fee               |" << data.today_sell_fee;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesUnitStkDetailQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[FuturesUnitStkDetailQryInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|position_flag                |" << data.position_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesUnitStkDetailQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[FuturesUnitStkDetailQryOutput]===============";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|stock_open_date              |" << data.stock_open_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|open_amount                  |" << data.open_amount;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|drop_amount                  |" << data.drop_amount;
    ogsDebug << "|occupy_deposit_balance       |" << data.occupy_deposit_balance;
    ogsDebug << "|open_price                   |" << data.open_price;
    ogsDebug << "|drop_income                  |" << data.drop_income;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|pre_settlement_price         |" << data.pre_settlement_price;
    ogsDebug << "|multiple                     |" << data.multiple;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[FuturesEntrustQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[FuturesEntrustQryOutput]==================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|pre_buy_frozen_balance       |" << data.pre_buy_frozen_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|exchange_report_no           |" << data.exchange_report_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesHistEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[FuturesHistEntrustQryInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesHistEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[FuturesHistEntrustQryOutput]================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|pre_buy_frozen_balance       |" << data.pre_buy_frozen_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==========[FuturesPortfolioSingleEntrustQryInput]===========";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|portfolio_type               |" << data.portfolio_type;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==========[FuturesPortfolioSingleEntrustQryOutput]==========";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|portfolio_type               |" << data.portfolio_type;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|limit_deal_amount            |" << data.limit_deal_amount;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|buy_deal_balance             |" << data.buy_deal_balance;
    ogsDebug << "|buy_deal_price               |" << data.buy_deal_price;
    ogsDebug << "|sell_deal_balance            |" << data.sell_deal_balance;
    ogsDebug << "|sell_deal_price              |" << data.sell_deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[FuturesRealDealQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|close_type                   |" << data.close_type;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[FuturesRealDealQryOutput]=================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|instance_no                  |" << data.instance_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|close_type                   |" << data.close_type;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesHistRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[FuturesHistRealDealQryInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|start_date                   |" << data.start_date;
    ogsDebug << "|end_date                     |" << data.end_date;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_serial_list          |" << data.entrust_serial_list;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesHistRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[FuturesHistRealDealQryOutput]===============";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|instance_no                  |" << data.instance_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesComboFundQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[FuturesComboFundQryInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const FuturesComboFundQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[FuturesComboFundQryOutput]=================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|occupy_deposit_balance       |" << data.occupy_deposit_balance;
    ogsDebug << "|enable_deposit_balance       |" << data.enable_deposit_balance;
    ogsDebug << "|futu_deposit_balance         |" << data.futu_deposit_balance;
    ogsDebug << "|futu_temp_occupy_deposit     |" << data.futu_temp_occupy_deposit;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "====================[StkOptEntrustInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|covered_flag                 |" << data.covered_flag;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[StkOptEntrustOutput]====================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptLockEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[StkOptLockEntrustInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptLockEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[StkOptLockEntrustOutput]==================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StkOptExerciseEntrustInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[StkOptExerciseEntrustOutput]================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[IndexOptionsMarketEntrustInput]==============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|buy_direction                |" << data.buy_direction;
    ogsDebug << "|buy_price                    |" << data.buy_price;
    ogsDebug << "|buy_amount                   |" << data.buy_amount;
    ogsDebug << "|sell_direction               |" << data.sell_direction;
    ogsDebug << "|sell_price                   |" << data.sell_price;
    ogsDebug << "|sell_amount                  |" << data.sell_amount;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[IndexOptionsMarketEntrustOutput]==============";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptShareTransferEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[StkOptShareTransferEntrustInput]==============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|buy_direction                |" << data.buy_direction;
    ogsDebug << "|buy_price                    |" << data.buy_price;
    ogsDebug << "|buy_amount                   |" << data.buy_amount;
    ogsDebug << "|sell_direction               |" << data.sell_direction;
    ogsDebug << "|sell_price                   |" << data.sell_price;
    ogsDebug << "|sell_amount                  |" << data.sell_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptShareTransferEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[StkOptShareTransferEntrustOutput]=============";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptCombiEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[StkOptCombiEntrustInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|covered_flag                 |" << data.covered_flag;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptCombiEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[StkOptCombiEntrustOutput]=================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[StkOptEntrustWithdrawCombiInput]==============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[StkOptEntrustWithdrawCombiOutput]=============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StkOptEntrustWithdrawInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[StkOptEntrustWithdrawOutput]================";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[IndexOptionsMarketWithdrawInput]==============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[IndexOptionsMarketWithdrawOutput]=============";
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[OptMarketEntrustWithdrawCombiInput]============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===========[OptMarketEntrustWithdrawCombiOutput]============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[OptMarketEntrustWithdrawInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[OptMarketEntrustWithdrawOutput]==============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawCombiInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=============[StkOptExerciseWithdrawCombiInput]=============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawCombiOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[StkOptExerciseWithdrawCombiOutput]=============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[StkOptExerciseWithdrawInput]================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[StkOptExerciseWithdrawOutput]===============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseBatchnoWithdrawInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "============[StkOptExerciseBatchnoWithdrawInput]============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseBatchnoWithdrawOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===========[StkOptExerciseBatchnoWithdrawOutput]============";
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|success_flag                 |" << data.success_flag;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsUftUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[OptionsUftUnitStkQryInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|option_type                  |" << data.option_type;
    ogsDebug << "|position_flag                |" << data.position_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsUftUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[OptionsUftUnitStkQryOutput]================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|option_type                  |" << data.option_type;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|begin_cost                   |" << data.begin_cost;
    ogsDebug << "|current_cost                 |" << data.current_cost;
    ogsDebug << "|pre_buy_amount               |" << data.pre_buy_amount;
    ogsDebug << "|pre_sell_amount              |" << data.pre_sell_amount;
    ogsDebug << "|pre_buy_balance              |" << data.pre_buy_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|today_buy_amount             |" << data.today_buy_amount;
    ogsDebug << "|today_sell_amount            |" << data.today_sell_amount;
    ogsDebug << "|today_buy_balance            |" << data.today_buy_balance;
    ogsDebug << "|today_sell_balance           |" << data.today_sell_balance;
    ogsDebug << "|today_buy_fee                |" << data.today_buy_fee;
    ogsDebug << "|today_sell_fee               |" << data.today_sell_fee;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[OptionsEntrustQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|option_type                  |" << data.option_type;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    ogsDebug << "|entrust_serial_list          |" << data.entrust_serial_list;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[OptionsEntrustQryOutput]==================";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|option_type                  |" << data.option_type;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|pre_buy_frozen_balance       |" << data.pre_buy_frozen_balance;
    ogsDebug << "|pre_sell_balance             |" << data.pre_sell_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|covered_flag                 |" << data.covered_flag;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|first_deal_time              |" << data.first_deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|withdraw_amount              |" << data.withdraw_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|exchange_report_no           |" << data.exchange_report_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsMarketEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[OptionsMarketEntrustQryInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsMarketEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[OptionsMarketEntrustQryOutput]===============";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|buy_direction                |" << data.buy_direction;
    ogsDebug << "|buy_covered_flag             |" << data.buy_covered_flag;
    ogsDebug << "|buy_price                    |" << data.buy_price;
    ogsDebug << "|buy_amount                   |" << data.buy_amount;
    ogsDebug << "|sell_direction               |" << data.sell_direction;
    ogsDebug << "|sell_covered_flag            |" << data.sell_covered_flag;
    ogsDebug << "|sell_price                   |" << data.sell_price;
    ogsDebug << "|sell_amount                  |" << data.sell_amount;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|buy_deal_amount              |" << data.buy_deal_amount;
    ogsDebug << "|buy_deal_balance             |" << data.buy_deal_balance;
    ogsDebug << "|sell_deal_amount             |" << data.sell_deal_amount;
    ogsDebug << "|sell_deal_balance            |" << data.sell_deal_balance;
    ogsDebug << "|buy_cancel_amount            |" << data.buy_cancel_amount;
    ogsDebug << "|sell_cancel_amount           |" << data.sell_cancel_amount;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[OptionsRealDealQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|option_type                  |" << data.option_type;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    ogsDebug << "|entrust_serial_list          |" << data.entrust_serial_list;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[OptionsRealDealQryOutput]=================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|instance_no                  |" << data.instance_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|option_type                  |" << data.option_type;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsDepositQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[OptionsDepositQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const OptionsDepositQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[OptionsDepositQryOutput]==================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|occupy_deposit_balance       |" << data.occupy_deposit_balance;
    ogsDebug << "|enable_deposit_balance       |" << data.enable_deposit_balance;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StkOptDepositEntrustInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|combistrategy_id             |" << data.combistrategy_id;
    ogsDebug << "|combi_direction              |" << data.combi_direction;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|mac_address                  |" << data.mac_address;
    ogsDebug << "|ip_address                   |" << data.ip_address;
    ogsDebug << "|hd_volserial                 |" << data.hd_volserial;
    ogsDebug << "|op_station                   |" << data.op_station;
    ogsDebug << "|terminal_info                |" << data.terminal_info;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StkOptDepositEntrustOutput]================";
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|entrust_fail_code            |" << data.entrust_fail_code;
    ogsDebug << "|fail_cause                   |" << data.fail_cause;
    ogsDebug << "|risk_serial_no               |" << data.risk_serial_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|combi_direction              |" << data.combi_direction;
    ogsDebug << "|risk_no                      |" << data.risk_no;
    ogsDebug << "|risk_type                    |" << data.risk_type;
    ogsDebug << "|risk_summary                 |" << data.risk_summary;
    ogsDebug << "|risk_operation               |" << data.risk_operation;
    ogsDebug << "|remark_short                 |" << data.remark_short;
    ogsDebug << "|risk_threshold_value         |" << data.risk_threshold_value;
    ogsDebug << "|risk_value                   |" << data.risk_value;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[StkOptDepositUnitStkQryInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[StkOptDepositUnitStkQryOutput]===============";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|combistrategy_id             |" << data.combistrategy_id;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|position_flag1               |" << data.position_flag1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|position_flag2               |" << data.position_flag2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|position_flag3               |" << data.position_flag3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|position_flag4               |" << data.position_flag4;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|frozen_amount                |" << data.frozen_amount;
    ogsDebug << "|combi_deposit_pre            |" << data.combi_deposit_pre;
    ogsDebug << "|combi_deposit_now            |" << data.combi_deposit_now;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===============[StkOptDepositEntrustQryInput]===============";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|combi_direction              |" << data.combi_direction;
    ogsDebug << "|entrust_state_list           |" << data.entrust_state_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==============[StkOptDepositEntrustQryOutput]===============";
    ogsDebug << "|entrust_date                 |" << data.entrust_date;
    ogsDebug << "|entrust_time                 |" << data.entrust_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|report_no                    |" << data.report_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|combistrategy_id             |" << data.combistrategy_id;
    ogsDebug << "|combi_direction              |" << data.combi_direction;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_state                |" << data.entrust_state;
    ogsDebug << "|withdraw_cause               |" << data.withdraw_cause;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StkOptDepositDealQryInput]=================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|combi_direction              |" << data.combi_direction;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|position_str                 |" << data.position_str;
    ogsDebug << "|request_num                  |" << data.request_num;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "================[StkOptDepositDealQryOutput]================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|combistrategy_code           |" << data.combistrategy_code;
    ogsDebug << "|stock_code1                  |" << data.stock_code1;
    ogsDebug << "|stock_code2                  |" << data.stock_code2;
    ogsDebug << "|stock_code3                  |" << data.stock_code3;
    ogsDebug << "|stock_code4                  |" << data.stock_code4;
    ogsDebug << "|combistrategy_id             |" << data.combistrategy_id;
    ogsDebug << "|combi_direction              |" << data.combi_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|position_str                 |" << data.position_str;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[CombUnitStkQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[CombUnitStkQryOutput]===================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|current_cost                 |" << data.current_cost;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombUftUnitStkQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[CombUftUnitStkQryInput]==================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no_list               |" << data.market_no_list;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|invest_type                  |" << data.invest_type;
    ogsDebug << "|position_flag                |" << data.position_flag;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombUftUnitStkQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "=================[CombUftUnitStkQryOutput]==================";
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|hold_seat                    |" << data.hold_seat;
    ogsDebug << "|position_flag                |" << data.position_flag;
    ogsDebug << "|current_amount               |" << data.current_amount;
    ogsDebug << "|enable_amount                |" << data.enable_amount;
    ogsDebug << "|pri_enable_amount            |" << data.pri_enable_amount;
    ogsDebug << "|begin_balance                |" << data.begin_balance;
    ogsDebug << "|current_cost                 |" << data.current_cost;
    ogsDebug << "|pre_buy_amount               |" << data.pre_buy_amount;
    ogsDebug << "|pre_sell_amount              |" << data.pre_sell_amount;
    ogsDebug << "|pre_buy_balance              |" << data.pre_buy_balance;
    ogsDebug << "|pre_sale_balance             |" << data.pre_sale_balance;
    ogsDebug << "|buy_amount                   |" << data.buy_amount;
    ogsDebug << "|sell_amount                  |" << data.sell_amount;
    ogsDebug << "|buy_balance                  |" << data.buy_balance;
    ogsDebug << "|sale_balance                 |" << data.sale_balance;
    ogsDebug << "|buy_fee                      |" << data.buy_fee;
    ogsDebug << "|sale_fee                     |" << data.sale_fee;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombEntrustQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[CombEntrustQryInput]====================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no_list               |" << data.market_no_list;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|entrust_status_list          |" << data.entrust_status_list;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombEntrustQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[CombEntrustQryOutput]===================";
    ogsDebug << "|business_date                |" << data.business_date;
    ogsDebug << "|business_time                |" << data.business_time;
    ogsDebug << "|operator_no                  |" << data.operator_no;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|price_type                   |" << data.price_type;
    ogsDebug << "|entrust_price                |" << data.entrust_price;
    ogsDebug << "|entrust_amount               |" << data.entrust_amount;
    ogsDebug << "|prebuy_frozen_balance        |" << data.prebuy_frozen_balance;
    ogsDebug << "|presale_balance              |" << data.presale_balance;
    ogsDebug << "|confirm_no                   |" << data.confirm_no;
    ogsDebug << "|entrust_status               |" << data.entrust_status;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_times                   |" << data.deal_times;
    ogsDebug << "|cancel_amount                |" << data.cancel_amount;
    ogsDebug << "|revoke_cause                 |" << data.revoke_cause;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombRealDealQryInput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "===================[CombRealDealQryInput]===================";
    ogsDebug << "|user_token                   |" << data.user_token;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no_list               |" << data.market_no_list;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|stock_type                   |" << data.stock_type;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|batch_no                     |" << data.batch_no;
    ogsDebug << "|report_seat                  |" << data.report_seat;
    return logger;
}
OgsLogger& operator << (OgsLogger& logger, const CombRealDealQryOutput& data)
{
    LOCK_OGSLOGGER(logger);
    ogsDebug << "==================[CombRealDealQryOutput]===================";
    ogsDebug << "|deal_date                    |" << data.deal_date;
    ogsDebug << "|deal_no                      |" << data.deal_no;
    ogsDebug << "|entrust_no                   |" << data.entrust_no;
    ogsDebug << "|extsystem_id                 |" << data.extsystem_id;
    ogsDebug << "|third_reff                   |" << data.third_reff;
    ogsDebug << "|account_code                 |" << data.account_code;
    ogsDebug << "|asset_no                     |" << data.asset_no;
    ogsDebug << "|combi_no                     |" << data.combi_no;
    ogsDebug << "|instance_no                  |" << data.instance_no;
    ogsDebug << "|stockholder_id               |" << data.stockholder_id;
    ogsDebug << "|market_no                    |" << data.market_no;
    ogsDebug << "|stock_code                   |" << data.stock_code;
    ogsDebug << "|entrust_direction            |" << data.entrust_direction;
    ogsDebug << "|futures_direction            |" << data.futures_direction;
    ogsDebug << "|deal_amount                  |" << data.deal_amount;
    ogsDebug << "|deal_price                   |" << data.deal_price;
    ogsDebug << "|deal_balance                 |" << data.deal_balance;
    ogsDebug << "|total_fee                    |" << data.total_fee;
    ogsDebug << "|deal_time                    |" << data.deal_time;
    return logger;
}
