/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#ifndef PBUFXREADER_H
#define PBUFXREADER_H

#include <pbufx/t2sdk_interface.h>

class PbUfxReader
{
public:
    static void freePacker(IF2Packer* packer);
    static void freeUnPacker(IF2UnPacker* unPacker);
};

#endif // PBUFXREADER_H
