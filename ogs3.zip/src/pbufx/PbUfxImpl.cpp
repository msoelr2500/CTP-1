﻿/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxImpl.h"
#include <qtp_log.h>
#include <iostream>
#include "../BufferHandle.h"
#include "../ReadConfig.h"
#include "../OgsApi.h"
#include "PbUfxConverter.h"
#include <qtp_log.h>

using ogs::PackBuffer;
using ogs::UnpackBuffer;
using ogs::ReadConfig;
using namespace std;

PbUfxClientManager PbUfxImpl::mClients;

PbUfxImpl::PbUfxImpl()
{
    PbUfxConfig config;
    config.mOperatorNo      = ReadConfig::localOption.Reserve1;
    config.mOperatorPasswd  = ReadConfig::localOption.Reserve2;
    config.mAuthorizationId = ReadConfig::localOption.Reserve3;
    config.mSiteInfoFormat  = ReadConfig::localOption.SiteInfoFormat;
    // config.mTerminalInfo 被忽略。

    mConnection.setConfig(config);
}

PbUfxImpl::~PbUfxImpl() {}

bool PbUfxImpl::initialize()
{
    return mConnection.initialize();
}

bool PbUfxImpl::connect()
{
    return mConnection.connect();
}

void PbUfxImpl::disconnect()
{
    mConnection.disconnect();
}

Intf_RetType PbUfxImpl::heartBeatToBroker()
{
    return kIntfNotSupport;
}

void PbUfxImpl::setCallBack(int (*fn)(ogs::QueryOrderAns))
{
    func = fn;
}

bool PbUfxImpl::isConnected() const
{
    return mConnection.isConnected();
}

/*!
 * \brief 登陆
 *
 * PB-UFX以柜员号（operator_no）表示一个账户，登陆时根据该柜员号获取其账户代码（字符串account_code）。
 * 进行业务操作时，ogs输入的有效账户信息只有资金账户（客户号无效），所以必须使用资金帐户来获取所有账户
 * 信息。
 */
Intf_RetType PbUfxImpl::ogsLogin(const ogs::LoginQry &in, list<ogs::LoginAns> &out, string &errMsg, map<int, string> &args)
{
    out.clear();

    // 设置输入。
    AmUserLoginInput loginInput;
    loginInput.operator_no      = mConnection.config().mOperatorNo;
    loginInput.password         = mConnection.config().mOperatorPasswd;
    PbUfxConverter::to_mac_address (loginInput.mac_address,  in.macAddr);
    PbUfxConverter::to_ip_address  (loginInput.ip_address,   in.ipAddr);
    PbUfxConverter::to_hd_volserial(loginInput.hd_volserial, in.diskSn);
    loginInput.op_station       = op_station(args);
    loginInput.terminal_info    = mConnection.config().mTerminalInfo;
    loginInput.authorization_id = mConnection.config().mAuthorizationId;

    // 调用接口。
    list<AmUserLoginOutput> loginOutput;
    Intf_RetType loginResult = mConnection.pbufxAmUserLogin(loginInput, loginOutput, errMsg);
    if (kIntfSuccess != loginResult) {
        return loginResult;
    }

    // 处理输出。
    for (AmUserLoginOutput& item : loginOutput) {
        // 查询登陆操作员有操作权限的账户列表。
        AmFundQueryInput clientQryInput;
        clientQryInput.user_token = item.user_token;

        list<AmFundQueryOutput> clientQryOutputList;
        Intf_RetType clientQryResult = mConnection.pbufxAmFundQuery(clientQryInput, clientQryOutputList, errMsg);
        if (clientQryResult != kIntfSuccess) {
            return clientQryResult;
        }

        // 处理输出结果。
        for (AmFundQueryOutput& clientQryOutputItem : clientQryOutputList) {
            mClients.removeClient(clientQryOutputItem.account_code);
        }

        for (AmFundQueryOutput& clientQryOutputItem : clientQryOutputList) {
            if (mClients.hasClients(clientQryOutputItem.account_code)) continue;

            PbUfxClient client;
            client.client_id              = clientQryOutputItem.account_code;
            client.mData.account_code     = clientQryOutputItem.account_code;
            client.mData.account_name     = clientQryOutputItem.account_name;
            client.mData.account_type     = clientQryOutputItem.account_type;
            client.mData.user_token       = item.user_token;
            client.mData.operator_no      = loginInput.operator_no;
            client.mData.op_station       = op_station(args);
            client.mData.terminal_info    = loginInput.terminal_info;
            client.mData.authorization_id = loginInput.authorization_id;

            // 查询登陆操作员有操作权限的资产单元列表。
            AmAssetQueryInput input;
            input.user_token = client.mData.user_token;
            input.account_code = clientQryOutputItem.account_code;

            list<AmAssetQueryOutput> assetQueryOutputList;
            Intf_RetType pbufxAmAssetQueryResult = mConnection.pbufxAmAssetQuery(input, assetQueryOutputList, errMsg);
            if (kIntfSuccess != pbufxAmAssetQueryResult) {
                return pbufxAmAssetQueryResult;
            }

            // 处理输出结果。
            for (AmAssetQueryOutput& assetQryOutputItem : assetQueryOutputList) {
                PbUfxFundAccount account;
                account.fund_account       = assetQryOutputItem.capital_account;
                account.mData.account_code = assetQryOutputItem.account_code;
                account.mData.asset_no     = assetQryOutputItem.asset_no;
                account.mData.asset_name   = assetQryOutputItem.asset_name;

                if (!client.hasFundAccount(assetQryOutputItem.capital_account)) {
                    ogs::LoginAns ans = {0};
                    PbUfxConverter::from_capital_account(ans.bacid, assetQryOutputItem.capital_account);
                    out.push_back(ans);
                } else {
                    continue;
                }

                // 分别获取每个资金账户名下的股东账户。
                AmHolderQueryInput holderQryInput;
                holderQryInput.user_token   = client.mData.user_token;
                holderQryInput.account_code = account.mData.account_code;
                holderQryInput.asset_no     = account.mData.asset_no;

                list<AmHolderQueryOutput> holderQryOutputList;
                Intf_RetType holderQryResult = mConnection.pbufxAmHolderQuery(holderQryInput, holderQryOutputList, errMsg);
                if (kIntfSuccess != holderQryResult) {
                    return holderQryResult;
                }

                // 处理输出结果。
                for (AmHolderQueryOutput& holderQryOutputItem : holderQryOutputList) {
                    Exchange exchange = PbUfxConverter::to_exchange_index(holderQryOutputItem.market_no);
                    if (!AccountHelper::isExchangeValid(exchange)) continue;

                    PbUfxTradeAccount& tradeAccount = account[exchange];
                    tradeAccount.stock_account = holderQryOutputItem.stockholder_id;
                    tradeAccount.account_code  = holderQryOutputItem.account_code;
                    tradeAccount.combi_no      = holderQryOutputItem.combi_no;
                    tradeAccount.market_no     = holderQryOutputItem.market_no;
                    tradeAccount.asset_no      = holderQryOutputItem.asset_no;
                    tradeAccount.enabled       = true;
                }
                client.addNewFundAccount(account);
            }
            mClients.addNewClient(client);
        }
    }

    mClients.printAccounts();

    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsSendOrder(const ogs::SendOrderQry &in, list<ogs::SendOrderAns> &out, string &errMsg, map<int, string> &args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    ogs::parseInnerCode(in.innerCode, code, market, sc);

    // 查找指定账户。
    PbUfxClientData clientData = mClients.clientDataByFundAccount(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxTradeAccount tradeAccount = mClients.tradeAccount(PbUfxConverter::to_fund_account(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    SecuEntrustInput input;
    input.user_token        = clientData.user_token;
    input.account_code      = clientData.account_code;
    input.asset_no          = tradeAccount.asset_no;
    input.stockholder_id    = tradeAccount.stock_account;
    input.market_no         = tradeAccount.market_no;
    input.combi_no          = tradeAccount.combi_no;
    input.stock_code        = code;
    input.entrust_direction = PbUfxConverter::to_entrust_direction(in.directive);
    input.price_type        = PbUfxConverter::to_price_type(in.execution);
    input.entrust_price     = PbUfxConverter::to_entrust_price(in.price);
    input.entrust_amount    = PbUfxConverter::to_entrust_amount(in.volume);
    input.mac_address       = in.macAddr;
    input.ip_address        = in.ipAddr;
    input.hd_volserial      = in.diskSn;
    input.op_station        = op_station(args);
    input.terminal_info     = clientData.terminal_info;

    // 调用接口。
    list<SecuEntrustOutput> output;
    Intf_RetType result = mConnection.pbufxSecuEntrust(input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustOutput& item : output) {
        ogs::SendOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        PbUfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsCancelOrder(const ogs::CancelOrderQry &in, list<ogs::CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    PbUfxClientData clientData = mClients.clientDataByFundAccount(PbUfxConverter::to_fund_account(in.bacid));

    // 设置输入。
    SecuEntrustWithdrawInput input;
    input.user_token    = clientData.user_token;
    input.entrust_no    = PbUfxConverter::to_entrust_no(in.sysOrderId);
    PbUfxConverter::to_mac_address(input.mac_address, in.macAddr);
    PbUfxConverter::to_ip_address(input.ip_address, in.ipAddr);
    PbUfxConverter::to_hd_volserial(input.hd_volserial, in.diskSn);
    input.op_station    = op_station(args);
    input.terminal_info = clientData.terminal_info;

    // 调用接口。
    list<SecuEntrustWithdrawOutput> output;
    Intf_RetType result = mConnection.pbufxSecuEntrustWithdraw(input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustWithdrawOutput& item : output) {
        ogs::CancelOrderAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        ans.custOrderId = in.custOrderId;
        PbUfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsQueryOrder(const ogs::QueryOrderQry &in, list<ogs::QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    ogs::parseInnerCode(in.innerCode, code, market, sc);

    // 查找指定账户。
    PbUfxClientData clientData = mClients.clientDataByFundAccount(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxFundAccountData fundAccountData = mClients.fundAccountData(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxTradeAccount tradeAccount = mClients.tradeAccount(PbUfxConverter::to_fund_account(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    SecuEntrustQryInput input;
    input.user_token     = clientData.user_token;
    input.entrust_no     = PbUfxConverter::to_entrust_no(in.sysOrderId);
    input.account_code   = clientData.account_code;
    input.asset_no       = fundAccountData.asset_no;
    input.combi_no       = tradeAccount.combi_no;
    input.stockholder_id = tradeAccount.stock_account;
    input.market_no      = tradeAccount.market_no;
    input.stock_code     = code;
    input.entrust_direction = PbUfxConverter::to_entrust_direction(in.directive);

    // 调用接口。
    list<SecuEntrustQryOutput> output;
    Intf_RetType result = mConnection.pbufxSecuEntrustQry(input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuEntrustQryOutput& item : output) {
        ogs::QueryOrderAns ans = {0};
        PbUfxConverter::from_capital_account(ans.bacid, mClients.fundAccountByTradeAccount(item.stockholder_id));
        ans.custOrderId    = in.custOrderId;
        PbUfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        ans.price          = PbUfxConverter::from_entrust_price(item.entrust_price);
        ans.volume         = PbUfxConverter::from_entrust_amount(item.entrust_amount);
        ans.orderStatus    = PbUfxConverter::from_entrust_state(item.entrust_state);
        ans.dealVolume     = PbUfxConverter::from_deal_amount(item.deal_amount);
        ans.dealPrice      = PbUfxConverter::from_deal_price(item.deal_price);
        ans.dealBalance    = PbUfxConverter::from_deal_balance(item.deal_balance);
        ans.innerCode      = qtp::UniversalCode::SymbolToUC(item.stock_code);
        ans.withdrawVolume = PbUfxConverter::from_withdraw_amount(item.withdraw_amount);
        ans.tradeDate      = PbUfxConverter::from_entrust_date(item.entrust_date);
        ans.orderTime      = PbUfxConverter::from_entrust_time(item.entrust_time);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsQueryPosition(const ogs::QueryPositionQry &in, list<ogs::QueryPositionAns> &out, string &errMsg, map<int, string> &args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    ogs::parseInnerCode(in.innerCode, code, market, sc);

    // 查找指定账户。
    PbUfxClientData clientData = mClients.clientDataByFundAccount(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxFundAccountData fundAccountData = mClients.fundAccountData(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxTradeAccount tradeAccount = mClients.tradeAccount(PbUfxConverter::to_fund_account(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    SecuUnitStkQryInput input;
    input.user_token     = clientData.user_token;
    input.account_code   = clientData.account_code;
    input.asset_no       = fundAccountData.asset_no;
    input.combi_no       = tradeAccount.combi_no;
    input.market_no      = tradeAccount.market_no;
    input.stock_code     = code;
    input.stockholder_id = tradeAccount.stock_account;

    // 调用接口。
    list<SecuUnitStkQryOutput> output;
    Intf_RetType result = mConnection.pbufxSecuUnitStkQry(input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuUnitStkQryOutput& item : output) {
        ogs::QueryPositionAns ans = {0};
        strcpy(ans.acidcard, in.acidcard);
        PbUfxConverter::from_capital_account(ans.bacid, mClients.fundAccountByTradeAccount(item.stockholder_id));
        ans.currentVolume = PbUfxConverter::from_current_amount(item.current_amount);
        ans.usableVolume  = PbUfxConverter::from_enable_amount(item.enable_amount);
        ans.innerCode     = PbUfxConverter::from_stock_code(item.stock_code);
        out.push_back(ans);
    }
    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsQueryBargain(const ogs::QueryBargainQry &in, list<ogs::QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    string code;
    qtp::MarketCode market;
    qtp::SecurityCategory sc;
    ogs::parseInnerCode(in.innerCode, code, market, sc);

    // 查找指定账户。
    PbUfxClientData clientData = mClients.clientDataByFundAccount(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxFundAccountData fundAccountData = mClients.fundAccountData(PbUfxConverter::to_fund_account(in.bacid));
    PbUfxTradeAccount tradeAccount = mClients.tradeAccount(PbUfxConverter::to_fund_account(in.bacid),
                                                          AccountHelper::toExchange(market));

    // 设置输入。
    SecuRealDealQryInput input;
    input.user_token     = clientData.user_token;
    input.account_code   = clientData.account_code;
    input.asset_no       = fundAccountData.asset_no;
    input.combi_no       = tradeAccount.combi_no;
    input.entrust_no     = PbUfxConverter::to_entrust_no(in.sysOrderId);
    input.stockholder_id = tradeAccount.stock_account;
    input.market_no      = tradeAccount.market_no;
    input.stock_code     = code;

    // 调用接口。
    list<SecuRealDealQryOutput> output;
    Intf_RetType result = mConnection.pbufxSecuRealDealQry(input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (SecuRealDealQryOutput& item : output) {
        ogs::QueryBargainAns ans = {0};
        PbUfxConverter::from_capital_account(ans.bacid, mClients.fundAccountByTradeAccount(item.stockholder_id));
        ans.custOrderId    = in.custOrderId;
        ans.dealVolume     = PbUfxConverter::from_deal_amount(item.deal_amount);
        ans.dealPrice      = PbUfxConverter::from_deal_price(item.deal_price);
        ans.dealBalance    = PbUfxConverter::from_deal_balance(item.deal_balance);
        ans.innerCode      = qtp::UniversalCode::SymbolToUC(item.stock_code);
        PbUfxConverter::from_entrust_no(item.entrust_no, ans.sysOrderId);
        PbUfxConverter::from_deal_no(item.deal_no, ans.dealId);
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsQueryFundInfo(const ogs::QueryFundInfoQry &in, list<ogs::QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    out.clear();

    // 查找指定账户。
    string fund_account = PbUfxConverter::to_fund_account(in.bacid);
    PbUfxClientData clientData = mClients.clientDataByFundAccount(fund_account);
    PbUfxFundAccountData fundAccountData = mClients.fundAccountData(fund_account);

    // 设置输入。
    SecuComboFundQryInput input;
    input.user_token = clientData.user_token;
    input.account_code = clientData.account_code;
    input.asset_no = fundAccountData.asset_no;

    // 调用接口。
    list<SecuComboFundQryOutput> output;
    Intf_RetType result = mConnection.pbufxSecuComboFundQry(input, output, errMsg);
    if (kIntfSuccess != result) {
        return result;
    }

    // 处理输出。
    for (const SecuComboFundQryOutput& item : output) {
        ogs::QueryFundInfoAns ans = {0};
        strcpy(ans.bacid, in.bacid);
        strcpy(ans.acidcard, in.acidcard);
        ans.balance        = PbUfxConverter::from_current_balance(item.current_balance);
        ans.useableBalance = PbUfxConverter::from_enable_balance(item.enable_balance_t0) +
                             PbUfxConverter::from_enable_balance(item.enable_balance_t1);
        ans.frozenBalance  = ans.balance - ans.useableBalance;
        out.push_back(ans);
    }

    return kIntfSuccess;
}

Intf_RetType PbUfxImpl::ogsPaybackSecurity(const ogs::PaybackSecurityQry &in, list<ogs::PaybackSecurityAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

Intf_RetType PbUfxImpl::ogsPaybackFunds(const ogs::PaybackFundsQry &in, list<ogs::PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return kIntfNotSupport;
}

string PbUfxImpl::op_station(std::map<int, string> &args)
{
    // 默认使用配置文件中的站点信息格式。
    if (!mConnection.config().mSiteInfoFormat.empty()) {
        return ogs::SiteInfo(mConnection.config().mSiteInfoFormat, args);
    }

    // 配置文件中未制定站点信息格式，则使用默认格式。
    string client_ip = args[1];
    string mac       = args[2];
    string disksn    = args[3];
    string cpuid     = args[4];
    string wip       = args[5];

    return PbUfxConverter::op_station(wip, client_ip, mac, disksn, cpuid);
}
