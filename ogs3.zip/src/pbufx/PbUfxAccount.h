/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#ifndef PBUFXACCOUNT_H
#define PBUFXACCOUNT_H

#include "../AccountManager.h"

class PbUfxTradeAccount : public TradeAccount
{
public:
    std::string account_code;       //!< 账户编号
    std::string asset_no;           //!< 资产单元编号
    std::string combi_no;           //!< 组合编号
    std::string market_no;          //!< 交易市场
};

struct PbUfxFundAccountData
{
    std::string account_code;       //!< 账户编号
    std::string asset_no;           //!< 资产单元编号
    std::string asset_name;         //!< 资产单元名称
};

class PbUfxFundAccount : public FundAccount<PbUfxTradeAccount>
{
public:
    PbUfxFundAccountData mData;
};

struct PbUfxClientData {
    std::string operator_no;        //!< 操作员编号
    std::string op_station;         //!< 登录站点
    std::string user_token;         //!< 令牌号
    std::string terminal_info;      //!< 终端信息
    std::string authorization_id;   //!< 开发者授权编号
    //--------------------------------------------------
    std::string account_code;       //!< 账户编号
    std::string account_name;       //!< 账户名称
    std::string account_type;       //!< 账户类型
};

class PbUfxClient : public Client<PbUfxFundAccount>
{
public:
    PbUfxClientData mData;
};

class PbUfxClientManager : public ClientManager<PbUfxClient>
{
public:
    PbUfxClientData clientData(const std::string client_id) {
        lock_data(this);
        int index = findClientById(client_id);
        if (index < 0) {
            return PbUfxClientData();
        }
        return this->at(index).mData;
    }

    PbUfxClientData clientDataByFundAccount(const std::string fund_account) {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0) {
            return PbUfxClientData();
        }
        return this->at(index).mData;
    }

    PbUfxFundAccountData fundAccountData(const std::string& fund_account) {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0) {
            return PbUfxFundAccountData();
        }
        PbUfxClient& client = this->at(index);
        return client.at(client.indexOf(fund_account)).mData;
    }

    PbUfxTradeAccount tradeAccount(const std::string& fund_account, Exchange exchange)
    {
        lock_data(this);
        int index = findClientByFundAccount(fund_account);
        if (index < 0 || !AccountHelper::isExchangeValid(exchange)) {
            return PbUfxTradeAccount();
        }
        return this->at(index).at(this->at(index).indexOf(fund_account))[exchange];
    }

    std::string fundAccountByTradeAccount(const std::string& trade_account)
    {
        lock_data(this);
        int index = findClientByTradeAccount(trade_account);
        if (index >= 0) {
            const PbUfxClient& client = this->at(index);
            int fIndex = client.fundAccountIndexByTradeAccount(trade_account);
            if (fIndex >= 0) {
                return client.at(fIndex).fund_account;
            }
        }
        return std::string();
    }
};

#endif // PBUFXACCOUNT_H
