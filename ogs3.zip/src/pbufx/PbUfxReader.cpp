/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxReader.h"

void PbUfxReader::freePacker(IF2Packer *packer)
{
    packer->FreeMem(packer->GetPackBuf());
    packer->Release();
}

void PbUfxReader::freeUnPacker(IF2UnPacker *unPacker)
{
    unPacker->Release();
}
