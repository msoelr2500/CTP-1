/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxInterface.h"

using namespace std;

namespace ogs {

PbUfxInterface::PbUfxInterface()
{
    LOG(info) << "创建了一个PBUFX接口对象";
}

PbUfxInterface::~PbUfxInterface()
{

}

bool PbUfxInterface::getConnectStatus()
{
    return pbufxImpl.isConnected();
}

Intf_RetType PbUfxInterface::initCommon()
{
    static int counter = 1;

    if(pbufxImpl.initialize()){
        LOG(info) << "[ufx] 初始化[" << counter << "]:成功";
        counter++;
        return kIntfSuccess;
    }
    LOG(info) << "[ufx] 初始化失败";
    return kIntfFail;
}

Intf_RetType PbUfxInterface::initSubscribe()
{
    LOG(info) << "[ufx] 初始化订阅功能";
    return kIntfFail;
}

Intf_RetType PbUfxInterface::connectBroker()
{
    if(pbufxImpl.connect()){
        LOG(info) << "[ufx] 已经连接券商服务器";
        return kIntfSuccess;
    }
    return kIntfFail;
}

Intf_RetType PbUfxInterface::reConnectBroker()
{
    if(pbufxImpl.isConnected()){
        pbufxImpl.disconnect();
    }
    return connectBroker();
}

Intf_RetType PbUfxInterface::heartBeatToBroker()
{
    LOG(info) << "[ufx] heartBeatToBroker";
    return pbufxImpl.heartBeatToBroker();
}

void PbUfxInterface::setCallBack(int (*fn)(QueryOrderAns))
{
    pbufxImpl.setCallBack(fn);
}

Intf_RetType PbUfxInterface::ogsLogin(const LoginQry &in, list<LoginAns> &out, string &errMsg, map<int, string> &args)
{
    return pbufxImpl.ogsLogin(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsSendOrder(const SendOrderQry &in, list<SendOrderAns> &out, string &errMsg, map<int, string> &args)
{
    return pbufxImpl.ogsSendOrder(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsCancelOrder(const CancelOrderQry &in, list<CancelOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return pbufxImpl.ogsCancelOrder(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsQueryOrder(const QueryOrderQry &in, list<QueryOrderAns> &out, string &errMsg, map<int, string>& args)
{
    return pbufxImpl.ogsQueryOrder(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsQueryPosition(const QueryPositionQry &in, list<QueryPositionAns> &out, string &errMsg, map<int, string>& args)
{
    return pbufxImpl.ogsQueryPosition(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsQueryBargain(const QueryBargainQry &in, list<QueryBargainAns> &out, string &errMsg, map<int, string>& args)
{
    return pbufxImpl.ogsQueryBargain(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsQueryFundInfo(const QueryFundInfoQry &in, list<QueryFundInfoAns> &out, string &errMsg, map<int, string>& args)
{
    return pbufxImpl.ogsQueryFundInfo(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsPaybackSecurity(const PaybackSecurityQry &in, list<PaybackSecurityAns> &out, string &errMsg, map<int, string> &args)
{
    return pbufxImpl.ogsPaybackSecurity(in, out, errMsg, args);
}

Intf_RetType PbUfxInterface::ogsPaybackFunds(const PaybackFundsQry &in, list<PaybackFundsAns> &out, string &errMsg, map<int, string>& args)
{
    return pbufxImpl.ogsPaybackFunds(in, out, errMsg, args);
}

}
