/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxConverter.h"
#include <string.h>

using std::string;

using ogs::ogs_dict::ExecutionType;
using ogs::ogs_dict::OrderStatusType;
using qtp::MarketCode;
using ogs::ogs_dict::DirectiveType;

string PbUfxConverter::op_station(const string &wip, const std::string& clientIp, const string &mac, const string &disksn, const string &cpuid)
{
    string result;
    StringHelper::string_format(result, "TYJR-LHHJ- IIP.%s LIP.%s MAC.%s HD.%s CPU.%s",
                                         wip.c_str(), clientIp.c_str(), mac.c_str(), disksn.c_str(), cpuid.c_str());
    return result;
}

void PbUfxConverter::to_mac_address(std::string &mac_address, const char *macAddr)
{
    if (macAddr) mac_address = macAddr;
}

void PbUfxConverter::to_ip_address(std::string &ip_address, const char *ipAddr)
{
    if (ipAddr) ip_address = ipAddr;
}

void PbUfxConverter::to_hd_volserial(std::string &hd_volserial, const char *diskSn)
{
    if (diskSn) hd_volserial = diskSn;
}

std::string PbUfxConverter::to_stock_account(PbUfxFundAccount &account, qtp::MarketCode market)
{
    Exchange exchange = AccountHelper::toExchange(market);
    if (AccountHelper::isExchangeValid(exchange)) {
        return account[exchange].stock_account;
    }
    return string("");
}

std::string PbUfxConverter::to_input_content(ogs::OGS_ACTYPE actype)
{
    return std::to_string(actype);
}

std::string PbUfxConverter::to_password(const char *password)
{
    return string(password);
}

std::string PbUfxConverter::to_entrust_no(const char *sysOrderId)
{
    return string(sysOrderId);
}

std::string PbUfxConverter::to_amount(ogs::OGS_VOLUME volume)
{
    return std::to_string(volume);
}

std::string PbUfxConverter::to_entrust_type(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
        return string("0");
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
        return string("7");
    case ogs::ogs_dict::kDtLoanBuy:
        return string("6");
    default: return string();
    }
}

std::string PbUfxConverter::to_exchange_type(qtp::MarketCode code)
{
    switch(code){
    case qtp::kMC_SSE: return string("1");
    case qtp::kMC_CFFE: return string("F4");
    case qtp::kMC_SZE: return string("2");
    case qtp::kMC_UNKNOW: dafault: return string();
    }
}

std::string PbUfxConverter::to_stock_code(const std::string &code)
{
    if (code == "000000") {
        return string("");
    }
    return code;
}

std::string PbUfxConverter::to_price_type(ogs::OGS_EXECUTION execution)
{
    switch (execution) {
    case ogs::ogs_dict::kExeLimit: return string("0");
    default: return string();
    }
}

std::string PbUfxConverter::to_entrust_direction(ogs::OGS_DIRECTIVE type)
{
    switch (type) {
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtGuaranteeBuy:
        return string("1");
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtGuaranteeSell:
        return string("2");
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtMarketMarginSell:
        return string("67");
    case ogs::ogs_dict::kDtLoanBuy:
        return string("75");
    case ogs::ogs_dict::kDtMarketSecPayback:
    case ogs::ogs_dict::kDtSecPayback:
        return string("70");
    case ogs::ogs_dict::kDtSellPayBack:
        return string("76");
    case ogs::ogs_dict::kDtCashRepay:
        return string("69");
    default: return string();
    }
}

std::string PbUfxConverter::to_entrust_prop(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtLoanBuy:
        return string("0");
    case ogs::ogs_dict::kDtGuaranteeBuy:
    case ogs::ogs_dict::kDtGuaranteeSell:
    case ogs::ogs_dict::kDtMarketSecPayback:
    case ogs::ogs_dict::kDtSecPayback:
    case ogs::ogs_dict::kDtBuyPayback:
    /*! \todo ogs_dict出现了字段变动。
    case ogs::ogs_dict::kDtApplyParch:
        return string("3");
    case ogs::ogs_dict::kDTRedemption:
        return string("4");
    *********************************/
    default: return string();
    }
}

std::string PbUfxConverter::to_asset_prop(ogs::OGS_DIRECTIVE type)
{
    switch(type){
    case ogs::ogs_dict::kDtBuy:
    case ogs::ogs_dict::kDtSell:
        return string("0");
    case ogs::ogs_dict::kDtMarketMarginSell:
    case ogs::ogs_dict::kDtMarginSell:
    case ogs::ogs_dict::kDtLoanBuy:
        return string("7");
    case ogs::ogs_dict::kDtGuaranteeBuy:
    case ogs::ogs_dict::kDtGuaranteeSell:
    case ogs::ogs_dict::kDtMarketSecPayback:
    case ogs::ogs_dict::kDtSecPayback:
    case ogs::ogs_dict::kDtBuyPayback:
    /*! \todo ogs_dict出现了字段变动。
    case ogs::ogs_dict::kDtApplyParch:
        return string("3");
    case ogs::ogs_dict::kDTRedemption:
        return string("4");
    *********************************/
    default: return string();
    }
}

std::string PbUfxConverter::to_asset_prop(ogs::OGS_ACTYPE type)
{
    switch(type){
    case ogs::ogs_dict::kStockNoraml:
        return string("0");
    case ogs::ogs_dict::kStockCredit:
        return string("7");
    default: return string();
    }
}

Exchange PbUfxConverter::to_exchange_index(const std::string &market_no)
{
    if (market_no == "1") {
        return Exchange::SSE;
    } else if (market_no == "2") {
        return Exchange::SZE;
    } else if (market_no == "7") {
        return Exchange::CFFE;
    }
    return Exchange::ExchangeCount;
}

std::string PbUfxConverter::to_price(uint32_t ogs_price)
{
    return std::to_string(ogs_price / 10000.0);
}

int PbUfxConverter::from_price(const std::string &price)
{
    return (int)(std::stod(price) * 10000);
}

ogs::OGS_VOLUME PbUfxConverter::from_amount(const std::string &amount)
{
    return std::stoi(amount);
}

/*! ufx返回时间格式为："HHmmss" */
uint32_t PbUfxConverter::from_time(const std::string &time)
{
    int hour = std::stoi(time.substr(0, 2));
    int minute = std::stoi(time.substr(2, 2));
    int second = std::stoi(time.substr(4, 2));

    return hour * 10000 + minute * 100 + second;
}

/*! ufx返回日期格式为："yyyyMMdd" */
uint32_t PbUfxConverter::from_date(const std::string &date)
{
    int year = std::stoi(date.substr(0, 4));
    int month = std::stoi(date.substr(4, 2));
    int day = std::stoi(date.substr(6, 2));

    return year * 10000 + (month + 1) * 100 + day;
}

ogs::OGS_BALANCE PbUfxConverter::from_balance(const std::string &balance)
{
    return std::atof(balance.c_str()) * 10000;
}

qtp::MarketCode PbUfxConverter::from_exchange_type(const std::string &exchange_type)
{
    if(exchange_type == "1"){
        return qtp::kMC_SSE;
    }else if(exchange_type == "F4"){
        return qtp::kMC_CFFE;
    }else if(exchange_type == "2"){
        return qtp::kMC_SZE;
    }else{
        return qtp::kMC_UNKNOW;
    }
}

ogs::ogs_dict::OrderStatusType PbUfxConverter::from_entrust_state(const std::string &entrust_state)
{
    if(entrust_state == "1"){
        return ogs::ogs_dict::kOtNotReported;
    }else if(entrust_state == "2" ||
             entrust_state == "3"){
        return ogs::ogs_dict::kOtWaitReporting;
    }else if(entrust_state == "4"){
        return ogs::ogs_dict::kOtReported;
    }else if(entrust_state == "8" ||
             entrust_state == "C" ||
             entrust_state == "A" ||
             entrust_state == "B" ||
             entrust_state == "D"){
        return ogs::ogs_dict::kOtCanceling;
    }else if(entrust_state == "9" ||
             entrust_state == "F" ||
             entrust_state == "d"){
        return ogs::ogs_dict::kOtCanceled;
    }else if(entrust_state == "6"){
        return ogs::ogs_dict::kOtPartMatched;
    }else if(entrust_state == "7"){
        return ogs::ogs_dict::kOtMatchedAll;
    }else if(entrust_state == "5"){
        return ogs::ogs_dict::kOtBad;
    }else if(entrust_state == "b" ||
             entrust_state == "c"){
        return ogs::ogs_dict::kOtNotApproved;
    }
    return ogs::ogs_dict::kOtNotApproved;
}

ogs::OGS_INNERCODE PbUfxConverter::from_stock_code(const std::string &stock_code)
{
    return qtp::UniversalCode::SymbolToUC(stock_code);
}

void PbUfxConverter::from_entrust_no(const std::string &entrust_no, char *sysOrderId)
{
    memcpy(sysOrderId, entrust_no.c_str(), entrust_no.size());
}

void PbUfxConverter::from_deal_no(const std::string &deal_no, char *dealId)
{
    memcpy(dealId, deal_no.c_str(), deal_no.size());
}
