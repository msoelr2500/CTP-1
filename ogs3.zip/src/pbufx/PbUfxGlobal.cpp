/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxGlobal.h"
#include "PbUfxInterface.h"

namespace ogs {

#ifdef __cplusplus
extern "C"
{
#endif

    DEFINE_VERSION(pbufx)

    void InterfaceCreate(std::string brokerType, std::shared_ptr<Interface> &inPtr) {
        if ((strcmp(brokerType.c_str(), "PBUFX") == 0) || (strcmp(brokerType.c_str(), "pbufx") == 0)) {
            inPtr = std::shared_ptr<Interface>(new PbUfxInterface());
        }
    }

    int LoadLocalOption(void* src,size_t size){
        if(size!= sizeof(ogs::ReadConfig::localOption)){
            return -1;
        }
        memcpy(&ogs::ReadConfig::localOption,src,size);
        return 0;
    }

    void LogLibVersion()
    {
        LOG(info) << "PBUFX 接口库版本：" << GET_VERSION_STR(pbufx);
    }

#ifdef __cplusplus
}
#endif
}

