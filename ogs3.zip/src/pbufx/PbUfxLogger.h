/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#ifndef PBUFXLOGGER_H
#define PBUFXLOGGER_H

#include "../OgsLogger.h"
#include "PbUfxApiWrapper.h"
#include <iostream>

#define pbufxLogger ogsLogger
#define pbufxDebug ogsDebug
#define pbufxInfo ogsInfo
#define pbufxError ogsError

OgsLogger& operator << (OgsLogger& logger, const MessageHeartbeatInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmUserLoginInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmUserLoginOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmUserLogoutInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmUserChgPassInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmFundQueryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmFundQueryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmAssetQueryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmAssetQueryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmCombiQueryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmCombiQueryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmHolderQueryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmHolderQueryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmFundAssetQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmFundAssetQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmUnitAssetQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmUnitAssetQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmCurrentsQueryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmCurrentsQueryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmHistCurrentsQueryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmHistCurrentsQueryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmDepositRatioQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmDepositRatioQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmCapitalAdjustInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmCapitalAdjustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawByEntrustNoInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawByEntrustNoOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuHistEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuHistRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuHistRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuComboFundQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuComboFundQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const SecuShareTransferEntrustWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmEtfDealingInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmEtfDealingOutput& data);
OgsLogger& operator << (OgsLogger& logger, const AmEtfEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const AmEtfEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FundEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FundEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfDealingQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfDealingQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FundRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FundRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfDealingRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfDealingRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfStockListQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfStockListQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfBaseInfoQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const EtfBaseInfoQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesInfoQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesInfoQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesUftUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesUftUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesUnitStkDetailQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesUnitStkDetailQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesHistEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesHistEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesPortfolioSingleEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesHistRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesHistRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesComboFundQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const FuturesComboFundQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptLockEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptLockEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptShareTransferEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptShareTransferEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptCombiEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptCombiEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const IndexOptionsMarketWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptMarketEntrustWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawCombiInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawCombiOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseBatchnoWithdrawInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptExerciseBatchnoWithdrawOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsUftUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsUftUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsMarketEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsMarketEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsRealDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsDepositQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const OptionsDepositQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const StkOptDepositDealQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const CombUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const CombUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const CombUftUnitStkQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const CombUftUnitStkQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const CombEntrustQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const CombEntrustQryOutput& data);
OgsLogger& operator << (OgsLogger& logger, const CombRealDealQryInput& data);
OgsLogger& operator << (OgsLogger& logger, const CombRealDealQryOutput& data);

#endif // PBUFXLOGGER_H
