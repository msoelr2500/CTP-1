/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#ifndef PBUFXAPIWRAPPER_H
#define PBUFXAPIWRAPPER_H

#define PBUFX_SUB_CONFIG_FILE "subscriber.ini"
#define PBUFX_CONFIG_FILE "t2sdk.ini"
#define PBUFX_CONNECT_TIMEOUT_MS 1000

#include <string>
#include <list>
#include <mutex>
#include <ufx/t2sdk_interface.h>
#include "../Interface.h" // for Intf_RetType
#include <unistd.h>

struct PbUfxConfig {
    std::string mOperatorPasswd;        //!< 操作员编号
    std::string mOperatorNo;            //!< 操作员密码
    std::string mSiteInfoFormat;        //!< 站点信息（站点留痕）的格式。
    std::string mTerminalInfo;          //!< 终端信息
    std::string mAuthorizationId;       //!< 开发者授权编号
};

struct MessageHeartbeatInput {
    std::string user_token;             //!< 令牌号
};
struct AmUserLoginInput {
    std::string operator_no;            //!< 操作员编号
    std::string password;               //!< 操作员密码
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
    std::string authorization_id;       //!< 开发者授权编号
};
struct AmUserLoginOutput {
    std::string user_token;             //!< 令牌号
    std::string version_no;             //!< 版本号
};
struct AmUserLogoutInput {
    std::string user_token;             //!< 令牌号
};
struct AmUserChgPassInput {
    std::string user_token;             //!< 用户口令
    std::string old_password;           //!< 原密码
    std::string new_password;           //!< 新密码
};
struct AmFundQueryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
};
struct AmFundQueryOutput {
    std::string account_code;           //!< 账户编号
    std::string account_name;           //!< 账户名称
    std::string account_type;           //!< 账户类型
};
struct AmAssetQueryInput {
    std::string user_token;             //!< 用户口令
    std::string capital_account;        //!< 资金账号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
};
struct AmAssetQueryOutput {
    std::string capital_account;        //!< 资金账号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string asset_name;             //!< 资产单元名称
};
struct AmCombiQueryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
};
struct AmCombiQueryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string combi_name;             //!< 组合名称
    std::string market_no_list;         //!< 允许的交易市场
    std::string futu_invest_type;       //!< 期货投资类型
    std::string entrust_direction_list; //!< 允许的委托方向
};
struct AmHolderQueryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
};
struct AmHolderQueryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
};
struct AmFundAssetQryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string currency_code;          //!< 币种
};
struct AmFundAssetQryOutput {
    std::string account_code;           //!< 账户编号
    std::string currency_code;          //!< 币种
    std::string total_asset;            //!< 总资产
    std::string nav;                    //!< 账户单位净值
    std::string yesterday_nav;          //!< 昨日单位净值
    std::string current_balance;        //!< 当前资金余额
    std::string begin_balance;          //!< 期初资金余额
    std::string futu_deposit_balance;   //!< 期货保证金账户余额
    std::string occupy_deposit_balance; //!< 期货占用保证金
    std::string futu_asset;             //!< 期货资产（合约价值）
    std::string stock_asset;            //!< 股票资产
    std::string bond_asset;             //!< 债券资产
    std::string fund_asset;             //!< 基金资产
    std::string repo_asset;             //!< 回购资产
    std::string other_asset;            //!< 其他资产
    std::string fund_share;             //!< 基金总份额
    std::string fund_net_asset;         //!< 基金净资产
    std::string payable_balance;        //!< 应付款
    std::string receivable_balance;     //!< 应收款
};
struct AmUnitAssetQryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string currency_code;          //!< 币种
};
struct AmUnitAssetQryOutput {
    std::string business_date;          //!< 业务日期
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string currency_code;          //!< 币种
    std::string current_balance;        //!< 当前资金余额
    std::string begin_balance;          //!< 期初资金余额
    std::string futu_deposit_balance;   //!< 期货保证金账户余额
    std::string futu_asset;             //!< 期货资产（合约价值）
    std::string stock_asset;            //!< 股票资产
    std::string bond_asset;             //!< 债券资产
    std::string fund_asset;             //!< 基金资产
    std::string repo_asset;             //!< 回购资产
    std::string option_asset;           //!< 期权资产
    std::string other_asset;            //!< 其他资产
    std::string payable_balance;        //!< 应付款
    std::string receivable_balance;     //!< 应收款
    std::string futu_today_profit;      //!< 期货盯市盈亏
    std::string futu_float_profit;      //!< 期货浮动盈亏
    std::string futu_close_profit;      //!< 期货平仓盈亏
    std::string futu_fee;               //!< 期货买卖费用
    std::string spot_accumulate_profit; //!< 现货累计实现盈亏
};
struct AmCurrentsQueryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct AmCurrentsQueryOutput {
    std::string business_date;          //!< 业务日期
    std::string business_time;          //!< 业务时间
    std::string serial_no;              //!< 流水号
    std::string currency_code;          //!< 币种
    std::string busin_no;               //!< 业务类别编号
    std::string busin_caption;          //!< 业务说明
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string position_flag;          //!< 多空标志
    std::string invest_type;            //!< 投资类型
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string business_price;         //!< 发生价格
    std::string business_amount;        //!< 发生数量
    std::string business_balance;       //!< 发生金额
    std::string trade_fee;              //!< 交易费
    std::string stamp_tax;              //!< 印花税
    std::string transfer_fee;           //!< 过户费
    std::string commission;             //!< 佣金
    std::string handling_fee;           //!< 经手费
    std::string admin_fee;              //!< 证管费
    std::string clearing_fee;           //!< 结算费
    std::string delivery_fee;           //!< 交割费
    std::string risk_fund;              //!< 结算风险金
    std::string other_fee;              //!< 其他费
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string deal_no;                //!< 成交编号
    std::string deal_time;              //!< 成交时间
    std::string settle_speed;           //!< 清算速度
    std::string capital_direction;      //!< 资金变化方向
    std::string stock_direction;        //!< 证券变化方向
    std::string close_type;             //!< 平仓类型
    std::string position_str;           //!< 定位串
};
struct AmHistCurrentsQueryInput {
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 起始日期
    std::string end_date;               //!< 结束日期
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct AmHistCurrentsQueryOutput {
    std::string business_date;          //!< 业务日期
    std::string business_time;          //!< 业务时间
    std::string serial_no;              //!< 流水号
    std::string currency_code;          //!< 币种
    std::string busin_no;               //!< 业务类别编号
    std::string busin_caption;          //!< 业务说明
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string position_flag;          //!< 多空标志
    std::string invest_type;            //!< 投资类型
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string business_price;         //!< 发生价格
    std::string business_amount;        //!< 发生数量
    std::string business_balance;       //!< 发生金额
    std::string trade_fee;              //!< 交易费
    std::string stamp_tax;              //!< 印花税
    std::string transfer_fee;           //!< 过户费
    std::string commission;             //!< 佣金
    std::string handling_fee;           //!< 经手费
    std::string admin_fee;              //!< 证管费
    std::string clearing_fee;           //!< 结算费
    std::string delivery_fee;           //!< 交割费
    std::string risk_fund;              //!< 结算风险金
    std::string other_fee;              //!< 其他费
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string deal_no;                //!< 成交编号
    std::string deal_time;              //!< 成交时间
    std::string settle_speed;           //!< 清算速度
    std::string capital_direction;      //!< 资金变化方向
    std::string stock_direction;        //!< 证券变化方向
    std::string close_type;             //!< 平仓类型
    std::string position_str;           //!< 定位串
};
struct AmDepositRatioQryInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
};
struct AmDepositRatioQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string deposit_ratio;          //!< 空头保证金比例
    std::string long_deposit_ratio;     //!< 多头保证金比例
};
struct AmCapitalAdjustInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string adjust_mode;            //!< 调整类型
    std::string business_balance;       //!< 调整金额
    std::string enable_date;            //!< 生效时间
    std::string remark;                 //!< 备注
};
struct AmCapitalAdjustOutput {
    std::string adjust_result;          //!< 调整结果
    std::string fail_cause;             //!< 失败原因
};
struct SecuEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct SecuShareTransferEntInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string stock_code;             //!< 证券代码
    std::string buy_price;              //!< 买入价格
    std::string buy_amount;             //!< 买入数量
    std::string sell_price;             //!< 卖出价格
    std::string sell_amount;            //!< 卖出数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferEntOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct SecuShareTransferWithdrawCombiInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct SecuShareTransferWithdrawByEntrustNoInput {
    std::string user_token;             //!< 令牌号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferWithdrawByEntrustNoOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct SecuEntrustCombiInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string covered_flag;           //!< 备兑标志
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string limit_entrust_ratio;    //!< 现货最小委托比例
    std::string ftr_limit_entrust_ratio;//!< 期货最小委托比例
    std::string opt_limit_entrust_ratio;//!< 期权最小委托比例
    std::string invest_type;            //!< 投资类型
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuEntrustCombiOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string request_order;          //!< 请求次序
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct SecuEntrustWithdrawCombiInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuEntrustWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct SecuEntrustWithdrawInput {
    std::string user_token;             //!< 令牌号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuEntrustWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct SecuShareTransferWithdrawInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferWithdrawOutput {
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 撤单失败原因
};
struct SecuUnitStkQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
};
struct SecuUnitStkQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string invest_type;            //!< 投资类型
    std::string current_amount;         //!< 当前数量
    std::string enable_amount;          //!< 可用数量
    std::string begin_cost;             //!< 期初成本
    std::string current_cost;           //!< 当前成本
    std::string pre_buy_amount;         //!< 买挂单数量
    std::string pre_sell_amount;        //!< 卖挂单数量
    std::string pre_buy_balance;        //!< 买挂单金额
    std::string pre_sell_balance;       //!< 卖挂单金额
    std::string today_buy_amount;       //!< 当日买入数量
    std::string today_sell_amount;      //!< 当日卖出数量
    std::string today_buy_balance;      //!< 当日买入金额
    std::string today_sell_balance;     //!< 当日卖出金额
    std::string today_buy_fee;          //!< 当日买费用
    std::string today_sell_fee;         //!< 当日卖费用
};
struct SecuEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct SecuEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string pre_buy_frozen_balance; //!< 预买冻结金额
    std::string pre_sell_balance;       //!< 预卖金额
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string withdraw_amount;        //!< 撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
    std::string exchange_report_no;     //!< 交易所申报编号
};
struct SecuHistEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 起始日期
    std::string end_date;               //!< 结束日期
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct SecuHistEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string pre_buy_frozen_balance; //!< 预买冻结金额
    std::string pre_sell_balance;       //!< 预卖金额
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string withdraw_amount;        //!< 撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
};
struct SecuShareTransferEntrQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string stock_code;             //!< 证券代码
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct SecuShareTransferEntrQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string buy_price;              //!< 买入价格
    std::string buy_amount;             //!< 买入数量
    std::string sell_price;             //!< 卖出价格
    std::string sell_amount;            //!< 卖出数量
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string buy_deal_amount;        //!< 买入成交数量
    std::string buy_deal_balance;       //!< 买入成交金额
    std::string sell_deal_amount;       //!< 卖出成交数量
    std::string sell_deal_balance;      //!< 卖出成交金额
    std::string buy_cancel_amount;      //!< 买入方向撤单数量
    std::string sell_cancel_amount;     //!< 卖出方向撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
};
struct SecuRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct SecuRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string instance_no;            //!< 交易实例编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
    std::string position_str;           //!< 定位串
};
struct SecuHistRealDealQryInput {
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 起始日期
    std::string end_date;               //!< 结束日期
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_serial_list;    //!< 委托序号串
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct SecuHistRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
    std::string position_str;           //!< 定位串
};
struct SecuComboFundQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
};
struct SecuComboFundQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string enable_balance_t0;      //!< T+0可用资金
    std::string enable_balance_t1;      //!< T+1可用资金
    std::string current_balance;        //!< 当前资金余额
};
struct SecuShareTransferEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string rival_holdid;           //!< 对方股东代码
    std::string rival_seat;             //!< 对方席位号
    std::string engaged_no;             //!< 约定号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct SecuShareTransferEntrustWithdrawInput {
    std::string user_token;             //!< 令牌号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferEntrustWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct SecuShareTransferEntrustWithdrawCombiInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct SecuShareTransferEntrustWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct AmEtfDealingInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_amount;         //!< 委托数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct AmEtfDealingOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
};
struct AmEtfEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_price;          //!< 委托价格
    std::string entrust_balance;        //!< 委托金额
    std::string purchase_way;           //!< 申赎方式
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct AmEtfEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct FundEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FundEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_balance;        //!< 委托金额
    std::string purchase_way;           //!< 申赎方式
    std::string pre_buy_frozen_balance; //!< 预买冻结金额
    std::string pre_sell_balance;       //!< 预卖金额
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string position_str;           //!< 定位串
    std::string exchange_report_no;     //!< 交易所申报编号
};
struct EtfDealingQryInput {
    std::string user_token;             //!< 用户口令
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
};
struct EtfDealingQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string detail_entrust_no;      //!< ETF委托序号
    std::string report_no;              //!< 申报编号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string entrust_state;          //!< 委托状态
};
struct FundRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FundRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
    std::string position_str;           //!< 定位串
};
struct EtfDealingRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
};
struct EtfDealingRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_time;              //!< 成交时间
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
};
struct EtfStockListQryInput {
    std::string user_token;             //!< 令牌号
    std::string market_no;              //!< 交易市场
    std::string etf_code;               //!< ETF代码（二级市场）
};
struct EtfStockListQryOutput {
    std::string business_date;          //!< 业务日期
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stock_amount;           //!< 证券数量
    std::string replace_flag;           //!< 现金替代标志
    std::string replace_ratio;          //!< 溢价比率
    std::string replace_balance;        //!< 替代金额
    std::string redeem_replace_balance; //!< 赎回替代金额
};
struct EtfBaseInfoQryInput {
    std::string user_token;             //!< 令牌号
    std::string market_no;              //!< 交易市场
    std::string etf_type;               //!< ETF分类
    std::string etf_code;               //!< ETF代码（二级市场）
};
struct EtfBaseInfoQryOutput {
    std::string business_date;          //!< 业务日期
    std::string market_no;              //!< 交易市场
    std::string etf_code;               //!< ETF代码（二级市场）
    std::string stock_name;             //!< 证券名称
    std::string stock_code;             //!< 证券代码
    std::string stock_num;              //!< 成分股数量
    std::string creation_redeem_type;   //!< 当天状态
    std::string etf_market_type;        //!< ETF市场类型
    std::string rival_market;           //!< 对方市场
    std::string etf_type;               //!< ETF分类
    std::string max_cash_ratio;         //!< 现金替代比例上限
    std::string report_unit;            //!< 申报单位
    std::string yesterday_cash;         //!< T－1日申购赎回基准单位的现金余额
    std::string yesterday_nav;          //!< 昨日单位净值
    std::string estimate_cash;          //!< 预估现金差额
    std::string underlying_index;       //!< 拟合指数代码
};
struct FuturesInfoQryInput {
    std::string user_token;             //!< 令牌号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
};
struct FuturesInfoQryOutput {
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stock_name;             //!< 证券名称
    std::string future_kind_name;       //!< 期货品种名
    std::string settlement_month;       //!< 合约月份
    std::string target_market_no;       //!< 标的物市场
    std::string target_stock_code;      //!< 标的物代码
    std::string multiple;               //!< 合约乘数
    std::string last_trade_date;        //!< 最后交易日
    std::string last_trade_time;        //!< 最后交易时间
    std::string settlement_date;        //!< 交割日
    std::string settlement_price;       //!< 结算价
    std::string pre_settlement_price;   //!< 前结算价
    std::string market_position;        //!< 市场持仓量
    std::string pre_market_position;    //!< 前市场持仓量
    std::string market_price_permit;    //!< 市价申报许可
    std::string uplimited_price;        //!< 涨停板价格
    std::string downlimited_price;      //!< 跌停板价格
};
struct FuturesEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string close_direction;        //!< 平仓类型
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string limit_deal_amount;      //!< 最小成交量
    std::string invest_type;            //!< 投资类型
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct FuturesEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct FuturesPortfolioSingleEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格（价差）
    std::string entrust_amount;         //!< 委托数量
    std::string limit_deal_amount;      //!< 最小成交量
    std::string invest_type;            //!< 投资类型
    std::string portfolio_type;         //!< 组合单类型
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct FuturesPortfolioSingleEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct FuturesEntrustWithdrawCombiInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct FuturesEntrustWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct FuturesEntrustWithdrawInput {
    std::string user_token;             //!< 令牌号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct FuturesEntrustWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct FuturesPortfolioSingleEntrustWithdrawCombiInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct FuturesPortfolioSingleEntrustWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct FuturesPortfolioSingleEntrustWithdrawInput {
    std::string user_token;             //!< 用户口令
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct FuturesPortfolioSingleEntrustWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct FuturesUftUnitStkQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string invest_type;            //!< 投资类型
    std::string position_flag;          //!< 多空标志
};
struct FuturesUftUnitStkQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string position_flag;          //!< 多空标志
    std::string invest_type;            //!< 投资类型
    std::string current_amount;         //!< 当前数量
    std::string today_amount;           //!< 今日数量
    std::string lastday_amount;         //!< 昨仓数量
    std::string enable_amount;          //!< 可用数量
    std::string today_enable_amount;    //!< 今日可用数量
    std::string lastday_enable_amount;  //!< 昨仓可用数量
    std::string begin_cost;             //!< 期初成本
    std::string current_cost;           //!< 当前成本
    std::string current_cost_price;     //!< 当前成本价
    std::string pre_buy_amount;         //!< 开仓挂单数量
    std::string pre_sell_amount;        //!< 平仓挂单数量
    std::string pre_buy_balance;        //!< 开仓挂单金额
    std::string pre_sell_balance;       //!< 平仓挂单金额
    std::string today_buy_amount;       //!< 当日买入数量
    std::string today_sell_amount;      //!< 当日卖出数量
    std::string today_buy_balance;      //!< 当日买入金额
    std::string today_sell_balance;     //!< 当日卖出金额
    std::string today_buy_fee;          //!< 当日买费用
    std::string today_sell_fee;         //!< 当日卖费用
};
struct FuturesUnitStkDetailQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string invest_type;            //!< 投资类型
    std::string position_flag;          //!< 多空标志
};
struct FuturesUnitStkDetailQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string position_flag;          //!< 多空标志
    std::string invest_type;            //!< 投资类型
    std::string stock_open_date;        //!< 开仓日期
    std::string deal_no;                //!< 成交编号
    std::string open_amount;            //!< 开仓数量
    std::string current_amount;         //!< 当前数量
    std::string drop_amount;            //!< 平仓数量
    std::string occupy_deposit_balance; //!< 占用保证金
    std::string open_price;             //!< 开仓价
    std::string drop_income;            //!< 平仓收益
    std::string total_fee;              //!< 总费用
    std::string pre_settlement_price;   //!< 前结算价
    std::string multiple;               //!< 合约乘数
};
struct FuturesEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FuturesEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string pre_buy_frozen_balance; //!< 预买冻结金额
    std::string pre_sell_balance;       //!< 预卖金额
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string withdraw_amount;        //!< 撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
    std::string exchange_report_no;     //!< 交易所申报编号
};
struct FuturesHistEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string start_date;             //!< 起始日期
    std::string end_date;               //!< 结束日期
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FuturesHistEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string pre_buy_frozen_balance; //!< 预买冻结金额
    std::string pre_sell_balance;       //!< 预卖金额
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string withdraw_amount;        //!< 撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
};
struct FuturesPortfolioSingleEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string entrust_state_list;     //!< 委托状态
    std::string portfolio_type;         //!< 组合单类型
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FuturesPortfolioSingleEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string portfolio_type;         //!< 组合单类型
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string limit_deal_amount;      //!< 最小成交量
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string buy_deal_balance;       //!< 买方向成交金额
    std::string buy_deal_price;         //!< 买方向成交均价
    std::string sell_deal_balance;      //!< 卖方向成交金额
    std::string sell_deal_price;        //!< 卖方向成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string withdraw_amount;        //!< 撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
};
struct FuturesRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string close_type;             //!< 平仓类型
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FuturesRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string instance_no;            //!< 交易实例编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
    std::string close_type;             //!< 平仓类型
    std::string position_str;           //!< 定位串
};
struct FuturesHistRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string start_date;             //!< 起始日期
    std::string end_date;               //!< 结束日期
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_serial_list;    //!< 委托序号串
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct FuturesHistRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string instance_no;            //!< 交易实例编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
    std::string position_str;           //!< 定位串
};
struct FuturesComboFundQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
};
struct FuturesComboFundQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string occupy_deposit_balance; //!< 期货占用保证金
    std::string enable_deposit_balance; //!< 期货可用保证金
    std::string futu_deposit_balance;   //!< 期货保证金账户余额
    std::string futu_temp_occupy_deposit;//!< 期货挂单占用保证金
};
struct StkOptEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string covered_flag;           //!< 备兑标志
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct StkOptLockEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_amount;         //!< 委托数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptLockEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
};
struct StkOptExerciseEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string entrust_amount;         //!< 委托数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptExerciseEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
};
struct IndexOptionsMarketEntrustInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string buy_direction;          //!< 买入开平方向
    std::string buy_price;              //!< 买入价格
    std::string buy_amount;             //!< 买入数量
    std::string sell_direction;         //!< 卖出开平方向
    std::string sell_price;             //!< 卖出价格
    std::string sell_amount;            //!< 卖出数量
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct IndexOptionsMarketEntrustOutput {
    std::string batch_no;               //!< 委托批号
};
struct StkOptShareTransferEntrustInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string buy_direction;          //!< 买入开平方向
    std::string buy_price;              //!< 买入价格
    std::string buy_amount;             //!< 买入数量
    std::string sell_direction;         //!< 卖出开平方向
    std::string sell_price;             //!< 卖出价格
    std::string sell_amount;            //!< 卖出数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptShareTransferEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号，如委托失败，则返回0
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号，用于关联风控信息包中的风控信息条目
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct StkOptCombiEntrustInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 买卖方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string covered_flag;           //!< 备兑标志
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptCombiEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
};
struct StkOptEntrustWithdrawCombiInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptEntrustWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct StkOptEntrustWithdrawInput {
    std::string user_token;             //!< 令牌号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptEntrustWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct IndexOptionsMarketWithdrawInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct IndexOptionsMarketWithdrawOutput {
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 撤单失败原因
};
struct OptMarketEntrustWithdrawCombiInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct OptMarketEntrustWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct OptMarketEntrustWithdrawInput {
    std::string user_token;             //!< 用户口令
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct OptMarketEntrustWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct StkOptExerciseWithdrawCombiInput {
    std::string user_token;             //!< 用户口令
    std::string account_code;           //!< 账户编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptExerciseWithdrawCombiOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct StkOptExerciseWithdrawInput {
    std::string user_token;             //!< 用户口令
    std::string entrust_no;             //!< 委托序号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptExerciseWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct StkOptExerciseBatchnoWithdrawInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptExerciseBatchnoWithdrawOutput {
    std::string entrust_no;             //!< 委托序号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string success_flag;           //!< 撤单成功标志
    std::string fail_cause;             //!< 失败原因
};
struct OptionsUftUnitStkQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string option_type;            //!< 期权类型
    std::string position_flag;          //!< 多空标志
};
struct OptionsUftUnitStkQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string option_type;            //!< 期权类型
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string position_flag;          //!< 多空标志
    std::string current_amount;         //!< 当前数量
    std::string enable_amount;          //!< 可用数量
    std::string begin_cost;             //!< 期初成本
    std::string current_cost;           //!< 当前成本
    std::string pre_buy_amount;         //!< 开仓挂单数量
    std::string pre_sell_amount;        //!< 平仓挂单数量
    std::string pre_buy_balance;        //!< 开仓挂单金额
    std::string pre_sell_balance;       //!< 平仓挂单金额
    std::string today_buy_amount;       //!< 当日开仓数量
    std::string today_sell_amount;      //!< 当日平仓数量
    std::string today_buy_balance;      //!< 当日开仓金额
    std::string today_sell_balance;     //!< 当日平仓金额
    std::string today_buy_fee;          //!< 当日开仓费用
    std::string today_sell_fee;         //!< 当日平仓费用
};
struct OptionsEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string option_type;            //!< 期权类型
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
    std::string entrust_serial_list;    //!< 委托序号串
};
struct OptionsEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string option_type;            //!< 期权类型
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string pre_buy_frozen_balance; //!< 预开仓冻结金额
    std::string pre_sell_balance;       //!< 预平仓金额
    std::string confirm_no;             //!< 委托确认号
    std::string covered_flag;           //!< 备兑标志
    std::string entrust_state;          //!< 委托状态
    std::string first_deal_time;        //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string withdraw_amount;        //!< 撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
    std::string exchange_report_no;     //!< 交易所申报编号
};
struct OptionsMarketEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct OptionsMarketEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string buy_direction;          //!< 买入开平方向
    std::string buy_covered_flag;       //!< 买入方向备兑标志
    std::string buy_price;              //!< 买入价格
    std::string buy_amount;             //!< 买入数量
    std::string sell_direction;         //!< 卖出开平方向
    std::string sell_covered_flag;      //!< 卖出方向备兑标志
    std::string sell_price;             //!< 卖出价格
    std::string sell_amount;            //!< 卖出数量
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string buy_deal_amount;        //!< 买入成交数量
    std::string buy_deal_balance;       //!< 买入成交金额
    std::string sell_deal_amount;       //!< 卖出成交数量
    std::string sell_deal_balance;      //!< 卖出成交金额
    std::string buy_cancel_amount;      //!< 买入方向撤单数量
    std::string sell_cancel_amount;     //!< 卖出方向撤单数量
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
};
struct OptionsRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string option_type;            //!< 期权类型
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
    std::string entrust_serial_list;    //!< 委托序号串
};
struct OptionsRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string instance_no;            //!< 交易实例编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string option_type;            //!< 期权类型
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
    std::string position_str;           //!< 定位串
};
struct OptionsDepositQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
};
struct OptionsDepositQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string occupy_deposit_balance; //!< 占用保证金
    std::string enable_deposit_balance; //!< 可用保证金
};
struct StkOptDepositEntrustInput {
    std::string user_token;             //!< 令牌号
    std::string batch_no;               //!< 委托批号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string combistrategy_code;     //!< 组合策略代码
    std::string combistrategy_id;       //!< 组合策略持仓编号
    std::string combi_direction;        //!< 组合方向
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code1;            //!< 证券代码1
    std::string stock_code2;            //!< 证券代码2
    std::string stock_code3;            //!< 证券代码3
    std::string stock_code4;            //!< 证券代码4
    std::string entrust_amount;         //!< 委托数量
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string mac_address;            //!< 登录机器MAC地址
    std::string ip_address;             //!< 登录机器IP地址
    std::string hd_volserial;           //!< 登录机器硬盘序列号
    std::string op_station;             //!< 登录站点
    std::string terminal_info;          //!< 终端信息
};
struct StkOptDepositEntrustOutput {
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string entrust_fail_code;      //!< 委托失败代码
    std::string fail_cause;             //!< 失败原因
    std::string risk_serial_no;         //!< 风控判断流水号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string combi_direction;        //!< 组合方向
    std::string risk_no;                //!< 风控序号
    std::string risk_type;              //!< 风控类型
    std::string risk_summary;           //!< 风控说明
    std::string risk_operation;         //!< 风控触警操作
    std::string remark_short;           //!< 风控触发风控说明
    std::string risk_threshold_value;   //!< 风控阀值
    std::string risk_value;             //!< 风控计算值
};
struct StkOptDepositUnitStkQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string combistrategy_code;     //!< 组合策略代码
    std::string stock_code1;            //!< 证券代码1
    std::string stock_code2;            //!< 证券代码2
    std::string stock_code3;            //!< 证券代码3
    std::string stock_code4;            //!< 证券代码4
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
};
struct StkOptDepositUnitStkQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string combistrategy_code;     //!< 组合策略代码
    std::string combistrategy_id;       //!< 组合策略持仓编号
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string stock_code1;            //!< 证券代码1
    std::string position_flag1;         //!< 多空标志1
    std::string stock_code2;            //!< 证券代码2
    std::string position_flag2;         //!< 多空标志2
    std::string stock_code3;            //!< 证券代码3
    std::string position_flag3;         //!< 多空标志3
    std::string stock_code4;            //!< 证券代码4
    std::string position_flag4;         //!< 多空标志4
    std::string current_amount;         //!< 当前数量
    std::string frozen_amount;          //!< 冻结数量
    std::string combi_deposit_pre;      //!< 组合前占用保证金
    std::string combi_deposit_now;      //!< 组合后占用保证金
};
struct StkOptDepositEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string combistrategy_code;     //!< 组合策略代码
    std::string stock_code1;            //!< 证券代码1
    std::string stock_code2;            //!< 证券代码2
    std::string stock_code3;            //!< 证券代码3
    std::string stock_code4;            //!< 证券代码4
    std::string combi_direction;        //!< 组合方向
    std::string entrust_state_list;     //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct StkOptDepositEntrustQryOutput {
    std::string entrust_date;           //!< 委托日期
    std::string entrust_time;           //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string report_no;              //!< 申报编号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string combistrategy_code;     //!< 组合策略代码
    std::string stock_code1;            //!< 证券代码1
    std::string stock_code2;            //!< 证券代码2
    std::string stock_code3;            //!< 证券代码3
    std::string stock_code4;            //!< 证券代码4
    std::string combistrategy_id;       //!< 组合策略持仓编号
    std::string combi_direction;        //!< 组合方向
    std::string entrust_amount;         //!< 委托数量
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_state;          //!< 委托状态
    std::string withdraw_cause;         //!< 撤单原因
    std::string position_str;           //!< 定位串
};
struct StkOptDepositDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string combistrategy_code;     //!< 组合策略代码
    std::string stock_code1;            //!< 证券代码1
    std::string stock_code2;            //!< 证券代码2
    std::string stock_code3;            //!< 证券代码3
    std::string stock_code4;            //!< 证券代码4
    std::string combi_direction;        //!< 组合方向
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string position_str;           //!< 定位串
    std::string request_num;            //!< 请求数
};
struct StkOptDepositDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string combistrategy_code;     //!< 组合策略代码
    std::string stock_code1;            //!< 证券代码1
    std::string stock_code2;            //!< 证券代码2
    std::string stock_code3;            //!< 证券代码3
    std::string stock_code4;            //!< 证券代码4
    std::string combistrategy_id;       //!< 组合策略持仓编号
    std::string combi_direction;        //!< 组合方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_time;              //!< 成交时间
    std::string position_str;           //!< 定位串
};
struct CombUnitStkQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
};
struct CombUnitStkQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string position_flag;          //!< 多空标志
    std::string invest_type;            //!< 投资类型
    std::string current_amount;         //!< 当前数量
    std::string enable_amount;          //!< 可用数量
    std::string current_cost;           //!< 当前成本
};
struct CombUftUnitStkQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no_list;         //!< 交易市场列表
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string invest_type;            //!< 投资类型
    std::string position_flag;          //!< 多空标志
};
struct CombUftUnitStkQryOutput {
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stockholder_id;         //!< 股东代码
    std::string hold_seat;              //!< 持仓席位
    std::string position_flag;          //!< 多空标志
    std::string current_amount;         //!< 当前数量
    std::string enable_amount;          //!< 可用数量
    std::string pri_enable_amount;      //!< 一级市场可用
    std::string begin_balance;          //!< 期初成本
    std::string current_cost;           //!< 当前成本
    std::string pre_buy_amount;         //!< 买挂单数量
    std::string pre_sell_amount;        //!< 卖挂单数量
    std::string pre_buy_balance;        //!< 买挂单金额
    std::string pre_sale_balance;       //!< 卖挂单金额
    std::string buy_amount;             //!< 当日买入数量
    std::string sell_amount;            //!< 当日卖出数量
    std::string buy_balance;            //!< 当日买入金额
    std::string sale_balance;           //!< 当日卖出金额
    std::string buy_fee;                //!< 当日买费用
    std::string sale_fee;               //!< 当日卖费用
};
struct CombEntrustQryInput {
    std::string user_token;             //!< 用户口令
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no_list;         //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string entrust_status_list;    //!< 委托状态
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
};
struct CombEntrustQryOutput {
    std::string business_date;          //!< 委托日期
    std::string business_time;          //!< 委托时间
    std::string operator_no;            //!< 操作员编号
    std::string batch_no;               //!< 委托批号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string stockholder_id;         //!< 股东代码
    std::string report_seat;            //!< 申报席位
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string price_type;             //!< 委托价格类型
    std::string entrust_price;          //!< 委托价格
    std::string entrust_amount;         //!< 委托数量
    std::string prebuy_frozen_balance;  //!< 预买冻结金额
    std::string presale_balance;        //!< 预卖金额
    std::string confirm_no;             //!< 委托确认号
    std::string entrust_status;         //!< 委托状态
    std::string deal_time;              //!< 首次成交时间
    std::string deal_amount;            //!< 成交数量
    std::string deal_balance;           //!< 成交金额
    std::string deal_price;             //!< 成交均价
    std::string deal_times;             //!< 分笔成交次数
    std::string cancel_amount;          //!< 撤单数量
    std::string revoke_cause;           //!< 撤单原因
};
struct CombRealDealQryInput {
    std::string user_token;             //!< 令牌号
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string entrust_no;             //!< 委托序号
    std::string deal_no;                //!< 成交编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no_list;         //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string stock_type;             //!< 证券类别
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string batch_no;               //!< 委托批号
    std::string report_seat;            //!< 申报席位
};
struct CombRealDealQryOutput {
    std::string deal_date;              //!< 成交日期
    std::string deal_no;                //!< 成交编号
    std::string entrust_no;             //!< 委托序号
    std::string extsystem_id;           //!< 第三方系统自定义号
    std::string third_reff;             //!< 第三方系统自定义说明
    std::string account_code;           //!< 账户编号
    std::string asset_no;               //!< 资产单元编号
    std::string combi_no;               //!< 组合编号
    std::string instance_no;            //!< 交易实例编号
    std::string stockholder_id;         //!< 股东代码
    std::string market_no;              //!< 交易市场
    std::string stock_code;             //!< 证券代码
    std::string entrust_direction;      //!< 委托方向
    std::string futures_direction;      //!< 开平方向
    std::string deal_amount;            //!< 成交数量
    std::string deal_price;             //!< 成交价格
    std::string deal_balance;           //!< 成交金额
    std::string total_fee;              //!< 总费用
    std::string deal_time;              //!< 成交时间
};

class PbUfxApiWrapper
{
public:
    explicit PbUfxApiWrapper();
    explicit PbUfxApiWrapper(const PbUfxConfig& config);
    virtual ~PbUfxApiWrapper();

    ////////////////////////////////////////////////////////////////////////////
    /// 初始化，配置选项和网络连接
    ////////////////////////////////////////////////////////////////////////////

    bool connect();

    static void sleepFor(int s);

    /*! \brief 初始化或重初始化lpconfig，在主线程读完配置文件后执行一次，不能在其他线程使用 */
    bool initialize();

    bool isConnected() const;

    static bool resetConnection(CConnectionInterface** connection,
                                CCallbackInterface *callback = NULL);

    static bool closeConnection(CConnectionInterface* connection);

    void disconnect();
    void setConfig(const PbUfxConfig& config);
    const PbUfxConfig& config() const;

    static Intf_RetType onRecvCommonError(int result, IF2UnPacker *unPacker, std::string& errMsg);

    static void safeAssign(std::string& target, const char* source);

    static void printUnPack(IF2UnPacker* unPacker);

    ///--------------------------------------------------------------------------------------------------------
    /// PB-UFX API // 业务范围：账户
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType pbufxMessageHeartbeat(const MessageHeartbeatInput& input, std::string& errMsg);
    Intf_RetType pbufxAmUserLogin(const AmUserLoginInput& input, std::list<AmUserLoginOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmUserLogout(const AmUserLogoutInput& input, std::string& errMsg);
    Intf_RetType pbufxAmUserChgPass(const AmUserChgPassInput& input, std::string& errMsg);
    Intf_RetType pbufxAmFundQuery(const AmFundQueryInput& input, std::list<AmFundQueryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmAssetQuery(const AmAssetQueryInput& input, std::list<AmAssetQueryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmCombiQuery(const AmCombiQueryInput& input, std::list<AmCombiQueryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmHolderQuery(const AmHolderQueryInput& input, std::list<AmHolderQueryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmFundAssetQry(const AmFundAssetQryInput& input, std::list<AmFundAssetQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmUnitAssetQry(const AmUnitAssetQryInput& input, std::list<AmUnitAssetQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmCurrentsQuery(const AmCurrentsQueryInput& input, std::list<AmCurrentsQueryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmHistCurrentsQuery(const AmHistCurrentsQueryInput& input, std::list<AmHistCurrentsQueryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmDepositRatioQry(const AmDepositRatioQryInput& input, std::list<AmDepositRatioQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmCapitalAdjust(const AmCapitalAdjustInput& input, std::list<AmCapitalAdjustOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// PB-UFX API // 业务范围：证券
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType pbufxSecuEntrust(const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferEnt(const SecuShareTransferEntInput& input, std::list<SecuShareTransferEntOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferWithdrawCombi(const SecuShareTransferWithdrawCombiInput& input, std::list<SecuShareTransferWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferWithdrawByEntrustNo(const SecuShareTransferWithdrawByEntrustNoInput& input, std::list<SecuShareTransferWithdrawByEntrustNoOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuEntrustCombi(const SecuEntrustCombiInput& input, std::list<SecuEntrustCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuEntrustWithdrawCombi(const SecuEntrustWithdrawCombiInput& input, std::list<SecuEntrustWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuEntrustWithdraw(const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferWithdraw(const SecuShareTransferWithdrawInput& input, std::list<SecuShareTransferWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuUnitStkQry(const SecuUnitStkQryInput& input, std::list<SecuUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuEntrustQry(const SecuEntrustQryInput& input, std::list<SecuEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuHistEntrustQry(const SecuHistEntrustQryInput& input, std::list<SecuHistEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferEntrQry(const SecuShareTransferEntrQryInput& input, std::list<SecuShareTransferEntrQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuRealDealQry(const SecuRealDealQryInput& input, std::list<SecuRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuHistRealDealQry(const SecuHistRealDealQryInput& input, std::list<SecuHistRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuComboFundQry(const SecuComboFundQryInput& input, std::list<SecuComboFundQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferEntrust(const SecuShareTransferEntrustInput& input, std::list<SecuShareTransferEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferEntrustWithdraw(const SecuShareTransferEntrustWithdrawInput& input, std::list<SecuShareTransferEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxSecuShareTransferEntrustWithdrawCombi(const SecuShareTransferEntrustWithdrawCombiInput& input, std::list<SecuShareTransferEntrustWithdrawCombiOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// PB-UFX API // 业务范围：基金
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType pbufxAmEtfDealing(const AmEtfDealingInput& input, std::list<AmEtfDealingOutput>& output, std::string& errMsg);
    Intf_RetType pbufxAmEtfEntrust(const AmEtfEntrustInput& input, std::list<AmEtfEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFundEntrustQry(const FundEntrustQryInput& input, std::list<FundEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxEtfDealingQry(const EtfDealingQryInput& input, std::list<EtfDealingQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFundRealDealQry(const FundRealDealQryInput& input, std::list<FundRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxEtfDealingRealDealQry(const EtfDealingRealDealQryInput& input, std::list<EtfDealingRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxEtfStockListQry(const EtfStockListQryInput& input, std::list<EtfStockListQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxEtfBaseInfoQry(const EtfBaseInfoQryInput& input, std::list<EtfBaseInfoQryOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// PB-UFX API // 业务范围：期货
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType pbufxFuturesInfoQry(const FuturesInfoQryInput& input, std::list<FuturesInfoQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesEntrust(const FuturesEntrustInput& input, std::list<FuturesEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesPortfolioSingleEntrust(const FuturesPortfolioSingleEntrustInput& input, std::list<FuturesPortfolioSingleEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesEntrustWithdrawCombi(const FuturesEntrustWithdrawCombiInput& input, std::list<FuturesEntrustWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesEntrustWithdraw(const FuturesEntrustWithdrawInput& input, std::list<FuturesEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesPortfolioSingleEntrustWithdrawCombi(const FuturesPortfolioSingleEntrustWithdrawCombiInput& input, std::list<FuturesPortfolioSingleEntrustWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesPortfolioSingleEntrustWithdraw(const FuturesPortfolioSingleEntrustWithdrawInput& input, std::list<FuturesPortfolioSingleEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesUftUnitStkQry(const FuturesUftUnitStkQryInput& input, std::list<FuturesUftUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesUnitStkDetailQry(const FuturesUnitStkDetailQryInput& input, std::list<FuturesUnitStkDetailQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesEntrustQry(const FuturesEntrustQryInput& input, std::list<FuturesEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesHistEntrustQry(const FuturesHistEntrustQryInput& input, std::list<FuturesHistEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesPortfolioSingleEntrustQry(const FuturesPortfolioSingleEntrustQryInput& input, std::list<FuturesPortfolioSingleEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesRealDealQry(const FuturesRealDealQryInput& input, std::list<FuturesRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesHistRealDealQry(const FuturesHistRealDealQryInput& input, std::list<FuturesHistRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxFuturesComboFundQry(const FuturesComboFundQryInput& input, std::list<FuturesComboFundQryOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// PB-UFX API // 业务范围：期权
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType pbufxStkOptEntrust(const StkOptEntrustInput& input, std::list<StkOptEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptLockEntrust(const StkOptLockEntrustInput& input, std::list<StkOptLockEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptExerciseEntrust(const StkOptExerciseEntrustInput& input, std::list<StkOptExerciseEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxIndexOptionsMarketEntrust(const IndexOptionsMarketEntrustInput& input, std::list<IndexOptionsMarketEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptShareTransferEntrust(const StkOptShareTransferEntrustInput& input, std::list<StkOptShareTransferEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptCombiEntrust(const StkOptCombiEntrustInput& input, std::list<StkOptCombiEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptEntrustWithdrawCombi(const StkOptEntrustWithdrawCombiInput& input, std::list<StkOptEntrustWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptEntrustWithdraw(const StkOptEntrustWithdrawInput& input, std::list<StkOptEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxIndexOptionsMarketWithdraw(const IndexOptionsMarketWithdrawInput& input, std::list<IndexOptionsMarketWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptMarketEntrustWithdrawCombi(const OptMarketEntrustWithdrawCombiInput& input, std::list<OptMarketEntrustWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptMarketEntrustWithdraw(const OptMarketEntrustWithdrawInput& input, std::list<OptMarketEntrustWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptExerciseWithdrawCombi(const StkOptExerciseWithdrawCombiInput& input, std::list<StkOptExerciseWithdrawCombiOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptExerciseWithdraw(const StkOptExerciseWithdrawInput& input, std::list<StkOptExerciseWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptExerciseBatchnoWithdraw(const StkOptExerciseBatchnoWithdrawInput& input, std::list<StkOptExerciseBatchnoWithdrawOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptionsUftUnitStkQry(const OptionsUftUnitStkQryInput& input, std::list<OptionsUftUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptionsEntrustQry(const OptionsEntrustQryInput& input, std::list<OptionsEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptionsMarketEntrustQry(const OptionsMarketEntrustQryInput& input, std::list<OptionsMarketEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptionsRealDealQry(const OptionsRealDealQryInput& input, std::list<OptionsRealDealQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxOptionsDepositQry(const OptionsDepositQryInput& input, std::list<OptionsDepositQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptDepositEntrust(const StkOptDepositEntrustInput& input, std::list<StkOptDepositEntrustOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptDepositUnitStkQry(const StkOptDepositUnitStkQryInput& input, std::list<StkOptDepositUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptDepositEntrustQry(const StkOptDepositEntrustQryInput& input, std::list<StkOptDepositEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxStkOptDepositDealQry(const StkOptDepositDealQryInput& input, std::list<StkOptDepositDealQryOutput>& output, std::string& errMsg);

    ///--------------------------------------------------------------------------------------------------------
    /// PB-UFX API // 业务范围：标准
    ///--------------------------------------------------------------------------------------------------------

    Intf_RetType pbufxCombUnitStkQry(const CombUnitStkQryInput& input, std::list<CombUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxCombUftUnitStkQry(const CombUftUnitStkQryInput& input, std::list<CombUftUnitStkQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxCombEntrustQry(const CombEntrustQryInput& input, std::list<CombEntrustQryOutput>& output, std::string& errMsg);
    Intf_RetType pbufxCombRealDealQry(const CombRealDealQryInput& input, std::list<CombRealDealQryOutput>& output, std::string& errMsg);

private:
    CConnectionInterface *mConnection = NULL;
    CConnectionInterface *mSubConnection = NULL;

    bool mConnected = false;
    PbUfxConfig mConfig;

    //! pb-ufx配置文件接口
    static CConfigInterface* mLpConfig;
    static CConfigInterface* mLpSubConfig;

    static std::mutex mInitMutex;
};

#endif // PBUFXAPIWRAPPER_H
