/////////////////////////////////////////////////////////////////////////////
/// \module ogs
/// \version 3.0
/// \author 杨翌超
/// \date 2016-11-24
/////////////////////////////////////////////////////////////////////////////

#include "PbUfxApiWrapper.h"
#include "../StringHelper.h"
#include "PbUfxReader.h"
#include "PbUfxLogger.h"

using namespace std;

CConfigInterface* PbUfxApiWrapper::mLpConfig = nullptr;
CConfigInterface* PbUfxApiWrapper::mLpSubConfig = nullptr;

std::mutex PbUfxApiWrapper::mInitMutex;

PbUfxApiWrapper::PbUfxApiWrapper()
{

}

PbUfxApiWrapper::PbUfxApiWrapper(const PbUfxConfig &config)
{
    setConfig(config);
}

PbUfxApiWrapper::~PbUfxApiWrapper()
{
    if (!mSubConnection) mSubConnection->Release();
    if (!mConnection) mConnection->Release();
}

bool PbUfxApiWrapper::initialize()
{
    std::lock_guard<std::mutex> initLock(mInitMutex);

    static bool initialized = false;

    // 只在第一次调用时执行初始化操作。
    if (!initialized) {
        cout << "[pb-ufx] 初始化..." << endl;

        if (mLpConfig    != NULL) { mLpConfig->Release(); }
        if (mLpSubConfig != NULL) { mLpSubConfig->Release(); }

        // 通过T2SDK的引出函数，来获取一个新的CConfig对象
        // 此对象在创建连接对象时被传递，用于配置所创建的连接对象的各种属性（比如服务器IP地址、安全模式等）
        // 值得注意的是，在向配置对象设置配置信息时，配置信息既可以从ini文件中载入，
        // 也可以在程序代码中设定，或者是2者的混合，如果对同一个配置项设不同的值，则以最近一次设置为准
        mLpConfig = NewConfig();
        mLpSubConfig = NewConfig();

        // 通过T2SDK的引出函数NewXXXX返回的对象，需要调用对象的Release方法释放，而不能直接用delete
        // 因为t2sdk.dll和调用程序可能是由不同的编译器、编译模式生成，delete可能会导致异常
        // 为了适合Delphi等使用（Delphi对接口自动调用AddRef方法），用C/C++开发的代码，需要在NewXXXX之后调用一下AddRef
        // 以保证引用计数正确
        mLpConfig->AddRef();
        mLpSubConfig->AddRef();

        // load configure file.
        if (mLpConfig->Load(PBUFX_CONFIG_FILE) != 0) {
            string error = "[pb-ufx] 初始化时出现错误：加载t2sdk.ini失败。";
            pbufxError << error;
            cout << error << endl;
            return false;
        }

        if (mLpSubConfig->Load(PBUFX_SUB_CONFIG_FILE) != 0) {
            string error = "[pb-ufx] 初始化时出现错误：加载subscriber.ini失败。";
            pbufxError << error;
            cout << error << endl;
            return false;
        }

        char buf[1024] = { 0 };
        Encode(buf, mConfig.mOperatorPasswd.c_str(), 0);

        if(mLpConfig->SetString("safe", "comm_pwd", buf)) {
            string error = "[pb-ufx] 初始化时出现错误：设置操作员密码失败。";
            pbufxError << error;
            cout << error << endl;
            return false;
        }

        string msg = "[pb-ufx] 初始化成功。";
        pbufxDebug << msg;
        cout << msg << endl;
        initialized = true;
    }
    return true;
}

bool PbUfxApiWrapper::isConnected() const
{
    return mConnected;
}

bool PbUfxApiWrapper::connect()
{
    sleepFor(2);

    if(!resetConnection(&mConnection)) return false;

    std::cout << "[pb-ufx] 连接成功！" << std::endl;
    mConnected = true;
    return true;
}

void PbUfxApiWrapper::sleepFor(int s)
{
#ifdef WIN32
    Sleep(s * 1000);
#else
    sleep(s);
#endif
}

void PbUfxApiWrapper::disconnect()
{
    closeConnection(mConnection);
    mConnected = false;
}

void PbUfxApiWrapper::setConfig(const PbUfxConfig &config)
{
    mConfig = config;
}

const PbUfxConfig &PbUfxApiWrapper::config() const
{
    return mConfig;
}

Intf_RetType PbUfxApiWrapper::onRecvCommonError(int result, IF2UnPacker *unPacker, string &errMsg)
{
    Intf_RetType returnValue = kIntfFail;
    if (result == 2) {
        string input((const char*)unPacker);
        errMsg = string("非业务错误信息：") + StringHelper::convertCodec(input);
        // 不能执行freeUnPacker操作。
        returnValue = kIntfError;
    } else if (result == 3) {
        errMsg = "业务包解包失败。";
        PbUfxReader::freeUnPacker(unPacker);
        returnValue = kIntfFail;
    } else if (result < 0) {
        string input((const char*)unPacker);
        errMsg = string("RecvBiz操作失败：") + StringHelper::convertCodec(input);
        PbUfxReader::freeUnPacker(unPacker);
        returnValue = kIntfRecvFail;
    } else {
        errMsg = "出现了未定义的错误。";
        PbUfxReader::freeUnPacker(unPacker);
    }

    std::cout << errMsg << std::endl;
    return returnValue;
}

void PbUfxApiWrapper::safeAssign(std::string &target, const char *source)
{
    if(!source){
        target.clear();
    }else{
        target.assign(source);
    }
}

void PbUfxApiWrapper::printUnPack(IF2UnPacker *unPacker)
{
    int i = 0, j = 0, k = 0;
    for (i = 0; i < unPacker->GetDatasetCount(); ++i)
    {
        // 设置当前结果集
        unPacker->SetCurrentDatasetByIndex(i);

        // 打印所有记录
        for (j = 0; j < (int)unPacker->GetRowCount(); ++j)
        {
            // 打印每条记录
            for (k = 0; k < unPacker->GetColCount(); ++k)
            {
                printf("%s:\t", unPacker->GetColName(k));
                switch (unPacker->GetColType(k))
                {
                case 'I':
                    printf("%d", unPacker->GetIntByIndex(k));
                    break;
                case 'C':
                    printf("%c", unPacker->GetCharByIndex(k));
                    break;
                case 'S':
                    printf("%s", StringHelper::convertCodec(unPacker->GetStrByIndex(k)).c_str());
                    break;
                case 'F':
                    printf("%f", unPacker->GetDoubleByIndex(k));
                    break;
                case 'R':
                {
                    int nLength;
                    void *lpData = unPacker->GetRawByIndex(k, &nLength);
                    // 对2进制数据进行处理
                    break;
                }
                default:
                    // 未知数据类型
                    printf("未知数据类型。\n");
                    break;
                }
                std::cout << std::endl;
            }
            unPacker->Next();
            std::cout << "---------------------------------" << std::endl;
        }
        putchar('\n');
    }
}

bool PbUfxApiWrapper::resetConnection(CConnectionInterface** connection, CCallbackInterface *callback)
{
    if (*connection != NULL){
        closeConnection(*connection);
    }

    *connection = NewConnection(mLpConfig);
    (*connection)->AddRef();

    int result = (*connection)->Create(callback);
    if (result != 0){
        string error = string("无法创建连接: ") + StringHelper::convertCodec((*connection)->GetErrorMsg(result));
        pbufxError << error;
        std::cout << error << std::endl;
        return false;
    }

    if (result = ((*connection)->Connect(PBUFX_CONNECT_TIMEOUT_MS))){
        string error = string("无法连接: ") + StringHelper::convertCodec((*connection)->GetErrorMsg(result));
        pbufxError << error;
        std::cout << error << std::endl;
        return false;
    }

    return true;
}

bool PbUfxApiWrapper::closeConnection(CConnectionInterface *connection)
{
    if(connection->Close()) return false;
    connection->Release();
    connection = NULL;
    return true;
}

/*!
 * \brief [10000] 心跳
 * \details 心跳功能，该功能用于刷新令牌活跃时间，以避免令牌过期。
 */
Intf_RetType PbUfxApiWrapper::pbufxMessageHeartbeat(const MessageHeartbeatInput& input, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(10000, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [10001] 登录。
 * \details 建立与投资管理系统的连接，UFX系统中做其他操作前必须先进行登陆。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmUserLogin(const AmUserLoginInput& input, std::list<AmUserLoginOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("operator_no", 'S');
    packer->AddField("password", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');
    packer->AddField("authorization_id", 'S');

    packer->AddStr(input.operator_no.c_str());
    packer->AddStr(input.password.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->AddStr(input.authorization_id.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(10001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmUserLoginOutput item;
                    safeAssign(item.user_token, unPacker->GetStr("user_token"));
                    safeAssign(item.version_no, unPacker->GetStr("version_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [10002] 退出登录。
 * \details 断开与UFX服务器的连接，令牌号失效，释放连接数。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmUserLogout(const AmUserLogoutInput& input, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(10002, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [10003] 密码修改。
 * \details 修改操作员密码。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmUserChgPass(const AmUserChgPassInput& input, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("old_password", 'S');
    packer->AddField("new_password", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.old_password.c_str());
    packer->AddStr(input.new_password.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(10003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [30001] 账户查询。
 * \details 支持查询登陆操作员有操作权限的有效账户列表。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmFundQuery(const AmFundQueryInput& input, std::list<AmFundQueryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(30001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmFundQueryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.account_name, unPacker->GetStr("account_name"));
                    safeAssign(item.account_type, unPacker->GetStr("account_type"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [30002] 资产单元查询。
 * \details 支持查询登陆操作员有操作权限的资产单元列表。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmAssetQuery(const AmAssetQueryInput& input, std::list<AmAssetQueryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("capital_account", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.capital_account.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(30002, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmAssetQueryOutput item;
                    safeAssign(item.capital_account, unPacker->GetStr("capital_account"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.asset_name, unPacker->GetStr("asset_name"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [30003] 组合查询。
 * \details 支持查询登陆操作员有操作权限且状态为有效的组合列表。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmCombiQuery(const AmCombiQueryInput& input, std::list<AmCombiQueryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(30003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmCombiQueryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.combi_name, unPacker->GetStr("combi_name"));
                    safeAssign(item.market_no_list, unPacker->GetStr("market_no_list"));
                    safeAssign(item.futu_invest_type, unPacker->GetStr("futu_invest_type"));
                    safeAssign(item.entrust_direction_list, unPacker->GetStr("entrust_direction_list"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [30004] 交易股东查询。
 * \details 支持查询组合默认交易股东信息。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmHolderQuery(const AmHolderQueryInput& input, std::list<AmHolderQueryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(30004, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmHolderQueryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35003] 账户资产查询。
 * \details 支持查询账户资产信息。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmFundAssetQry(const AmFundAssetQryInput& input, std::list<AmFundAssetQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("currency_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.currency_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmFundAssetQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.currency_code, unPacker->GetStr("currency_code"));
                    safeAssign(item.total_asset, unPacker->GetStr("total_asset"));
                    safeAssign(item.nav, unPacker->GetStr("nav"));
                    safeAssign(item.yesterday_nav, unPacker->GetStr("yesterday_nav"));
                    safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
                    safeAssign(item.begin_balance, unPacker->GetStr("begin_balance"));
                    safeAssign(item.futu_deposit_balance, unPacker->GetStr("futu_deposit_balance"));
                    safeAssign(item.occupy_deposit_balance, unPacker->GetStr("occupy_deposit_balance"));
                    safeAssign(item.futu_asset, unPacker->GetStr("futu_asset"));
                    safeAssign(item.stock_asset, unPacker->GetStr("stock_asset"));
                    safeAssign(item.bond_asset, unPacker->GetStr("bond_asset"));
                    safeAssign(item.fund_asset, unPacker->GetStr("fund_asset"));
                    safeAssign(item.repo_asset, unPacker->GetStr("repo_asset"));
                    safeAssign(item.other_asset, unPacker->GetStr("other_asset"));
                    safeAssign(item.fund_share, unPacker->GetStr("fund_share"));
                    safeAssign(item.fund_net_asset, unPacker->GetStr("fund_net_asset"));
                    safeAssign(item.payable_balance, unPacker->GetStr("payable_balance"));
                    safeAssign(item.receivable_balance, unPacker->GetStr("receivable_balance"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35011] 资产单元资产查询。
 * \details 支持查询资产单元资产信息。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmUnitAssetQry(const AmUnitAssetQryInput& input, std::list<AmUnitAssetQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("currency_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.currency_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35011, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmUnitAssetQryOutput item;
                    safeAssign(item.business_date, unPacker->GetStr("business_date"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.currency_code, unPacker->GetStr("currency_code"));
                    safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
                    safeAssign(item.begin_balance, unPacker->GetStr("begin_balance"));
                    safeAssign(item.futu_deposit_balance, unPacker->GetStr("futu_deposit_balance"));
                    safeAssign(item.futu_asset, unPacker->GetStr("futu_asset"));
                    safeAssign(item.stock_asset, unPacker->GetStr("stock_asset"));
                    safeAssign(item.bond_asset, unPacker->GetStr("bond_asset"));
                    safeAssign(item.fund_asset, unPacker->GetStr("fund_asset"));
                    safeAssign(item.repo_asset, unPacker->GetStr("repo_asset"));
                    safeAssign(item.option_asset, unPacker->GetStr("option_asset"));
                    safeAssign(item.other_asset, unPacker->GetStr("other_asset"));
                    safeAssign(item.payable_balance, unPacker->GetStr("payable_balance"));
                    safeAssign(item.receivable_balance, unPacker->GetStr("receivable_balance"));
                    safeAssign(item.futu_today_profit, unPacker->GetStr("futu_today_profit"));
                    safeAssign(item.futu_float_profit, unPacker->GetStr("futu_float_profit"));
                    safeAssign(item.futu_close_profit, unPacker->GetStr("futu_close_profit"));
                    safeAssign(item.futu_fee, unPacker->GetStr("futu_fee"));
                    safeAssign(item.spot_accumulate_profit, unPacker->GetStr("spot_accumulate_profit"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35012] 清算流水查询。
 * \details 支持查询当日清算流水。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmCurrentsQuery(const AmCurrentsQueryInput& input, std::list<AmCurrentsQueryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35012, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmCurrentsQueryOutput item;
                    safeAssign(item.business_date, unPacker->GetStr("business_date"));
                    safeAssign(item.business_time, unPacker->GetStr("business_time"));
                    safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
                    safeAssign(item.currency_code, unPacker->GetStr("currency_code"));
                    safeAssign(item.busin_no, unPacker->GetStr("busin_no"));
                    safeAssign(item.busin_caption, unPacker->GetStr("busin_caption"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.invest_type, unPacker->GetStr("invest_type"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.business_price, unPacker->GetStr("business_price"));
                    safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
                    safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
                    safeAssign(item.trade_fee, unPacker->GetStr("trade_fee"));
                    safeAssign(item.stamp_tax, unPacker->GetStr("stamp_tax"));
                    safeAssign(item.transfer_fee, unPacker->GetStr("transfer_fee"));
                    safeAssign(item.commission, unPacker->GetStr("commission"));
                    safeAssign(item.handling_fee, unPacker->GetStr("handling_fee"));
                    safeAssign(item.admin_fee, unPacker->GetStr("admin_fee"));
                    safeAssign(item.clearing_fee, unPacker->GetStr("clearing_fee"));
                    safeAssign(item.delivery_fee, unPacker->GetStr("delivery_fee"));
                    safeAssign(item.risk_fund, unPacker->GetStr("risk_fund"));
                    safeAssign(item.other_fee, unPacker->GetStr("other_fee"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.settle_speed, unPacker->GetStr("settle_speed"));
                    safeAssign(item.capital_direction, unPacker->GetStr("capital_direction"));
                    safeAssign(item.stock_direction, unPacker->GetStr("stock_direction"));
                    safeAssign(item.close_type, unPacker->GetStr("close_type"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [36012] 历史清算流水查询。
 * \details 支持查询历史清算流水。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmHistCurrentsQuery(const AmHistCurrentsQueryInput& input, std::list<AmHistCurrentsQueryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(36012, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmHistCurrentsQueryOutput item;
                    safeAssign(item.business_date, unPacker->GetStr("business_date"));
                    safeAssign(item.business_time, unPacker->GetStr("business_time"));
                    safeAssign(item.serial_no, unPacker->GetStr("serial_no"));
                    safeAssign(item.currency_code, unPacker->GetStr("currency_code"));
                    safeAssign(item.busin_no, unPacker->GetStr("busin_no"));
                    safeAssign(item.busin_caption, unPacker->GetStr("busin_caption"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.invest_type, unPacker->GetStr("invest_type"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.business_price, unPacker->GetStr("business_price"));
                    safeAssign(item.business_amount, unPacker->GetStr("business_amount"));
                    safeAssign(item.business_balance, unPacker->GetStr("business_balance"));
                    safeAssign(item.trade_fee, unPacker->GetStr("trade_fee"));
                    safeAssign(item.stamp_tax, unPacker->GetStr("stamp_tax"));
                    safeAssign(item.transfer_fee, unPacker->GetStr("transfer_fee"));
                    safeAssign(item.commission, unPacker->GetStr("commission"));
                    safeAssign(item.handling_fee, unPacker->GetStr("handling_fee"));
                    safeAssign(item.admin_fee, unPacker->GetStr("admin_fee"));
                    safeAssign(item.clearing_fee, unPacker->GetStr("clearing_fee"));
                    safeAssign(item.delivery_fee, unPacker->GetStr("delivery_fee"));
                    safeAssign(item.risk_fund, unPacker->GetStr("risk_fund"));
                    safeAssign(item.other_fee, unPacker->GetStr("other_fee"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.settle_speed, unPacker->GetStr("settle_speed"));
                    safeAssign(item.capital_direction, unPacker->GetStr("capital_direction"));
                    safeAssign(item.stock_direction, unPacker->GetStr("stock_direction"));
                    safeAssign(item.close_type, unPacker->GetStr("close_type"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35013] 保证金比例查询
 * \details 支持查询可期货保证金比例信息
 */
Intf_RetType PbUfxApiWrapper::pbufxAmDepositRatioQry(const AmDepositRatioQryInput& input, std::list<AmDepositRatioQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35013, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmDepositRatioQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.deposit_ratio, unPacker->GetStr("deposit_ratio"));
                    safeAssign(item.long_deposit_ratio, unPacker->GetStr("long_deposit_ratio"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35015] 资金调整
 * \details 支持资金调增、资金调减、保证金调增、保证金调减、资金投入、资金支取业务
 */
Intf_RetType PbUfxApiWrapper::pbufxAmCapitalAdjust(const AmCapitalAdjustInput& input, std::list<AmCapitalAdjustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("adjust_mode", 'S');
    packer->AddField("business_balance", 'S');
    packer->AddField("enable_date", 'S');
    packer->AddField("remark", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.adjust_mode.c_str());
    packer->AddStr(input.business_balance.c_str());
    packer->AddStr(input.enable_date.c_str());
    packer->AddStr(input.remark.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35015, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmCapitalAdjustOutput item;
                    safeAssign(item.adjust_result, unPacker->GetStr("adjust_result"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91001] 普通买卖委托
 * \details 支持沪深股票、基金、债券买卖，新股申购、质押式回购、债转股、债回售、基金认购、配股认购、配债认购、债券认购业务。
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuEntrust(const SecuEntrustInput& input, std::list<SecuEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91011] 股转做市委托
 * \details 支持股转市场做市业务
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferEnt(const SecuShareTransferEntInput& input, std::list<SecuShareTransferEntOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("buy_price", 'S');
    packer->AddField("buy_amount", 'S');
    packer->AddField("sell_price", 'S');
    packer->AddField("sell_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.buy_price.c_str());
    packer->AddStr(input.buy_amount.c_str());
    packer->AddStr(input.sell_price.c_str());
    packer->AddStr(input.sell_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91011, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferEntOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91115] 股转做市委托撤单（按委托序号）(新)
 * \details 支持按委托序号撤销股转做市委托。
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferWithdrawCombi(const SecuShareTransferWithdrawCombiInput& input, std::list<SecuShareTransferWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91115, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91113] 股转做市委托撤单（按委托序号）
 * \details 支持按委托序号撤销股转做市委托。
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferWithdrawByEntrustNo(const SecuShareTransferWithdrawByEntrustNoInput& input, std::list<SecuShareTransferWithdrawByEntrustNoOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91113, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferWithdrawByEntrustNoOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91090] 篮子委托
 * \details 支持沪深股票、基金、债券买卖和股指期货、国债期货、股票期权业务。
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuEntrustCombi(const SecuEntrustCombiInput& input, std::list<SecuEntrustCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("covered_flag", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("limit_entrust_ratio", 'S');
    packer->AddField("ftr_limit_entrust_ratio", 'S');
    packer->AddField("opt_limit_entrust_ratio", 'S');
    packer->AddField("invest_type", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.covered_flag.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.limit_entrust_ratio.c_str());
    packer->AddStr(input.ftr_limit_entrust_ratio.c_str());
    packer->AddStr(input.opt_limit_entrust_ratio.c_str());
    packer->AddStr(input.invest_type.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91090, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuEntrustCombiOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.request_order, unPacker->GetStr("request_order"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91114] 委托撤单(新)
 * \details 支持按委托序号撤单，可传入多个委托序号进行批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuEntrustWithdrawCombi(const SecuEntrustWithdrawCombiInput& input, std::list<SecuEntrustWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91114, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuEntrustWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91101] 委托撤单
 * \details 支持按委托序号撤单，可传入多个委托序号进行批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuEntrustWithdraw(const SecuEntrustWithdrawInput& input, std::list<SecuEntrustWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91101, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuEntrustWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91104] 股转做市委托撤单
 * \details 支持按委托批号撤销股转做市委托
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferWithdraw(const SecuShareTransferWithdrawInput& input, std::list<SecuShareTransferWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91104, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferWithdrawOutput item;
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [31001] 证券持仓查询
 * \details 支持查询沪深及股转市场的股票、基金、债券的持仓信息
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuUnitStkQry(const SecuUnitStkQryInput& input, std::list<SecuUnitStkQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("hold_seat", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.hold_seat.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(31001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuUnitStkQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.hold_seat, unPacker->GetStr("hold_seat"));
                    safeAssign(item.invest_type, unPacker->GetStr("invest_type"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
                    safeAssign(item.begin_cost, unPacker->GetStr("begin_cost"));
                    safeAssign(item.current_cost, unPacker->GetStr("current_cost"));
                    safeAssign(item.pre_buy_amount, unPacker->GetStr("pre_buy_amount"));
                    safeAssign(item.pre_sell_amount, unPacker->GetStr("pre_sell_amount"));
                    safeAssign(item.pre_buy_balance, unPacker->GetStr("pre_buy_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.today_buy_amount, unPacker->GetStr("today_buy_amount"));
                    safeAssign(item.today_sell_amount, unPacker->GetStr("today_sell_amount"));
                    safeAssign(item.today_buy_balance, unPacker->GetStr("today_buy_balance"));
                    safeAssign(item.today_sell_balance, unPacker->GetStr("today_sell_balance"));
                    safeAssign(item.today_buy_fee, unPacker->GetStr("today_buy_fee"));
                    safeAssign(item.today_sell_fee, unPacker->GetStr("today_sell_fee"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32001] 证券委托查询
 * \details 支持查询当日普通买卖委托流水
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuEntrustQry(const SecuEntrustQryInput& input, std::list<SecuEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.pre_buy_frozen_balance, unPacker->GetStr("pre_buy_frozen_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    safeAssign(item.exchange_report_no, unPacker->GetStr("exchange_report_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32101] 证券历史委托查询
 * \details 支持查询历史普通买卖委托流水
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuHistEntrustQry(const SecuHistEntrustQryInput& input, std::list<SecuHistEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32101, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuHistEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.pre_buy_frozen_balance, unPacker->GetStr("pre_buy_frozen_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32006] 股转做市委托查询
 * \details 支持查询当日股转做市委托
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferEntrQry(const SecuShareTransferEntrQryInput& input, std::list<SecuShareTransferEntrQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32006, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferEntrQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.buy_price, unPacker->GetStr("buy_price"));
                    safeAssign(item.buy_amount, unPacker->GetStr("buy_amount"));
                    safeAssign(item.sell_price, unPacker->GetStr("sell_price"));
                    safeAssign(item.sell_amount, unPacker->GetStr("sell_amount"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.buy_deal_amount, unPacker->GetStr("buy_deal_amount"));
                    safeAssign(item.buy_deal_balance, unPacker->GetStr("buy_deal_balance"));
                    safeAssign(item.sell_deal_amount, unPacker->GetStr("sell_deal_amount"));
                    safeAssign(item.sell_deal_balance, unPacker->GetStr("sell_deal_balance"));
                    safeAssign(item.buy_cancel_amount, unPacker->GetStr("buy_cancel_amount"));
                    safeAssign(item.sell_cancel_amount, unPacker->GetStr("sell_cancel_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33001] 证券成交查询
 * \details 支持查询当日普通买卖委托以及当日股转做市委托对应的成交流水
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuRealDealQry(const SecuRealDealQryInput& input, std::list<SecuRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.instance_no, unPacker->GetStr("instance_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33101] 证券历史成交查询
 * \details 支持查询历史普通买卖成交流水
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuHistRealDealQry(const SecuHistRealDealQryInput& input, std::list<SecuHistRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_serial_list", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_serial_list.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33101, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuHistRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [34001] 账户资金查询
 * \details 支持查询沪深A股及股转市场资金账户的资金可用，支持批量传入。
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuComboFundQry(const SecuComboFundQryInput& input, std::list<SecuComboFundQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(34001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuComboFundQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.enable_balance_t0, unPacker->GetStr("enable_balance_t0"));
                    safeAssign(item.enable_balance_t1, unPacker->GetStr("enable_balance_t1"));
                    safeAssign(item.current_balance, unPacker->GetStr("current_balance"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91051] 股转市场协议转让委托
 * \details 支持股转市场协议转让交易业务。
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferEntrust(const SecuShareTransferEntrustInput& input, std::list<SecuShareTransferEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("rival_holdid", 'S');
    packer->AddField("rival_seat", 'S');
    packer->AddField("engaged_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.rival_holdid.c_str());
    packer->AddStr(input.rival_seat.c_str());
    packer->AddStr(input.engaged_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91051, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91151] 股转市场协议转让委托撤单
 * \details 支持按委托序号撤单，可传入多个委托序号进行批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferEntrustWithdraw(const SecuShareTransferEntrustWithdrawInput& input, std::list<SecuShareTransferEntrustWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91151, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferEntrustWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91116] 股转市场协议转让委托撤单(新)
 * \details 支持按委托序号撤单，可传入多个委托序号进行批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxSecuShareTransferEntrustWithdrawCombi(const SecuShareTransferEntrustWithdrawCombiInput& input, std::list<SecuShareTransferEntrustWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91116, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    SecuShareTransferEntrustWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91003] 基金申赎
 * \details 支持沪深ETF、沪深跨市场ETF、沪深跨境ETF申赎业务
 */
Intf_RetType PbUfxApiWrapper::pbufxAmEtfDealing(const AmEtfDealingInput& input, std::list<AmEtfDealingOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmEtfDealingOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91008] 基金委托
 * \details 支持ETF（股票型ETF、债券型ETF、华宝兴业交易型货币基金、沪深跨境ETF、沪深黄金ETF、深交所交易型货币基金）、场内开放式基金申赎（LOF）、LOF基金分拆合并、转托管。
 */
Intf_RetType PbUfxApiWrapper::pbufxAmEtfEntrust(const AmEtfEntrustInput& input, std::list<AmEtfEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_balance", 'S');
    packer->AddField("purchase_way", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_balance.c_str());
    packer->AddStr(input.purchase_way.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91008, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    AmEtfEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32002] 基金委托查询
 * \details 支持查询当日基金委托流水。
 */
Intf_RetType PbUfxApiWrapper::pbufxFundEntrustQry(const FundEntrustQryInput& input, std::list<FundEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32002, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FundEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.entrust_balance, unPacker->GetStr("entrust_balance"));
                    safeAssign(item.purchase_way, unPacker->GetStr("purchase_way"));
                    safeAssign(item.pre_buy_frozen_balance, unPacker->GetStr("pre_buy_frozen_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    safeAssign(item.exchange_report_no, unPacker->GetStr("exchange_report_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32005] ETF申赎委托明细查询
 * \details 支持查询ETF申赎时的成份股和资金代码委托明细信息。
 */
Intf_RetType PbUfxApiWrapper::pbufxEtfDealingQry(const EtfDealingQryInput& input, std::list<EtfDealingQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32005, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    EtfDealingQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.detail_entrust_no, unPacker->GetStr("detail_entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33002] 基金成交查询
 * \details 支持查询当日基金委托成交流水
 */
Intf_RetType PbUfxApiWrapper::pbufxFundRealDealQry(const FundRealDealQryInput& input, std::list<FundRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33002, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FundRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33005] ETF申赎成交明细查询
 * \details 支持查询ETF申赎时的成份股和资金代码成交明细信息。
 */
Intf_RetType PbUfxApiWrapper::pbufxEtfDealingRealDealQry(const EtfDealingRealDealQryInput& input, std::list<EtfDealingRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33005, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    EtfDealingRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35014] ETF成份股信息查询
 * \details 支持查询沪深ETF成份股信息
 */
Intf_RetType PbUfxApiWrapper::pbufxEtfStockListQry(const EtfStockListQryInput& input, std::list<EtfStockListQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("etf_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.etf_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35014, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    EtfStockListQryOutput item;
                    safeAssign(item.business_date, unPacker->GetStr("business_date"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stock_amount, unPacker->GetStr("stock_amount"));
                    safeAssign(item.replace_flag, unPacker->GetStr("replace_flag"));
                    safeAssign(item.replace_ratio, unPacker->GetStr("replace_ratio"));
                    safeAssign(item.replace_balance, unPacker->GetStr("replace_balance"));
                    safeAssign(item.redeem_replace_balance, unPacker->GetStr("redeem_replace_balance"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35020] ETF基础信息查询
 * \details 支持沪深查询ETF基础信息
 */
Intf_RetType PbUfxApiWrapper::pbufxEtfBaseInfoQry(const EtfBaseInfoQryInput& input, std::list<EtfBaseInfoQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("etf_type", 'S');
    packer->AddField("etf_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.etf_type.c_str());
    packer->AddStr(input.etf_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35020, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    EtfBaseInfoQryOutput item;
                    safeAssign(item.business_date, unPacker->GetStr("business_date"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.etf_code, unPacker->GetStr("etf_code"));
                    safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stock_num, unPacker->GetStr("stock_num"));
                    safeAssign(item.creation_redeem_type, unPacker->GetStr("creation_redeem_type"));
                    safeAssign(item.etf_market_type, unPacker->GetStr("etf_market_type"));
                    safeAssign(item.rival_market, unPacker->GetStr("rival_market"));
                    safeAssign(item.etf_type, unPacker->GetStr("etf_type"));
                    safeAssign(item.max_cash_ratio, unPacker->GetStr("max_cash_ratio"));
                    safeAssign(item.report_unit, unPacker->GetStr("report_unit"));
                    safeAssign(item.yesterday_cash, unPacker->GetStr("yesterday_cash"));
                    safeAssign(item.yesterday_nav, unPacker->GetStr("yesterday_nav"));
                    safeAssign(item.estimate_cash, unPacker->GetStr("estimate_cash"));
                    safeAssign(item.underlying_index, unPacker->GetStr("underlying_index"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [30010] 期货信息查询
 * \details 支持查询期货市场未过期的期货信息。
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesInfoQry(const FuturesInfoQryInput& input, std::list<FuturesInfoQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(30010, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesInfoQryOutput item;
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stock_name, unPacker->GetStr("stock_name"));
                    safeAssign(item.future_kind_name, unPacker->GetStr("future_kind_name"));
                    safeAssign(item.settlement_month, unPacker->GetStr("settlement_month"));
                    safeAssign(item.target_market_no, unPacker->GetStr("target_market_no"));
                    safeAssign(item.target_stock_code, unPacker->GetStr("target_stock_code"));
                    safeAssign(item.multiple, unPacker->GetStr("multiple"));
                    safeAssign(item.last_trade_date, unPacker->GetStr("last_trade_date"));
                    safeAssign(item.last_trade_time, unPacker->GetStr("last_trade_time"));
                    safeAssign(item.settlement_date, unPacker->GetStr("settlement_date"));
                    safeAssign(item.settlement_price, unPacker->GetStr("settlement_price"));
                    safeAssign(item.pre_settlement_price, unPacker->GetStr("pre_settlement_price"));
                    safeAssign(item.market_position, unPacker->GetStr("market_position"));
                    safeAssign(item.pre_market_position, unPacker->GetStr("pre_market_position"));
                    safeAssign(item.market_price_permit, unPacker->GetStr("market_price_permit"));
                    safeAssign(item.uplimited_price, unPacker->GetStr("uplimited_price"));
                    safeAssign(item.downlimited_price, unPacker->GetStr("downlimited_price"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91004] 期货委托
 * \details 支持中金所股指期货、国债期货和上期所、大商所、郑商所、能源交易所的商品期货业务
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesEntrust(const FuturesEntrustInput& input, std::list<FuturesEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("close_direction", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("limit_deal_amount", 'S');
    packer->AddField("invest_type", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.close_direction.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.limit_deal_amount.c_str());
    packer->AddStr(input.invest_type.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91004, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91013] 商品期货组合单委托
 * \details 支持商品期货标准套利单、互换单业务。
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesPortfolioSingleEntrust(const FuturesPortfolioSingleEntrustInput& input, std::list<FuturesPortfolioSingleEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("limit_deal_amount", 'S');
    packer->AddField("invest_type", 'S');
    packer->AddField("portfolio_type", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.limit_deal_amount.c_str());
    packer->AddStr(input.invest_type.c_str());
    packer->AddStr(input.portfolio_type.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91013, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesPortfolioSingleEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91119] 期货委托撤单(新)
 * \details 支持按委托序号撤单，支持多条委托批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesEntrustWithdrawCombi(const FuturesEntrustWithdrawCombiInput& input, std::list<FuturesEntrustWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91119, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesEntrustWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91105] 期货委托撤单
 * \details 支持按委托序号撤单，支持多条委托批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesEntrustWithdraw(const FuturesEntrustWithdrawInput& input, std::list<FuturesEntrustWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91105, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesEntrustWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91121] 商品期货组合单委托撤单(新)
 * \details 支持商品期货组合单撤单，可传入多条委托进行批量撤单。
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesPortfolioSingleEntrustWithdrawCombi(const FuturesPortfolioSingleEntrustWithdrawCombiInput& input, std::list<FuturesPortfolioSingleEntrustWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91121, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesPortfolioSingleEntrustWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91107] 商品期货组合单委托撤单
 * \details 支持商品期货组合单撤单，可传入多条委托进行批量撤单。
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesPortfolioSingleEntrustWithdraw(const FuturesPortfolioSingleEntrustWithdrawInput& input, std::list<FuturesPortfolioSingleEntrustWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91107, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesPortfolioSingleEntrustWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [31003] 期货持仓查询
 * \details 支持查询期货持仓
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesUftUnitStkQry(const FuturesUftUnitStkQryInput& input, std::list<FuturesUftUnitStkQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("hold_seat", 'S');
    packer->AddField("invest_type", 'S');
    packer->AddField("position_flag", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.hold_seat.c_str());
    packer->AddStr(input.invest_type.c_str());
    packer->AddStr(input.position_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(31003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesUftUnitStkQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.hold_seat, unPacker->GetStr("hold_seat"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.invest_type, unPacker->GetStr("invest_type"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.today_amount, unPacker->GetStr("today_amount"));
                    safeAssign(item.lastday_amount, unPacker->GetStr("lastday_amount"));
                    safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
                    safeAssign(item.today_enable_amount, unPacker->GetStr("today_enable_amount"));
                    safeAssign(item.lastday_enable_amount, unPacker->GetStr("lastday_enable_amount"));
                    safeAssign(item.begin_cost, unPacker->GetStr("begin_cost"));
                    safeAssign(item.current_cost, unPacker->GetStr("current_cost"));
                    safeAssign(item.current_cost_price, unPacker->GetStr("current_cost_price"));
                    safeAssign(item.pre_buy_amount, unPacker->GetStr("pre_buy_amount"));
                    safeAssign(item.pre_sell_amount, unPacker->GetStr("pre_sell_amount"));
                    safeAssign(item.pre_buy_balance, unPacker->GetStr("pre_buy_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.today_buy_amount, unPacker->GetStr("today_buy_amount"));
                    safeAssign(item.today_sell_amount, unPacker->GetStr("today_sell_amount"));
                    safeAssign(item.today_buy_balance, unPacker->GetStr("today_buy_balance"));
                    safeAssign(item.today_sell_balance, unPacker->GetStr("today_sell_balance"));
                    safeAssign(item.today_buy_fee, unPacker->GetStr("today_buy_fee"));
                    safeAssign(item.today_sell_fee, unPacker->GetStr("today_sell_fee"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [31013] 期货持仓明细查询
 * \details 支持查询期货持仓明细
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesUnitStkDetailQry(const FuturesUnitStkDetailQryInput& input, std::list<FuturesUnitStkDetailQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("invest_type", 'S');
    packer->AddField("position_flag", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.invest_type.c_str());
    packer->AddStr(input.position_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(31013, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesUnitStkDetailQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.invest_type, unPacker->GetStr("invest_type"));
                    safeAssign(item.stock_open_date, unPacker->GetStr("stock_open_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.open_amount, unPacker->GetStr("open_amount"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.drop_amount, unPacker->GetStr("drop_amount"));
                    safeAssign(item.occupy_deposit_balance, unPacker->GetStr("occupy_deposit_balance"));
                    safeAssign(item.open_price, unPacker->GetStr("open_price"));
                    safeAssign(item.drop_income, unPacker->GetStr("drop_income"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.pre_settlement_price, unPacker->GetStr("pre_settlement_price"));
                    safeAssign(item.multiple, unPacker->GetStr("multiple"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32003] 期货委托查询
 * \details 支持查询当日期货委托流水
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesEntrustQry(const FuturesEntrustQryInput& input, std::list<FuturesEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.pre_buy_frozen_balance, unPacker->GetStr("pre_buy_frozen_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    safeAssign(item.exchange_report_no, unPacker->GetStr("exchange_report_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32103] 期货历史委托查询
 * \details 支持查询期货历史普通买卖委托流水
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesHistEntrustQry(const FuturesHistEntrustQryInput& input, std::list<FuturesHistEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32103, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesHistEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.pre_buy_frozen_balance, unPacker->GetStr("pre_buy_frozen_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32008] 商品期货组合委托查询
 * \details 支持查询当日商品期货组合委托流水
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesPortfolioSingleEntrustQry(const FuturesPortfolioSingleEntrustQryInput& input, std::list<FuturesPortfolioSingleEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("portfolio_type", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.portfolio_type.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32008, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesPortfolioSingleEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.portfolio_type, unPacker->GetStr("portfolio_type"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.limit_deal_amount, unPacker->GetStr("limit_deal_amount"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.buy_deal_balance, unPacker->GetStr("buy_deal_balance"));
                    safeAssign(item.buy_deal_price, unPacker->GetStr("buy_deal_price"));
                    safeAssign(item.sell_deal_balance, unPacker->GetStr("sell_deal_balance"));
                    safeAssign(item.sell_deal_price, unPacker->GetStr("sell_deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33003] 期货成交查询
 * \details 支持查询当日期货成交流水
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesRealDealQry(const FuturesRealDealQryInput& input, std::list<FuturesRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("close_type", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.close_type.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.instance_no, unPacker->GetStr("instance_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.close_type, unPacker->GetStr("close_type"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33103] 期货历史成交查询
 * \details 支持查询期货历史期货成交流水
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesHistRealDealQry(const FuturesHistRealDealQryInput& input, std::list<FuturesHistRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("start_date", 'S');
    packer->AddField("end_date", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_serial_list", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.start_date.c_str());
    packer->AddStr(input.end_date.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_serial_list.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33103, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesHistRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.instance_no, unPacker->GetStr("instance_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [34003] 期货保证金账户查询
 * \details 支持查询期货保证金账户的资金可用信息，可查询期货、股指期权可用保证金，支持批量传入。
 */
Intf_RetType PbUfxApiWrapper::pbufxFuturesComboFundQry(const FuturesComboFundQryInput& input, std::list<FuturesComboFundQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(34003, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    FuturesComboFundQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.occupy_deposit_balance, unPacker->GetStr("occupy_deposit_balance"));
                    safeAssign(item.enable_deposit_balance, unPacker->GetStr("enable_deposit_balance"));
                    safeAssign(item.futu_deposit_balance, unPacker->GetStr("futu_deposit_balance"));
                    safeAssign(item.futu_temp_occupy_deposit, unPacker->GetStr("futu_temp_occupy_deposit"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91005] 期权委托
 * \details 支持沪深股票期权、中金所股指期权交易业务
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptEntrust(const StkOptEntrustInput& input, std::list<StkOptEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("covered_flag", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.covered_flag.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91005, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91006] 备兑锁定与解锁
 * \details 支持沪深股票期权保证券的锁定与解锁业务
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptLockEntrust(const StkOptLockEntrustInput& input, std::list<StkOptLockEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91006, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptLockEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91007] 期权行权
 * \details 支持沪深股票期权行权业务
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptExerciseEntrust(const StkOptExerciseEntrustInput& input, std::list<StkOptExerciseEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91007, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptExerciseEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91012] 股指期权做市委托
 * \details 支持股指期权做市业务
 */
Intf_RetType PbUfxApiWrapper::pbufxIndexOptionsMarketEntrust(const IndexOptionsMarketEntrustInput& input, std::list<IndexOptionsMarketEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("buy_direction", 'S');
    packer->AddField("buy_price", 'S');
    packer->AddField("buy_amount", 'S');
    packer->AddField("sell_direction", 'S');
    packer->AddField("sell_price", 'S');
    packer->AddField("sell_amount", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.buy_direction.c_str());
    packer->AddStr(input.buy_price.c_str());
    packer->AddStr(input.buy_amount.c_str());
    packer->AddStr(input.sell_direction.c_str());
    packer->AddStr(input.sell_price.c_str());
    packer->AddStr(input.sell_amount.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91012, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    IndexOptionsMarketEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91014] 期权做市合笔委托
 * \details 支持深交所股票期权,中金所股指期权做市业务，支持批量传入
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptShareTransferEntrust(const StkOptShareTransferEntrustInput& input, std::list<StkOptShareTransferEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("buy_direction", 'S');
    packer->AddField("buy_price", 'S');
    packer->AddField("buy_amount", 'S');
    packer->AddField("sell_direction", 'S');
    packer->AddField("sell_price", 'S');
    packer->AddField("sell_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.buy_direction.c_str());
    packer->AddStr(input.buy_price.c_str());
    packer->AddStr(input.buy_amount.c_str());
    packer->AddStr(input.sell_direction.c_str());
    packer->AddStr(input.sell_price.c_str());
    packer->AddStr(input.sell_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91014, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptShareTransferEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91091] 期权篮子委托
 * \details 支持上交所股票期权篮子委托业务，用于股票期权批量下单和做市委托。
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptCombiEntrust(const StkOptCombiEntrustInput& input, std::list<StkOptCombiEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("price_type", 'S');
    packer->AddField("entrust_price", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("covered_flag", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.price_type.c_str());
    packer->AddStr(input.entrust_price.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.covered_flag.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91091, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptCombiEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91120] 期权委托撤单(新)
 * \details 支持按委托序号撤销期权(股票期权、股指期权）委托，可传入多个委托序号进行批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptEntrustWithdrawCombi(const StkOptEntrustWithdrawCombiInput& input, std::list<StkOptEntrustWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91120, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptEntrustWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91106] 期权委托撤单
 * \details 支持按委托序号撤销期权(股票期权、股指期权）委托，可传入多个委托序号进行批量撤单
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptEntrustWithdraw(const StkOptEntrustWithdrawInput& input, std::list<StkOptEntrustWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91106, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptEntrustWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91108] 股指期权做市委托撤单
 * \details 支持按委托批号撤销股指期权委托
 */
Intf_RetType PbUfxApiWrapper::pbufxIndexOptionsMarketWithdraw(const IndexOptionsMarketWithdrawInput& input, std::list<IndexOptionsMarketWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91108, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    IndexOptionsMarketWithdrawOutput item;
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91122] 期权做市合笔委托撤单(新)
 * \details 支持撤销深交所股票期权做市委托,中金所股指期权做市委托
 */
Intf_RetType PbUfxApiWrapper::pbufxOptMarketEntrustWithdrawCombi(const OptMarketEntrustWithdrawCombiInput& input, std::list<OptMarketEntrustWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91122, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptMarketEntrustWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91109] 期权做市合笔委托撤单
 * \details 支持撤销深交所股票期权做市委托,中金所股指期权做市委托
 */
Intf_RetType PbUfxApiWrapper::pbufxOptMarketEntrustWithdraw(const OptMarketEntrustWithdrawInput& input, std::list<OptMarketEntrustWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91109, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptMarketEntrustWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91123] 期权行权撤单(新)
 * \details 支持沪深股票期权行权撤单，可传入多条委托序号进行批量撤单。
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptExerciseWithdrawCombi(const StkOptExerciseWithdrawCombiInput& input, std::list<StkOptExerciseWithdrawCombiOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91123, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptExerciseWithdrawCombiOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91111] 期权行权撤单
 * \details 支持沪深股票期权行权撤单，可传入多条委托序号进行批量撤单。
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptExerciseWithdraw(const StkOptExerciseWithdrawInput& input, std::list<StkOptExerciseWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91111, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptExerciseWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91112] 期权行权撤单(按委托批号撤单)
 * \details 支持沪深股票期权行权按委托批号撤单。
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptExerciseBatchnoWithdraw(const StkOptExerciseBatchnoWithdrawInput& input, std::list<StkOptExerciseBatchnoWithdrawOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91112, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptExerciseBatchnoWithdrawOutput item;
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.success_flag, unPacker->GetStr("success_flag"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [31004] 期权持仓查询
 * \details 支持查询沪深股票期权、中金所股指期权持仓信息
 */
Intf_RetType PbUfxApiWrapper::pbufxOptionsUftUnitStkQry(const OptionsUftUnitStkQryInput& input, std::list<OptionsUftUnitStkQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("hold_seat", 'S');
    packer->AddField("option_type", 'S');
    packer->AddField("position_flag", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.hold_seat.c_str());
    packer->AddStr(input.option_type.c_str());
    packer->AddStr(input.position_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(31004, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptionsUftUnitStkQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.option_type, unPacker->GetStr("option_type"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.hold_seat, unPacker->GetStr("hold_seat"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
                    safeAssign(item.begin_cost, unPacker->GetStr("begin_cost"));
                    safeAssign(item.current_cost, unPacker->GetStr("current_cost"));
                    safeAssign(item.pre_buy_amount, unPacker->GetStr("pre_buy_amount"));
                    safeAssign(item.pre_sell_amount, unPacker->GetStr("pre_sell_amount"));
                    safeAssign(item.pre_buy_balance, unPacker->GetStr("pre_buy_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.today_buy_amount, unPacker->GetStr("today_buy_amount"));
                    safeAssign(item.today_sell_amount, unPacker->GetStr("today_sell_amount"));
                    safeAssign(item.today_buy_balance, unPacker->GetStr("today_buy_balance"));
                    safeAssign(item.today_sell_balance, unPacker->GetStr("today_sell_balance"));
                    safeAssign(item.today_buy_fee, unPacker->GetStr("today_buy_fee"));
                    safeAssign(item.today_sell_fee, unPacker->GetStr("today_sell_fee"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32004] 期权委托查询
 * \details 支持查询沪深股票期权、中金所股指期权当日委托流水
 */
Intf_RetType PbUfxApiWrapper::pbufxOptionsEntrustQry(const OptionsEntrustQryInput& input, std::list<OptionsEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("option_type", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');
    packer->AddField("entrust_serial_list", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.option_type.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->AddStr(input.entrust_serial_list.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32004, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptionsEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.option_type, unPacker->GetStr("option_type"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.pre_buy_frozen_balance, unPacker->GetStr("pre_buy_frozen_balance"));
                    safeAssign(item.pre_sell_balance, unPacker->GetStr("pre_sell_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.covered_flag, unPacker->GetStr("covered_flag"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.first_deal_time, unPacker->GetStr("first_deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.withdraw_amount, unPacker->GetStr("withdraw_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    safeAssign(item.exchange_report_no, unPacker->GetStr("exchange_report_no"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32007] 期权做市委托查询
 * \details 支持查询当日股指期权、深交所股票期权做市委托
 */
Intf_RetType PbUfxApiWrapper::pbufxOptionsMarketEntrustQry(const OptionsMarketEntrustQryInput& input, std::list<OptionsMarketEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32007, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptionsMarketEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.buy_direction, unPacker->GetStr("buy_direction"));
                    safeAssign(item.buy_covered_flag, unPacker->GetStr("buy_covered_flag"));
                    safeAssign(item.buy_price, unPacker->GetStr("buy_price"));
                    safeAssign(item.buy_amount, unPacker->GetStr("buy_amount"));
                    safeAssign(item.sell_direction, unPacker->GetStr("sell_direction"));
                    safeAssign(item.sell_covered_flag, unPacker->GetStr("sell_covered_flag"));
                    safeAssign(item.sell_price, unPacker->GetStr("sell_price"));
                    safeAssign(item.sell_amount, unPacker->GetStr("sell_amount"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.buy_deal_amount, unPacker->GetStr("buy_deal_amount"));
                    safeAssign(item.buy_deal_balance, unPacker->GetStr("buy_deal_balance"));
                    safeAssign(item.sell_deal_amount, unPacker->GetStr("sell_deal_amount"));
                    safeAssign(item.sell_deal_balance, unPacker->GetStr("sell_deal_balance"));
                    safeAssign(item.buy_cancel_amount, unPacker->GetStr("buy_cancel_amount"));
                    safeAssign(item.sell_cancel_amount, unPacker->GetStr("sell_cancel_amount"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33004] 期权成交查询
 * \details 支持查询沪深股票期权、中金所股指期权当日成交流水
 */
Intf_RetType PbUfxApiWrapper::pbufxOptionsRealDealQry(const OptionsRealDealQryInput& input, std::list<OptionsRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("option_type", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');
    packer->AddField("entrust_serial_list", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.option_type.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->AddStr(input.entrust_serial_list.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33004, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptionsRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.instance_no, unPacker->GetStr("instance_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.option_type, unPacker->GetStr("option_type"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [34004] 期权保证金账户查询
 * \details 支持沪深衍生品保证金账户查询（股指期权保证金账户请使用34003接口查询）。
 */
Intf_RetType PbUfxApiWrapper::pbufxOptionsDepositQry(const OptionsDepositQryInput& input, std::list<OptionsDepositQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(34004, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    OptionsDepositQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.occupy_deposit_balance, unPacker->GetStr("occupy_deposit_balance"));
                    safeAssign(item.enable_deposit_balance, unPacker->GetStr("enable_deposit_balance"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [91015] 上交所股票期权组合保证金委托
 * \details 支持上交所股票期权组合策略保证金交易业务
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptDepositEntrust(const StkOptDepositEntrustInput& input, std::list<StkOptDepositEntrustOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("combistrategy_code", 'S');
    packer->AddField("combistrategy_id", 'S');
    packer->AddField("combi_direction", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("report_seat", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code1", 'S');
    packer->AddField("stock_code2", 'S');
    packer->AddField("stock_code3", 'S');
    packer->AddField("stock_code4", 'S');
    packer->AddField("entrust_amount", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("mac_address", 'S');
    packer->AddField("ip_address", 'S');
    packer->AddField("hd_volserial", 'S');
    packer->AddField("op_station", 'S');
    packer->AddField("terminal_info", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.combistrategy_code.c_str());
    packer->AddStr(input.combistrategy_id.c_str());
    packer->AddStr(input.combi_direction.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code1.c_str());
    packer->AddStr(input.stock_code2.c_str());
    packer->AddStr(input.stock_code3.c_str());
    packer->AddStr(input.stock_code4.c_str());
    packer->AddStr(input.entrust_amount.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.mac_address.c_str());
    packer->AddStr(input.ip_address.c_str());
    packer->AddStr(input.hd_volserial.c_str());
    packer->AddStr(input.op_station.c_str());
    packer->AddStr(input.terminal_info.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(91015, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptDepositEntrustOutput item;
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.entrust_fail_code, unPacker->GetStr("entrust_fail_code"));
                    safeAssign(item.fail_cause, unPacker->GetStr("fail_cause"));
                    safeAssign(item.risk_serial_no, unPacker->GetStr("risk_serial_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.combi_direction, unPacker->GetStr("combi_direction"));
                    safeAssign(item.risk_no, unPacker->GetStr("risk_no"));
                    safeAssign(item.risk_type, unPacker->GetStr("risk_type"));
                    safeAssign(item.risk_summary, unPacker->GetStr("risk_summary"));
                    safeAssign(item.risk_operation, unPacker->GetStr("risk_operation"));
                    safeAssign(item.remark_short, unPacker->GetStr("remark_short"));
                    safeAssign(item.risk_threshold_value, unPacker->GetStr("risk_threshold_value"));
                    safeAssign(item.risk_value, unPacker->GetStr("risk_value"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [31015] 上交所股票期权组合保证金持仓查询
 * \details 支持查询上交所股票期权组合策略保证金持仓信息
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptDepositUnitStkQry(const StkOptDepositUnitStkQryInput& input, std::list<StkOptDepositUnitStkQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("combistrategy_code", 'S');
    packer->AddField("stock_code1", 'S');
    packer->AddField("stock_code2", 'S');
    packer->AddField("stock_code3", 'S');
    packer->AddField("stock_code4", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("hold_seat", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.combistrategy_code.c_str());
    packer->AddStr(input.stock_code1.c_str());
    packer->AddStr(input.stock_code2.c_str());
    packer->AddStr(input.stock_code3.c_str());
    packer->AddStr(input.stock_code4.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.hold_seat.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(31015, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptDepositUnitStkQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.combistrategy_code, unPacker->GetStr("combistrategy_code"));
                    safeAssign(item.combistrategy_id, unPacker->GetStr("combistrategy_id"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.hold_seat, unPacker->GetStr("hold_seat"));
                    safeAssign(item.stock_code1, unPacker->GetStr("stock_code1"));
                    safeAssign(item.position_flag1, unPacker->GetStr("position_flag1"));
                    safeAssign(item.stock_code2, unPacker->GetStr("stock_code2"));
                    safeAssign(item.position_flag2, unPacker->GetStr("position_flag2"));
                    safeAssign(item.stock_code3, unPacker->GetStr("stock_code3"));
                    safeAssign(item.position_flag3, unPacker->GetStr("position_flag3"));
                    safeAssign(item.stock_code4, unPacker->GetStr("stock_code4"));
                    safeAssign(item.position_flag4, unPacker->GetStr("position_flag4"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.frozen_amount, unPacker->GetStr("frozen_amount"));
                    safeAssign(item.combi_deposit_pre, unPacker->GetStr("combi_deposit_pre"));
                    safeAssign(item.combi_deposit_now, unPacker->GetStr("combi_deposit_now"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [32015] 上交所股票期权组合保证金委托查询
 * \details 支持查询上交所股票期权组合策略保证金委托信息
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptDepositEntrustQry(const StkOptDepositEntrustQryInput& input, std::list<StkOptDepositEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("combistrategy_code", 'S');
    packer->AddField("stock_code1", 'S');
    packer->AddField("stock_code2", 'S');
    packer->AddField("stock_code3", 'S');
    packer->AddField("stock_code4", 'S');
    packer->AddField("combi_direction", 'S');
    packer->AddField("entrust_state_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.combistrategy_code.c_str());
    packer->AddStr(input.stock_code1.c_str());
    packer->AddStr(input.stock_code2.c_str());
    packer->AddStr(input.stock_code3.c_str());
    packer->AddStr(input.stock_code4.c_str());
    packer->AddStr(input.combi_direction.c_str());
    packer->AddStr(input.entrust_state_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(32015, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptDepositEntrustQryOutput item;
                    safeAssign(item.entrust_date, unPacker->GetStr("entrust_date"));
                    safeAssign(item.entrust_time, unPacker->GetStr("entrust_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.report_no, unPacker->GetStr("report_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.combistrategy_code, unPacker->GetStr("combistrategy_code"));
                    safeAssign(item.stock_code1, unPacker->GetStr("stock_code1"));
                    safeAssign(item.stock_code2, unPacker->GetStr("stock_code2"));
                    safeAssign(item.stock_code3, unPacker->GetStr("stock_code3"));
                    safeAssign(item.stock_code4, unPacker->GetStr("stock_code4"));
                    safeAssign(item.combistrategy_id, unPacker->GetStr("combistrategy_id"));
                    safeAssign(item.combi_direction, unPacker->GetStr("combi_direction"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_state, unPacker->GetStr("entrust_state"));
                    safeAssign(item.withdraw_cause, unPacker->GetStr("withdraw_cause"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [33015] 上交所股票期权组合保证金成交查询
 * \details 支持查询上交所股票期权组合策略保证金成交信息
 */
Intf_RetType PbUfxApiWrapper::pbufxStkOptDepositDealQry(const StkOptDepositDealQryInput& input, std::list<StkOptDepositDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("combistrategy_code", 'S');
    packer->AddField("stock_code1", 'S');
    packer->AddField("stock_code2", 'S');
    packer->AddField("stock_code3", 'S');
    packer->AddField("stock_code4", 'S');
    packer->AddField("combi_direction", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("position_str", 'S');
    packer->AddField("request_num", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.combistrategy_code.c_str());
    packer->AddStr(input.stock_code1.c_str());
    packer->AddStr(input.stock_code2.c_str());
    packer->AddStr(input.stock_code3.c_str());
    packer->AddStr(input.stock_code4.c_str());
    packer->AddStr(input.combi_direction.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.position_str.c_str());
    packer->AddStr(input.request_num.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(33015, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    StkOptDepositDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.combistrategy_code, unPacker->GetStr("combistrategy_code"));
                    safeAssign(item.stock_code1, unPacker->GetStr("stock_code1"));
                    safeAssign(item.stock_code2, unPacker->GetStr("stock_code2"));
                    safeAssign(item.stock_code3, unPacker->GetStr("stock_code3"));
                    safeAssign(item.stock_code4, unPacker->GetStr("stock_code4"));
                    safeAssign(item.combistrategy_id, unPacker->GetStr("combistrategy_id"));
                    safeAssign(item.combi_direction, unPacker->GetStr("combi_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.position_str, unPacker->GetStr("position_str"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [31005] 多业务持仓查询
 * \details 支持查询现货、期货、期权持仓信息
 */
Intf_RetType PbUfxApiWrapper::pbufxCombUnitStkQry(const CombUnitStkQryInput& input, std::list<CombUnitStkQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("hold_seat", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.hold_seat.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(31005, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    CombUnitStkQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.hold_seat, unPacker->GetStr("hold_seat"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.invest_type, unPacker->GetStr("invest_type"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
                    safeAssign(item.current_cost, unPacker->GetStr("current_cost"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35001] 组合持仓查询
 * \details 查询组合当前持仓
 */
Intf_RetType PbUfxApiWrapper::pbufxCombUftUnitStkQry(const CombUftUnitStkQryInput& input, std::list<CombUftUnitStkQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("market_no_list", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("hold_seat", 'S');
    packer->AddField("invest_type", 'S');
    packer->AddField("position_flag", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.market_no_list.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.hold_seat.c_str());
    packer->AddStr(input.invest_type.c_str());
    packer->AddStr(input.position_flag.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35001, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    CombUftUnitStkQryOutput item;
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.hold_seat, unPacker->GetStr("hold_seat"));
                    safeAssign(item.position_flag, unPacker->GetStr("position_flag"));
                    safeAssign(item.current_amount, unPacker->GetStr("current_amount"));
                    safeAssign(item.enable_amount, unPacker->GetStr("enable_amount"));
                    safeAssign(item.pri_enable_amount, unPacker->GetStr("pri_enable_amount"));
                    safeAssign(item.begin_balance, unPacker->GetStr("begin_balance"));
                    safeAssign(item.current_cost, unPacker->GetStr("current_cost"));
                    safeAssign(item.pre_buy_amount, unPacker->GetStr("pre_buy_amount"));
                    safeAssign(item.pre_sell_amount, unPacker->GetStr("pre_sell_amount"));
                    safeAssign(item.pre_buy_balance, unPacker->GetStr("pre_buy_balance"));
                    safeAssign(item.pre_sale_balance, unPacker->GetStr("pre_sale_balance"));
                    safeAssign(item.buy_amount, unPacker->GetStr("buy_amount"));
                    safeAssign(item.sell_amount, unPacker->GetStr("sell_amount"));
                    safeAssign(item.buy_balance, unPacker->GetStr("buy_balance"));
                    safeAssign(item.sale_balance, unPacker->GetStr("sale_balance"));
                    safeAssign(item.buy_fee, unPacker->GetStr("buy_fee"));
                    safeAssign(item.sale_fee, unPacker->GetStr("sale_fee"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35006] 当日委托查询
 * \details 查询当日委托信息
 */
Intf_RetType PbUfxApiWrapper::pbufxCombEntrustQry(const CombEntrustQryInput& input, std::list<CombEntrustQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no_list", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("entrust_status_list", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no_list.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.entrust_status_list.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35006, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    CombEntrustQryOutput item;
                    safeAssign(item.business_date, unPacker->GetStr("business_date"));
                    safeAssign(item.business_time, unPacker->GetStr("business_time"));
                    safeAssign(item.operator_no, unPacker->GetStr("operator_no"));
                    safeAssign(item.batch_no, unPacker->GetStr("batch_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.report_seat, unPacker->GetStr("report_seat"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.price_type, unPacker->GetStr("price_type"));
                    safeAssign(item.entrust_price, unPacker->GetStr("entrust_price"));
                    safeAssign(item.entrust_amount, unPacker->GetStr("entrust_amount"));
                    safeAssign(item.prebuy_frozen_balance, unPacker->GetStr("prebuy_frozen_balance"));
                    safeAssign(item.presale_balance, unPacker->GetStr("presale_balance"));
                    safeAssign(item.confirm_no, unPacker->GetStr("confirm_no"));
                    safeAssign(item.entrust_status, unPacker->GetStr("entrust_status"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_times, unPacker->GetStr("deal_times"));
                    safeAssign(item.cancel_amount, unPacker->GetStr("cancel_amount"));
                    safeAssign(item.revoke_cause, unPacker->GetStr("revoke_cause"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
/*!
 * \brief [35007] 当日成交查询
 * \details 查询当日成交信息
 */
Intf_RetType PbUfxApiWrapper::pbufxCombRealDealQry(const CombRealDealQryInput& input, std::list<CombRealDealQryOutput>& output, std::string& errMsg)
{
    pbufxLogger() << input;

    IF2Packer* packer = NewPacker(2);
    packer->AddRef();
    packer->BeginPack();
    packer->AddField("user_token", 'S');
    packer->AddField("account_code", 'S');
    packer->AddField("asset_no", 'S');
    packer->AddField("combi_no", 'S');
    packer->AddField("entrust_no", 'S');
    packer->AddField("deal_no", 'S');
    packer->AddField("stockholder_id", 'S');
    packer->AddField("market_no_list", 'S');
    packer->AddField("stock_code", 'S');
    packer->AddField("stock_type", 'S');
    packer->AddField("entrust_direction", 'S');
    packer->AddField("futures_direction", 'S');
    packer->AddField("extsystem_id", 'S');
    packer->AddField("third_reff", 'S');
    packer->AddField("batch_no", 'S');
    packer->AddField("report_seat", 'S');

    packer->AddStr(input.user_token.c_str());
    packer->AddStr(input.account_code.c_str());
    packer->AddStr(input.asset_no.c_str());
    packer->AddStr(input.combi_no.c_str());
    packer->AddStr(input.entrust_no.c_str());
    packer->AddStr(input.deal_no.c_str());
    packer->AddStr(input.stockholder_id.c_str());
    packer->AddStr(input.market_no_list.c_str());
    packer->AddStr(input.stock_code.c_str());
    packer->AddStr(input.stock_type.c_str());
    packer->AddStr(input.entrust_direction.c_str());
    packer->AddStr(input.futures_direction.c_str());
    packer->AddStr(input.extsystem_id.c_str());
    packer->AddStr(input.third_reff.c_str());
    packer->AddStr(input.batch_no.c_str());
    packer->AddStr(input.report_seat.c_str());
    packer->EndPack();

    int result;
    if ((result = mConnection->SendBiz(35007, packer, 0, 2)) <= 0){
        PbUfxReader::freePacker(packer);
        return kIntfSendFail;
    }

    IF2UnPacker *unPacker = NULL;
    result = mConnection->RecvBiz(result, (void**)&unPacker);
    if (result == 0) {
        unPacker->SetCurrentDatasetByIndex(0);
        if (unPacker->GetInt("ErrorCode") != 0) {
            errMsg = StringHelper::convertCodec(unPacker->GetStr("ErrorMsg"));
            return kIntfWorkFail;
        } else {
            errMsg.assign("业务操作成功。");
            std::cout << errMsg << std::endl;
            for (int datasetIndex = 1; datasetIndex < unPacker->GetDatasetCount(); datasetIndex++) {
                unPacker->SetCurrentDatasetByIndex(datasetIndex);
                for (int recordIndex = 0; recordIndex < unPacker->GetRowCount(); recordIndex++) {
                    CombRealDealQryOutput item;
                    safeAssign(item.deal_date, unPacker->GetStr("deal_date"));
                    safeAssign(item.deal_no, unPacker->GetStr("deal_no"));
                    safeAssign(item.entrust_no, unPacker->GetStr("entrust_no"));
                    safeAssign(item.extsystem_id, unPacker->GetStr("extsystem_id"));
                    safeAssign(item.third_reff, unPacker->GetStr("third_reff"));
                    safeAssign(item.account_code, unPacker->GetStr("account_code"));
                    safeAssign(item.asset_no, unPacker->GetStr("asset_no"));
                    safeAssign(item.combi_no, unPacker->GetStr("combi_no"));
                    safeAssign(item.instance_no, unPacker->GetStr("instance_no"));
                    safeAssign(item.stockholder_id, unPacker->GetStr("stockholder_id"));
                    safeAssign(item.market_no, unPacker->GetStr("market_no"));
                    safeAssign(item.stock_code, unPacker->GetStr("stock_code"));
                    safeAssign(item.entrust_direction, unPacker->GetStr("entrust_direction"));
                    safeAssign(item.futures_direction, unPacker->GetStr("futures_direction"));
                    safeAssign(item.deal_amount, unPacker->GetStr("deal_amount"));
                    safeAssign(item.deal_price, unPacker->GetStr("deal_price"));
                    safeAssign(item.deal_balance, unPacker->GetStr("deal_balance"));
                    safeAssign(item.total_fee, unPacker->GetStr("total_fee"));
                    safeAssign(item.deal_time, unPacker->GetStr("deal_time"));
                    output.push_back(item);

                    unPacker->Next();
                    pbufxLogger() << item;
                }
            }
        }
    } else if(result == 1) {
        PbUfxReader::freePacker(packer);
        errMsg.assign(string("业务操作失败：") + StringHelper::convertCodec(unPacker->GetStr("error_info")));
        std::cout << errMsg << std::endl;
        return kIntfWorkFail;
    }else{
        return onRecvCommonError(result, unPacker, errMsg);
    }
    return kIntfSuccess;
}
