#include "OgsLogger.h"
#include "OgsMessage.h"
#include "OgsApi.h"
#include "Interface.h"
#include "ogs_dict.h"

template <typename ItemType> void logOgsMessageItems(OgsMessage& ogsMsg)
{
    ItemType* array;
    if (!ogsMsg.parse(&array)) {
        ogsDebug << "[OgsLogger] " << ogsMsg.error();
    }
    for (int i = 0; i < ogsMsg.itemCount(); i++) {
        ogsLogger().lockLessLog(array[i]);
    }
}

std::mutex &OgsLogger::mutex()
{
    return mMutex;
}

OgsLogger &OgsLogger::operator <<(ogs::LoginQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::LoginAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::SendOrderQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::SendOrderAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::CancelOrderQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::CancelOrderAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryOrderQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryOrderAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryBargainQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryBargainAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryFundInfoQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryFundInfoAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryPositionQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::QueryPositionAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::PaybackSecurityQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::PaybackSecurityAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::PaybackFundsQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::PaybackFundsAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::HeartBeatQry &qry)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(qry);
    return (*this);
}

OgsLogger &OgsLogger::operator <<(ogs::HeartBeatAns &ans)
{
    LOCK_OGSLOGGER(*this);
    lockLessLog(ans);
    return (*this);
}

void OgsLogger::lockLessLog(ogs::LoginQry &qry) const
{
    ogsDebug << "#--[LoginQry]----------------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::LoginAns &ans) const
{
    ogsDebug << "#--[LoginAns]----------------------------------";
    ogsDebug << "# bacid:            " << ans.bacid;

}

void OgsLogger::lockLessLog(ogs::SendOrderQry &qry) const
{
    ogsDebug << "#--[SendOrderQry]------------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# innerCode:        " << qry.innerCode;
    ogsDebug << "# directive:        " << qry.directive;
    ogsDebug << "# execution:        " << qry.execution;
    ogsDebug << "# price:            " << qry.price;
    ogsDebug << "# volume:           " << qry.volume;
    ogsDebug << "# custOrderId:      " << qry.custOrderId;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::SendOrderAns &ans) const
{
    ogsDebug << "#--[SendOrderAns]------------------------------";
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# custOrderId:      " << ans.custOrderId;
    ogsDebug << "# sysOrderId:       " << ans.sysOrderId;

}

void OgsLogger::lockLessLog(ogs::CancelOrderQry &qry) const
{
    ogsDebug << "#--[CancelOrderQry]----------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# innerCode:        " << qry.innerCode;
    ogsDebug << "# custOrderId:      " << qry.custOrderId;
    ogsDebug << "# sysOrderId:       " << qry.sysOrderId;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::CancelOrderAns &ans) const
{
    ogsDebug << "#--[CancelOrderAns]----------------------------";
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# custOrderId:      " << ans.custOrderId;
    ogsDebug << "# sysOrderId:       " << ans.sysOrderId;

}

void OgsLogger::lockLessLog(ogs::QueryOrderQry &qry) const
{
    ogsDebug << "#--[QueryOrderQry]-----------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# innerCode:        " << qry.innerCode;
    ogsDebug << "# directive:        " << qry.directive;
    ogsDebug << "# execution:        " << qry.execution;
    ogsDebug << "# custOrderId:      " << qry.custOrderId;
    ogsDebug << "# sysOrderId:       " << qry.sysOrderId;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::QueryOrderAns &ans) const
{
    ogsDebug << "#--[QueryOrderAns]-----------------------------";
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# custOrderId:      " << ans.custOrderId;
    ogsDebug << "# sysOrderId:       " << ans.sysOrderId;
    ogsDebug << "# price:            " << ans.price;
    ogsDebug << "# volume:           " << ans.volume;
    ogsDebug << "# orderStatus:      " << ans.orderStatus;
    ogsDebug << "# dealVolume:       " << ans.dealVolume;
    ogsDebug << "# dealBanlance:     " << ans.dealBalance;
    ogsDebug << "# dealPrice:        " << ans.dealPrice;
    ogsDebug << "# innerCode:        " << ans.innerCode;
    ogsDebug << "# withdrawVolume:   " << ans.withdrawVolume;
    ogsDebug << "# directive:        " << ans.directive;
    ogsDebug << "# tradeDate:        " << ans.tradeDate;
    ogsDebug << "# orderTime:        " << ans.orderTime;

}

void OgsLogger::lockLessLog(ogs::QueryBargainQry &qry) const
{
    ogsDebug << "#--[QueryBargainQry]---------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# innerCode:        " << qry.innerCode;
    ogsDebug << "# custOrderId:      " << qry.custOrderId;
    ogsDebug << "# sysOrderId:       " << qry.sysOrderId;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::QueryBargainAns &ans) const
{
    ogsDebug << "#--[QueryBargainAns]---------------------------";
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# custOrderId:      " << ans.custOrderId;
    ogsDebug << "# sysOrderId:       " << ans.sysOrderId;
    ogsDebug << "# innerCode:        " << ans.innerCode;
    ogsDebug << "# dealId:           " << ans.dealId;
    ogsDebug << "# dealVolume:       " << ans.dealVolume;
    ogsDebug << "# dealBalance:      " << ans.dealBalance;
    ogsDebug << "# dealPrice:        " << ans.dealPrice;

}

void OgsLogger::lockLessLog(ogs::QueryFundInfoQry &qry) const
{
    ogsDebug << "#--[QueryFundInfoQry]--------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::QueryFundInfoAns &ans) const
{
    ogsDebug << "#--[QueryFundInfoAns]--------------------------";
    ogsDebug << "# acidcard:         " << ans.acidcard;
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# balance:          " << ans.balance;
    ogsDebug << "# useableBalance:   " << ans.useableBalance;
    ogsDebug << "# frozenBalance:    " << ans.frozenBalance;

}

void OgsLogger::lockLessLog(ogs::QueryPositionQry &qry) const
{
    ogsDebug << "#--[QueryPositionQry]--------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# innerCode:        " << qry.innerCode;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::QueryPositionAns &ans) const
{
    ogsDebug << "#--[QueryPositionAns]--------------------------";
    ogsDebug << "# acidcard:         " << ans.acidcard;
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# innerCode:        " << ans.innerCode;
    ogsDebug << "# currentVolume:    " << ans.currentVolume;
    ogsDebug << "# usableVolume:     " << ans.usableVolume;

}

void OgsLogger::lockLessLog(ogs::PaybackSecurityQry &qry) const
{
    ogsDebug << "#--[PaybackSecurityQry]------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# innerCode:        " << qry.innerCode;
    ogsDebug << "# repayVolume:      " << qry.repayVolume;
    ogsDebug << "# omsOrderId:       " << qry.omsOrderId;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::PaybackSecurityAns &ans) const
{
    ogsDebug << "#--[PaybackSecurityAns]------------------------";
    ogsDebug << "# acidcard:         " << ans.acidcard;
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# innerCode:        " << ans.innerCode;
    ogsDebug << "# omsOrderId:       " << ans.omsOrderId;
    ogsDebug << "# repayVolumeReal:  " << ans.repayVolumeReal;

}

void OgsLogger::lockLessLog(ogs::PaybackFundsQry &qry) const
{
    ogsDebug << "#--[PaybackFundsQry]---------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;
    ogsDebug << "# actype:           " << qry.actype;
    logPassword(qry.password);
    ogsDebug << "# repayAmt:         " << qry.repayAmt;
    ogsDebug << "# omsOrderId:       " << qry.omsOrderId;
    ogsDebug << "# ipAddr:           " << qry.ipAddr;
    ogsDebug << "# macAddr:          " << qry.macAddr;
    ogsDebug << "# diskSn:           " << qry.diskSn;

}

void OgsLogger::lockLessLog(ogs::PaybackFundsAns &ans) const
{
    ogsDebug << "#--[PaybackFundsAns]---------------------------";
    ogsDebug << "# acidcard:         " << ans.acidcard;
    ogsDebug << "# bacid:            " << ans.bacid;
    ogsDebug << "# omsOrderId:       " << ans.omsOrderId;
    ogsDebug << "# repayAmtReal:     " << ans.repayAmtReal;

}

void OgsLogger::lockLessLog(ogs::HeartBeatQry &qry) const
{
    ogsDebug << "#--[HeartBeatQry]------------------------------";
    ogsDebug << "# acidcard:         " << qry.acidcard;
    ogsDebug << "# bacid:            " << qry.bacid;

}

void OgsLogger::lockLessLog(ogs::HeartBeatAns &ans) const
{
    ogsDebug << "#--[HeartBeatAns]------------------------------";
    ogsDebug << "# sysStatus:        " << ans.sysStatus;
    ogsDebug << "# sysDate:          " << ans.sysDate;
    ogsDebug << "# sysTime:          " << ans.sysTime;

}

OgsLogger &OgsLogger::operator <<(OgsMessage &msg)
{
    LOCK_OGSLOGGER(*this);
    ogsDebug << "###[OgsMessage]################################";
    ogsDebug << "# msgType:          " << OgsLogger::msgType(msg.type());
    if (msg.isCorrupted()) {

        ogsDebug << "# isCorrupted:      true";
        ogsDebug << "# errorInfo:        " << msg.error();
        ogsDebug << "###############################################";
        return (*this);
    }
    qtp::session_id_t session;
    uint32_t errorCode;
    std::string errMsg;
    ogsDebug << "# itemCount:        " <<  msg.itemCount();
    ogsDebug << "# session:          " << (msg.session(session) ? std::to_string(session) : "[NULL]");
    ogsDebug << "# errorCode:        " << (msg.errorCode(errorCode) ? OgsLogger::errorCode(errorCode) : "[NULL]");
    ogsDebug << "# errorMsg:         " << (msg.errorMsg(errMsg) ? errMsg : "[NULL]");

    switch (msg.type()) {
    case ogs::kMtLogin:                 logOgsMessageItems<ogs::LoginQry>(msg);             break;
    case ogs::kMtSendOrder:             logOgsMessageItems<ogs::SendOrderQry>(msg);         break;
    case ogs::kMtCancelOrder:           logOgsMessageItems<ogs::CancelOrderQry>(msg);       break;
    case ogs::kMtQueryOrder:            logOgsMessageItems<ogs::QueryOrderQry>(msg);        break;
    case ogs::kMtQueryBargain:          logOgsMessageItems<ogs::QueryBargainQry>(msg);      break;
    case ogs::kMtQueryFundInfo:         logOgsMessageItems<ogs::QueryFundInfoQry>(msg);     break;
    case ogs::kMtQueryPosition:         logOgsMessageItems<ogs::QueryPositionQry>(msg);     break;
    case ogs::kMtHeartBeat:             logOgsMessageItems<ogs::HeartBeatQry>(msg);         break;
    case ogs::kMtLoginAns:              logOgsMessageItems<ogs::LoginAns>(msg);             break;
    case ogs::kMtSendOrderAns:          logOgsMessageItems<ogs::SendOrderAns>(msg);         break;
    case ogs::kMtCancelOrderAns:        logOgsMessageItems<ogs::CancelOrderAns>(msg);       break;
    case ogs::kMtQueryOrderAns:         logOgsMessageItems<ogs::QueryOrderAns>(msg);        break;
    case ogs::kMtQueryBargainAns:       logOgsMessageItems<ogs::QueryBargainAns>(msg);      break;
    case ogs::kMtQueryFundInfoAns:      logOgsMessageItems<ogs::QueryFundInfoAns>(msg);     break;
    case ogs::kMtQueryPositionAns:      logOgsMessageItems<ogs::QueryPositionAns>(msg);     break;
    case ogs::kMtHeartBeatAns:          logOgsMessageItems<ogs::HeartBeatAns>(msg);         break;
    case ogs::kMtQueryOrderSe:          logOgsMessageItems<ogs::QueryOrderQry>(msg);        break;
    case ogs::kMtQueryOrderSeAns:       logOgsMessageItems<ogs::QueryOrderAns>(msg);        break;
    case ogs::kMtPaybackSecurity:       logOgsMessageItems<ogs::PaybackSecurityQry>(msg);   break;
    case ogs::kMtPaybackSecurityAns:    logOgsMessageItems<ogs::PaybackSecurityAns>(msg);   break;
    case ogs::kMtPaybackFunds:          logOgsMessageItems<ogs::PaybackFundsQry>(msg);      break;
    case ogs::kMtPaybackFundsAns:       logOgsMessageItems<ogs::PaybackFundsAns>(msg);      break;
    }

    ogsDebug << "###############################################";
    return (*this);
}

std::string OgsLogger::msgType(uint32_t type)
{
    switch (type) {
    case ogs::kMtLogin:                 return "kMtLogin";
    case ogs::kMtSendOrder:             return "kMtSendOrder";
    case ogs::kMtCancelOrder:           return "kMtCancelOrder";
    case ogs::kMtQueryOrder:            return "kMtQueryOrder";
    case ogs::kMtQueryBargain:          return "kMtQueryBargain";
    case ogs::kMtQueryFundInfo:         return "kMtQueryFundInfo";
    case ogs::kMtQueryPosition:         return "kMtQueryPosition";
    case ogs::kMtHeartBeat:             return "kMtHeartBeat";
    case ogs::kMtLoginAns:              return "kMtLoginAns";
    case ogs::kMtSendOrderAns:          return "kMtSendOrderAns";
    case ogs::kMtCancelOrderAns:        return "kMtCancelOrderAns";
    case ogs::kMtQueryOrderAns:         return "kMtQueryOrderAns";
    case ogs::kMtQueryBargainAns:       return "kMtQueryBargainAns";
    case ogs::kMtQueryFundInfoAns:      return "kMtQueryFundInfoAns";
    case ogs::kMtQueryPositionAns:      return "kMtQueryPositionAns";
    case ogs::kMtHeartBeatAns:          return "kMtHeartBeatAns";
    case ogs::kMtErrorInfoAns:          return "kMtErrorInfoAns";
    case ogs::kMtQueryOrderSe:          return "kMtQueryOrderSe";
    case ogs::kMtQueryOrderSeAns:       return "kMtQueryOrderSeAns";
    case ogs::kMtPaybackSecurity:       return "kMtPaybackSecurity";
    case ogs::kMtPaybackSecurityAns:    return "kMtPaybackSecurityAns";
    case ogs::kMtPaybackFunds:          return "kMtPaybackFunds";
    case ogs::kMtPaybackFundsAns:       return "kMtPaybackFundsAns";
    case ogs::kMtOrderMgrTimer:         return "kMtOrderMgrTimer";
    case ogs::kMtHeartBeatTimer:        return "kMtHeartBeatTimer";
    case ogs::kMtHoldSessionTimer:      return "kMtHoldSessionTimer";
    case ogs::kMtRemoveSession:         return "kMtRemoveSession";
    default:                            return "[unknown message type]";
    }
}

std::string OgsLogger::errorCode(uint32_t code)
{
    switch(code) {
    case kIntfNotSupport:   return "kIntfNotSupport";
    case kIntfSuccess:      return "kIntfSuccess";
    case kIntfFail:         return "kIntfFail";
    case kIntfError:        return "kIntfError";
    case kIntfDisconnect:   return "kIntfDisconnect";
    case kIntfSendFail:     return "kIntfSendFail";
    case kIntfSendTimeOut:  return "kIntfSendTimeOut";
    case kIntfRecvFail:     return "kIntfRecvFail";
    case kIntfRecvTimeOut:  return "kIntfRecvTimeOut";
    case kIntfWorkFail:     return "kIntfWorkFail";
    default:                return "[unknown error code]";
    }
}

void OgsLogger::logPassword(const char *password) const
{
#ifdef OGSLOGGER_LOG_PLAIN_PASSWORD
    ogsDebug << "# password:         " << password;
#else
    OGS_UNUSED(password);
    ogsDebug << "# password:         " << "******";
#endif
}
