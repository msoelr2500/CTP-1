//
// Created by lwk on 16-6-1.
//

#ifndef OGS_MODULE_H
#define OGS_MODULE_H

#include <memory>
#include <string>
#include "Lock_Vector.h"
#include "OrderStage.h"
#include "ProxyStage.h"

namespace ogs {

    class ProxyStage;

    class Module {
    public:
        Module(std::string brokerType, uint32_t queueId, int threadCnt);

        ~Module();

        uint32_t getActiveStageId();

    private:
        std::shared_ptr<ProxyStage> m_ProxyStagePtr;
        LockVector<std::shared_ptr<qtp::QtpStage>> m_vStage;
        LockVector<std::shared_ptr<std::thread>> m_vThread;
        LockVector<uint32_t> m_vOrderStageId;
        uint32_t m_ActiveStage;

        static bool m_initSubFlag;
    };
}

#endif //OGS_MODULE_H
