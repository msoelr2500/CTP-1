//
// Created by lwk on 16-7-22.
//

#ifndef OGS_LOGPKG_H
#define OGS_LOGPKG_H

#include <string>

#include "OgsLogger.h"
#include "qtp_log.h"
#include "BufferHandle.h"
#include "DataStruct.h"

#define LOGPKG_LEVEL 300

namespace ogs {

    inline static void LogPkg(const std::string *buffer, const MessageType messageType) {
        BUF_HANDLE_COUNTTYPE cnt = 0;
        switch (messageType) {
            case kMtLogin: {
                UnpackBuffer<LoginQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(LoginQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtSendOrder: {
                UnpackBuffer<SendOrderQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(SendOrderQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtCancelOrder: {
                UnpackBuffer<CancelOrderQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(CancelOrderQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryOrderSe:
            case kMtQueryOrder: {
                UnpackBuffer<QueryOrderQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryOrderQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryBargain: {
                UnpackBuffer<QueryBargainQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryBargainQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryFundInfo: {
                UnpackBuffer<QueryFundInfoQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryFundInfoQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryPosition: {
                UnpackBuffer<QueryPositionQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryPositionQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtHeartBeat: {
                UnpackBuffer<HeartBeatQry> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(HeartBeatQry))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtLoginAns: {
                UnpackBuffer<LoginAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(LoginAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtSendOrderAns: {
                UnpackBuffer<SendOrderAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(SendOrderAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtCancelOrderAns: {
                UnpackBuffer<CancelOrderAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(CancelOrderAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryOrderSeAns:
            case kMtQueryOrderAns: {
                UnpackBuffer<QueryOrderAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryOrderAns))) {
                    VLOG(LOGPKG_LEVEL) << "buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryBargainAns: {
                UnpackBuffer<QueryBargainAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryBargainAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryFundInfoAns: {
                UnpackBuffer<QueryFundInfoAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryFundInfoAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtQueryPositionAns: {
                UnpackBuffer<QueryPositionAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(QueryPositionAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtHeartBeatAns: {
                UnpackBuffer<HeartBeatAns> unpackBuffer(buffer);
                cnt = unpackBuffer.GetDataCount();
                if (buffer->length() != (sizeof(BUF_HANDLE_COUNTTYPE) + cnt * sizeof(HeartBeatAns))) {
                    VLOG(LOGPKG_LEVEL)<<"buffer size error.";
                    return;
                }
                unpackBuffer.First();
                for (BUF_HANDLE_COUNTTYPE i = 0; i < cnt; ++i) {
                    ogsLogger() << *unpackBuffer.GetDataObjPtr();
                    unpackBuffer.Next();
                }
                break;
            }
            case kMtErrorInfoAns: {
                break;
            }
        }
    }

}

#endif //OGS_LOGPKG_H
