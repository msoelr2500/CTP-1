#include "Factory.h"
#include "ReadConfig.h"

namespace ogs {

    Factory::Factory() {

    }

    Factory::~Factory() {
    }

    void  Factory::init(int argc, char *argv[]) {
        ReadConfig readConfig;
        readConfig.Reading(argc, argv);
        if (strcmp(ReadConfig::localOption.LibPath.c_str(), "") == 0) {
            LOG(error) << "[Factory] LibPath in config file is empty, shutdown ogs-server.";
            std::cerr << "\033[31m[OrderStage] [Factory] LibPath in config file is empty, shutdown ogs-server!\033[0m" << std::endl;
            exit(0);
        }
        LoadInterafceLib(ReadConfig::localOption.LibPath.c_str());

		Fn_LogLibVersion();

        switch(ReadConfig::localOption.LogLevel){
            case 0:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kTrace);
                break;
            case 1:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kDebug);
                break;
            case 2:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kInfo);
                break;
            case 3:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kNotice);
                break;
            case 4:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kWarn);
                break;
            case 5:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kError);
                break;
            case 6:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kCritical);
                break;
            case 7:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kAlert);
                break;
            case 8:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kEmerg);
                break;
            default:
                qtp::QtpLog::SetLevel(qtp::QtpLog::kInfo);
                break;
        }
        qtp::QtpLog::SetVerbose(ReadConfig::localOption.LogVerbose);
        if(ReadConfig::localOption.LogDir != "")
        {
            // 调试的时候，可以设为空，这样就调试信息就直接打在屏幕上，方便调试
            qtp::QtpLog::Create("ogs", ReadConfig::localOption.LogDir);
        }
        qtp::QtpLog::SetPatten("[%H:%M:%S.%e] [%l] %v");

        std::string version_str = GET_VERSION_STR(ogs);
        LOG(info) << "ogs version:" << version_str;
        Fn_LogLibVersion();

        m_ogsServerPtr = new OgsServer(this);
        m_repStagePtr = new RepStage(this);
        m_orderMgrStagePtr = new OrderMgrStage(this);
        m_sysMgrStagePtr = new SysMgrStage();
        m_manager.Init();
        m_manager.MakeNotifiable();
    }

    void  Factory::runRecvThr() {
        struct sockaddr_in sin = {0};
        sin.sin_family = AF_INET;
        sin.sin_port = htons(ReadConfig::localOption.LocalPort);
        sin.sin_addr.s_addr = inet_addr(ReadConfig::localOption.LocalAddr.c_str());
        m_manager.AddMember(m_ogsServerPtr);
        if (m_ogsServerPtr->Bind((sockaddr *) &sin, sizeof(sin)) != 0) {
            LOG(error) << ReadConfig::localOption.LocalAddr << " " << ReadConfig::localOption.LocalPort <<
            " bind fail!";
            return;
        }
        LOG(info) << ReadConfig::localOption.LocalAddr << " " << ReadConfig::localOption.LocalPort << " bind success!";

        // 注册定时器
        // kOrderMgrTimerId定时器超时事件主要在OrderMgrStage中触发查单。
        timeval timeValRG;
        timeValRG.tv_sec = ReadConfig::localOption.RequestGap / 1000;
        timeValRG.tv_usec = (ReadConfig::localOption.RequestGap % 1000) * 1000;
        m_ogsServerPtr->AddTimeout(kOrderMgrTimerId, timeValRG);

        // kHeartBeatTimerId定时器超时事件主要在所有的OrderStage中触发心跳。OrderStage一般借由Module由ProxyStage管
        // 理。目前主要有两个ProxyStage，即kTaskOrderStageProxyID和kReqOrderStageProxyID标识的ProxyStage。
        timeval timeValHB;
        timeValHB.tv_sec = ReadConfig::localOption.HeartBeatGap / 1000;
        timeValHB.tv_usec = (ReadConfig::localOption.HeartBeatGap % 1000) * 1000;
        m_ogsServerPtr->AddTimeout(kHeartBeatTimerId, timeValHB);

        timeval timeValHS;
        timeValHS.tv_sec = ReadConfig::localOption.HoldSessionGap / 2;
        timeValHS.tv_usec = 0;
        m_ogsServerPtr->AddTimeout(kHoldSessionTimerId, timeValHS);
    }

    void Factory::runRepThr() {
        m_repStagePtr->set_queue(qtp::QtpQueueMgr::Instance().CeateQueue(kRepStageID));
        std::shared_ptr<std::thread> repStage_thread(new std::thread([&]() { m_repStagePtr->Run(); }));
        m_vThread.push_back(repStage_thread);
    }

    /*!
     * \brief 创建一个用于管理订单的OrderMgrStage。OrderMgrStage主要负责订单管理，在下单时保存订单信息，并在请求查单时负责查询。
     */
    void Factory::orderMgrModule() {
        m_orderMgrStagePtr->set_queue(qtp::QtpQueueMgr::Instance().CeateQueue(kOrderMgrStageID));
        std::shared_ptr<std::thread> orderMgrStage_thread(new std::thread([&]() { m_orderMgrStagePtr->Run(); }));
        m_vThread.push_back(orderMgrStage_thread);
    }

    /*!
     * \brief 创建一个用于处理来自OMS模块的心跳消息的SysMgrStage。
     */
    void Factory::sysMgrModule() {
        m_sysMgrStagePtr->set_queue(qtp::QtpQueueMgr::Instance().CeateQueue(kSysMgrStageID));
        std::shared_ptr<std::thread> sysMgrStage_thread(new std::thread([&]() { m_sysMgrStagePtr->Run(); }));
        m_vThread.push_back(sysMgrStage_thread);
    }

    void  Factory::start() {
        std::shared_ptr<std::thread> manager_thread(new std::thread([&]() { m_manager.Start(); }));
        m_vThread.push_back(manager_thread);
    }

    /*!
     * \brief 创建一个用于处理一般业务（登陆，下单，撤单，除查单外的一般数据查询等）的ProxyStage，由OgsServer使用。
     */
    void Factory::taskOrderStageModule() {
        std::shared_ptr<Module> module(new Module(ReadConfig::localOption.BrokerType, kTaskOrderStageProxyID,
                                                  ReadConfig::localOption.TaskThreadCnt));
        m_vModule.push_back(module);
    }

    /*!
     * \brief 创建一个负责查单的ProxyStage，其查单操作由OrderMgrStage在收到kMtOrderMgrTimer定时器事件时发起。
     *
     * 当ProxyStage把查单请求提交给OrderStage后，OrderStage先从券商接口查单，然后把查单结果发送给OrderMgrStage。
     * OrderMgrStage通过某种策略处理查单结果得到最终结果，并借由RepStage发送给ogs客户端完成整个查单过程。
     */
    void Factory::reqOrderStageModule() {
        std::shared_ptr<Module> module(new Module(ReadConfig::localOption.BrokerType, kReqOrderStageProxyID,
                                                  ReadConfig::localOption.ReqThreadCnt));
        m_vModule.push_back(module);
    }

    void Factory::join() {
        for (int i = 0; i < m_vThread.size(); ++i) {
            m_vThread[i]->join();
        }
    }

    OgsServer *Factory::GetOgsServerPtr() {
        return m_ogsServerPtr;
    }


}
