## OGS3.0 订单网关系统开发指南 ##
目的：简要介绍OGS3.0，帮助新接手的OGS系统开发的人快速上手
#### 开发环境搭建 ####
请安装[Git](https://git-scm.com/download/win "Git 下载链接")，搭建好Git环境，并联系张文获取Git的OGS3.0方面的权限。
* 项目Gitlab地址：https://gitlab.isonsystem.cn:1443/TradingPlatform/ogs3
* 项目Git地址：git@gitlab.isonsystem.cn:TradingPlatform/ogs3.git
* 开发分支：develop
* 开发环境：Ubuntu 14.04 64位
* 开发工具：[Qt Creator](https://www.qt.io/download-open-source/#section-2 "Qt Creator 下载链接")

#### ToDo List ####
- [ ] **Bug修复**
    - [ ] 定时查单，为了保证将订单写入RocksDB，强制写一次数据库，导致往前台推送一次
	- [ ] 量化一次发送几百个订单，券商那边成交，但是OGS通过接口查询，过了四五分钟才返回成交状态
	- [ ] 将OrderStage里面的宏使用函数替代
	- [ ] 定时查询订单，没有站点信息留痕
#### 目录结构 ####
将OGS3.0的代码clone下来之后，主要文件结构如下（待更新）：
```
OGS3/
├── README.md
├── OGS3.pro
├── deps/
│   └── linux64/
│       ├── inc/
|       │   ├── glog/
|       │   ├── ibcpp/
|       │   ├── rapidjson/
|       │   └── YouIncludeFile/
│       └── lib/
|           ├── libczmq.so.1
|           ├── libgcc_s.so.1
|           ├── libglog.so.0 ...
|           └── YouLibFile/
├── doc/
│   ├── ison_config.json
│   └── YouDocFile/
└── src/
```
有些文件或目录要单独介绍一下，以后增加文件，加到对应的目录下面：
1. README.md：项目介绍文件。
2. OGS3.pro：项目文件，请使用QtCreator打开。
3. deps：项目依赖的头文件跟库。下面的Linux64，指的只Linux下面，64位需要的库。因为目前只在Linux下面开发，所以只有这个文件夹。如果要在window开发环境下面，请以win32，win64进行分类。下面的`inc/`文件夹，放需要包含的头文件。`lib/`文件夹，放需要的库文件。其中有两个文件要说明一下。**YouIncludeFile** 指的是你额外需要加进来的包含文件，建议以你的分支命名。如你的分支是kams，那么就新建一个kams的文件夹，将券商提供的头文件放进去。其中 **YouLibFile** 也是类似，这个文件夹用来存放你额外需要的库文件。
4. doc：存放资料文件。其中 ison_config.json 为ogs的配置文件。

#### 如何开始一个新的OGS代码编写 ####
假设要新开发一个新的 *kams* 为例。注意：下面的目录，均以此文件为当前目录。
1. 安装依赖的库文件：bzip2-1.0.6， snappy-1.1.0libz(`sudo apt-get install libsnappy-dev`
)， libz(`sudo apt-get install libz-dev`
)。Rocksdb(`sudo apt-get install libbz2-dev` `sudo make install-shared`)
2. 使用QtCreator打开项目：File->Open File Or Project...->CMakeLists.txt。然后一路点下一步。
3. 在include下面创建一个kams目录，存放券商提供的头文件。
4. 在lib下面创建一个kams目录，存放券商提供的库文件。
5. 在src下面有一个template文件夹，可以以此为蓝本创建新的OGS。建议将此文件夹拷贝出来(主要是怕替换的时候将这个模板文件夹里面的文件替换掉了)。首先将文件夹的名字修改成kams。**注意使用匹配大小写的模式**，将里面所有文件里面的TEMPLATE替换成KAMS，将Template替换成Kams，将template替换成kams。然后将文件TemplateXXXXX.h跟TemplateXXXXX.cpp替换成KamsXXXXX.h跟KamsXXXXX.cpp。然后更新里面的CMakeLists.txt文件，将所需要的库加到target_link_libraries配置里面。将刚刚更新好的文件，拷贝到template同级目录。
6. 更新src/CMakeLists.txt文件，将刚刚改好的kams目录加到文件里面，即`add_subdirectory(kams)`
7. 此时，进行编译，应该在bin目录下面会生成一个ogs-server可执行文件，在lib目录下面会生成一个libkams.so库文件。
8. 在ogs-server可执行文件当前目录，拷贝一个ogs.ini文件，将LibPath选项更新为刚生成的库文件目录，即`../lib/libkams.so`，此时，ogs-server就会加载运行该库文件了。

#### OGS 调试开发指南 ####
1. 如何在调试模式下面单步调试库。需要设置一下QtCreator。Tools -> Options -> Debugger -> GDB -> Additional Startup Commands加入如下命令：`set solib-search-path /home/lcq/Code/ogs3/lib`。注意将/home/lcq/Code/ogs3/lib改为你自己的lib目录。

#### 一些问题记录 ####






































































































end
